/**
 * backend/api/_admin/promocodes.js
 *
 * Super-Admin Promo Code Management.
 * Pure PostgreSQL via _lib/db.js. Zero Supabase.
 */

import { verifyPermission, logAdminAction } from '../_lib/auth.js';
import { setCorsHeaders } from '../_lib/cors.js';
import { query } from '../_lib/db.js';

export default async function promocodesHandler(req, res) {
    setCorsHeaders(req, res, 'GET, POST, OPTIONS');
    if (req.method === 'OPTIONS') return res.status(200).end();

    const access = await verifyPermission(req, 'all_access');
    if (!access.success) return res.status(access.status).json({ error: access.error });

    const { action } = req.query;

    try {
        if (req.method === 'GET' && action === 'list') {
            const { rows } = await query(
                'SELECT * FROM promo_codes ORDER BY created_at DESC'
            );
            return res.status(200).json(rows);
        }

        if (req.method === 'POST') {
            const body = req.body || {};

            if (action === 'create') {
                const { code, amount, max_uses, require_deposit } = body;
                if (!code || typeof amount !== 'number' || typeof max_uses !== 'number') {
                    return res.status(400).json({ error: 'code, amount, and max_uses are required.' });
                }

                try {
                    const { rows } = await query(
                        `INSERT INTO promo_codes (code, amount, max_uses, current_uses, require_deposit)
                         VALUES ($1, $2, $3, 0, $4)
                         RETURNING *`,
                        [code.trim().toUpperCase(), amount, max_uses, !!require_deposit]
                    );

                    const created = rows[0];
                    await logAdminAction(access.user.id, 'CREATE_PROMO_CODE', created.id, { code: created.code, amount });
                    return res.status(200).json({ success: true, promocode: created });
                } catch (insertErr) {
                    if (insertErr.code === '23505') {
                        return res.status(400).json({ error: 'Promo code already exists. Please choose a unique code.' });
                    }
                    throw insertErr;
                }
            }

            if (action === 'delete') {
                const { id } = body;
                if (!id) return res.status(400).json({ error: 'id is required' });

                await query('DELETE FROM promo_codes WHERE id = $1', [id]);
                await logAdminAction(access.user.id, 'DELETE_PROMO_CODE', id, {});
                return res.status(200).json({ success: true });
            }
        }

        return res.status(400).json({ error: `Unsupported action: ${action}` });
    } catch (e) {
        console.error('[Promo Code Admin Error]:', e);
        return res.status(500).json({ error: e.message });
    }
}
