/**
 * pwaManager.js - MetricWin PWA & Web Push Notification Manager
 * Handles Service Worker registration, native install prompts (Android/Desktop/iOS),
 * and Web Push Notification permissions.
 */

let deferredInstallPrompt = null;

/**
 * Register Service Worker at root scope
 */
export async function registerServiceWorker() {
    if ('serviceWorker' in navigator) {
        try {
            const reg = await navigator.serviceWorker.register('/sw.js', { scope: '/' });
            console.log('[PWA] Service Worker registered successfully:', reg.scope);
            return reg;
        } catch (err) {
            console.warn('[PWA] Service Worker registration failed:', err.message);
        }
    }
    return null;
}

/**
 * Update topbar Install App button visibility depending on standalone status & install state
 */
export function updateInstallButtonVisibility() {
    const btn = document.getElementById('installAppHeaderBtn');
    if (!btn) return;

    const isStandalone = window.navigator.standalone || 
                         (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) ||
                         localStorage.getItem('pwa_installed') === 'true';

    if (isStandalone) {
        btn.style.display = 'none';
    } else {
        btn.style.display = 'inline-flex';
    }
}

/**
 * Initialize PWA install prompt handler & render install UI
 */
export function initPwaInstaller() {
    // 0. Check and hide topbar install button if already installed
    updateInstallButtonVisibility();

    if (window.matchMedia) {
        window.matchMedia('(display-mode: standalone)').addEventListener('change', (e) => {
            if (e.matches) {
                localStorage.setItem('pwa_installed', 'true');
            }
            updateInstallButtonVisibility();
        });
    }

    // 1. Capture Chrome/Android/Desktop beforeinstallprompt event
    window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        deferredInstallPrompt = e;
        updateInstallButtonVisibility();
        console.log('[PWA] Native install prompt captured & ready.');
    });

    // 2. Detect iOS Safari standalone state
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    const isStandalone = window.navigator.standalone || (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches);

    if (isIOS && !isStandalone && !localStorage.getItem('pwa_installed')) {
        // Show iOS Add to Home Screen instructions after 3 seconds
        setTimeout(() => {
            if (!localStorage.getItem('pwa_ios_dismissed')) {
                showInstallBanner(true); // iOS mode
            }
        }, 3000);
    }

    // 3. Track appinstalled event
    window.addEventListener('appinstalled', () => {
        console.log('[PWA] MetricWin app installed successfully!');
        localStorage.setItem('pwa_installed', 'true');
        deferredInstallPrompt = null;
        hideInstallBanner();
        hideInstallInstructionModal();
        updateInstallButtonVisibility();
    });
}

/**
 * Trigger PWA Install flow when user clicks topbar Install button
 */
export async function triggerPwaInstall() {
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    const isStandalone = window.navigator.standalone || 
                         (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) ||
                         localStorage.getItem('pwa_installed') === 'true';

    if (isStandalone) {
        updateInstallButtonVisibility();
        if (window.showToast) window.showToast('MetricWin App is already installed and running!', 'info');
        else alert('MetricWin App is already installed!');
        return;
    }

    // 1. If native prompt event was captured, fire native prompt immediately
    if (deferredInstallPrompt) {
        try {
            deferredInstallPrompt.prompt();
            const { outcome } = await deferredInstallPrompt.userChoice;
            console.log(`[PWA] Install prompt outcome: ${outcome}`);
            deferredInstallPrompt = null;
            hideInstallBanner();
            if (outcome === 'accepted') {
                localStorage.setItem('pwa_installed', 'true');
                updateInstallButtonVisibility();
                if (window.showToast) window.showToast('MetricWin App installation started!', 'success');
            }
            return;
        } catch (err) {
            console.warn('[PWA] Error triggering native install prompt:', err);
        }
    }

    // 2. iOS Devices fallback instructions
    if (isIOS) {
        showInstallInstructionModal('ios');
        return;
    }

    // 3. Android / Desktop fallback instructions when beforeinstallprompt hasn't buffered
    showInstallInstructionModal('android');
}

/**
 * Render sleek floating PWA Install Banner at bottom
 */
function showInstallBanner(isIOS = false) {
    if (document.getElementById('pwaInstallBanner')) return;

    const banner = document.createElement('div');
    banner.id = 'pwaInstallBanner';
    banner.style.cssText = `
        position: fixed;
        bottom: 16px;
        left: 50%;
        transform: translateX(-50%);
        width: calc(100% - 32px);
        max-width: 440px;
        background: linear-gradient(135deg, rgba(15, 23, 42, 0.96), rgba(30, 41, 59, 0.98));
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        border: 1px solid rgba(56, 189, 248, 0.3);
        border-radius: 14px;
        padding: 12px 16px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.5), 0 0 20px rgba(56, 189, 248, 0.2);
        z-index: 9999;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        color: #fff;
        font-family: inherit;
        animation: pwaBannerSlideUp 0.35s cubic-bezier(0.16, 1, 0.3, 1);
    `;

    banner.innerHTML = `
        <div style="display:flex; align-items:center; gap:10px;">
            <img src="/logo.svg" alt="MetricWin" style="width:36px; height:36px; border-radius:8px;">
            <div>
                <div style="font-weight:700; font-size:0.85rem; color:#f8fafc;">Install MetricWin App ✈️</div>
                <div style="font-size:0.72rem; color:#94a3b8;">${isIOS ? 'Tap Share ⎋ & Add to Home Screen' : 'Instant access & push notifications'}</div>
            </div>
        </div>
        <div style="display:flex; align-items:center; gap:6px;">
            <button id="pwaInstallActionBtn" style="background:linear-gradient(135deg, #38bdf8, #0284c7); border:none; border-radius:8px; padding:6px 12px; font-weight:700; font-size:0.75rem; color:#fff; cursor:pointer; box-shadow:0 0 10px rgba(56, 189, 248, 0.4);">INSTALL</button>
            <button id="pwaDismissBtn" style="background:transparent; border:none; color:#64748b; font-size:1.1rem; cursor:pointer; padding:4px;">✕</button>
        </div>
    `;

    document.body.appendChild(banner);

    const dismissBtn = document.getElementById('pwaDismissBtn');
    if (dismissBtn) {
        dismissBtn.onclick = () => {
            hideInstallBanner();
            if (isIOS) localStorage.setItem('pwa_ios_dismissed', 'true');
        };
    }

    const actionBtn = document.getElementById('pwaInstallActionBtn');
    if (actionBtn) {
        actionBtn.onclick = () => triggerPwaInstall();
    }
}

function hideInstallBanner() {
    const banner = document.getElementById('pwaInstallBanner');
    if (banner) {
        banner.style.opacity = '0';
        banner.style.transform = 'translateX(-50%) translateY(20px)';
        banner.style.transition = 'all 0.25s ease';
        setTimeout(() => banner.remove(), 250);
    }
}

/**
 * Display interactive step-by-step install guide modal for phones when native prompt isn't buffered
 */
function showInstallInstructionModal(platform = 'android') {
    hideInstallInstructionModal();

    const isIOS = platform === 'ios';
    const modal = document.createElement('div');
    modal.id = 'pwaInstructionModal';
    modal.style.cssText = `
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.75);
        backdrop-filter: blur(8px);
        -webkit-backdrop-filter: blur(8px);
        z-index: 10000;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 16px;
        animation: fadeIn 0.2s ease;
    `;

    modal.innerHTML = `
        <div style="
            background: #0f172a;
            border: 1px solid rgba(56, 189, 248, 0.3);
            border-radius: 20px;
            padding: 24px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 20px 50px rgba(0,0,0,0.8), 0 0 30px rgba(56, 189, 248, 0.15);
            color: #f8fafc;
            text-align: center;
            position: relative;
        ">
            <button id="closePwaModalBtn" style="
                position: absolute;
                top: 14px;
                right: 14px;
                background: rgba(255,255,255,0.08);
                border: none;
                color: #94a3b8;
                width: 28px;
                height: 28px;
                border-radius: 50%;
                font-size: 1rem;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
            ">✕</button>

            <img src="/logo.svg" alt="MetricWin" style="width: 56px; height: 56px; margin: 0 auto 12px; border-radius: 12px; box-shadow: 0 4px 16px rgba(0,0,0,0.4);">
            
            <h3 style="font-size: 1.15rem; font-weight: 800; margin: 0 0 6px; color: #fff;">Install MetricWin App</h3>
            <p style="font-size: 0.78rem; color: #94a3b8; margin: 0 0 18px;">Add MetricWin directly to your phone home screen for instant access.</p>

            ${isIOS ? `
                <div style="background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08); border-radius: 12px; padding: 14px; text-align: left; font-size: 0.82rem; display: flex; flex-direction: column; gap: 10px;">
                    <div style="display:flex; align-items:center; gap:10px;">
                        <span style="background:#38bdf8; color:#0f172a; font-weight:800; border-radius:50%; width:22px; height:22px; display:inline-flex; align-items:center; justify-content:center; flex-shrink:0;">1</span>
                        <span>Tap the <strong>Share button (⎋)</strong> at the bottom of Safari.</span>
                    </div>
                    <div style="display:flex; align-items:center; gap:10px;">
                        <span style="background:#38bdf8; color:#0f172a; font-weight:800; border-radius:50%; width:22px; height:22px; display:inline-flex; align-items:center; justify-content:center; flex-shrink:0;">2</span>
                        <span>Scroll down and select <strong>"Add to Home Screen (+)"</strong>.</span>
                    </div>
                    <div style="display:flex; align-items:center; gap:10px;">
                        <span style="background:#38bdf8; color:#0f172a; font-weight:800; border-radius:50%; width:22px; height:22px; display:inline-flex; align-items:center; justify-content:center; flex-shrink:0;">3</span>
                        <span>Tap <strong>Add</strong> in the top right corner.</span>
                    </div>
                </div>
            ` : `
                <div style="background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08); border-radius: 12px; padding: 14px; text-align: left; font-size: 0.82rem; display: flex; flex-direction: column; gap: 10px;">
                    <div style="display:flex; align-items:center; gap:10px;">
                        <span style="background:#38bdf8; color:#0f172a; font-weight:800; border-radius:50%; width:22px; height:22px; display:inline-flex; align-items:center; justify-content:center; flex-shrink:0;">1</span>
                        <span>Tap the <strong>3 dots menu (⋮)</strong> in your browser top right.</span>
                    </div>
                    <div style="display:flex; align-items:center; gap:10px;">
                        <span style="background:#38bdf8; color:#0f172a; font-weight:800; border-radius:50%; width:22px; height:22px; display:inline-flex; align-items:center; justify-content:center; flex-shrink:0;">2</span>
                        <span>Select <strong>"Install App"</strong> or <strong>"Add to Home screen"</strong>.</span>
                    </div>
                    <div style="display:flex; align-items:center; gap:10px; font-size:0.75rem; color:#64748b; margin-top:4px;">
                        <span>💡 <em>If opened inside TikTok/WhatsApp/Instagram, tap 3 dots & select "Open in Chrome".</em></span>
                    </div>
                </div>
            `}

            <button id="gotItPwaBtn" style="
                width: 100%;
                margin-top: 18px;
                background: linear-gradient(135deg, #38bdf8, #0284c7);
                border: none;
                border-radius: 10px;
                padding: 10px;
                font-weight: 700;
                font-size: 0.88rem;
                color: #fff;
                cursor: pointer;
                box-shadow: 0 4px 14px rgba(56, 189, 248, 0.4);
            ">Got it!</button>
        </div>
    `;

    document.body.appendChild(modal);

    const closeBtn = document.getElementById('closePwaModalBtn');
    const gotItBtn = document.getElementById('gotItPwaBtn');

    if (closeBtn) closeBtn.onclick = hideInstallInstructionModal;
    if (gotItBtn) gotItBtn.onclick = hideInstallInstructionModal;
    modal.onclick = (e) => {
        if (e.target === modal) hideInstallInstructionModal();
    };
}

function hideInstallInstructionModal() {
    const modal = document.getElementById('pwaInstructionModal');
    if (modal) modal.remove();
}

/**
 * Request Push Notification Permission
 */
export async function requestPushPermission() {
    if (!('Notification' in window)) {
        alert('Web Push Notifications are not supported by your browser.');
        return false;
    }

    if (Notification.permission === 'granted') {
        return true;
    }

    const permission = await Notification.requestPermission();
    if (permission === 'granted') {
        console.log('[PWA] Web Push Notification permission granted.');
        return true;
    } else {
        console.warn('[PWA] Push notification permission denied.');
        return false;
    }
}

/**
 * Trigger a test Web Push Notification locally
 */
export async function triggerTestPushNotification() {
    const granted = await requestPushPermission();
    if (!granted) return;

    if ('serviceWorker' in navigator) {
        const reg = await navigator.serviceWorker.ready;
        reg.showNotification('MetricWin Alert ✈️', {
            body: 'Push Notifications active! You will receive instant alerts for withdrawals, referral rewards & promos.',
            icon: '/logo.svg',
            badge: '/logo.svg',
            vibrate: [100, 50, 100],
            data: { url: '/account#referrals' }
        });
    }
}
