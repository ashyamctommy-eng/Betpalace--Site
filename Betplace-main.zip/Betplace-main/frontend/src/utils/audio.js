/**
 * Audio Sound Manager
 */

export function initAudio() {}
export function toggleMute() {}
export function playTone() {}
export function playSoundBetPlaced() {}
export function playSoundCashOut() {}
export function playSoundExplosion() {}
export function startEngineRumble() {}
export function stopEngineRumble() {}
export function startRisingTone() {}
export function stopRisingTone() {}
export function updateRisingToneFreq() {}

if (typeof window !== 'undefined') {
    window.initAudio = initAudio;
    window.toggleMute = toggleMute;
    window.playSoundBetPlaced = playSoundBetPlaced;
    window.playSoundCashOut = playSoundCashOut;
    window.playSoundExplosion = playSoundExplosion;
}
