/**
 * betStateMachine.js
 * Exposes deterministic FSM states and transitions for the Metricwins betting panels.
 */

export const BetState = {
    IDLE: 'IDLE',
    SUBMITTING: 'SUBMITTING',
    ACCEPTED: 'ACCEPTED',
    QUEUED_FOR_NEXT_ROUND: 'QUEUED_FOR_NEXT_ROUND',
    WAITING_FOR_ROUND: 'WAITING_FOR_ROUND',
    CANCELLING: 'CANCELLING',
    CANCELLED: 'CANCELLED',
    ROUND_ACTIVE: 'ROUND_ACTIVE',
    CASHING_OUT: 'CASHING_OUT',
    CASHED_OUT: 'CASHED_OUT',
    ROUND_FINISHED: 'ROUND_FINISHED',
    ERROR: 'ERROR'
};

const ALLOWED_TRANSITIONS = {
    [BetState.IDLE]: [BetState.SUBMITTING],
    [BetState.SUBMITTING]: [BetState.ACCEPTED, BetState.QUEUED_FOR_NEXT_ROUND, BetState.ERROR],
    [BetState.ACCEPTED]: [BetState.QUEUED_FOR_NEXT_ROUND, BetState.WAITING_FOR_ROUND, BetState.CANCELLING, BetState.ERROR],
    [BetState.QUEUED_FOR_NEXT_ROUND]: [BetState.WAITING_FOR_ROUND, BetState.CANCELLING, BetState.ERROR],
    [BetState.WAITING_FOR_ROUND]: [BetState.ROUND_ACTIVE, BetState.CANCELLING, BetState.ERROR],
    [BetState.CANCELLING]: [BetState.CANCELLED, BetState.WAITING_FOR_ROUND, BetState.QUEUED_FOR_NEXT_ROUND, BetState.ERROR],
    [BetState.CANCELLED]: [BetState.IDLE],
    [BetState.ROUND_ACTIVE]: [BetState.CASHING_OUT, BetState.ROUND_FINISHED, BetState.ERROR],
    [BetState.CASHING_OUT]: [BetState.CASHED_OUT, BetState.ROUND_ACTIVE, BetState.ERROR],
    [BetState.CASHED_OUT]: [BetState.ROUND_FINISHED, BetState.IDLE],
    [BetState.ROUND_FINISHED]: [BetState.IDLE],
    [BetState.ERROR]: [BetState.IDLE, BetState.SUBMITTING, BetState.ACCEPTED, BetState.WAITING_FOR_ROUND, BetState.ROUND_ACTIVE]
};

// Verbose FSM logging: only active in local development (Vite strips import.meta.env.DEV in prod)
// Can still be force-enabled in production via ?fsm_debug=true for support debugging sessions.
const isVerboseLogging = () => {
    if (typeof import.meta !== 'undefined' && import.meta.env) {
        // Vite build: DEV is true in `vite dev`, false in `vite build`
        if (import.meta.env.DEV) return true;
        // Allow opt-in override in production for debugging (e.g. support sessions)
        if (typeof window !== 'undefined' && window.location.search.includes('fsm_debug=true')) return true;
        return false;
    }
    // Node.js / test environment — always verbose
    if (typeof window !== 'undefined') {
        return window.fsmDebug === true || window.location.search.includes('fsm_debug=true');
    }
    return true;
};

export class BetStateMachine {
    constructor(panelId, onStateChangeCallback) {
        this.panelId = panelId;
        this.state = BetState.IDLE;
        this.onStateChange = onStateChangeCallback;
        
        // Metadata fields
        this.roundId = null;
        this.betId = null;
        this.timestamp = Date.now();
        this.transitionReason = 'Initialization';
        this.requestId = null;
        this.errorMsg = null;
        
        // Watchdog timer
        this.watchdogTimer = null;
        this.previousStateBeforePending = null;
    }

    /**
     * Attempts to transition to a new state with strict validation.
     */
    transitionTo(nextState, reason, metadata = {}) {
        const prevState = this.state;
        
        // Enforce transition validity
        const allowed = ALLOWED_TRANSITIONS[prevState] || [];
        if (!allowed.includes(nextState)) {
            console.error(`[FSM-Panel${this.panelId}] BLOCKED invalid state transition: "${prevState}" → "${nextState}". Reason: ${reason}`);
            return false;
        }

        // Clean up any existing watchdog
        this.clearWatchdog();

        // Calculate request processing latency if requestId matches
        let latency = null;
        if (metadata.requestId && metadata.requestStartTime) {
            latency = Date.now() - metadata.requestStartTime;
        }

        // Save previous valid state before entering a pending flow
        if ([BetState.SUBMITTING, BetState.CANCELLING, BetState.CASHING_OUT].includes(nextState)) {
            this.previousStateBeforePending = prevState;
        }

        // Apply metadata updates
        this.state = nextState;
        this.roundId = metadata.roundId !== undefined ? (metadata.roundId ? Number(metadata.roundId) : null) : this.roundId;
        this.betId = metadata.betId !== undefined ? metadata.betId : this.betId;
        this.requestId = metadata.requestId !== undefined ? metadata.requestId : this.requestId;
        this.errorMsg = metadata.errorMsg || null;
        this.transitionReason = reason;
        this.timestamp = Date.now();

        // Structured Logging Telemetry
        if (isVerboseLogging() || nextState === BetState.ERROR) {
            console.log(`[FSM-Panel${this.panelId}] [Telemetry] Transition:
  Prev State:     ${prevState}
  New State:      ${nextState}
  Reason:         ${reason}
  Round ID:       ${this.roundId}
  Bet ID:         ${this.betId}
  Request ID:     ${this.requestId}
  Timestamp:      ${this.timestamp}
  Latency:        ${latency ? `${latency}ms` : 'N/A'}
  Error Message:  ${this.errorMsg || 'None'}
`);
        }

        // Set up watchdog timer for pending states (prevent stuck loading UI on network drops)
        if ([BetState.SUBMITTING, BetState.CANCELLING, BetState.CASHING_OUT].includes(nextState)) {
            this.startWatchdog();
        }

        // Trigger callback to re-bind UI state
        if (typeof this.onStateChange === 'function') {
            this.onStateChange(this);
        }

        // Automatic recovery transitions
        if (nextState === BetState.CANCELLED) {
            // Cancelled automatically resets to IDLE
            setTimeout(() => {
                this.transitionTo(BetState.IDLE, 'Automatic cleanup after cancel confirmation');
            }, 10);
        } else if (nextState === BetState.ERROR) {
            // Error automatically recovers to IDLE after 4 seconds
            setTimeout(() => {
                if (this.state === BetState.ERROR) {
                    this.transitionTo(BetState.IDLE, 'Automatic recovery reset after error display timeout');
                }
            }, 4000);
        }

        return true;
    }

    startWatchdog() {
        this.clearWatchdog();
        const expectedState = this.state;
        this.watchdogTimer = setTimeout(() => {
            if (this.state !== expectedState) return;
            console.warn(`[FSM-Panel${this.panelId}] Watchdog triggered for pending state: "${this.state}". Request ID: ${this.requestId}`);
            
            this.transitionTo(BetState.ERROR, 'Transaction request timeout (watchdog)', {
                errorMsg: 'Network timeout. Please retry.'
            });
        }, 10000); // 10-second request watchdog
    }

    clearWatchdog() {
        if (this.watchdogTimer) {
            clearTimeout(this.watchdogTimer);
            this.watchdogTimer = null;
        }
    }

    reset(reason = 'Reset to IDLE') {
        this.clearWatchdog();
        this.state = BetState.IDLE;
        this.roundId = null;
        this.betId = null;
        this.requestId = null;
        this.errorMsg = null;
        this.transitionReason = reason;
        this.timestamp = Date.now();
        if (typeof this.onStateChange === 'function') {
            this.onStateChange(this);
        }
    }
}
