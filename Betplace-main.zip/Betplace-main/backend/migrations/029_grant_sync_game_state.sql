-- ═══════════════════════════════════════════════════════════════════
-- MIGRATION 029: Grant public / anon / authenticated access to sync_and_get_game_state
-- ═══════════════════════════════════════════════════════════════════

GRANT EXECUTE ON FUNCTION public.sync_and_get_game_state() TO public;
GRANT EXECUTE ON FUNCTION public.sync_and_get_game_state() TO anon;
GRANT EXECUTE ON FUNCTION public.sync_and_get_game_state() TO authenticated;
GRANT EXECUTE ON FUNCTION public.sync_and_get_game_state() TO service_role;

-- Ensure active_game_state table has SELECT granted to anon and authenticated
GRANT SELECT ON public.active_game_state TO anon, authenticated, public;

-- Ensure RLS on active_game_state permits SELECT for everyone
DROP POLICY IF EXISTS "Everyone can view game state" ON public.active_game_state;
CREATE POLICY "Everyone can view game state" ON public.active_game_state FOR SELECT USING (true);

NOTIFY pgrst, 'reload schema';
