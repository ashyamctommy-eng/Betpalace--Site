/**
 * gameBridge.js — Shared Authoritative Game State Bridge
 *
 * This is the SINGLE source of truth for all game state shared between:
 *   - main.js     (game logic, server sync, betting)
 *   - FlightScene (Phaser animation engine)
 *   - debugPanel  (live telemetry display)
 *
 * Design principles:
 *   - Only one object. No window.* properties. No globals.
 *   - Reads/writes are synchronous. No async. No events fired here.
 *   - main.js writes; FlightScene reads (exception: planeX/Y written by scene for debug).
 *
 * State values that main.js must keep updated:
 *   gameState           — current authoritative state string
 *   serverRoundStartTime — epoch ms when the flying phase began (server authority)
 *   serverTimeOffset    — correction: add to Date.now() to get synced server time
 *   currentMultiplier   — latest computed multiplier (written by gameLoop)
 *   crashPoint          — server-authoritative crash multiplier for this round
 *   roundId             — current server round ID
 *
 * State values that FlightScene writes back (read-only for everything else):
 *   bezierT   — current Bézier curve parameter [0..1]
 *   planeX    — plane canvas X position in pixels
 *   planeY    — plane canvas Y position in pixels
 *
 * Telemetry values updated by gameLoop:
 *   rafRunning, fps, lastEventLabel, socketStatus
 */

export const gameBridge = {
    // ── Core game state ──────────────────────────────────────────────────────

    /** @type {'WAITING'|'COUNTDOWN'|'FLYING'|'CRASHED'|'RESETTING'} */
    gameState: 'WAITING',

    /** Round ID as reported by the server */
    roundId: 0,

    /** Epoch ms of when this round's FLYING phase began (server-authoritative) */
    serverRoundStartTime: 0,

    /**
     * Signed clock correction in ms.
     * Correct current server time = Date.now() + serverTimeOffset
     */
    serverTimeOffset: 0,

    /** Server-determined crash multiplier for the current round */
    crashPoint: 1.00,

    // ── Computed values (written by gameLoop each frame) ─────────────────────

    /** Current multiplier value (1.00 during waiting/countdown/crashed) */
    currentMultiplier: 1.00,

    // ── FlightScene telemetry (written by Phaser scene each frame) ───────────

    /** Current Bézier curve parameter [0.0 .. 1.0] */
    bezierT: 0,

    /** Plane position in canvas pixels (for debug panel) */
    planeX: 0,
    planeY: 0,

    // ── Debug / telemetry ────────────────────────────────────────────────────

    /** Whether the game loop rAF is currently active */
    rafRunning: false,

    /** Most recently rendered frames per second */
    fps: 0,

    /** Human-readable description of the last server event received */
    lastEventLabel: 'none',

    /** Current state of the Supabase Realtime connection */
    socketStatus: 'CONNECTING',
};
