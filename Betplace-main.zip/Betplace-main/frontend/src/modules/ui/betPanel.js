/**
 * Bet Panel Controller
 */

export function updateBetPanelUI(state) {
    const { balance, isDemoMode } = state;
    
    // Header balance display
    const headerBalance = document.getElementById('headerBalance');
    if (headerBalance) {
        if (isDemoMode) {
            headerBalance.textContent = `KES ${balance.toLocaleString(undefined, { minimumFractionDigits: 2 })} (DEMO)`;
            headerBalance.style.color = '#10b981';
        } else {
            headerBalance.textContent = `KES ${balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}`;
            headerBalance.style.color = '';
        }
    }

    const metricwinBalanceBox = document.getElementById('metricwinBalanceBox');
    if (metricwinBalanceBox) {
        metricwinBalanceBox.textContent = `KES ${Math.floor(balance).toLocaleString()}${isDemoMode ? ' (DEMO)' : ''}`;
    }
}
