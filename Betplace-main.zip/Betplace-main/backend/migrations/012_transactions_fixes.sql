-- ══════════════════════════════════════════════
-- MIGRATION 012: Ensure transactions columns exist
-- ══════════════════════════════════════════════

-- Ensure reference column exists (used for tracking STK push references and transaction status check)
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS reference TEXT UNIQUE;

-- Ensure phone column exists (used by callback handlers to record target phone details on transactions)
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS phone TEXT;
