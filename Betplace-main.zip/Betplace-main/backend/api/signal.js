/**
 * backend/api/signal.js
 *
 * Aviator Predictor Signal API.
 * Uses pure PostgreSQL via _lib/db.js. Zero Supabase dependency.
 */

import { verifyPermission } from './_lib/auth.js';
import { setCorsHeaders } from './_lib/cors.js';
import { query } from './_lib/db.js';

export default async function signalHandler(req, res) {
    setCorsHeaders(req, res, 'GET, OPTIONS');

    if (req.method === 'OPTIONS') return res.status(200).end();
    if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });

    try {
        // Authenticate user and verify 'view_signals' permission
        const access = await verifyPermission(req, 'view_signals');
        if (!access.success) {
            return res.status(access.status).json({ error: access.error });
        }

        // Advance game loop
        try {
            await query('SELECT sync_and_get_game_state()');
        } catch (e) {
            console.warn('[Signal Warning] Could not progress game state loop:', e.message);
        }

        // Fetch authoritative state
        const { rows } = await query(
            'SELECT round_id, status, crash_point, next_crash_point FROM active_game_state WHERE id = 1'
        );

        const data = rows[0] || {
            round_id: 1,
            status: 'waiting',
            crash_point: 2.00,
            next_crash_point: null
        };

        let signalVal;
        if (
            data.status === 'waiting' &&
            data.next_crash_point !== null &&
            data.next_crash_point !== undefined &&
            !isNaN(parseFloat(data.next_crash_point))
        ) {
            signalVal = parseFloat(data.next_crash_point);
        } else {
            signalVal = parseFloat(data.crash_point);
        }

        // Generate consistent, realistic upcoming predictions for the next 3 rounds
        const currentRoundId = parseInt(data.round_id, 10) || 1;
        const nextPredictions = [1, 2, 3].map(offset => {
            const targetRoundId = currentRoundId + offset;
            const isNextAndArmed = offset === 1 && data.next_crash_point !== null && data.next_crash_point !== undefined && !isNaN(parseFloat(data.next_crash_point));
            let multiplier;

            if (isNextAndArmed) {
                multiplier = parseFloat(data.next_crash_point);
            } else {
                // Seeded pseudo-random formula based on targetRoundId
                const x = Math.sin(targetRoundId * 9301 + 49297) * 233280;
                const r = x - Math.floor(x);
                if (r < 0.45) {
                    multiplier = 1.15 + (r / 0.45) * 1.10;
                } else if (r < 0.75) {
                    multiplier = 2.25 + ((r - 0.45) / 0.30) * 2.50;
                } else if (r < 0.92) {
                    multiplier = 4.80 + ((r - 0.75) / 0.17) * 6.50;
                } else {
                    multiplier = 12.00 + ((r - 0.92) / 0.08) * 25.00;
                }
                multiplier = parseFloat(multiplier.toFixed(2));
            }

            const confidence = isNextAndArmed
                ? 99.9
                : parseFloat((94.5 + ((Math.cos(targetRoundId * 1337) + 1) / 2) * 5.0).toFixed(1));

            return {
                roundId: targetRoundId,
                offset,
                multiplier,
                isArmed: !!isNextAndArmed,
                confidence
            };
        });

        return res.status(200).json({
            success: true,
            roundId: data.round_id,
            status: data.status,
            crashPoint: signalVal,
            nextCrashPoint: data.next_crash_point,
            nextPredictions
        });
    } catch (err) {
        console.error('[Signal Error]:', err);
        return res.status(500).json({ error: err.message });
    }
}
