/**
 * backend/api/_lib/db.js
 *
 * Central PostgreSQL Database Pool for MetroWins Backend.
 * Replaces Supabase JS client completely.
 */

import pg from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const { Pool } = pg;

const connectionString = process.env.DATABASE_URL;

if (!connectionString) {
    console.warn('[Database Warning] DATABASE_URL is not set. Database operations will fail.');
}

const isLocal = !connectionString || connectionString.includes('localhost') || connectionString.includes('127.0.0.1');

export const pool = new Pool({
    connectionString,
    ssl: isLocal ? false : { rejectUnauthorized: false },
    max: 20,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 10000,
});

pool.on('error', (err) => {
    console.error('[PostgreSQL Pool Error]:', err.message);
});

/**
 * Execute a SQL query with parameters
 * @param {string} text - SQL statement
 * @param {Array} [params] - Bound parameters
 * @returns {Promise<pg.QueryResult>}
 */
export async function query(text, params) {
    const start = Date.now();
    try {
        const res = await pool.query(text, params);
        const duration = Date.now() - start;
        if (process.env.DEBUG_SQL === 'true') {
            console.log(`[SQL Query] (${duration}ms) ${text}`);
        }
        return res;
    } catch (err) {
        console.error(`[SQL Error]: ${err.message} -- Query: ${text}`);
        throw err;
    }
}

/**
 * Get a client from the pool for transactions
 * @returns {Promise<pg.PoolClient>}
 */
export async function getClient() {
    return await pool.connect();
}

export default {
    query,
    getClient,
    pool
};
