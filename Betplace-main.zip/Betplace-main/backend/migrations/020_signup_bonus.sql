-- ═══════════════════════════════════════════════════════════════
-- MIGRATION 020: New User Signup Bonus
-- ═══════════════════════════════════════════════════════════════

-- 1. Insert default signup bonus config into system_settings
INSERT INTO public.system_settings (key, value)
VALUES (
    'signup_bonus',
    '{
        "enabled": false,
        "amount_kes": 50
    }'::jsonb
)
ON CONFLICT (key) DO NOTHING;

-- 2. RPC: credit_signup_bonus
-- Called server-side after a new user registers.
-- Reads signup_bonus setting; if enabled, credits the user's balance.
-- Protected so it can only run once per user (idempotent via free_bet_given flag reuse or a
-- unique transaction reference).
CREATE OR REPLACE FUNCTION public.credit_signup_bonus(
    p_user_id UUID
)
RETURNS JSON AS $$
DECLARE
    v_settings   JSONB;
    v_enabled    BOOLEAN;
    v_amount     DECIMAL;
    v_already    INT;
BEGIN
    -- Load config
    SELECT value INTO v_settings
    FROM public.system_settings
    WHERE key = 'signup_bonus'
    LIMIT 1;

    IF v_settings IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Signup bonus config not found');
    END IF;

    v_enabled := COALESCE((v_settings->>'enabled')::BOOLEAN, FALSE);
    v_amount  := COALESCE((v_settings->>'amount_kes')::DECIMAL, 0);

    IF NOT v_enabled THEN
        RETURN json_build_object('success', false, 'error', 'Signup bonus disabled');
    END IF;

    IF v_amount <= 0 THEN
        RETURN json_build_object('success', false, 'error', 'Signup bonus amount is 0');
    END IF;

    -- Idempotency: check if bonus was already given
    SELECT COUNT(*) INTO v_already
    FROM public.transactions
    WHERE user_id = p_user_id
      AND type    = 'signup_bonus'
    LIMIT 1;

    IF v_already > 0 THEN
        RETURN json_build_object('success', false, 'error', 'Signup bonus already credited');
    END IF;

    -- Credit the balance
    UPDATE public.profiles
    SET balance = balance + v_amount
    WHERE id = p_user_id;

    -- Log the transaction
    INSERT INTO public.transactions (user_id, type, amount, status, reference)
    VALUES (p_user_id, 'signup_bonus', v_amount, 'completed',
            'SIGNUP_BONUS_' || p_user_id::TEXT);

    RETURN json_build_object('success', true, 'credited', v_amount);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Restrict to service_role only
REVOKE ALL ON FUNCTION public.credit_signup_bonus(UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.credit_signup_bonus(UUID) TO service_role;
