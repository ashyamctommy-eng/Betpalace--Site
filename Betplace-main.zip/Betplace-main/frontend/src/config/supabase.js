/**
 * frontend/src/config/supabase.js
 *
 * Native MetroWins Client & Auth Manager.
 * 100% Standalone (ZERO SUPABASE DEPENDENCY).
 * Connects directly to MetroWins Backend on Render / VPS / Vercel.
 */

import { apiUrl } from './api.js';

// Storage keys
const TOKEN_KEY = 'metrowins_auth_token';
const USER_KEY  = 'metrowins_auth_user';

// In-memory auth change listeners
const authListeners = new Set();

export function getStoredToken() {
    try {
        return localStorage.getItem(TOKEN_KEY) || '';
    } catch {
        return '';
    }
}

export function getStoredUser() {
    try {
        const raw = localStorage.getItem(USER_KEY);
        return raw ? JSON.parse(raw) : null;
    } catch {
        return null;
    }
}

export function setStoredSession(token, user) {
    try {
        if (token) localStorage.setItem(TOKEN_KEY, token);
        else localStorage.removeItem(TOKEN_KEY);

        if (user) localStorage.setItem(USER_KEY, JSON.stringify(user));
        else localStorage.removeItem(USER_KEY);
    } catch (_) {}

    // Notify listeners
    authListeners.forEach(listener => {
        try {
            listener(token ? 'SIGNED_IN' : 'SIGNED_OUT', token ? { access_token: token, user } : null);
        } catch (_) {}
    });
}

/**
 * Universal fetch wrapper with Bearer token injection
 */
async function request(path, options = {}) {
    const url = apiUrl(path);
    const token = getStoredToken();

    const headers = {
        'Content-Type': 'application/json',
        ...(options.headers || {})
    };

    if (token && !headers['Authorization']) {
        headers['Authorization'] = `Bearer ${token}`;
    }

    const res = await fetch(url, { ...options, headers });
    const data = await res.json().catch(() => ({}));

    if (!res.ok) {
        const message = data.message || data.error || `HTTP error ${res.status}`;
        const err = new Error(message);
        err.status = res.status;
        err.data = data;
        throw err;
    }

    return data;
}

/**
 * Standalone Auth Client (replaces supabase.auth)
 */
export const auth = {
    async getSession() {
        const token = getStoredToken();
        const user = getStoredUser();
        if (!token) return { data: { session: null }, error: null };
        return { data: { session: { access_token: token, user } }, error: null };
    },

    async getUser() {
        const token = getStoredToken();
        if (!token) return { data: { user: null }, error: null };

        try {
            const res = await request('/api/auth/me');
            if (res.user) {
                setStoredSession(token, res.user);
                return { data: { user: res.user }, error: null };
            }
        } catch (err) {
            if (err.status === 401 || err.status === 403) {
                setStoredSession(null, null);
            }
            return { data: { user: null }, error: err };
        }

        const fallbackUser = getStoredUser();
        return { data: { user: fallbackUser }, error: null };
    },

    async signInWithPassword({ email, password }) {
        try {
            const res = await request('/api/auth/login', {
                method: 'POST',
                body: JSON.stringify({ identifier: email, password })
            });

            if (res.success && res.token) {
                setStoredSession(res.token, res.user);
                return { data: { user: res.user, session: { access_token: res.token } }, error: null };
            }
            return { data: { user: null, session: null }, error: new Error(res.message || 'Login failed') };
        } catch (err) {
            return { data: { user: null, session: null }, error: err };
        }
    },

    async signUp({ email, password, options = {} }) {
        try {
            const phone = options.data?.phone || email;
            const username = options.data?.username;
            const referralCode = options.data?.referralCode;

            const res = await request('/api/auth/register', {
                method: 'POST',
                body: JSON.stringify({ phone, password, email, username, referralCode })
            });

            if (res.success && res.token) {
                setStoredSession(res.token, res.user);
                return { data: { user: res.user, session: { access_token: res.token } }, error: null };
            }
            return { data: { user: null, session: null }, error: new Error(res.message || 'Registration failed') };
        } catch (err) {
            return { data: { user: null, session: null }, error: err };
        }
    },

    async signOut() {
        try {
            await request('/api/auth/logout', { method: 'POST' }).catch(() => {});
        } finally {
            setStoredSession(null, null);
        }
        return { error: null };
    },

    onAuthStateChange(callback) {
        authListeners.add(callback);
        // Initial fire
        const token = getStoredToken();
        const user = getStoredUser();
        setTimeout(() => {
            try {
                callback(token ? 'INITIAL_SESSION' : 'SIGNED_OUT', token ? { access_token: token, user } : null);
            } catch (_) {}
        }, 0);

        return {
            data: {
                subscription: {
                    unsubscribe() {
                        authListeners.delete(callback);
                    }
                }
            }
        };
    }
};

/**
 * Standalone RPC Client (replaces supabase.rpc)
 */
export async function rpc(functionName, params = {}) {
    try {
        if (functionName === 'sync_and_get_game_state') {
            const res = await request('/api/game');
            return { data: res, error: null };
        }

        if (functionName === 'place_bet') {
            const body = {
                amount: params.amount ?? params.p_amount,
                p_amount: params.p_amount ?? params.amount,
                roundId: params.roundId ?? params.p_round_id ?? params.round_id,
                p_round_id: params.p_round_id ?? params.roundId ?? params.round_id,
                autoCashout: params.autoCashout ?? params.p_auto_cashout ?? params.auto_cashout,
                ...params
            };
            const res = await request('/api/game/bet', {
                method: 'POST',
                body: JSON.stringify(body)
            });
            return { data: res, error: null };
        }

        if (functionName === 'cash_out') {
            const body = {
                betId: params.betId ?? params.p_bet_id ?? params.bet_id,
                p_bet_id: params.p_bet_id ?? params.betId ?? params.bet_id,
                multiplier: params.multiplier ?? params.p_multiplier,
                p_multiplier: params.p_multiplier ?? params.multiplier,
                ...params
            };
            const res = await request('/api/game/cashout', {
                method: 'POST',
                body: JSON.stringify(body)
            });
            return { data: res, error: null };
        }

        if (functionName === 'cancel_bet') {
            const body = {
                betId: params.betId ?? params.p_bet_id ?? params.bet_id,
                p_bet_id: params.p_bet_id ?? params.betId ?? params.bet_id,
                ...params
            };
            const res = await request('/api/game/cancel', {
                method: 'POST',
                body: JSON.stringify(body)
            });
            return { data: res, error: null };
        }

        if (functionName === 'has_permission') {
            const res = await request(`/api/rpc/has_permission`, {
                method: 'POST',
                body: JSON.stringify(params)
            });
            return { data: res, error: null };
        }

        // Generic fallback RPC
        const res = await request(`/api/rpc/${functionName}`, {
            method: 'POST',
            body: JSON.stringify(params)
        });
        return { data: res, error: null };
    } catch (err) {
        return { data: null, error: err };
    }
}

/**
 * Robust chainable query builder adapter for backward compatibility
 */
export function from(table) {
    const builder = {
        _table: table,
        select(columns = '*') { return builder; },
        eq(column, value) {
            builder._eqCol = column;
            builder._eqVal = value;
            return builder;
        },
        or(filterStr) { return builder; },
        ilike(column, pattern) { return builder; },
        in(column, values) {
            builder._inCol = column;
            builder._inVals = values;
            return builder;
        },
        order(column, options = {}) { return builder; },
        limit(num) { return builder; },
        range(from, to) { return builder; },
        async single() {
            if (table === 'profiles') {
                try {
                    const res = await request('/api/wallet/balance');
                    return { data: { balance: res.balance, is_frozen: res.isFrozen }, error: null };
                } catch (err) {
                    return { data: null, error: err };
                }
            }
            if (table === 'transactions') {
                try {
                    const ref = builder._eqVal || '';
                    const res = await request(`/api/wallet/status?reference=${encodeURIComponent(ref)}`);
                    return { data: res.transaction || (res.status ? { status: res.status } : null), error: null };
                } catch (err) {
                    return { data: null, error: err };
                }
            }
            if (table === 'system_settings') {
                try {
                    const res = await request('/api/admin/content?action=settings');
                    const val = builder._eqVal ? res[builder._eqVal] : null;
                    return { data: { key: builder._eqVal, value: val }, error: null };
                } catch (err) {
                    return { data: null, error: err };
                }
            }
            return { data: null, error: null };
        },
        async maybeSingle() {
            return builder.single();
        },
        async upsert(record) { return { data: record, error: null }; },
        async insert(record) { return { data: record, error: null }; },
        async update(record) { return { data: record, error: null }; },
        async delete() { return { data: null, error: null }; },
        then(resolve, reject) {
            const execute = async () => {
                if (table === 'transactions') {
                    try {
                        const res = await request('/api/wallet/transactions');
                        return { data: Array.isArray(res) ? res : [], error: null };
                    } catch (err) {
                        return { data: [], error: err };
                    }
                }
                if (table === 'system_settings') {
                    try {
                        const res = await request('/api/admin/content?action=settings');
                        return { data: Object.entries(res).map(([k, v]) => ({ key: k, value: v })), error: null };
                    } catch (err) {
                        return { data: [], error: err };
                    }
                }
                if (table === 'promotions') {
                    try {
                        const res = await request('/api/admin/content?action=promotions');
                        return { data: res, error: null };
                    } catch (err) {
                        return { data: [], error: err };
                    }
                }
                return { data: [], error: null };
            };
            return execute().then(resolve, reject);
        }
    };
    return builder;
}

/**
 * WebSocket Real-Time Channel (replaces supabase.channel)
 */
export function channel(name) {
    let ws = null;
    let handlers = [];

    function connect() {
        const rawBase = import.meta.env.VITE_API_URL || window.location.origin;
        const isSecure = window.location.protocol === 'https:' || rawBase.startsWith('https:');
        const host = rawBase.replace(/^https?:\/\//, '').replace(/\/+$/, '');
        const wsUrl = `${isSecure ? 'wss://' : 'ws://'}${host}/ws`;

        try {
            ws = new WebSocket(wsUrl);
            ws.onmessage = (event) => {
                try {
                    const parsed = JSON.parse(event.data);
                    handlers.forEach(h => h(parsed));
                } catch (_) {}
            };
        } catch (_) {}
    }

    connect();

    return {
        on(event, filter, callback) {
            const fn = typeof filter === 'function' ? filter : callback;
            if (fn) handlers.push(fn);
            return this;
        },
        subscribe() {
            return this;
        },
        unsubscribe() {
            if (ws) {
                try { ws.close(); } catch (_) {}
            }
            handlers = [];
        }
    };
}

// Universal client export
export const supabase = {
    auth,
    rpc,
    from,
    channel
};

export default supabase;
