-- ════════════════════════════════════════════════════════════
-- Migration 028: Drop old place_bet function overload
-- 
-- PROBLEM: There are two conflicting place_bet function signatures
-- in the database, causing the error:
--   "Could not choose the best candidate function between:
--    public.place_bet(p_amount => numeric, p_round_id => bigint, ...)
--    public.place_bet(p_round_id => bigint, p_amount => numeric, ...)"
--
-- Root cause: 001_initial_schema.sql created place_bet with signature
--   (p_amount DECIMAL, p_round_id BIGINT, p_use_free_bet BOOLEAN)
--
-- run_security_migration.sql created a hardened version with signature
--   (p_round_id BIGINT, p_amount DECIMAL, p_use_free_bet BOOLEAN)
--
-- Both exist simultaneously in the DB, causing ambiguity.
--
-- FIX: Drop the old signature (param order: amount first).
--      The new hardened version (run_security_migration.sql) stays.
-- ════════════════════════════════════════════════════════════

-- Drop the OLD place_bet (p_amount first, then p_round_id)
DROP FUNCTION IF EXISTS public.place_bet(DECIMAL, BIGINT, BOOLEAN);

-- Confirm the correct hardened version still exists with proper grants
-- (This is a no-op if already granted, safe to re-run)
GRANT EXECUTE ON FUNCTION public.place_bet(BIGINT, DECIMAL, BOOLEAN) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.place_bet(BIGINT, DECIMAL, BOOLEAN) FROM anon, public;

-- Reload PostgREST schema cache
NOTIFY pgrst, 'reload schema';
