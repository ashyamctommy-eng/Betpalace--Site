-- ══════════════════════════════════════════════
-- MIGRATION 010: Secure Profiles RLS & Automated Triggers
-- ══════════════════════════════════════════════

-- Enable Row Level Security strictly on profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- 1. Policies configuration
-- Drop any generic update policies if they exist (ensuring only SERVICE_ROLE can update sensitive columns)
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;

-- Create policy allowing users to read their own profile details
CREATE POLICY "Users can view own profile" 
ON public.profiles 
FOR SELECT 
USING (auth.uid() = id);

-- 2. Secure automated profile creation trigger
-- This ensures that when a user signs up successfully, the database immediately builds a secure profiles record.
-- The trigger runs in SECURITY DEFINER context, bypassing public RLS queries. Also handles user metadata mapping.
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (
        id, 
        phone, 
        username, 
        email, 
        balance, 
        role
    )
    VALUES (
        NEW.id,
        COALESCE(NEW.phone, NEW.raw_user_meta_data->>'phone', '+254700000000'),
        COALESCE(NEW.raw_user_meta_data->>'username', 'player_' || substring(NEW.id::text from 1 for 8)),
        COALESCE(NEW.email, NEW.phone || '@metricwin.app'),
        0.00,
        'User'
    )
    ON CONFLICT (id) DO NOTHING;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Bind trigger to auth.users table
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
