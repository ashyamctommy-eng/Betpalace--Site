/**
 * Metricwin Application Constants
 */

export const GAME_CONFIG = {
    MIN_STAKE: 50,
    MAX_STAKE: 500000,
    WAITING_DURATION_MS: 5000,
    POST_CRASH_DURATION_MS: 2000,
    DEFAULT_DEMO_BALANCE: 10000.00,
    DEFAULT_ROUND_DURATION: 15000,
    TICKER_MAX_HISTORY: 20
};

export const API_ENDPOINTS = {
    GAME_STATE: import.meta.env.VITE_GAME_STATE_URL || '/api/game',
    SIGNAL: '/api/signal',
    DEPOSIT: '/api/deposit',
    WITHDRAW: '/api/withdraw',
    CLAIM_PROMO: '/api/claim-promo',
    ADMIN_ACTIONS: '/api/_admin/actions'
};

export const AUDIO_CONFIG = {
    BET_PLACED_FREQ: 587.33, // D5
    CASHOUT_FREQ_START: 523.25, // C5
    CASHOUT_FREQ_END: 1046.50, // C6
    CRASH_FREQ_START: 300,
    CRASH_FREQ_END: 80
};
