/**
 * backend/api/sports.js
 *
 * Sportsbook & SharpAPI (v1) Integration Router.
 * Supports:
 *  - Real-time live and upcoming sports odds via SharpAPI (https://sharpapi.io)
 *  - Multi-market aggregation: 1X2 Moneyline (h2h), Totals (Over/Under), Spreads, Both Teams to Score (BTTS)
 *  - Multi-sportsbook best price consensus (DraftKings, FanDuel, etc.)
 *  - Live in-play scores, periods, and game clock synchronization from SharpAPI Events feed
 *  - High-performance caching layer to preserve SharpAPI rate limits and quota (12 req/min on free tier)
 *  - Rate limit telemetry tracking (X-RateLimit-Limit, X-RateLimit-Remaining, X-RateLimit-Reset, X-Data-Delay)
 *  - Comprehensive realistic simulation fallback when API key is not provided or quota exceeded
 *  - Placing Sports Bets (Singles and Accumulators/Parlays)
 *  - User Sports Betting ledger & Cashout
 */

import { query } from './_lib/db.js';
import { verifyAuthToken } from './_lib/auth.js';

const SHARP_API_BASE = process.env.SHARP_API_BASE || 'https://api.sharpapi.io/api/v1';
const API_KEY = process.env.SHARP_API_KEY || process.env.THE_ODDS_API_KEY || '';

// In-memory cache to conserve SharpAPI rate limits and quota
export const cache = {
    sports: { data: null, timestamp: 0, ttl: 10 * 60 * 1000 }, // 10 mins
    odds: new Map(), // key -> { data, timestamp, ttl: 60 * 1000 }
    live: { data: null, timestamp: 0, ttl: 30 * 1000 }, // 30 secs
    oddsTtl: 60 * 1000,
    quota: {
        remaining: null,
        limit: null,
        resetsAt: null,
        dataDelay: null,
        tier: null,
        lastChecked: null
    }
};

export function clearSportsCache() {
    cache.sports.data = null;
    cache.sports.timestamp = 0;
    cache.odds.clear();
    cache.live.data = null;
    cache.live.timestamp = 0;
    return true;
}

export function getSportsCacheTelemetry() {
    return {
        cachedSportsCount: cache.sports.data ? cache.sports.data.length : 0,
        cachedOddsCount: cache.odds.size,
        cachedLiveCount: cache.live.data ? cache.live.data.length : 0,
        quota: cache.quota
    };
}

let sportsConfigCache = null;
let sportsConfigCacheTime = 0;

export async function getSportsbookConfig() {
    const now = Date.now();
    if (sportsConfigCache && (now - sportsConfigCacheTime < 15000)) {
        return sportsConfigCache;
    }
    try {
        const { rows } = await query("SELECT value FROM system_settings WHERE key = 'sportsbook_config' LIMIT 1");
        if (rows.length > 0 && rows[0].value) {
            sportsConfigCache = typeof rows[0].value === 'string' ? JSON.parse(rows[0].value) : rows[0].value;
            sportsConfigCacheTime = now;
            return sportsConfigCache;
        }
    } catch (_) {}
    return { enabled: true, minStake: 10, maxStake: 50000, maxPayout: 1000000 };
}

/**
 * Updates internal rate-limit and quota state from SharpAPI response headers
 */
function updateQuotaFromHeaders(headers) {
    if (!headers) return;
    const remaining = headers.get('x-ratelimit-remaining');
    const limit = headers.get('x-ratelimit-limit');
    const resetsAt = headers.get('x-ratelimit-reset');
    const dataDelay = headers.get('x-data-delay');
    const tier = headers.get('x-tier');

    if (remaining !== null && remaining !== undefined) {
        cache.quota.remaining = parseInt(remaining, 10);
    }
    if (limit !== null && limit !== undefined) {
        cache.quota.limit = parseInt(limit, 10);
    }
    if (resetsAt !== null && resetsAt !== undefined) {
        cache.quota.resetsAt = resetsAt;
    }
    if (dataDelay !== null && dataDelay !== undefined) {
        cache.quota.dataDelay = dataDelay;
    }
    if (tier) {
        cache.quota.tier = tier;
    }
    cache.quota.lastChecked = new Date().toISOString();
}

// ── Betplace Category to SharpAPI Mapping ─────────────────────────────────────
const SPORT_MAP = {
    'soccer_epl': {
        sport: 'soccer',
        league: 'england_-_premier_league',
        title: 'English Premier League',
        group: 'Soccer',
        icon: '⚽'
    },
    'soccer_uefa_champs_league': {
        sport: 'soccer',
        league: 'uefa_-_champions_league',
        title: 'UEFA Champions League',
        group: 'Soccer',
        icon: '🏆'
    },
    'soccer_spain_la_liga': {
        sport: 'soccer',
        league: 'spain_-_la_liga',
        title: 'La Liga (Spain)',
        group: 'Soccer',
        icon: '⚽'
    },
    'soccer_italy_serie_a': {
        sport: 'soccer',
        league: 'italy_-_serie_a',
        title: 'Serie A (Italy)',
        group: 'Soccer',
        icon: '⚽'
    },
    'basketball_nba': {
        sport: 'basketball',
        league: 'nba',
        title: 'NBA',
        group: 'Basketball',
        icon: '🏀'
    },
    'americanfootball_nfl': {
        sport: 'football',
        league: 'nfl',
        title: 'NFL',
        group: 'American Football',
        icon: '🏈'
    },
    'tennis_atp': {
        sport: 'tennis',
        league: 'atp',
        title: 'ATP Tour',
        group: 'Tennis',
        icon: '🎾'
    }
};

function getSportEmoji(sportId) {
    const s = (sportId || '').toLowerCase();
    if (s.includes('soccer') || (s.includes('football') && !s.includes('american'))) return '⚽';
    if (s.includes('basket')) return '🏀';
    if (s.includes('tennis')) return '🎾';
    if (s.includes('american') || s.includes('nfl')) return '🏈';
    if (s.includes('base') || s.includes('mlb')) return '⚾';
    if (s.includes('ice') || s.includes('hockey') || s.includes('nhl')) return '🏒';
    if (s.includes('rugby')) return '🏉';
    if (s.includes('cricket')) return '🏏';
    if (s.includes('mma') || s.includes('box') || s.includes('ufc')) return '🥊';
    if (s.includes('dart')) return '🎯';
    if (s.includes('motor') || s.includes('f1')) return '🏎️';
    return '🏆';
}

function formatLeagueTitle(leagueStr) {
    if (!leagueStr) return 'Match Odds';
    return leagueStr
        .replace(/^.*_-_/, '')
        .replace(/_/g, ' ')
        .replace(/\b\w/g, l => l.toUpperCase());
}

function findSportKey(sport, league) {
    const s = (sport || '').toLowerCase();
    const l = (league || '').toLowerCase();

    for (const [k, v] of Object.entries(SPORT_MAP)) {
        if (v.league && l.includes(v.league.toLowerCase())) return k;
    }

    if (l.includes('premier') || l.includes('epl')) return 'soccer_epl';
    if (l.includes('champions')) return 'soccer_uefa_champs_league';
    if (l.includes('la_liga') || l.includes('laliga')) return 'soccer_spain_la_liga';
    if (l.includes('serie_a')) return 'soccer_italy_serie_a';
    if (l.includes('nba')) return 'basketball_nba';
    if (l.includes('nfl')) return 'americanfootball_nfl';
    if (l.includes('atp')) return 'tennis_atp';

    if (s.includes('soccer')) return 'soccer_epl';
    if (s.includes('basket')) return 'basketball_nba';
    if (s.includes('tennis')) return 'tennis_atp';
    if (s.includes('football')) return 'americanfootball_nfl';

    return s || 'all';
}

// ── Realistic Mock & Live Simulation Data (Fallback Engine) ───────────────────
const MOCK_SPORTS = [
    { key: 'soccer_epl', group: 'Soccer', title: 'English Premier League', active: true, icon: '⚽' },
    { key: 'soccer_uefa_champs_league', group: 'Soccer', title: 'UEFA Champions League', active: true, icon: '🏆' },
    { key: 'soccer_spain_la_liga', group: 'Soccer', title: 'La Liga (Spain)', active: true, icon: '⚽' },
    { key: 'soccer_italy_serie_a', group: 'Soccer', title: 'Serie A (Italy)', active: true, icon: '⚽' },
    { key: 'basketball_nba', group: 'Basketball', title: 'NBA', active: true, icon: '🏀' },
    { key: 'americanfootball_nfl', group: 'American Football', title: 'NFL', active: true, icon: '🏈' },
    { key: 'tennis_atp', group: 'Tennis', title: 'ATP Tour', active: true, icon: '🎾' }
];

function generateMockMatches(sportKey) {
    const now = Date.now();
    const matchesBySport = {
        soccer_epl: [
            {
                id: 'epl_001',
                sport_key: 'soccer_epl',
                sport_title: 'Premier League',
                home_team: 'Arsenal',
                away_team: 'Chelsea',
                is_live: true,
                live_time: "64'",
                score: { home: 2, away: 1 },
                commence_time: new Date(now - 64 * 60 * 1000).toISOString(),
                bookmakers: [{
                    title: 'Betplace Bookmaker',
                    markets: [
                        { key: 'h2h', outcomes: [{ name: 'Arsenal', price: 1.55 }, { name: 'Draw', price: 3.40 }, { name: 'Chelsea', price: 5.20 }] },
                        { key: 'totals', outcomes: [{ name: 'Over 2.5', price: 1.45 }, { name: 'Under 2.5', price: 2.65 }] },
                        { key: 'btts', outcomes: [{ name: 'Yes', price: 1.70 }, { name: 'No', price: 2.10 }] }
                    ]
                }]
            },
            {
                id: 'epl_002',
                sport_key: 'soccer_epl',
                sport_title: 'Premier League',
                home_team: 'Manchester City',
                away_team: 'Liverpool',
                is_live: true,
                live_time: "28'",
                score: { home: 1, away: 1 },
                commence_time: new Date(now - 28 * 60 * 1000).toISOString(),
                bookmakers: [{
                    title: 'Betplace Bookmaker',
                    markets: [
                        { key: 'h2h', outcomes: [{ name: 'Manchester City', price: 2.10 }, { name: 'Draw', price: 3.25 }, { name: 'Liverpool', price: 3.30 }] },
                        { key: 'totals', outcomes: [{ name: 'Over 2.5', price: 1.62 }, { name: 'Under 2.5', price: 2.20 }] },
                        { key: 'btts', outcomes: [{ name: 'Yes', price: 1.50 }, { name: 'No', price: 2.45 }] }
                    ]
                }]
            },
            {
                id: 'epl_003',
                sport_key: 'soccer_epl',
                sport_title: 'Premier League',
                home_team: 'Aston Villa',
                away_team: 'Tottenham Hotspur',
                is_live: false,
                commence_time: new Date(now + 3 * 3600 * 1000).toISOString(),
                bookmakers: [{
                    title: 'Betplace Bookmaker',
                    markets: [
                        { key: 'h2h', outcomes: [{ name: 'Aston Villa', price: 2.25 }, { name: 'Draw', price: 3.50 }, { name: 'Tottenham Hotspur', price: 2.95 }] },
                        { key: 'totals', outcomes: [{ name: 'Over 2.5', price: 1.58 }, { name: 'Under 2.5', price: 2.30 }] },
                        { key: 'btts', outcomes: [{ name: 'Yes', price: 1.55 }, { name: 'No', price: 2.35 }] }
                    ]
                }]
            },
            {
                id: 'epl_004',
                sport_key: 'soccer_epl',
                sport_title: 'Premier League',
                home_team: 'Newcastle United',
                away_team: 'Manchester United',
                is_live: false,
                commence_time: new Date(now + 7 * 3600 * 1000).toISOString(),
                bookmakers: [{
                    title: 'Betplace Bookmaker',
                    markets: [
                        { key: 'h2h', outcomes: [{ name: 'Newcastle United', price: 2.05 }, { name: 'Draw', price: 3.60 }, { name: 'Manchester United', price: 3.40 }] },
                        { key: 'totals', outcomes: [{ name: 'Over 2.5', price: 1.70 }, { name: 'Under 2.5', price: 2.10 }] },
                        { key: 'btts', outcomes: [{ name: 'Yes', price: 1.60 }, { name: 'No', price: 2.25 }] }
                    ]
                }]
            }
        ],
        soccer_uefa_champs_league: [
            {
                id: 'ucl_001',
                sport_key: 'soccer_uefa_champs_league',
                sport_title: 'Champions League',
                home_team: 'Real Madrid',
                away_team: 'Bayern Munich',
                is_live: true,
                live_time: "52'",
                score: { home: 1, away: 0 },
                commence_time: new Date(now - 52 * 60 * 1000).toISOString(),
                bookmakers: [{
                    title: 'Betplace Bookmaker',
                    markets: [
                        { key: 'h2h', outcomes: [{ name: 'Real Madrid', price: 1.75 }, { name: 'Draw', price: 3.60 }, { name: 'Bayern Munich', price: 4.50 }] },
                        { key: 'totals', outcomes: [{ name: 'Over 2.5', price: 1.80 }, { name: 'Under 2.5', price: 1.95 }] },
                        { key: 'btts', outcomes: [{ name: 'Yes', price: 1.85 }, { name: 'No', price: 1.90 }] }
                    ]
                }]
            },
            {
                id: 'ucl_002',
                sport_key: 'soccer_uefa_champs_league',
                sport_title: 'Champions League',
                home_team: 'Paris Saint-Germain',
                away_team: 'Barcelona',
                is_live: false,
                commence_time: new Date(now + 24 * 3600 * 1000).toISOString(),
                bookmakers: [{
                    title: 'Betplace Bookmaker',
                    markets: [
                        { key: 'h2h', outcomes: [{ name: 'Paris Saint-Germain', price: 2.15 }, { name: 'Draw', price: 3.75 }, { name: 'Barcelona', price: 3.10 }] },
                        { key: 'totals', outcomes: [{ name: 'Over 2.5', price: 1.55 }, { name: 'Under 2.5', price: 2.40 }] }
                    ]
                }]
            }
        ],
        basketball_nba: [
            {
                id: 'nba_001',
                sport_key: 'basketball_nba',
                sport_title: 'NBA',
                home_team: 'Los Angeles Lakers',
                away_team: 'Golden State Warriors',
                is_live: true,
                live_time: 'Q3 04:12',
                score: { home: 78, away: 81 },
                commence_time: new Date(now - 75 * 60 * 1000).toISOString(),
                bookmakers: [{
                    title: 'Betplace Bookmaker',
                    markets: [
                        { key: 'h2h', outcomes: [{ name: 'Los Angeles Lakers', price: 1.95 }, { name: 'Golden State Warriors', price: 1.85 }] },
                        { key: 'totals', outcomes: [{ name: 'Over 224.5', price: 1.90 }, { name: 'Under 224.5', price: 1.90 }] }
                    ]
                }]
            },
            {
                id: 'nba_002',
                sport_key: 'basketball_nba',
                sport_title: 'NBA',
                home_team: 'Boston Celtics',
                away_team: 'Milwaukee Bucks',
                is_live: false,
                commence_time: new Date(now + 5 * 3600 * 1000).toISOString(),
                bookmakers: [{
                    title: 'Betplace Bookmaker',
                    markets: [
                        { key: 'h2h', outcomes: [{ name: 'Boston Celtics', price: 1.48 }, { name: 'Milwaukee Bucks', price: 2.65 }] },
                        { key: 'totals', outcomes: [{ name: 'Over 228.5', price: 1.92 }, { name: 'Under 228.5', price: 1.88 }] }
                    ]
                }]
            }
        ],
        americanfootball_nfl: [
            {
                id: 'nfl_001',
                sport_key: 'americanfootball_nfl',
                sport_title: 'NFL',
                home_team: 'Kansas City Chiefs',
                away_team: 'San Francisco 49ers',
                is_live: false,
                commence_time: new Date(now + 48 * 3600 * 1000).toISOString(),
                bookmakers: [{
                    title: 'Betplace Bookmaker',
                    markets: [
                        { key: 'h2h', outcomes: [{ name: 'Kansas City Chiefs', price: 1.80 }, { name: 'San Francisco 49ers', price: 2.05 }] },
                        { key: 'spreads', outcomes: [{ name: 'Kansas City Chiefs -2.5', price: 1.90 }, { name: 'San Francisco 49ers +2.5', price: 1.90 }] }
                    ]
                }]
            }
        ],
        tennis_atp: [
            {
                id: 'ten_001',
                sport_key: 'tennis_atp',
                sport_title: 'ATP Tour',
                home_team: 'Carlos Alcaraz',
                away_team: 'Jannik Sinner',
                is_live: true,
                live_time: 'Set 2 (6-4, 3-2)',
                score: { home: 1, away: 0 },
                commence_time: new Date(now - 55 * 60 * 1000).toISOString(),
                bookmakers: [{
                    title: 'Betplace Bookmaker',
                    markets: [
                        { key: 'h2h', outcomes: [{ name: 'Carlos Alcaraz', price: 1.40 }, { name: 'Jannik Sinner', price: 2.90 }] }
                    ]
                }]
            }
        ]
    };

    if (sportKey && matchesBySport[sportKey]) {
        return matchesBySport[sportKey];
    }

    return Object.values(matchesBySport).flat();
}

// ── SharpAPI Data Transformer ────────────────────────────────────────────────
/**
 * Transforms SharpAPI odds rows and events into canonical Betplace match cards
 */
function transformSharpDataToMatches(oddsRows = [], eventsList = [], defaultSportKey = 'soccer_epl') {
    const eventsMap = new Map();

    for (const ev of (eventsList || [])) {
        if (ev && ev.id) {
            eventsMap.set(ev.id, ev);
        }
    }

    const matchMap = new Map();

    for (const odd of oddsRows) {
        const eventId = odd.event_id || odd.id;
        if (!eventId) continue;

        // Skip non-match / outright / championship-winner markets without an away team
        const homeTeam = (odd.home_team || '').trim();
        const awayTeam = (odd.away_team || '').trim();
        const marketTypeRaw = (odd.market_type || '').toLowerCase();
        if (marketTypeRaw === 'outright' || marketTypeRaw === 'championship_winner') continue;
        if (!homeTeam || !awayTeam) continue;

        if (!matchMap.has(eventId)) {
            const ev = eventsMap.get(eventId) || {};
            const isLive = Boolean(odd.is_live || ev.is_live);

            let score = null;
            let liveTime = null;

            if (ev.game_state) {
                if (typeof ev.game_state.home_score === 'number' && typeof ev.game_state.away_score === 'number') {
                    score = { home: ev.game_state.home_score, away: ev.game_state.away_score };
                }
                const period = ev.game_state.game_period || '';
                const clock = ev.game_state.game_clock || '';
                liveTime = (period + (clock ? ' ' + clock : '')).trim() || 'LIVE';
            } else if (isLive) {
                liveTime = 'LIVE';
            }

            const sportKey = findSportKey(odd.sport || ev.sport, odd.league || ev.league) || defaultSportKey;
            const sportTitle = formatLeagueTitle(odd.league || ev.league || odd.sport || ev.sport);

            matchMap.set(eventId, {
                id: eventId,
                sport_key: sportKey,
                sport_title: sportTitle,
                home_team: homeTeam,
                away_team: awayTeam,
                is_live: isLive,
                live_time: liveTime,
                score: score,
                commence_time: odd.event_start_time || ev.start_time || new Date().toISOString(),
                _bookmakerTitle: odd.sportsbook_name || 'Betplace Bookmaker',
                _markets: {
                    h2h: { key: 'h2h', outcomes: [] },
                    totals: { key: 'totals', outcomes: [] },
                    spreads: { key: 'spreads', outcomes: [] },
                    btts: { key: 'btts', outcomes: [] }
                }
            });
        }

        const match = matchMap.get(eventId);
        const selType = (odd.selection_type || '').toLowerCase();
        const selection = (odd.selection || '').trim();
        const price = Number(odd.odds_decimal) || 1.90;

        // Moneyline / 1X2 -> h2h
        if (marketTypeRaw === 'moneyline' || marketTypeRaw === 'h2h' || marketTypeRaw === 'match_winner') {
            let outcomeName = selection;
            if (selType === 'home' || outcomeName === match.home_team) outcomeName = match.home_team;
            else if (selType === 'away' || outcomeName === match.away_team) outcomeName = match.away_team;
            else if (selType === 'draw' || outcomeName.toLowerCase() === 'draw') outcomeName = 'Draw';

            const existing = match._markets.h2h.outcomes.find(o => o.name === outcomeName);
            if (!existing) {
                match._markets.h2h.outcomes.push({ name: outcomeName, price });
            } else {
                existing.price = Math.max(existing.price, price); // Consolidate best price
            }
        }
        // Totals (Over / Under)
        else if (marketTypeRaw === 'totals' || marketTypeRaw === 'total_goals' || marketTypeRaw === 'total_points' || marketTypeRaw === 'total') {
            const line = odd.line != null ? ` ${odd.line}` : ' 2.5';
            const name = selType === 'over' || selection.toLowerCase().startsWith('over') ? `Over${line}` : `Under${line}`;
            const existing = match._markets.totals.outcomes.find(o => o.name === name);
            if (!existing) {
                match._markets.totals.outcomes.push({ name, price });
            } else {
                existing.price = Math.max(existing.price, price);
            }
        }
        // Point Spreads
        else if (marketTypeRaw === 'spreads' || marketTypeRaw === 'point_spread' || marketTypeRaw === 'spread') {
            const lineStr = odd.line != null ? (odd.line > 0 ? ` +${odd.line}` : ` ${odd.line}`) : '';
            const name = `${selection}${lineStr}`;
            const existing = match._markets.spreads.outcomes.find(o => o.name === name);
            if (!existing) {
                match._markets.spreads.outcomes.push({ name, price });
            } else {
                existing.price = Math.max(existing.price, price);
            }
        }
        // Both Teams to Score (BTTS)
        else if (marketTypeRaw === 'btts' || marketTypeRaw === 'both_teams_to_score') {
            const name = selType === 'yes' || selection.toLowerCase() === 'yes' ? 'Yes' : 'No';
            const existing = match._markets.btts.outcomes.find(o => o.name === name);
            if (!existing) {
                match._markets.btts.outcomes.push({ name, price });
            } else {
                existing.price = Math.max(existing.price, price);
            }
        }
    }

    const results = [];
    for (const match of matchMap.values()) {
        const markets = [];
        if (match._markets.h2h.outcomes.length > 0) {
            const sortedH2h = [];
            const homeOutcome = match._markets.h2h.outcomes.find(o => o.name === match.home_team);
            const drawOutcome = match._markets.h2h.outcomes.find(o => o.name === 'Draw');
            const awayOutcome = match._markets.h2h.outcomes.find(o => o.name === match.away_team);

            if (homeOutcome) sortedH2h.push(homeOutcome);
            if (drawOutcome) sortedH2h.push(drawOutcome);
            if (awayOutcome) sortedH2h.push(awayOutcome);

            for (const o of match._markets.h2h.outcomes) {
                if (!sortedH2h.includes(o)) sortedH2h.push(o);
            }

            markets.push({ key: 'h2h', outcomes: sortedH2h });
        }

        if (match._markets.totals.outcomes.length > 0) {
            markets.push(match._markets.totals);
        }
        if (match._markets.spreads.outcomes.length > 0) {
            markets.push(match._markets.spreads);
        }
        if (match._markets.btts.outcomes.length > 0) {
            markets.push(match._markets.btts);
        }

        // If no h2h was parsed, provide reasonable fallback odds so bet buttons remain functional
        if (!markets.some(m => m.key === 'h2h')) {
            markets.unshift({
                key: 'h2h',
                outcomes: [
                    { name: match.home_team, price: 1.95 },
                    { name: 'Draw', price: 3.20 },
                    { name: match.away_team, price: 3.10 }
                ]
            });
        }

        results.push({
            id: match.id,
            sport_key: match.sport_key,
            sport_title: match.sport_title,
            home_team: match.home_team,
            away_team: match.away_team,
            is_live: match.is_live,
            live_time: match.live_time,
            score: match.score,
            commence_time: match.commence_time,
            bookmakers: [{
                title: match._bookmakerTitle || 'Betplace Bookmaker',
                markets: markets
            }]
        });
    }

    return results;
}

/**
 * Fetch list of active sports and featured categories
 */
async function getSportsList() {
    const now = Date.now();
    if (cache.sports.data && (now - cache.sports.timestamp < cache.sports.ttl)) {
        return cache.sports.data;
    }

    if (API_KEY) {
        try {
            const res = await fetch(`${SHARP_API_BASE}/sports`, {
                headers: {
                    'Accept': 'application/json',
                    'X-API-Key': API_KEY,
                    'Authorization': `Bearer ${API_KEY}`
                }
            });

            updateQuotaFromHeaders(res.headers);

            if (res.ok) {
                const body = await res.json();
                const sharpSports = Array.isArray(body.data) ? body.data : (Array.isArray(body) ? body : []);

                const list = [...MOCK_SPORTS];

                for (const s of sharpSports) {
                    const exists = list.some(item => item.key === s.id || item.group.toLowerCase() === s.name?.toLowerCase());
                    if (!exists && s.name) {
                        list.push({
                            key: s.id,
                            group: s.name,
                            title: s.name,
                            active: (s.event_count || 0) > 0,
                            icon: getSportEmoji(s.id),
                            event_count: s.event_count,
                            live_count: s.live_count
                        });
                    }
                }

                cache.sports.data = list;
                cache.sports.timestamp = now;
                return list;
            } else {
                console.warn(`[SharpAPI] /sports responded with status ${res.status}: ${res.statusText}`);
            }
        } catch (err) {
            console.warn('[SharpAPI] Failed to fetch sports from API, falling back to mock data:', err.message);
        }
    }

    cache.sports.data = MOCK_SPORTS;
    cache.sports.timestamp = now;
    return MOCK_SPORTS;
}

/**
 * Fetch matches & odds for a sport or league
 */
async function getOddsForSport(sportKey = 'soccer_epl') {
    const now = Date.now();
    const cacheKey = `odds_${sportKey}`;
    const cached = cache.odds.get(cacheKey);

    if (cached && (now - cached.timestamp < cache.oddsTtl)) {
        return cached.data;
    }

    if (API_KEY) {
        try {
            const mapping = SPORT_MAP[sportKey] || {};
            const sportParam = mapping.sport || (sportKey !== 'all' ? sportKey : null);
            const leagueParam = mapping.league || null;

            const oddsUrl = new URL(`${SHARP_API_BASE}/odds`);
            oddsUrl.searchParams.set('market', 'moneyline,both_teams_to_score,total_goals,total_points,point_spread');
            oddsUrl.searchParams.set('limit', '100');
            if (sportParam) oddsUrl.searchParams.set('sport', sportParam);
            if (leagueParam) oddsUrl.searchParams.set('league', leagueParam);

            const eventsUrl = new URL(`${SHARP_API_BASE}/events`);
            eventsUrl.searchParams.set('status', 'upcoming,live');
            eventsUrl.searchParams.set('limit', '50');
            if (sportParam) eventsUrl.searchParams.set('sport', sportParam);
            if (leagueParam) eventsUrl.searchParams.set('league', leagueParam);

            const headers = {
                'Accept': 'application/json',
                'X-API-Key': API_KEY,
                'Authorization': `Bearer ${API_KEY}`
            };

            const [oddsRes, eventsRes] = await Promise.all([
                fetch(oddsUrl.toString(), { headers }),
                fetch(eventsUrl.toString(), { headers }).catch(() => null)
            ]);

            updateQuotaFromHeaders(oddsRes.headers);

            if (oddsRes.ok) {
                const oddsJson = await oddsRes.json();
                const eventsJson = eventsRes && eventsRes.ok ? await eventsRes.json() : null;

                const oddsRows = Array.isArray(oddsJson.data) ? oddsJson.data : (Array.isArray(oddsJson) ? oddsJson : []);
                const eventsList = eventsJson && Array.isArray(eventsJson.data) ? eventsJson.data : [];

                let transformedMatches = transformSharpDataToMatches(oddsRows, eventsList, sportKey);

                // If specific league has few matches, fetch broad sport matches (e.g. general soccer)
                if (transformedMatches.length === 0 && sportParam && leagueParam) {
                    const fallbackUrl = new URL(`${SHARP_API_BASE}/odds`);
                    fallbackUrl.searchParams.set('market', 'moneyline,both_teams_to_score,total_goals,total_points,point_spread');
                    fallbackUrl.searchParams.set('sport', sportParam);
                    fallbackUrl.searchParams.set('limit', '50');

                    const fallbackRes = await fetch(fallbackUrl.toString(), { headers }).catch(() => null);
                    if (fallbackRes && fallbackRes.ok) {
                        updateQuotaFromHeaders(fallbackRes.headers);
                        const fallbackJson = await fallbackRes.json();
                        const fallbackRows = Array.isArray(fallbackJson.data) ? fallbackJson.data : [];
                        transformedMatches = transformSharpDataToMatches(fallbackRows, eventsList, sportKey);
                    }
                }

                if (transformedMatches.length > 0) {
                    cache.odds.set(cacheKey, { data: transformedMatches, timestamp: now });
                    return transformedMatches;
                }
            } else {
                console.warn(`[SharpAPI] Odds request for ${sportKey} returned status ${oddsRes.status}`);
            }
        } catch (err) {
            console.warn(`[SharpAPI] Failed to fetch odds for ${sportKey}, using mock fallback:`, err.message);
        }
    }

    const mockData = generateMockMatches(sportKey === 'all' ? null : sportKey);
    cache.odds.set(cacheKey, { data: mockData, timestamp: now });
    return mockData;
}

/**
 * Fetch live in-play matches
 */
async function getLiveMatches() {
    const now = Date.now();
    if (cache.live.data && (now - cache.live.timestamp < cache.live.ttl)) {
        return cache.live.data;
    }

    if (API_KEY) {
        try {
            const headers = {
                'Accept': 'application/json',
                'X-API-Key': API_KEY,
                'Authorization': `Bearer ${API_KEY}`
            };

            const oddsUrl = new URL(`${SHARP_API_BASE}/odds`);
            oddsUrl.searchParams.set('live', 'true');
            oddsUrl.searchParams.set('limit', '100');

            const eventsUrl = new URL(`${SHARP_API_BASE}/events`);
            eventsUrl.searchParams.set('live', 'true');
            eventsUrl.searchParams.set('limit', '50');

            const [oddsRes, eventsRes] = await Promise.all([
                fetch(oddsUrl.toString(), { headers }),
                fetch(eventsUrl.toString(), { headers }).catch(() => null)
            ]);

            updateQuotaFromHeaders(oddsRes.headers);

            if (oddsRes.ok) {
                const oddsJson = await oddsRes.json();
                const eventsJson = eventsRes && eventsRes.ok ? await eventsRes.json() : null;

                const oddsRows = Array.isArray(oddsJson.data) ? oddsJson.data : [];
                const eventsList = eventsJson && Array.isArray(eventsJson.data) ? eventsJson.data : [];

                const matches = transformSharpDataToMatches(oddsRows, eventsList, 'all');
                const liveMatches = matches.filter(m => m.is_live);
                if (liveMatches.length > 0) {
                    cache.live.data = liveMatches;
                    cache.live.timestamp = now;
                    return liveMatches;
                }
            }
        } catch (err) {
            console.warn('[SharpAPI] Failed to fetch live matches, falling back to mock:', err.message);
        }
    }

    const allMatches = generateMockMatches(null);
    const liveMatches = allMatches.filter(m => m.is_live);
    cache.live.data = liveMatches;
    cache.live.timestamp = now;
    return liveMatches;
}

export default async function sportsHandler(req, res) {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const pathname = url.pathname;
    const method = req.method;

    // ── 1. GET /api/sports/list or /api/sports ────────────────────────────────────
    if ((method === 'GET' || method === 'HEAD') && (pathname === '/' || pathname === '/list' || pathname === '/sports')) {
        try {
            const sports = await getSportsList();
            return res.status(200).json({
                success: true,
                provider: 'SharpAPI',
                sports,
                quota: cache.quota
            });
        } catch (err) {
            return res.status(500).json({ success: false, error: err.message });
        }
    }

    // ── 2. GET /api/sports/odds ───────────────────────────────────────────────────
    if ((method === 'GET' || method === 'HEAD') && pathname === '/odds') {
        try {
            const sport = url.searchParams.get('sport') || 'soccer_epl';
            const odds = await getOddsForSport(sport);
            return res.status(200).json({
                success: true,
                provider: 'SharpAPI',
                sport,
                count: odds.length,
                matches: odds,
                quota: cache.quota
            });
        } catch (err) {
            return res.status(500).json({ success: false, error: err.message });
        }
    }

    // ── 3. GET /api/sports/live ───────────────────────────────────────────────────
    if ((method === 'GET' || method === 'HEAD') && pathname === '/live') {
        try {
            const liveMatches = await getLiveMatches();
            return res.status(200).json({
                success: true,
                provider: 'SharpAPI',
                count: liveMatches.length,
                matches: liveMatches,
                quota: cache.quota
            });
        } catch (err) {
            return res.status(500).json({ success: false, error: err.message });
        }
    }

    // ── 4. GET /api/sports/usage or /api/sports/quota ─────────────────────────────
    if ((method === 'GET' || method === 'HEAD') && (pathname === '/usage' || pathname === '/quota')) {
        try {
            if (API_KEY) {
                try {
                    const usageRes = await fetch(`${SHARP_API_BASE}/account/usage`, {
                        headers: {
                            'Accept': 'application/json',
                            'X-API-Key': API_KEY,
                            'Authorization': `Bearer ${API_KEY}`
                        }
                    });
                    if (usageRes.ok) {
                        const usageData = await usageRes.json();
                        return res.status(200).json({
                            success: true,
                            provider: 'SharpAPI',
                            usage: usageData.data || usageData,
                            quota: cache.quota
                        });
                    }
                } catch (_) {
                    // Fall back to cached quota
                }
            }
            return res.status(200).json({
                success: true,
                provider: 'SharpAPI',
                quota: cache.quota
            });
        } catch (err) {
            return res.status(500).json({ success: false, error: err.message });
        }
    }

    // ── 5. POST /api/sports/bet (Place Sports Bet) ────────────────────────────────
    if (method === 'POST' && pathname === '/bet') {
        const auth = await verifyAuthToken(req);
        if (!auth.success) {
            return res.status(auth.status).json({ success: false, error: auth.error });
        }

        const { stake, totalOdds, potentialPayout, betType, selections } = req.body || {};

        const numStake = parseFloat(stake);
        const numOdds = parseFloat(totalOdds);
        const numPayout = parseFloat(potentialPayout);
        const type = betType === 'accumulator' ? 'accumulator' : 'single';
        const config = await getSportsbookConfig();
        if (config.enabled === false) {
            return res.status(400).json({ success: false, error: 'Sports betting is temporarily suspended for maintenance.' });
        }
        const minStake = config.minStake || 10;
        const maxStake = config.maxStake || 50000;
        const maxPayout = config.maxPayout || 1000000;

        if (!numStake || isNaN(numStake) || numStake < minStake) {
            return res.status(400).json({ success: false, error: `Minimum stake is ${minStake} KES.` });
        }

        if (numStake > maxStake) {
            return res.status(400).json({ success: false, error: `Maximum stake allowed is ${maxStake} KES.` });
        }

        if (numPayout > maxPayout) {
            return res.status(400).json({ success: false, error: `Potential payout exceeds platform maximum limit of ${maxPayout} KES.` });
        }

        if (!numOdds || isNaN(numOdds) || numOdds < 1.01) {
            return res.status(400).json({ success: false, error: 'Invalid odds.' });
        }

        if (!Array.isArray(selections) || selections.length === 0) {
            return res.status(400).json({ success: false, error: 'At least one match selection is required.' });
        }

        try {
            const { rows } = await query(
                'SELECT place_sports_bet($1, $2, $3, $4, $5, $6) AS result',
                [auth.user.id, numStake, numOdds, numPayout, type, JSON.stringify(selections)]
            );

            const result = rows[0]?.result;
            if (!result || !result.success) {
                return res.status(400).json(result || { success: false, error: 'Failed to place sports bet.' });
            }

            return res.status(200).json({
                success: true,
                message: 'Bet placed successfully!',
                betId: result.betId,
                newBalance: result.newBalance,
                stake: result.stake,
                totalOdds: result.totalOdds,
                potentialPayout: result.potentialPayout
            });
        } catch (err) {
            console.error('[Sports Bet Error]:', err.message);
            return res.status(500).json({ success: false, error: err.message });
        }
    }

    // ── 6. GET /api/sports/my-bets ────────────────────────────────────────────────
    if (method === 'GET' && (pathname === '/my-bets' || pathname === '/bets')) {
        const auth = await verifyAuthToken(req);
        if (!auth.success) {
            return res.status(auth.status).json({ success: false, error: auth.error });
        }

        const filterStatus = url.searchParams.get('status'); // 'all', 'pending', 'settled'

        try {
            let sql = 'SELECT * FROM sports_bets WHERE user_id = $1';
            const params = [auth.user.id];

            if (filterStatus === 'pending') {
                sql += " AND status = 'pending'";
            } else if (filterStatus === 'settled') {
                sql += " AND status IN ('won', 'lost', 'cashed_out', 'cancelled')";
            }

            sql += ' ORDER BY created_at DESC LIMIT 50';

            const { rows } = await query(sql, params);
            return res.status(200).json({
                success: true,
                count: rows.length,
                bets: rows
            });
        } catch (err) {
            console.error('[My Bets Error]:', err.message);
            return res.status(500).json({ success: false, error: err.message });
        }
    }

    // ── 7. POST /api/sports/cashout ───────────────────────────────────────────────
    if (method === 'POST' && pathname === '/cashout') {
        const auth = await verifyAuthToken(req);
        if (!auth.success) {
            return res.status(auth.status).json({ success: false, error: auth.error });
        }

        const { betId, cashoutAmount } = req.body || {};
        if (!betId || !cashoutAmount) {
            return res.status(400).json({ success: false, error: 'Bet ID and cashout amount are required.' });
        }

        try {
            const { rows } = await query(
                'SELECT cash_out_sports_bet($1, $2, $3) AS result',
                [auth.user.id, betId, parseFloat(cashoutAmount)]
            );

            const result = rows[0]?.result;
            return res.status(result?.success ? 200 : 400).json(result);
        } catch (err) {
            console.error('[Cashout Error]:', err.message);
            return res.status(500).json({ success: false, error: err.message });
        }
    }

    return res.status(404).json({ error: 'Endpoint not found in sports API.' });
}
