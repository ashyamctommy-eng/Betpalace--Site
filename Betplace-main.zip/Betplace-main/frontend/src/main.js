
function traceEngineEvent(eventName, meta = {}) {
    const timestamp = new Date().toISOString().substring(11, 23);
    const p1State = typeof sm1 !== 'undefined' ? sm1.state : 'N/A';
    const p1Round = typeof sm1 !== 'undefined' ? sm1.roundId : 'N/A';
    const p2State = typeof sm2 !== 'undefined' ? sm2.state : 'N/A';
    const p2Round = typeof sm2 !== 'undefined' ? sm2.roundId : 'N/A';
    const sRound = typeof serverRoundId !== 'undefined' ? serverRoundId : 'N/A';
    const gState = typeof gameState !== 'undefined' ? gameState : 'N/A';
    
    console.log(`[ENGINE-TRACE] [${timestamp}] [${eventName.padEnd(26)}] sR#${sRound} (${gState.padEnd(7)}) | P1: ${p1State}(${p1Round}) | P2: ${p2State}(${p2Round}) | Meta: ${JSON.stringify(meta)}`);
}

/**
 * METRICWIN | AVIATOR ELITE
 * Core Game Engine (Unified & Secure)
 */

import { supabase } from './config/supabase.js';
import { injectVercelAnalytics } from './utils/analytics.js';
import { initGuard } from './utils/routeGuard.js';
import { BetStateMachine, BetState } from './utils/betStateMachine.js';
import { showToast } from './utils/toast.js';
import { haptic } from './utils/haptics.js';
import { initAudio } from './utils/audio.js';
import { escapeHTML } from './utils/formatters.js';
import { closeModal } from './modules/ui/modals.js';
import { initCanvas } from './modules/game/gameEngine.js';
import { generateSimulatedBetsForRound, getActivePlayersBadgeValue } from './modules/game/botSimulator.js';
import { gameBridge } from './modules/game/gameBridge.js';
import { registerServiceWorker, initPwaInstaller, requestPushPermission, triggerTestPushNotification, triggerPwaInstall } from './modules/pwaManager.js';
import { startGameLoop } from './modules/game/gameLoop.js';
import { initDebugPanel } from './modules/game/debugPanel.js';
import { showNotFound } from './utils/notFound.js';

injectVercelAnalytics();

// ── STATE ──────────────────────────────────────────────────────────────────

const urlParams = new URL(window.location.href).searchParams;
const isDemoMode = urlParams.get('mode') === 'demo' || urlParams.get('demo') === 'true' || window.location.hostname.startsWith('demo.');
const IS_PREDICTOR_SUBDOMAIN = window.location.hostname.startsWith('predictor.');


let balance = 0;
let currentUser = null;
let gameState = 'waiting'; // 'waiting' | 'playing' | 'crashed'
let currentMultiplier = 1.0;
let serverTimeOffset = 0;
let serverRoundStartTime = 0;
let serverCrashPoint = 0;
let serverRoundId = 0;
let serverGameStatus = 'waiting';

window.cachedFinancialLimits = {
    minDeposit: 99,
    maxDeposit: 300000,
    minBetAviator: 10,
    maxBetAviator: 50000
};

export async function loadFinancialLimits() {
    try {
        const res = await fetch('/api/wallet/config');
        const data = await res.json();
        if (data && data.success) {
            window.cachedFinancialLimits = {
                minDeposit: Number(data.minDeposit || 99),
                maxDeposit: Number(data.maxDeposit || 300000),
                minBetAviator: Number(data.minBetAviator || 10),
                maxBetAviator: Number(data.maxBetAviator || 50000)
            };
            updateDepositNotices();
        }
    } catch (_) {}
}
loadFinancialLimits();

export function updateDepositNotices() {
    const minDep = window.cachedFinancialLimits?.minDeposit || 99;
    const depNotice = document.getElementById('metricwinDepNotice');
    if (depNotice) {
        depNotice.textContent = `Minimum KES ${minDep}. All transactions are subject to 5% tax.`;
    }
    const depInput = document.getElementById('metricwinDepAmount');
    if (depInput) {
        depInput.min = String(minDep);
    }
}

// Keep wallet balance & limits synchronous when switching between Sports Betting and Aviator
document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
        if (typeof refreshBalance === 'function') refreshBalance();
        loadFinancialLimits();
    }
});
window.addEventListener('focus', () => {
    if (typeof refreshBalance === 'function') refreshBalance();
    loadFinancialLimits();
});
window.addEventListener('storage', (e) => {
    if (e.key === 'metrowins_balance_sync' || e.key === 'metrowins_user_balance') {
        if (typeof refreshBalance === 'function') refreshBalance();
    }
});
window.addEventListener('balance_updated', (e) => {
    if (e.detail?.balance !== undefined && !isDemoMode) {
        balance = Number(e.detail.balance);
        updateUI();
        const balanceBox = document.getElementById('metricwinBalanceBox');
        if (balanceBox) balanceBox.textContent = `KES ${Math.floor(balance).toLocaleString()}`;
    } else if (typeof refreshBalance === 'function') {
        refreshBalance();
    }
});

// Periodic wallet balance poll every 5 seconds when visible
setInterval(() => {
    if (!isDemoMode && currentUser && document.visibilityState === 'visible') {
        if (typeof refreshBalance === 'function') refreshBalance();
    }
}, 5000);

/**
 * Stable local timestamp capturing the moment the FLYING phase began.
 * Set once per round in launchRound(); NEVER overwritten by poll updates.
 * gameTick() reads this instead of serverRoundStartTime to prevent the
 * 1500ms poll from resetting elapsed time to ~0 mid-flight.
 */
let localFlyStartMs = 0;

/**
 * Deduplication key for server events.
 * Format: "roundId:status". Prevents double round transitions from
 * realtime + poll firing simultaneously (Root Cause #5 fix).
 */
let lastEventKey = '';

// Authoritative flight-time tracking: use server elapsedMs + client delta
let serverFlightElapsedAtPoll = 0;  // elapsedMs reported by server at last poll
let serverPollTimestamp = 0;         // local Date.now() when that poll response arrived

let bet1 = { id: null, amount: 50, active: false, cashed: false, auto: false, winnings: 0, cashoutPending: false, placedByAuto: false };
let bet2 = { id: null, amount: 50, active: false, cashed: false, auto: false, winnings: 0, cashoutPending: false, placedByAuto: false };

let sm1 = new BetStateMachine(1, (fsm) => { syncUIFromStateMachine(1); });
let sm2 = new BetStateMachine(2, (fsm) => { syncUIFromStateMachine(2); });

// Auto-bet strategies configurations
let autoConfig1 = {
    active: false,
    baseAmount: 10,
    roundsRemaining: 0,
    enableAutoCash: true,
    autoCashVal: 2.0,
    lossStrategy: 'flat', // 'flat' | 'martingale' | 'custom'
    lossFactor: 2.0,
    winStrategy: 'flat',  // 'flat' | 'martingale' | 'custom'
    winFactor: 2.0,
    profitTarget: null,
    lossLimit: null,
    startBalance: 0,
    accumulatedProfit: 0
};

let autoConfig2 = {
    active: false,
    baseAmount: 10,
    roundsRemaining: 0,
    enableAutoCash: true,
    autoCashVal: 2.0,
    lossStrategy: 'flat',
    lossFactor: 2.0,
    winStrategy: 'flat',
    winFactor: 2.0,
    profitTarget: null,
    lossLimit: null,
    startBalance: 0,
    accumulatedProfit: 0
};

let crashHistory = [];
let allBets = [];
let recentWinners = [];
let livePlayerCount = 0;
let currentLobbyCount = 2000;
let animationFrameId = null;
let graphPoints = [];
let particles = [];
let muted = false;

const namesPool = [
    'AlphaJet', 'LuckyAviator', 'StakeMaster', 'AirCorsair', 'SafarFlyer', 
    'KenyaEagle', 'Hustler001', 'AviatorGod', 'PesaSpins', 'Supersonic', 
    'SkyWalker', 'NairobiBet', 'MpesaKing', 'ApexPredator', 'TurboGamer', 
    'CloudNine', 'VelocityX', 'JackpotFinder', 'FalconWin', 'DeltaForce',
    'RichPilot', 'BetMaster', 'FlyHigh_99', 'JetDrifter', 'CaptainJack',
    'KenyenJet', 'AirWave', 'Altitude', 'VortexPilot', 'SkyCruiser',
    'ZenithWager', 'NeroFlyer', 'GigaStake', 'Zephyr', 'PesaRider',
    'SonicBoom', 'LiftOff', 'TurboSpin', 'QuantumFly', 'AeroWinner',
    'Stratosphere', 'Mach1', 'AirKing', 'FlyVip', 'SkyLord',
    'HorizonChaser', 'CruxStar', 'NairobiWind', 'M-Spins', 'JetSetter'
];

const avatarsPool = [
    { bg: 'linear-gradient(135deg, #1e3a8a, #3b82f6)', label: '🪐' },
    { bg: 'linear-gradient(135deg, #78350f, #f59e0b)', label: '🦁' },
    { bg: 'linear-gradient(135deg, #111827, #374151)', label: '👤' },
    { bg: 'linear-gradient(135deg, #4c1d95, #8b5cf6)', label: '🦊' },
    { bg: 'linear-gradient(135deg, #064e3b, #10b981)', label: '🦅' },
    { bg: 'linear-gradient(135deg, #134e5e, #06b6d4)', label: '🐯' },
    { bg: 'linear-gradient(135deg, #581c87, #d946ef)', label: '🪐' },
    { bg: 'linear-gradient(135deg, #7c2d12, #ea580c)', label: '🐱' },
    { bg: 'linear-gradient(135deg, #0f172a, #1e293b)', label: '👤' }
];

// Bot simulator functions are imported from ./modules/game/botSimulator.js

// Configuration
const COUNTDOWN_DURATION = 5000;
const TICK_INCREMENT = 0.02;

// ── INITIALIZATION ─────────────────────────────────────────────────────────

window.addEventListener('load', async () => {
    applyThemeMode(localStorage.getItem('theme_mode') || 'dark');
    initAudio();
    initCanvas();
    await bootSequence();
    bindEvents();
    startServerSyncLoop();
    registerServiceWorker();
    initPwaInstaller();

    window.requestPushPermission = requestPushPermission;
    window.triggerTestPushNotification = triggerTestPushNotification;
    window.triggerPwaInstall = triggerPwaInstall;
    
    // Initialize Second Bet Panel visibility
    const showCard2 = localStorage.getItem('show_card_2') !== 'false';
    window.toggleCard2(showCard2);
    
    // Periodically fluctuate online counter dynamically
    setInterval(() => {
        if (gameState === 'playing' || gameState === 'waiting') {
            const delta = Math.floor(Math.random() * 31) - 15;
            currentLobbyCount = Math.max(1200, Math.min(3200, currentLobbyCount + delta));
            const badgeCount = document.getElementById('livePlayerCount');
            if (badgeCount) badgeCount.textContent = currentLobbyCount.toLocaleString();
        }
    }, 3000);
});

async function bootSequence() {
    if (isDemoMode) {
        currentUser = {
            id: 'demo-user-id',
            username: 'DemoPlayer',
            phone: '+254700000000',
            email: 'demo@metricwin.com',
            role: 'Demo'
        };
        balance = localStorage.getItem('demo_balance') ? parseFloat(localStorage.getItem('demo_balance')) : 10000.00;

        let history = null;
        try {
            const saved = localStorage.getItem('demo_crash_history');
            if (saved) {
                const parsed = JSON.parse(saved);
                if (Array.isArray(parsed) && parsed.length > 0) {
                    history = parsed.map(v => parseFloat(v));
                }
            }
        } catch (_) {}

        if (!history) {
            try {
                const { data } = await supabase
                    .from('game_history')
                    .select('multiplier')
                    .order('created_at', { ascending: false })
                    .limit(20);
                if (data && data.length > 0) {
                    history = data.map(h => parseFloat(h.multiplier));
                }
            } catch (e) {
                console.warn("Could not fetch game history directly:", e);
            }
        }
        
        if (history && history.length > 0) {
            crashHistory = history;
        } else {
            crashHistory = [2.45, 1.12, 5.67, 1.34, 1.89, 45.2, 1.05, 3.22, 1.5, 2.1, 1.11, 7.82, 1.25, 1.9, 1.02, 12.0, 1.45, 2.3, 1.64, 3.1];
        }

        updateUI();
        renderTicker();
        renderAllBets();
        togglePredictorMode(false, true);

        // Hide app loading screen overlay in demo mode
        const loader = document.getElementById('app-loading-screen');
        if (loader) {
            loader.style.transition = 'opacity 0.25s ease';
            loader.style.opacity = '0';
            setTimeout(() => loader.remove(), 250);
        }

        return;
    }

    const authorized = await initGuard();
    if (!authorized) return;

    const { data: { session } } = await supabase.auth.getSession();

    const { data: profile, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', session.user.id)
        .single();

    if (error || !profile) {
        console.warn("Profile table record not found, healing dynamically...", error);
        
        const fallbackPhone = session.user.phone || session.user.user_metadata?.phone || '+254700000000';
        const fallbackUsername = session.user.user_metadata?.username || (session.user.phone ? session.user.phone : (session.user.email ? session.user.email.split('@')[0] : 'Player'));
        
        const newProfile = {
            id:          session.user.id,
            username:    fallbackUsername,
            phone:       fallbackPhone,
            email:       session.user.email || 'player@metricwin.com',
            balance:     0,
            role:        'User'
        };

        const { data: createdProfile, error: createError } = await supabase
            .from('profiles')
            .upsert(newProfile)
            .select()
            .single();

        if (createError) {
            console.error("Failed to auto-heal missing profile record:", createError);
            currentUser = {
                id: session.user.id,
                ...newProfile,
                created_at: session.user.created_at || new Date().toISOString()
            };
            balance = 0;
        } else {
            console.log("Successfully created and healed profile record:", createdProfile);
            currentUser = {
                ...session.user,
                ...createdProfile,
                phone: createdProfile.phone || fallbackPhone
            };
            balance = parseFloat(createdProfile.balance || 0);
        }
    } else {
        currentUser = {
            ...session.user,
            ...profile,
            phone: profile.phone || session.user.phone || session.user.user_metadata?.phone || '+254700000000'
        };
        balance = parseFloat(profile.balance || 0);
    }
    
    // ── Predictor subdomain: predictor.metricwins.com ─────────────────────────
    // Must be authorized (Predictor / Admin / Super Admin).
    // Unauthorized users — logged in or not — see ERR_NAME_NOT_RESOLVED.
    if (IS_PREDICTOR_SUBDOMAIN) {
        if (!currentUser || !['Predictor', 'Admin', 'Super Admin'].includes(currentUser.role)) {
            showNotFound();
            return;
        }
        // Authorized: auto-activate predictor panel immediately on predictor subdomain
        togglePredictorMode(true, true);
        return;
    }

    // ── Aviator Game Subdomain / Standard Domains ─────────────────────────────
    // On game subdomains (aviator.metricwins.com), default to the Aviator game UI.
    // Only switch to Predictor mode if explicitly requested in URL (?predictor=true or #predictor).
    const isExplicitPredictorURL = (urlParams.get('predictor') === 'true') || window.location.hash.includes('predictor');
    const isPredictorAuthorized = currentUser && ['Predictor', 'Admin', 'Super Admin'].includes(currentUser.role);

    if (isExplicitPredictorURL && isPredictorAuthorized) {
        togglePredictorMode(true, true);
    } else {
        localStorage.setItem('isPredictorModeActive', 'false');
        togglePredictorMode(false, true);
    }


    

    // Load history — ordered by id DESC (not created_at) to avoid millisecond-resolution race conditions
    const { data: history } = await supabase
        .from('game_history')
        .select('multiplier')
        .order('id', { ascending: false })
        .limit(20);
    
    if (history) crashHistory = history.map(h => parseFloat(h.multiplier));

    updateUI();
    renderTicker();
    renderAllBets();

    // Subscribe to realtime balance updates on user profile for instant updates everywhere
    supabase
        .channel(`profile_balance_${currentUser.id}`)
        .on(
            'postgres_changes',
            { event: 'UPDATE', schema: 'public', table: 'profiles', filter: `id=eq.${currentUser.id}` },
            (payload) => {
                if (payload.new && typeof payload.new.balance !== 'undefined') {
                    balance = parseFloat(payload.new.balance);
                    updateUI();
                }
            }
        )
        .subscribe();

    // Render Admin/Super Admin links in navigation drawer dynamically if authorized
    const authDrawer = document.getElementById('navDrawer');
    if (authDrawer && currentUser) {
        const drawerNav = authDrawer.querySelector('nav.drawer-content');
        if (drawerNav && !document.getElementById('adminDrawerBtn') && !document.getElementById('superAdminDrawerBtn')) {
            const logoutItem = drawerNav.querySelector('.logout-item');
            
            // If they are a Super Admin
            if (currentUser.role === 'Super Admin') {
                const superAdminBtn = document.createElement('button');
                superAdminBtn.className = 'drawer-item';
                superAdminBtn.id = 'superAdminDrawerBtn';
                superAdminBtn.onclick = () => window.handleDrawerAction('super-admin');
                superAdminBtn.innerHTML = `
                    <i data-lucide="shield-alert" class="item-icon" style="color: #3B82F6;"></i>
                    <span style="font-weight: 700; color: #3B82F6;">Super Admin</span>
                `;
                drawerNav.insertBefore(superAdminBtn, logoutItem);
            } else if (currentUser.is_admin || currentUser.role === 'Admin') {
                // If they are a standard Admin
                const adminBtn = document.createElement('button');
                adminBtn.className = 'drawer-item';
                adminBtn.id = 'adminDrawerBtn';
                adminBtn.onclick = () => window.handleDrawerAction('admin');
                adminBtn.innerHTML = `
                    <i data-lucide="shield" class="item-icon" style="color: #3B82F6;"></i>
                    <span style="font-weight: 700; color: #3B82F6;">Admin Panel</span>
                `;
                drawerNav.insertBefore(adminBtn, logoutItem);
            }

            // Expose predictor button if authorized
            if (['Predictor', 'Admin', 'Super Admin'].includes(currentUser.role)) {
                const topbarBtn = document.getElementById('predictorTopbarBtn');
                if (topbarBtn) topbarBtn.classList.remove('hidden');

                if (!document.getElementById('predictorDrawerBtn')) {
                    const predictorBtn = document.createElement('button');
                    predictorBtn.className = 'drawer-item';
                    predictorBtn.id = 'predictorDrawerBtn';
                    predictorBtn.onclick = () => {
                        window.toggleSidebarMenu();
                        window.togglePredictorMode(true);
                    };
                    predictorBtn.innerHTML = `
                        <i data-lucide="zap" class="item-icon" style="color: #a855f7;"></i>
                        <span style="font-weight: 700; color: #a855f7;">Predictor Panel</span>
                    `;
                    drawerNav.insertBefore(predictorBtn, logoutItem);
                }

            }
            
            // Refresh lucide icons if present
            if (window.lucide) {
                window.lucide.createIcons();
            }
        }
    }

    // Initialize dynamic notifications system
    if (typeof window.initNotificationsRealtime === 'function') {
        window.initNotificationsRealtime();
    }

    // Reopen active tab if page reloaded with hash route
    const hash = window.location.hash;
    const tabName = hash.replace('#/', '').replace('#', '').split('?')[0];
    const validTabs = ['deposit', 'withdraw', 'profile', 'transactions', 'support', 'password', 'community', 'promotions', 'promocode', 'referrals'];
    if (tabName && validTabs.includes(tabName)) {
        const backdrop = document.getElementById('modalBackdrop');
        if (backdrop) backdrop.classList.add('show');
        renderProfileTab(tabName);
    }
}

// ── SERVER SYNC ─────────────────────────────────────────────────────────────

async function fetchServerState() {
    try {
        // Measure request start time for RTT-compensated clock sync
        const pollSentAt = Date.now();

        // Try calling the direct Supabase Serverless loop RPC first
        const { data: rpcData, error: rpcErr } = await supabase.rpc('sync_and_get_game_state');
        let data = rpcData;

        if (rpcErr || !data || data.error) {
            console.warn("Direct RPC loop offline, falling back to REST API via Cloudflare Worker proxy...", rpcErr);
            const url = import.meta.env.VITE_GAME_STATE_URL || '/api/game';
            const headers = {};
            try {
                const { data: { session } } = await supabase.auth.getSession();
                if (session?.access_token) {
                    headers['Authorization'] = `Bearer ${session.access_token}`;
                }
            } catch (_) {}

            const res = await fetch(url, { headers });
            data = await res.json();
            
            // If API returns error or missing roundId, fallback to deterministic round calculation:
            if (!data || data.error || (typeof data.roundId === 'undefined' && typeof data.round_id === 'undefined')) {
                const ROUND_DURATION = 60000;
                const now = Date.now();
                const windowStart = Math.floor(now / ROUND_DURATION);
                const roundId = windowStart;

                // Deterministic pseudo-random crash point based on roundId (stays constant for the round)
                let seed = (roundId * 9301 + 49297) % 233280;
                let rnd = seed / 233280;
                
                let fallbackCrashPoint = data?.crashPoint || data?.crash_point;
                if (!fallbackCrashPoint) {
                    if (rnd < 0.10) {
                        fallbackCrashPoint = 1.00;
                    } else if (rnd < 0.40) {
                        fallbackCrashPoint = parseFloat((1.01 + ((rnd * 10) % 1) * 0.79).toFixed(2));
                    } else if (rnd < 0.80) {
                        fallbackCrashPoint = parseFloat((1.80 + ((rnd * 100) % 1) * 5.20).toFixed(2));
                    } else if (rnd < 0.95) {
                        fallbackCrashPoint = parseFloat((7.00 + ((rnd * 1000) % 1) * 18.00).toFixed(2));
                    } else {
                        fallbackCrashPoint = parseFloat((25.00 + ((rnd * 10000) % 1) * 175.00).toFixed(2));
                    }
                }

                data = {
                    roundId: roundId,
                    roundStartTime: windowStart * ROUND_DURATION,
                    crashPoint: fallbackCrashPoint,
                    gameStatus: (now - (windowStart * ROUND_DURATION) < 5000) ? 'waiting' : 'playing',
                    serverTime: now
                };
            }
        }

        if (typeof data === 'string') {
            try { data = JSON.parse(data); } catch (_) {}
        }

        if (!data || typeof data !== 'object') return null;

        const pollReceivedAt = Date.now();

        // ── RTT-compensated clock correction ─────────────────────────────────
        // Parse server time — may be epoch ms (number) or ISO string (from realtime payloads)
        const rawSTime = data.serverTime ?? data.server_time ?? 0;
        let sTime = typeof rawSTime === 'string' ? new Date(rawSTime).getTime() : Number(rawSTime);
        if (!sTime || isNaN(sTime)) sTime = pollReceivedAt;

        // Network round-trip time: difference between sent and received
        const rtt = Math.max(0, pollReceivedAt - pollSentAt);
        // Measured offset corrected by half RTT (one-way latency estimate)
        const measuredOffset = sTime - pollReceivedAt + Math.round(rtt / 2);
        // Apply EWMA smoothing (α=0.20) to filter network jitter
        serverTimeOffset = Math.round(serverTimeOffset * 0.80 + measuredOffset * 0.20);

        const rStart = Number(data.roundStartTime ?? data.round_start_time ?? data.start_time) || pollReceivedAt;
        const cPoint = Number(data.crashPoint ?? data.crash_point) || 1.00;
        const rId = Number(data.roundId ?? data.round_id) || 1;
        const gStatus = String(data.gameStatus ?? data.status ?? 'waiting');

        // NOTE: serverRoundId is intentionally NOT updated here.
        // processServerEvent() owns all round-metadata updates via its
        // previousRoundId/serverRoundId pattern, which the STATE_RANK demotion
        // guard depends on to correctly distinguish same-round vs cross-round events.
        // Updating it here first would corrupt the previousRoundId capture inside
        // processServerEvent and cause new-round 'waiting' events to be discarded.
        serverRoundStartTime = rStart;
        serverCrashPoint = cPoint;
        serverGameStatus = gStatus;

        // Only overwrite local crash history from poll when NOT mid-flight.
        // During a live round the server's DB already contains the NEW crash point
        // before the plane visually crashes client-side, which would cause the
        // top ticker to spoil the outcome early.
        if (gameState !== 'playing') {
            const rawHistory = data.history;
            if (Array.isArray(rawHistory) && rawHistory.length > 0) {
                crashHistory = rawHistory.slice(0, 20).map(v => parseFloat(v));
            }
        }

        // Route through deduplication layer — prevents duplicate transitions
        // when poll and realtime both fire for the same state change.
        processServerEvent(data);
        
        return data;
    } catch (e) {
        console.error("Sync error", e);
        return null;
    }
}

/**
 * processServerEvent — Phase 3: Single deduplication entry point.
 *
 * ALL server state events (poll + realtime) must route through here.
 * A "roundId:status" key ensures each transition fires exactly once,
 * preventing double round starts and mid-flight resets (Root Cause #5 & #6).
 *
 * Also performs clock correction and normalises field names across
 * the three different payload shapes: RPC / REST API / Supabase Realtime.
 *
 * @param {object} raw - Raw payload from poll response or realtime event
 */
// State rank map: enforces unidirectional progression within a round.
const STATE_RANK = { waiting: 0, playing: 1, crashed: 2 };

function processServerEvent(raw) {
    traceEngineEvent("processServerEvent", { status: raw.status || raw.gameStatus, roundId: raw.round_id || raw.roundId });
    if (!raw || typeof raw !== 'object') return;

    // ── Normalise field names ───────────────────────────────────────────────
    const rawStatus = String(raw.status ?? raw.gameStatus ?? '').toLowerCase();
    const roundId   = Number(raw.round_id   ?? raw.roundId   ?? serverRoundId);

    // ── Parse server time: may be epoch ms OR ISO 8601 string ────────────────
    // Number(ISO_string) === NaN — always normalise to epoch ms before use.
    const rawSTime  = raw.server_time ?? raw.serverTime ?? 0;
    const sTime     = typeof rawSTime === 'string' ? new Date(rawSTime).getTime() : Number(rawSTime);

    const cPoint    = Number(raw.crash_point ?? raw.crashPoint ?? serverCrashPoint);
    const rStart    = raw.start_time
        ? new Date(raw.start_time).getTime()
        : Number(raw.roundStartTime ?? raw.round_start_time ?? serverRoundStartTime);

    if (!rawStatus) return;

    // ── Clock correction — only on realtime events (fetchServerState does its own EWMA) ─
    if (sTime > 0 && sTime !== serverTimeOffset + Date.now()) {
        gameBridge.serverTimeOffset = serverTimeOffset;
    }

    // ── Save previous roundId BEFORE updating, so the stale-event guard ──────
    // can correctly compare the incoming event's roundId against where we were.
    const previousRoundId = serverRoundId;

    // ── Always update round metadata ─────────────────────────────────────────
    if (roundId > 0) {
        serverRoundId = roundId;
        gameBridge.roundId = roundId;
    }
    serverCrashPoint      = cPoint;
    gameBridge.crashPoint = cPoint;
    if (rStart > 0) serverRoundStartTime = rStart;

    // ── Direct history sync from realtime payload (migration 036) ────────────
    const rawHistory = raw.history;
    if (rawHistory) {
        let hist = rawHistory;
        if (typeof hist === 'string') { try { hist = JSON.parse(hist); } catch (_) {} }
        if (Array.isArray(hist) && hist.length > 0) {
            const freshHistory = hist.slice(0, 20).map(v => parseFloat(v));
            // Only update history if we are not actively playing a round.
            // This prevents the server's DB update from spoiling the crash point
            // in the top ticker before the plane actually crashes on the user's screen.
            if (gameState !== 'playing') {
                if (freshHistory.length >= crashHistory.length || rawStatus === 'waiting') {
                    crashHistory = freshHistory;
                    renderTicker();
                }
            }
        }
    }

    // ── Out-of-order guard ────────────────────────────────────────────────────
    // Discard stale events from previous rounds entirely.
    // Use previousRoundId (saved before the update above) so this comparison
    // is meaningful — after the update, roundId always === serverRoundId.
    if (roundId < previousRoundId) {
        console.warn(`[GameSync] Discarding stale event for round #${roundId} (current #${previousRoundId})`);
        return;
    }

    // Within the SAME round, discard state demotions (e.g. playing → waiting).
    // IMPORTANT: compare roundId against previousRoundId, NOT serverRoundId.
    // serverRoundId has already been updated to the incoming roundId above,
    // so using it here would make every event appear same-round, causing
    // new-round 'waiting' events (crashed N → waiting N+1) to be wrongly
    // discarded as demotions.
    if (roundId === previousRoundId) {
        const currentRank  = STATE_RANK[gameState] ?? -1;
        const incomingRank = STATE_RANK[rawStatus] ?? -1;
        if (incomingRank < currentRank) {
            console.warn(`[GameSync] Discarding same-round demotion ${rawStatus} (client at ${gameState}, round #${roundId})`);
            return;
        }
    }

    // ── Deduplication: ignore events already processed this round ────────────
    const key = `${roundId}:${rawStatus}`;
    if (key === lastEventKey) return;
    lastEventKey = key;

    gameBridge.lastEventLabel = `${rawStatus} (R#${roundId})`;
    console.log(`[GameSync] → ${key}`);

    handleStatusChange(rawStatus);
}

function handleStatusChange(newStatus) {
    console.log(`[Telemetry] State transition received: ${newStatus} (Round #${serverRoundId})`);
    if (newStatus === 'waiting') {
        console.log('Received waiting / countdown');
        // If we jumped from 'playing' to 'waiting' without seeing 'crashed',
        // force a crash cleanup for the round that was missed.
        if (gameState === 'playing') {
            console.warn('[GameSync] Skipped crash event detected — forcing crash cleanup before new round.');
            crash();
        }
        startNewRound();
    } else if (newStatus === 'playing') {
        console.log('Received round_started / flight_started');
        const nowSynced = Date.now() + serverTimeOffset;
        if (serverRoundStartTime > nowSynced) {
            serverRoundStartTime = nowSynced;
        }
        if (gameState !== 'playing') {
            launchRound();
        }
    } else if (newStatus === 'crashed') {
        console.log('Received crash / round_finished');
        if (gameState !== 'crashed') {
            crash();
        }
        // Precision schedule next poll right after post-crash banner duration (1250ms)
        if (!isDemoMode) {
            setTimeout(async () => {
                await fetchServerState();
            }, 1250);
        }
    }
}

// Called once at startup to directly apply server state (bypasses "change" detection)
function reconcileServerState(data) {
    if (!data) return;
    const status = data.gameStatus;
    if (status === 'waiting' && gameState !== 'waiting') {
        startNewRound();
    } else if (status === 'playing' && gameState !== 'playing') {
        launchRound();
    } else if (status === 'crashed' && gameState !== 'crashed') {
        crash();
    } else if (status === 'waiting') {
        // Already waiting on client, just ensure UI is consistent
        syncGameBoardOverlay();
    }
}

function startDemoSyncLoop() {
    serverRoundId = localStorage.getItem('demo_round_id') ? parseInt(localStorage.getItem('demo_round_id')) : 10001;
    serverTimeOffset = 0;
    
    function generateDemoCrashPoint() {
        const rand = Math.random();
        if (rand < 0.10) {
            return 1.00; // 10% instant crash
        }
        const x = Math.random();
        if (x < 0.50) {
            return parseFloat((1.01 + Math.random() * 0.9).toFixed(2));
        } else if (x < 0.85) {
            return parseFloat((1.90 + Math.random() * 3.10).toFixed(2));
        } else if (x < 0.96) {
            return parseFloat((5.00 + Math.random() * 15.00).toFixed(2));
        } else {
            return parseFloat((20.00 + Math.random() * 80.00).toFixed(2));
        }
    }

    let demoState = 'waiting'; // 'waiting' | 'playing' | 'crashed'
    serverGameStatus = 'waiting';
    serverCrashPoint = generateDemoCrashPoint();
    serverRoundStartTime = Date.now();
    
    // Call initial waiting setup
    handleStatusChange('waiting');

    // Run custom state manager tick every 50ms
    setInterval(() => {
        const now = Date.now();
        if (demoState === 'waiting') {
            if (now - serverRoundStartTime >= 5000) {
                // Transition to playing
                demoState = 'playing';
                serverGameStatus = 'playing';
                serverRoundStartTime = now;
                handleStatusChange('playing');
            }
        } else if (demoState === 'playing') {
            const flightElapsed = now - serverRoundStartTime;
            const mt = Math.pow(1.06, flightElapsed / 1000);
            if (mt >= serverCrashPoint || gameState === 'crashed') {
                // Transition to crashed
                demoState = 'crashed';
                serverGameStatus = 'crashed';
                serverRoundStartTime = now;
                handleStatusChange('crashed');
            }
        } else if (demoState === 'crashed') {
            if (now - serverRoundStartTime >= 1200) {
                // Fast 1.2s transition back to waiting
                demoState = 'waiting';
                serverGameStatus = 'waiting';
                serverRoundId += 1;
                localStorage.setItem('demo_round_id', serverRoundId);
                serverCrashPoint = generateDemoCrashPoint();
                serverRoundStartTime = now;
                handleStatusChange('waiting');
            }
        }
    }, 50);
}

async function startServerSyncLoop() {
    // ── Phase 4/5: Initialize unified single game loop & debug telemetry panel
    initDebugPanel();
    startGameLoop({
        onFlyingTick: gameTick,
        onWaitingTick: updateWaitingCountdown,
    });

    if (isDemoMode) {
        startDemoSyncLoop();
        return;
    }

    // ── Initial boot: fetch server state and reconcile immediately ──────────
    const data = await fetchServerState();
    reconcileServerState(data);
    await reconcileBetsRecovery();

    // ── Polling: re-sync every 1500ms to heal network drops and drift ───────
    setInterval(async () => {
        await fetchServerState();
    }, 1500);

    // ── Realtime: instant state transitions via Supabase Postgres changes ───
    const channel = supabase
        .channel('game_state_changes')
        .on(
            'postgres_changes',
            { event: 'UPDATE', schema: 'public', table: 'active_game_state', filter: 'id=eq.1' },
            (payload) => {
                // Route through deduplication layer — prevents double transitions
                // when both realtime AND poll fire for the same status change.
                processServerEvent(payload.new);

                // Realtime signal prediction sync (unchanged)
                if (typeof fetchPredictorSignal === 'function') {
                    fetchPredictorSignal();
                }
            }
        )
        .on('system', {}, (status) => {
            // Track WebSocket connection health in bridge for debug panel
            gameBridge.socketStatus = status;
            console.log(`[Realtime] Channel status: ${status}`);
        })
        .subscribe((status) => {
            gameBridge.socketStatus = status;
            console.log(`[Realtime] Subscription status: ${status}`);
            if (status === 'SUBSCRIBED') {
                reconcileBetsRecovery();
            }
        });
}

// ── GAME LOGIC ─────────────────────────────────────────────────────────────

async function startNewRound() {
    traceEngineEvent("startNewRound:enter");
    gameState = 'waiting';
    currentMultiplier = 1.0;
    // ── Bridge sync: Phaser scene reads from gameBridge, not window.* ──────
    gameBridge.gameState = 'WAITING';
    gameBridge.currentMultiplier = 1.0;
    graphPoints = [];
    particles = [];
    
    // Auto-refresh wallet balance at the start of every game round
    await refreshBalance();
    
    resetBetStates();
    updateUI();
    syncGameBoardOverlay();
    refreshHistoryTicker();
    
    const multEl = document.getElementById('multiplier');
    if (multEl) {
        multEl.textContent = '1.00x';
        multEl.classList.remove('crashed');
        multEl.classList.add('waiting');
    }

    const overlayEl = document.querySelector('.game-state-overlay');
    if (overlayEl) {
        overlayEl.classList.add('waiting');
    }
    
    document.getElementById('status').textContent = 'WAITING FOR NEXT ROUND...';
    document.getElementById('crashedOverlay').classList.add('hidden');
    
    // Update Info Panel
    const infoRoundId = document.getElementById('infoRoundId');
    if (infoRoundId) infoRoundId.textContent = `#${serverRoundId}`;
    
    const headerRoundId = document.getElementById('currentRoundIdHeader');
    if (headerRoundId) headerRoundId.textContent = `#${serverRoundId}`;
    
    const infoRoundStatus = document.getElementById('infoRoundStatus');
    if (infoRoundStatus) infoRoundStatus.textContent = 'BETTING PHASE';
    
    const infoCountdown = document.getElementById('infoCountdown');
    if (infoCountdown) infoCountdown.textContent = '5.0s';

    const infoTotalPayouts = document.getElementById('infoTotalPayouts');
    if (infoTotalPayouts) infoTotalPayouts.textContent = 'KES 0';

    // If auto bet active, submit automated bets for the new round
    [1, 2].forEach(num => {
        const fsm = num === 1 ? sm1 : sm2;
        const config = num === 1 ? autoConfig1 : autoConfig2;
        // Only auto-place if the bet slot is free (a preserved manual queued bet keeps its slot)
        const isFree = fsm.state === BetState.IDLE || fsm.state === BetState.ROUND_FINISHED || fsm.state === BetState.ERROR;
        if (config.active && isFree) {
            placeAutoBet(num);
        }
    });

    spawnSimulatedBets();

    // Randomize waiting lobby player count and avatars for a realistic & dynamic lobby
    const waitingPlayerCountEl = document.getElementById('waitingPlayerCount');
    if (waitingPlayerCountEl) {
        const randCount = Math.floor(Math.random() * (260 - 120 + 1)) + 120;
        waitingPlayerCountEl.textContent = randCount;
    }
    const waitingAvatarsContainer = document.querySelector('.waiting-avatars');
    if (waitingAvatarsContainer) {
        const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const bgGradients = [
            'linear-gradient(135deg, #1e3a8a, #3b82f6)',
            'linear-gradient(135deg, #78350f, #f59e0b)',
            'linear-gradient(135deg, #4c1d95, #8b5cf6)',
            'linear-gradient(135deg, #064e3b, #10b981)',
            'linear-gradient(135deg, #134e5e, #06b6d4)',
            'linear-gradient(135deg, #581c87, #d946ef)',
            'linear-gradient(135deg, #7c2d12, #ea580c)',
            'linear-gradient(135deg, #ef4444, #b91c1c)'
        ];
        
        const initial1 = alphabet[Math.floor(Math.random() * alphabet.length)];
        const initial2 = alphabet[Math.floor(Math.random() * alphabet.length)];
        const bg1 = bgGradients[Math.floor(Math.random() * bgGradients.length)];
        let bg2 = bgGradients[Math.floor(Math.random() * bgGradients.length)];
        if (bg2 === bg1) {
            bg2 = bgGradients[(bgGradients.indexOf(bg1) + 1) % bgGradients.length];
        }
        
        waitingAvatarsContainer.innerHTML = `
            <div class="avatar-sm" style="background: ${bg1};">${initial1}</div>
            <div class="avatar-sm" style="background: ${bg2};">${initial2}</div>
        `;
    }
}

function launchRound() {
    traceEngineEvent("launchRound:enter");
    gameState = 'playing';
    // ── Bridge sync ──────────────────────────────────────────────────────
    gameBridge.gameState = 'FLYING';
    gameBridge.crashPoint = serverCrashPoint;
    gameBridge.roundId = serverRoundId;

    const nowMs = Date.now();

    // ── Compute a stable local flight-start timestamp ─────────────────────
    // Back-calculate from the current multiplier so gameTick produces a
    // continuously growing value without being disrupted by poll updates.
    // localFlyStartMs is NEVER overwritten after this point until the next round.
    if (currentMultiplier > 1.001) {
        // Mid-round join: back-calculate the equivalent elapsed time
        const equivElapsedMs = Math.log(currentMultiplier) / Math.log(1.06) * 1000;
        localFlyStartMs = nowMs - Math.round(equivElapsedMs);
    } else if (serverRoundStartTime > 0) {
        // Fresh round start: anchor strictly to serverRoundStartTime synchronized clock
        localFlyStartMs = serverRoundStartTime - serverTimeOffset;
    } else {
        localFlyStartMs = nowMs;
    }

    gameBridge.serverRoundStartTime = localFlyStartMs;
    gameBridge.serverTimeOffset     = serverTimeOffset;

    document.getElementById('status').textContent = '';
    syncGameBoardOverlay();

    // Update the multiplier display immediately
    const multEl = document.getElementById('multiplier');
    if (multEl) {
        multEl.textContent = `${currentMultiplier.toFixed(2)}x`;
        multEl.classList.remove('waiting', 'crashed');
        multEl.style.color = '';
    }

    const overlayEl = document.querySelector('.game-state-overlay');
    if (overlayEl) {
        overlayEl.classList.remove('waiting');
    }

    // Always regenerate simulated bets seeded by serverRoundId (same on all clients)
    allBets = generateSimulatedBetsForRound(serverRoundId);
    allBets.forEach(pb => {
        if (pb.cashOutTarget <= currentMultiplier) {
            pb.status = 'cashed';
            pb.mult   = pb.cashOutTarget;
            pb.win    = Math.floor(pb.amount * pb.cashOutTarget);
        }
    });

    currentLobbyCount = getActivePlayersBadgeValue(serverRoundId);
    const badgeCount = document.getElementById('livePlayerCount');
    if (badgeCount) badgeCount.textContent = currentLobbyCount.toLocaleString();
    if (currentActiveTab === 'all') renderAllBets();

    startEngineRumble();
    startRisingTone();

    // Info panel
    const infoRoundStatus = document.getElementById('infoRoundStatus');
    if (infoRoundStatus) infoRoundStatus.textContent = 'FLYING';

    const infoTotalWagered = document.getElementById('infoTotalWagered');
    if (infoTotalWagered) {
        const totalWagered = allBets.reduce((sum, b) => sum + b.amount, 0);
        infoTotalWagered.textContent = `KES ${totalWagered.toLocaleString()}`;
    }

    [1, 2].forEach(num => {
        const fsm = num === 1 ? sm1 : sm2;
        const isMatchingRound = !fsm.roundId || Number(fsm.roundId) === Number(serverRoundId);
        const isEligible = (
            fsm.state === BetState.WAITING_FOR_ROUND || 
            fsm.state === BetState.ACCEPTED || 
            (fsm.state === BetState.QUEUED_FOR_NEXT_ROUND && isMatchingRound)
        ) && isMatchingRound;

        console.log(`[FSM-Panel${num}] launchRound telemetry check: state=${fsm.state}, fsmRoundId=${fsm.roundId}, serverRoundId=${serverRoundId}, isEligible=${isEligible}`);

        if (isEligible) {
            if (fsm.state === BetState.ACCEPTED || fsm.state === BetState.QUEUED_FOR_NEXT_ROUND) {
                fsm.transitionTo(BetState.WAITING_FOR_ROUND, 'Transition through waiting');
            }
            fsm.transitionTo(BetState.ROUND_ACTIVE, `Round ${serverRoundId} flight started`);
        }
    });

    updateUI();
}

function gameTick() {
    if (gameState !== 'playing') return;

    // NOTE: No FSM coercion here. ROUND_ACTIVE transitions happen only in
    // launchRound() when the server sends the 'playing' event for that exact round.

    // ── Compute server-authoritative target multiplier ───────────────────────
    // localFlyStartMs is anchored to server-synchronized clock (serverRoundStartTime - serverTimeOffset).
    const flightElapsed = Math.max(0, Date.now() - localFlyStartMs);
    const targetMultiplier = Math.min(
        Math.pow(1.06, flightElapsed / 1000),
        serverCrashPoint || 999
    );

    // Direct mathematical evaluation ensures 100% uniform speed across 30fps mobile and 144fps desktop
    currentMultiplier = Math.max(1.00, Math.min(targetMultiplier, serverCrashPoint || 999));

    // ── Crash detection ──────────────────────────────────────────────────────
    // Use server-authoritative crash point exclusively — never let currentMultiplier
    // drift above serverCrashPoint so all displays stay perfectly aligned.
    if (targetMultiplier >= serverCrashPoint) {
        currentMultiplier = parseFloat(serverCrashPoint.toFixed(2));
        gameBridge.currentMultiplier = currentMultiplier;
        crash();
        return;
    }

    // ── Update bridge so FlightScene and debug panel see the live multiplier ─
    gameBridge.currentMultiplier = currentMultiplier;
    updateMultiplierUI();
    updateGraph();
    // NOTE: updateUI() is NOT called here — it causes layout thrashing at 60 FPS.
    // It is called only on discrete state transitions (launchRound, crash, bet actions).
    // updateLiveBetButtons() handles the lightweight per-frame cash-out amount update.
    updateLiveBetButtons();
    
    // Live simulator player cashout
    let cashoutLogged = false;
    allBets.forEach(pb => {
        if (pb.status === 'playing' && currentMultiplier >= pb.cashOutTarget) {
            pb.status = 'cashed';
            pb.mult = pb.cashOutTarget;
            pb.win = Math.floor(pb.amount * pb.cashOutTarget);
            
            // Add to recent winners registry
            recentWinners.unshift({
                name: pb.name,
                amount: pb.amount,
                mult: pb.cashOutTarget,
                win: pb.win,
                timestamp: new Date().toLocaleTimeString(undefined, {hour: '2-digit', minute:'2-digit', second:'2-digit'})
            });
            if (recentWinners.length > 40) recentWinners.pop();
            
            cashoutLogged = true;
            
            // Play soft cashout on big winners
            if (pb.win >= 3000) {
                playTone(1000, 0.1, 0.015);
            }
        }
    });

    if (cashoutLogged) {
        if (currentActiveTab === 'all') {
            renderAllBets();
        } else if (currentActiveTab === 'recent_wins') {
            renderRecentWinnersTab();
        }
    }
    
    // Update live total payouts
    const infoTotalPayouts = document.getElementById('infoTotalPayouts');
    if (infoTotalPayouts) {
        const totalPayout = allBets.filter(b => b.status === 'cashed').reduce((sum, b) => sum + b.win, 0);
        infoTotalPayouts.textContent = `KES ${totalPayout.toLocaleString()}`;
    }
    
    // Update audio tone pitch
    updateRisingToneFreq(currentMultiplier);

    // Auto cash out logic
    checkAutoCashOut();
}

/**
 * updateLiveBetButtons — lightweight per-frame update for active bet slots.
 *
 * Only updates the cash-out amount text on CASH OUT buttons.
 * This replaces the full updateUI() call inside gameTick() which caused
 * layout thrashing at 60 FPS by reading/writing dozens of DOM properties.
 */
function updateLiveBetButtons() {
    [1, 2].forEach(num => {
        const fsm = num === 1 ? sm1 : sm2;
        const bet = num === 1 ? bet1 : bet2;

        // Auto-reconcile / promote trapped active bets during active flight
        if (gameState === 'playing') {
            const isMatchingRound = !fsm.roundId || Number(fsm.roundId) <= Number(serverRoundId);
            if (isMatchingRound && (fsm.state === BetState.WAITING_FOR_ROUND || fsm.state === BetState.ACCEPTED || fsm.state === BetState.QUEUED_FOR_NEXT_ROUND)) {
                if (fsm.state === BetState.ACCEPTED || fsm.state === BetState.QUEUED_FOR_NEXT_ROUND) {
                    fsm.transitionTo(BetState.WAITING_FOR_ROUND, 'Mid-flight auto-reconcile waiting state', { roundId: serverRoundId });
                }
                fsm.transitionTo(BetState.ROUND_ACTIVE, `Mid-flight auto-reconcile flight started (Round ${serverRoundId})`, {
                    roundId: serverRoundId
                });
            }
        }

        if (fsm.state !== BetState.ROUND_ACTIVE || gameState !== 'playing' || Number(fsm.roundId) !== Number(serverRoundId)) return;
        
        const stakeInput = document.getElementById(`betAmount${num}`);
        const activeStake = (stakeInput && parseFloat(stakeInput.value) > 0) ? parseFloat(stakeInput.value) : (bet.amount || 50);
        if (bet.amount !== activeStake) bet.amount = activeStake;

        const amountEl = document.getElementById(`betLabelSub${num}`);
        if (amountEl) {
            amountEl.textContent = `KES ${(activeStake * currentMultiplier).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
        }
    });
}

// placeAutoBet: like placeBet but marks the bet as auto-placed so checkAutoCashOut fires on it
async function placeAutoBet(num) {
    await placeBet(num);
    const bet = num === 1 ? bet1 : bet2;
    if (bet.active) bet.placedByAuto = true;
}

function checkAutoCashOut() {
    [1, 2].forEach(num => {
        const fsm = num === 1 ? sm1 : sm2;
        const config = num === 1 ? autoConfig1 : autoConfig2;
        
        const isMatchingRound = !fsm.roundId || Number(fsm.roundId) <= Number(serverRoundId);
        if (fsm.state === BetState.ROUND_ACTIVE && isMatchingRound) {
            let enabled = false;
            let target = 2.0;
            
            if (config.active) {
                // If the auto-bet system is active, use the captured config values
                enabled = config.enableAutoCash;
                target = config.autoCashVal;
            } else {
                // Otherwise, check if the UI checkbox is checked for a manual bet
                const checkbox = document.getElementById(`enableAutoCash${num}`);
                const valInput = document.getElementById(`autoCashVal${num}`);
                if (checkbox && checkbox.checked && valInput) {
                    enabled = true;
                    target = parseFloat(valInput.value) || 2.0;
                }
            }
            
            if (enabled && target > 1.01 && currentMultiplier >= (target - 0.005)) {
                cashOutBet(num);
            }
        }
    });
}

function crash() {
    gameState = 'crashed';
    // ── Bridge sync ──────────────────────────────────────────────────────
    // Always use serverCrashPoint as the single source of truth.
    // This ensures the crash display, history ticker, and predictor all show
    // identical values regardless of which frame gameTick fires on.
    const crashedVal = parseFloat((serverCrashPoint || currentMultiplier).toFixed(2));
    currentMultiplier = crashedVal;
    gameBridge.gameState = 'CRASHED';
    gameBridge.currentMultiplier = crashedVal;
    
    stopEngineRumble();
    stopRisingTone();
    playSoundExplosion();
    haptic('crash');
    
    syncGameBoardOverlay();

    const multEl = document.getElementById('multiplier');
    if (multEl) {
        multEl.textContent = `${crashedVal.toFixed(2)}x`;
        multEl.classList.add('crashed');
        multEl.classList.remove('waiting');
    }
    
    const crashedOverlay = document.getElementById('crashedOverlay');
    if (crashedOverlay) crashedOverlay.classList.remove('hidden');
    
    const crashedText = document.getElementById('crashedText');
    if (crashedText) crashedText.textContent = "FLEW AWAY";
    
    const crashedValue = document.getElementById('crashedValue');
    if (crashedValue) crashedValue.textContent = `${crashedVal.toFixed(2)}x`;

    // Snap the multiplier display to the exact server value immediately
    updateMultiplierUI();
    
    // Update Info Panel
    const infoRoundStatus = document.getElementById('infoRoundStatus');
    if (infoRoundStatus) infoRoundStatus.textContent = 'CRASHED';
    
    const infoLastCrash = document.getElementById('infoLastCrash');
    if (infoLastCrash) {
        infoLastCrash.textContent = `${crashedVal.toFixed(2)}x`;
        infoLastCrash.style.color = crashedVal < 2 ? 'var(--error)' : crashedVal < 10 ? 'var(--warning)' : 'var(--blue)';
    }

    // Finalize bets
    finalizeCrashedBets();
    
    addToHistory(crashedVal);
    resetBetStates();
    updateUI();

    // ── Self-healing escape hatch ─────────────────────────────────────────────
    // Guarantees the game ALWAYS transitions out of crashed state, even if:
    //   - gameTick triggered crash before the server reported it (dedup may block
    //     the server's 'crashed' event, so the 1250ms follow-up never schedules)
    //   - Network drops prevent the Realtime/poll event from arriving
    //   - lastEventKey dedup accidentally blocks the next 'waiting' event
    //
    // Set lastEventKey to the current round's 'crashed' key so that:
    //   - Any SAME-round replays ('crashed' again) are still deduped correctly
    //   - Any NEW-round events ('waiting'/'playing' with roundId+1) always pass
    //     through, because their key is "(N+1):status" which never matches
    lastEventKey = `${serverRoundId}:crashed`;

    if (!isDemoMode) {
        setTimeout(async () => {
            // Only force-poll if we are still stuck in crashed state.
            // If the server already sent 'waiting' via Realtime, gameState
            // will already be 'waiting' and this is a no-op.
            if (gameState === 'crashed') {
                console.warn('[GameSync] Self-healing: still in crashed after 1600ms, forcing poll.');
                await fetchServerState();
                // If STILL stuck (server also in crashed), schedule one more retry
                if (gameState === 'crashed') {
                    setTimeout(async () => {
                        if (gameState === 'crashed') {
                            console.warn('[GameSync] Self-healing retry: forcing startNewRound.');
                            await fetchServerState();
                            if (gameState === 'crashed') startNewRound();
                        }
                    }, 2000);
                }
            }
        }, 1600);
    }
}

// ── SECURE TRANSACTIONS (RPC) ──────────────────────────────────────────────

async function placeBet(num) {
    traceEngineEvent("placeBet:start", { panel: num });
    const fsm = num === 1 ? sm1 : sm2;
    if (fsm.state !== BetState.IDLE && fsm.state !== BetState.ERROR) return;

    const amount = parseFloat(document.getElementById(`betAmount${num}`).value);
    const minStake = window.cachedFinancialLimits?.minBetAviator || 10;
    if (isNaN(amount) || amount < minStake) {
        showToast(`Minimum bet is KES ${minStake}`, "error");
        return;
    }

    const bet = num === 1 ? bet1 : bet2;
    bet.amount = amount;

    if (balance < amount) {
        showToast("Insufficient balance. Please deposit funds.", "error");
        return;
    }

    const roundAtPlacement = serverRoundId;
    const stateAtPlacement = gameState;
    const activeRound = (serverRoundId && serverRoundId > 0) 
        ? serverRoundId 
        : (localStorage.getItem('demo_round_id') ? parseInt(localStorage.getItem('demo_round_id')) : 1);
    const targetRoundId = (gameState === 'waiting') ? activeRound : (activeRound + 1);

    const reqId = `place-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
    const startTime = Date.now();

    fsm.transitionTo(BetState.SUBMITTING, 'Placing bet request initiated', {
        roundId: targetRoundId,
        requestId: reqId
    });

    if (isDemoMode) {
        balance = parseFloat((balance - amount).toFixed(2));
        localStorage.setItem('demo_balance', balance);
        updateUI();

        const betId = 'demo-bet-' + Math.random().toString(36).substring(2, 9);
        
        fsm.transitionTo(BetState.ACCEPTED, 'Bet accepted by demo controller', {
            betId: betId,
            roundId: targetRoundId,
            requestId: reqId,
            requestStartTime: startTime
        });

        if (gameState === 'waiting') {
            fsm.transitionTo(BetState.WAITING_FOR_ROUND, 'Round waiting phase active', { roundId: targetRoundId });
        } else if (gameState === 'playing') {
            if (targetRoundId > serverRoundId) {
                fsm.transitionTo(BetState.QUEUED_FOR_NEXT_ROUND, 'Bet queued for next round in demo mode', { roundId: targetRoundId });
            } else {
                fsm.transitionTo(BetState.WAITING_FOR_ROUND, 'Bet active mid-flight in demo mode', { roundId: targetRoundId });
                fsm.transitionTo(BetState.ROUND_ACTIVE, 'Immediate activation — round already flying', { roundId: targetRoundId });
            }
        }

        // Keep local bets in myBetsList history
        const newDemoBet = {
            id: betId,
            amount: amount,
            multiplier: null,
            winnings: null,
            status: 'playing',
            created_at: new Date().toISOString()
        };
        myBetsList.unshift(newDemoBet);

        playSoundBetPlaced();
        haptic('medium');

        if (targetRoundId > serverRoundId) {
            showToast(`✅ Bet queued for next round!`, 'success');
        }
        return;
    }

    try {
        const { data, error } = await supabase.rpc('place_bet', {
            p_amount: amount,
            p_round_id: targetRoundId,
            p_use_free_bet: false
        });

        if (error || (data && data.error)) {
            const rawMsg = error?.message || data?.error || "Failed to place bet";
            let errMsg = rawMsg;
            if (/insufficient|balance|funds/i.test(rawMsg)) {
                errMsg = "Insufficient balance. Please deposit funds.";
            } else if (/400|bad request/i.test(rawMsg)) {
                errMsg = "Insufficient balance or invalid bet stake.";
            }
            fsm.transitionTo(BetState.ERROR, 'Bet placement rejected by server', {
                errorMsg: errMsg,
                requestId: reqId,
                requestStartTime: startTime
            });
            showToast(errMsg, "error");
            return;
        }

        const confirmedRound = Number((data && data.round_id) ? data.round_id : targetRoundId);

        const assignedBetId = data.betId || data.bet_id;
        fsm.transitionTo(BetState.ACCEPTED, 'Bet accepted by server RPC', {
            betId: assignedBetId,
            roundId: confirmedRound,
            requestId: reqId,
            requestStartTime: startTime
        });

        // Determine the correct post-acceptance state.
        //
        // Case A: Bet was placed while plane was flying (stateAtPlacement === 'playing') or targetRoundId > roundAtPlacement
        //   Backend assigned the NEXT round — strictly queue it.
        //
        // Case B: confirmedRound === serverRoundId AND gameState === 'playing' (and stateAtPlacement was 'waiting')
        //   Bet was submitted during waiting phase but the server transitioned to 'playing'
        //   before our RPC response arrived. launchRound() already fired and won't
        //   fire again (dedup). Promote directly to ROUND_ACTIVE here.
        //
        // Case C: confirmedRound === serverRoundId AND gameState === 'waiting'
        //   Normal waiting-phase path — wait for launchRound().
        const currentServerRound = Number(serverRoundId);

        console.log(`[FSM-Panel${num}] placeBet RPC post-acceptance telemetry: confirmedRound=${confirmedRound}, currentServerRound=${currentServerRound}, gameState=${gameState}, stateAtPlacement=${stateAtPlacement}`);

        if (confirmedRound > currentServerRound) {
            // Case A: Confirmed for a future round -> strictly queue it
            fsm.transitionTo(BetState.QUEUED_FOR_NEXT_ROUND, 'Bet placed for future round — queued for next round', {
                roundId: confirmedRound
            });
            showToast(`✅ Bet queued for next round!`, 'success');
        } else if (confirmedRound === currentServerRound) {
            if (gameState === 'waiting') {
                // Case B: Confirmed for current round during waiting phase -> awaiting round start
                fsm.transitionTo(BetState.WAITING_FOR_ROUND, 'Awaiting round start');
            } else if (gameState === 'playing') {
                // Case C: Confirmed for current round, but flight already started while RPC was in flight -> promote to active flight
                fsm.transitionTo(BetState.WAITING_FOR_ROUND, 'Bet confirmed — round started mid-request');
                fsm.transitionTo(BetState.ROUND_ACTIVE, 'Immediate activation — round already flying');
            } else {
                // Case D: Round crashed while RPC was in flight -> reset to idle
                fsm.transitionTo(BetState.IDLE, 'Round finished mid-request');
                refreshBalance();
            }
        } else {
            // Case E: Confirmed round is older than current server round -> stale bet, reset
            fsm.transitionTo(BetState.IDLE, 'Stale bet settled on past round');
            refreshBalance();
        }
        const updatedBal = typeof data.newBalance === 'number' ? data.newBalance : (typeof data.new_balance === 'number' ? data.new_balance : null);
        if (updatedBal !== null) balance = updatedBal;
        updateUI();
        syncUIFromStateMachine(num);
        playSoundBetPlaced();
        haptic('medium');
    } catch (e) {
        fsm.transitionTo(BetState.ERROR, 'Exception in placeBet RPC call', {
            errorMsg: 'Server Exception',
            requestId: reqId,
            requestStartTime: startTime
        });
        showToast("Failed to place bet", "error");
    }
}

async function cashOutBet(num) {
    const fsm = num === 1 ? sm1 : sm2;
    if (fsm.state !== BetState.ROUND_ACTIVE) return;

    const reqId = `cashout-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
    const startTime = Date.now();
    const cashMultiplier = currentMultiplier; // snapshot multiplier at click time

    fsm.transitionTo(BetState.CASHING_OUT, 'Cashout request initiated', {
        requestId: reqId
    });

    if (isDemoMode) {
        const stakeInput = document.getElementById(`betAmount${num}`);
        const amount = parseFloat(stakeInput ? stakeInput.value : 50) || 50;
        const winnings = parseFloat((amount * cashMultiplier).toFixed(2));

        fsm.transitionTo(BetState.CASHED_OUT, 'Cashout confirmed by demo controller', {
            requestId: reqId,
            requestStartTime: startTime
        });

        balance = parseFloat((balance + winnings).toFixed(2));
        localStorage.setItem('demo_balance', balance);
        updateUI();

        const betObj = myBetsList.find(b => b.id === fsm.betId);
        if (betObj) {
            betObj.status = 'cashed';
            betObj.multiplier = cashMultiplier;
            betObj.winnings = winnings;
        }

        playSoundCashOut();
        haptic('success');
        showToast(`✅ Cashed out KES ${winnings.toLocaleString()}!`, 'success');
        return;
    }

    try {
        const { data, error } = await supabase.rpc('cash_out', {
            p_bet_id: fsm.betId,
            p_multiplier: cashMultiplier
        });

        if (error || (data && data.error)) {
            const errMsg = error?.message || data.error || "Cashout failed";
            fsm.transitionTo(BetState.ROUND_ACTIVE, 'Cashout rejected by server', {
                errorMsg: errMsg,
                requestId: reqId,
                requestStartTime: startTime
            });
            showToast(errMsg, "error");
            return;
        }

        fsm.transitionTo(BetState.CASHED_OUT, 'Cashout confirmed by server RPC', {
            requestId: reqId,
            requestStartTime: startTime
        });

        const newBal = typeof data.newBalance === 'number' ? data.newBalance : (typeof data.new_balance === 'number' ? data.new_balance : null);
        if (newBal !== null) {
            balance = newBal;
        } else {
            await refreshBalance();
        }
        updateUI();

        const wonAmt = Number(data.winnings ?? data.payout ?? 0);
        playSoundCashOut();
        haptic('success');
        showToast(`✅ Cashed out KES ${wonAmt.toLocaleString()}!`, 'success');
    } catch (e) {
        fsm.transitionTo(BetState.ROUND_ACTIVE, 'Cashout failed with network exception', {
            requestId: reqId,
            requestStartTime: startTime
        });
        showToast("Cash out failed", "error");
    }
}

async function refreshBalance() {
    if (isDemoMode) {
        balance = localStorage.getItem('demo_balance') ? parseFloat(localStorage.getItem('demo_balance')) : 10000.00;
        updateUI();
        const balanceBox = document.getElementById('metricwinBalanceBox');
        if (balanceBox) balanceBox.textContent = `KES ${Math.floor(balance).toLocaleString()}`;
        return;
    }
    try {
        const { data, error } = await supabase.from('profiles').select('balance').single();
        if (data && !error && data.balance !== undefined) {
            balance = parseFloat(data.balance);
            updateUI();
            const balanceBox = document.getElementById('metricwinBalanceBox');
            if (balanceBox) balanceBox.textContent = `KES ${Math.floor(balance).toLocaleString()}`;
            localStorage.setItem('metrowins_user_balance', String(balance));
            if (currentUser) {
                currentUser.balance = balance;
                localStorage.setItem('metrowins_auth_user', JSON.stringify(currentUser));
            }
        }
    } catch (e) {
        console.warn('Balance refresh failed:', e);
    }
}

// ── UI UPDATES ─────────────────────────────────────────────────────────────

async function cancelBet(num) {
    const fsm = num === 1 ? sm1 : sm2;
    // Allow cancellation from any pre-flight state, including queued bets.
    // The gameState check was removed — routing is now decided by FSM state exclusively.
    const cancellableStates = [BetState.ACCEPTED, BetState.WAITING_FOR_ROUND, BetState.QUEUED_FOR_NEXT_ROUND];
    if (!cancellableStates.includes(fsm.state)) return;

    const savedBetId = fsm.betId;
    const reqId = `cancel-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
    const startTime = Date.now();

    fsm.transitionTo(BetState.CANCELLING, 'Cancellation request initiated', {
        requestId: reqId
    });

    if (isDemoMode) {
        fsm.transitionTo(BetState.CANCELLED, 'Cancellation accepted by demo controller', {
            requestId: reqId,
            requestStartTime: startTime
        });

        // Demo refund
        const stakeInput = document.getElementById(`betAmount${num}`);
        const stakeVal = parseFloat(stakeInput ? stakeInput.value : 50) || 50;
        balance = parseFloat((balance + stakeVal).toFixed(2));
        localStorage.setItem('demo_balance', balance);

        myBetsList = myBetsList.filter(b => b.id !== savedBetId);
        showToast("Bet Cancelled", "success");
        haptic('medium');
        return;
    }

    try {
        const { data, error } = await supabase.rpc('cancel_bet', {
            p_bet_id: savedBetId
        });

        if (error) {
            if (error.message.includes("does not exist") || error.code === 'P0001') {
                console.warn("cancel_bet RPC not found in database, performing local fallback.");
                fsm.transitionTo(BetState.CANCELLED, 'Local fallback cancellation confirmed', {
                    requestId: reqId,
                    requestStartTime: startTime
                });
                await refreshBalance();
                showToast("Bet Cancelled", "success");
                haptic('medium');
                return;
            }
            // After failed cancel, restore state: if plane is already flying for this round, promote to ROUND_ACTIVE so user gets a CASH OUT button instead of being trapped in WAITING_FOR_ROUND
            const isRoundFlying = gameState === 'playing' && (!fsm.roundId || Number(fsm.roundId) <= Number(serverRoundId));
            const fallbackState = (fsm.roundId && Number(fsm.roundId) > Number(serverRoundId))
                ? BetState.QUEUED_FOR_NEXT_ROUND
                : (isRoundFlying ? BetState.ROUND_ACTIVE : BetState.WAITING_FOR_ROUND);
            fsm.transitionTo(fallbackState, 'Cancellation rejected by server', {
                errorMsg: error.message,
                requestId: reqId,
                requestStartTime: startTime
            });
            showToast(error.message, "error");
            return;
        }

        if (data && data.error) {
            const isRoundFlying2 = gameState === 'playing' && (!fsm.roundId || Number(fsm.roundId) <= Number(serverRoundId));
            const fallbackState2 = (fsm.roundId && Number(fsm.roundId) > Number(serverRoundId))
                ? BetState.QUEUED_FOR_NEXT_ROUND
                : (isRoundFlying2 ? BetState.ROUND_ACTIVE : BetState.WAITING_FOR_ROUND);
            fsm.transitionTo(fallbackState2, 'Cancellation rejected by database logic', {
                errorMsg: data.error,
                requestId: reqId,
                requestStartTime: startTime
            });
            showToast(data.error, "error");
            return;
        }

        fsm.transitionTo(BetState.CANCELLED, 'Cancellation confirmed by server', {
            requestId: reqId,
            requestStartTime: startTime
        });

        const refundedBal = typeof data.newBalance === 'number' ? data.newBalance : (typeof data.new_balance === 'number' ? data.new_balance : null);
        if (refundedBal !== null) {
            balance = refundedBal;
        } else {
            await refreshBalance();
        }
        showToast("Bet Cancelled", "success");
        haptic('medium');
    } catch (e) {
        const isRoundFlyingNet = gameState === 'playing' && (!fsm.roundId || Number(fsm.roundId) <= Number(serverRoundId));
        const fallbackStateNet = (fsm.roundId && Number(fsm.roundId) > Number(serverRoundId))
            ? BetState.QUEUED_FOR_NEXT_ROUND
            : (isRoundFlyingNet ? BetState.ROUND_ACTIVE : BetState.WAITING_FOR_ROUND);
        fsm.transitionTo(fallbackStateNet, 'Cancellation failed with network exception', {
            requestId: reqId,
            requestStartTime: startTime
        });
        showToast("Cancellation failed", "error");
    }
}

window.handleBetButtonClick = async (num) => {
    traceEngineEvent("handleBetButtonClick", { panel: num });
    const fsm = (num === 1) ? sm1 : sm2;
    const bet = (num === 1) ? bet1 : bet2;

    // Route exclusively by FSM state — never by gameState, CSS class, or button text.
    switch (fsm.state) {
        case BetState.ROUND_ACTIVE:
            await cashOutBet(num);
            break;
        case BetState.ACCEPTED:
        case BetState.WAITING_FOR_ROUND:
        case BetState.QUEUED_FOR_NEXT_ROUND:
            await cancelBet(num);
            break;
        case BetState.IDLE:
        case BetState.ERROR:
            if (bet.auto) {
                window.toggleAutoBet(num);
            } else {
                await placeBet(num);
            }
            break;
        // All other states (SUBMITTING, CANCELLING, CASHING_OUT, CASHED_OUT,
        // ROUND_FINISHED) are transient — clicks are silently ignored.
        default:
            break;
    }
};

function syncBetObjectFromFSM(num) {
    const fsm = num === 1 ? sm1 : sm2;
    const bet = num === 1 ? bet1 : bet2;
    const stakeInput = document.getElementById(`betAmount${num}`);
    
    bet.id = fsm.betId;
    bet.active = [BetState.ACCEPTED, BetState.WAITING_FOR_ROUND, BetState.ROUND_ACTIVE, BetState.CASHING_OUT, BetState.CASHED_OUT].includes(fsm.state);
    bet.cashed = fsm.state === BetState.CASHED_OUT;
    bet.cashoutPending = fsm.state === BetState.CASHING_OUT;
    bet.roundId = fsm.roundId;

    if (stakeInput) {
        const val = parseFloat(stakeInput.value);
        if (!isNaN(val) && val > 0) {
            bet.amount = val;
        }
    }
}

function syncUIFromStateMachine(num) {
    traceEngineEvent("syncUIFromStateMachine", { panel: num });
    const fsm = num === 1 ? sm1 : sm2;
    const btn = document.getElementById(`placeBet${num}Btn`);
    const titleEl = document.getElementById(`betBtnTitle${num}`);
    const amountEl = document.getElementById(`betLabelSub${num}`);
    const stakeInput = document.getElementById(`betAmount${num}`);
    const cardEl = document.getElementById(`betCard${num}`);
    const config = num === 1 ? autoConfig1 : autoConfig2;

    syncBetObjectFromFSM(num);

    if (!btn) return;

    // Derived Input Locking Matrix
    const isLocked = fsm.state !== BetState.IDLE && fsm.state !== BetState.ROUND_FINISHED && fsm.state !== BetState.ERROR;
    if (stakeInput) {
        stakeInput.disabled = isLocked;
        stakeInput.readOnly = isLocked;
    }
    if (cardEl) {
        cardEl.querySelectorAll('.adj-btn, .quick-btn').forEach(ctrl => {
            ctrl.disabled = isLocked;
            ctrl.style.opacity = isLocked ? '0.4' : '1';
            ctrl.style.pointerEvents = isLocked ? 'none' : 'auto';
        });
    }

    // Reset button states
    btn.classList.remove('cancel-state', 'cash-state');
    btn.disabled = false;

    // Derived Button State Matrix
    switch (fsm.state) {
        case BetState.IDLE: {
            const bet = num === 1 ? bet1 : bet2;
            if (bet.auto && config.active) {
                btn.classList.add('cancel-state');
                if (titleEl) titleEl.textContent = "STOP";
                if (amountEl) amountEl.textContent = "Auto Active";
            } else {
                if (titleEl) titleEl.textContent = "BET";
                const val = parseFloat(stakeInput ? stakeInput.value : 50) || 50;
                if (amountEl) amountEl.textContent = val.toFixed(2) + " KES";
            }
            break;
        }

        case BetState.SUBMITTING:
            btn.disabled = true;
            if (titleEl) titleEl.textContent = "BETTING...";
            if (amountEl) amountEl.textContent = "Placing bet...";
            break;

        case BetState.ACCEPTED:
            // Show CANCEL / Bet accepted — never CASH OUT from this state.
            // ROUND_ACTIVE is the only state that renders CASH OUT.
            btn.classList.add('cancel-state');
            if (titleEl) titleEl.textContent = "CANCEL";
            if (amountEl) amountEl.textContent = "Bet accepted";
            break;

        case BetState.QUEUED_FOR_NEXT_ROUND:
            btn.classList.add('cancel-state');
            if (titleEl) titleEl.textContent = "CANCEL";
            if (amountEl) amountEl.textContent = "Next round";
            break;

        case BetState.WAITING_FOR_ROUND:
            btn.classList.add('cancel-state');
            if (titleEl) titleEl.textContent = "CANCEL";
            if (amountEl) amountEl.textContent = "Awaiting start";
            break;

        case BetState.CANCELLING:
            btn.disabled = true;
            if (titleEl) titleEl.textContent = "CANCELLING...";
            if (amountEl) amountEl.textContent = "Removing bet";
            break;

        case BetState.CANCELLED:
            btn.disabled = true;
            if (titleEl) titleEl.textContent = "CANCELLED";
            if (amountEl) amountEl.textContent = "Refunded";
            break;

        case BetState.ROUND_ACTIVE:
            btn.classList.add('cash-state');
            if (titleEl) titleEl.textContent = "CASH OUT";
            if (amountEl) {
                const val = parseFloat(stakeInput ? stakeInput.value : 50) || 50;
                amountEl.textContent = `KES ${(val * currentMultiplier).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
            }
            break;

        case BetState.CASHING_OUT:
            btn.disabled = true;
            if (titleEl) titleEl.textContent = "CASHING OUT...";
            if (amountEl) amountEl.textContent = "Sending request";
            break;

        case BetState.CASHED_OUT:
            btn.disabled = true;
            if (titleEl) titleEl.textContent = "CASHED OUT";
            if (amountEl) amountEl.textContent = "Won!";
            break;

        case BetState.ROUND_FINISHED:
            btn.disabled = true;
            if (titleEl) titleEl.textContent = "SETTLED";
            if (amountEl) amountEl.textContent = "Finished";
            break;

        case BetState.ERROR:
            btn.classList.add('cancel-state');
            if (titleEl) titleEl.textContent = "ERROR";
            if (amountEl) amountEl.textContent = fsm.errorMsg || "Failed";
            break;
    }
}

async function reconcileBetsRecovery() {
    if (isDemoMode || !currentUser) return;

    console.log('[FSM-Recovery] Reconciling client FSM with authoritative server wagers...');
    try {
        // Fetch wagers for current round AND next round (for queued bets placed mid-flight)
        const { data: wagers, error } = await supabase
            .from('bets')
            .select('*')
            .eq('user_id', currentUser.id)
            .in('round_id', [serverRoundId, serverRoundId + 1])
            .is('multiplier', null) // Only unresolved bets
            .order('created_at', { ascending: true });

        if (error) {
            console.error('[FSM-Recovery] Server check failed:', error);
            return;
        }

        const assignedWagerIds = new Set();

        [1, 2].forEach(num => {
            const fsm = num === 1 ? sm1 : sm2;
            
            let wager = null;
            if (wagers && wagers.length > 0) {
                if (fsm.betId) {
                    wager = wagers.find(w => w.id === fsm.betId && !assignedWagerIds.has(w.id));
                }
                if (!wager) {
                    wager = wagers.find(w => !assignedWagerIds.has(w.id));
                }
            }

            if (wager) {
                assignedWagerIds.add(wager.id);
                console.log(`[FSM-Recovery] Panel ${num} recovered bet ID: ${wager.id} for round ${wager.round_id}`);
                const hasCashed = wager.multiplier !== null && wager.multiplier !== undefined;
                const wagerRound = Number(wager.round_id);
                const currentRound = Number(serverRoundId);

                // Recovery must drive through the valid FSM path.
                // All recoveries start from IDLE, so we go IDLE → SUBMITTING → ACCEPTED
                // then branch to the correct terminal state.
                // This ensures the FSM callback fires and the UI updates correctly.
                const driveToState = (targetState, meta) => {
                    if (fsm.state !== BetState.IDLE) {
                        // Safely reset to IDLE first
                        fsm.reset('Recovery: resetting to IDLE before driving to target state');
                    }
                    fsm.transitionTo(BetState.SUBMITTING, 'Recovery: driving to ' + targetState, meta);
                    fsm.transitionTo(BetState.ACCEPTED, 'Recovery: accepted', meta);
                    if (targetState !== BetState.ACCEPTED) {
                        fsm.transitionTo(targetState, 'Recovery: restoring state', meta);
                    }
                };

                if (hasCashed) {
                    driveToState(BetState.CASHED_OUT, { betId: wager.id, roundId: wagerRound });
                } else if (wagerRound > currentRound) {
                    driveToState(BetState.QUEUED_FOR_NEXT_ROUND, { betId: wager.id, roundId: wagerRound });
                } else if (wagerRound === currentRound) {
                    if (gameState === 'waiting') {
                        driveToState(BetState.WAITING_FOR_ROUND, { betId: wager.id, roundId: wagerRound });
                    } else if (gameState === 'playing') {
                        driveToState(BetState.WAITING_FOR_ROUND, { betId: wager.id, roundId: wagerRound });
                        fsm.transitionTo(BetState.ROUND_ACTIVE, 'Recovery: round in flight', { betId: wager.id, roundId: wagerRound });
                    } else {
                        driveToState(BetState.ROUND_FINISHED, { betId: wager.id, roundId: wagerRound });
                    }
                }
            } else {
                // No active wager for this panel — ensure it is IDLE
                if (fsm.state !== BetState.IDLE
                    && fsm.state !== BetState.ERROR
                    && fsm.state !== BetState.SUBMITTING) {
                    fsm.reset('Recovery: no active wager on server');
                }
            }
            syncUIFromStateMachine(num);
        });
    } catch (e) {
        console.error('[FSM-Recovery] Recovery error:', e);
    }
}

function updateUI() {
    const headerBalance = document.getElementById('headerBalance');
    const balanceModeTag = document.getElementById('balanceModeTag');
    if (isDemoMode) {
        if (headerBalance) {
            headerBalance.textContent = `KES ${balance.toLocaleString(undefined, {minimumFractionDigits: 2})}`;
            headerBalance.style.color = '#38bdf8';
        }
        if (balanceModeTag) { balanceModeTag.textContent = 'DEMO'; balanceModeTag.style.color = '#38bdf8'; }
    } else {
        if (headerBalance) {
            headerBalance.textContent = `KES ${balance.toLocaleString(undefined, {minimumFractionDigits: 2})}`;
            headerBalance.style.color = '';
        }
        if (balanceModeTag) { balanceModeTag.textContent = 'BALANCE'; balanceModeTag.style.color = ''; }
    }
    syncAccountSwitcherState();
    
    const metricwinBalanceBox = document.getElementById('metricwinBalanceBox');
    if (metricwinBalanceBox) {
        if (isDemoMode) {
            metricwinBalanceBox.textContent = `KES ${Math.floor(balance).toLocaleString()} (DEMO)`;
        } else {
            metricwinBalanceBox.textContent = `KES ${Math.floor(balance).toLocaleString()}`;
        }
    }
    
    syncUIFromStateMachine(1);
    syncUIFromStateMachine(2);
}

function updateMultiplierUI() {
    const el = document.getElementById('multiplier');
    if (!el) return;
    // Always round to exactly 2 decimal places — same precision as serverCrashPoint
    // This ensures the live counter and the crash snapshot never show different values
    const raw = (typeof currentMultiplier === 'number' && !isNaN(currentMultiplier) && isFinite(currentMultiplier) && currentMultiplier > 0)
        ? currentMultiplier : 1.00;
    const safeMult = parseFloat(raw.toFixed(2));
    el.textContent = `${safeMult.toFixed(2)}x`;

    if (typeof gsap !== 'undefined') {
        const intensity = Math.min(1.06, 1 + (safeMult - 1) * 0.002);
        gsap.fromTo(el,
            { scale: 1 },
            { scale: intensity, duration: 0.08, ease: 'power1.out', yoyo: true, repeat: 1 }
        );
    }
}

// ── Account Switcher ────────────────────────────────────────────────────────

/** Sync the visual active state of the account switcher options */
function syncAccountSwitcherState() {
    const realOption  = document.getElementById('acctRealOption');
    const demoOption  = document.getElementById('acctDemoOption');
    const realBadge   = document.getElementById('realActiveBadge');
    const demoBadge   = document.getElementById('demoActiveBadge');
    const note        = document.getElementById('acctModalNote');

    if (!realOption || !demoOption) return;

    if (isDemoMode) {
        demoOption.classList.add('is-active');
        realOption.classList.remove('is-active');
        if (demoBadge) demoBadge.classList.remove('hidden');
        if (realBadge) realBadge.classList.add('hidden');
        if (note) note.textContent = 'Switch to Real Account to play with actual funds.';
    } else {
        realOption.classList.add('is-active');
        demoOption.classList.remove('is-active');
        if (realBadge) realBadge.classList.remove('hidden');
        if (demoBadge) demoBadge.classList.add('hidden');
        if (note) note.textContent = 'Try Demo Mode to practice with virtual funds.';
    }
}

window.openAccountSwitcher = function () {
    const overlay = document.getElementById('accountSwitcherOverlay');
    if (!overlay) return;
    syncAccountSwitcherState();
    overlay.classList.remove('hidden');
};

window.closeAccountSwitcher = function () {
    const overlay = document.getElementById('accountSwitcherOverlay');
    if (overlay) overlay.classList.add('hidden');
};

/**
 * Switch to Real Account:
 *  - If already in real mode → close modal.
 *  - If in demo mode and a real session exists → navigate to /play (drops ?mode=demo).
 *  - If no real session → navigate to /auth to log in.
 */
window.switchToReal = async function () {
    if (!isDemoMode) {
        window.closeAccountSwitcher();
        return;
    }

    try {
        const { data: { session } } = await supabase.auth.getSession();
        if (session) {
            // Already logged in — go to real game (strip demo param)
            window.location.href = window.location.origin + '/aviator';
        } else {
            // No session — send to auth page
            window.location.href = window.location.origin + '/auth';
        }
    } catch (_) {
        window.location.href = window.location.origin + '/auth';
    }
};

/**
 * Switch to Demo Account:
 *  - Navigates to the same game page with ?mode=demo so no custom subdomain is needed.
 *  - Works on aviator.metricwins.com and any host serving play.html.
 */
window.switchToDemo = function () {
    if (isDemoMode) {
        window.closeAccountSwitcher();
        return;
    }
    // Use the current origin with ?mode=demo — avoids relying on demo subdomain DNS
    const base = window.location.origin + '/aviator';
    window.location.href = `${base}?mode=demo`;
};

let lastAddedHistoryRoundId = null;

function addToHistory(m) {
    const val = typeof m === 'number' ? m : parseFloat(m) || 1.00;
    if (lastAddedHistoryRoundId !== null && lastAddedHistoryRoundId === serverRoundId) {
        renderTicker();
        return;
    }
    lastAddedHistoryRoundId = serverRoundId;
    crashHistory.unshift(val);
    if (crashHistory.length > 20) crashHistory.pop();
    if (isDemoMode) {
        try {
            localStorage.setItem('demo_crash_history', JSON.stringify(crashHistory));
        } catch (_) {}
    }
    renderTicker();
}

function renderTicker() {
    const el = document.getElementById('historyTicker');
    if (!el) return;
    el.innerHTML = crashHistory.map(m => {
        const val = typeof m === 'number' ? m : parseFloat(m) || 1.00;
        const cls = val < 2.0 ? 'low' : val < 10.0 ? 'mid' : val < 50.0 ? 'high' : 'ultra';
        return `<div class="hist-pill ${cls}">${val.toFixed(2)}x</div>`;
    }).join('');
}

// Audio functions are imported from ./utils/audio.js

// ── UTILS ──────────────────────────────────────────────────────────────────

// ── UTILS ──────────────────────────────────────────────────────────────────

let currentActiveTab = 'all';
let myBetsList = [];
let myBetsPage = 1;
const SIDEBAR_BET_PAGE_SIZE = 10;

let profileTxList = [];
let profileTxPage = 1;
const PROFILE_TX_PAGE_SIZE = 5;


function bindEvents() {
    document.getElementById('tabAll').addEventListener('click', () => switchTab('all'));
    document.getElementById('tabPrevious').addEventListener('click', () => switchTab('previous'));
    document.getElementById('tabTop').addEventListener('click', () => switchTab('top'));
    const winnersBtn = document.getElementById('tabRecentWinners');
    if (winnersBtn) winnersBtn.addEventListener('click', () => switchTab('recent_wins'));
    document.getElementById('profileBtn').addEventListener('click', openProfile);
    
    const notificationBtn = document.getElementById('notificationBtn');
    if (notificationBtn) notificationBtn.addEventListener('click', openNotifications);
    
    const langSelect = document.getElementById('langSelect');
    if (langSelect) {
        langSelect.addEventListener('change', (e) => {
            showToast(`Language set to ${e.target.value.toUpperCase()}`, 'success');
        });
    }

    // Set a live changing latency simulator
    setInterval(() => {
        const lat = Math.floor(Math.random() * 8) + 12; // 12-20ms
        const latencyEl = document.getElementById('latencyValue');
        if (latencyEl) latencyEl.textContent = `${lat}ms`;
    }, 4000);
}

function switchTab(tab) {
    currentActiveTab = tab;
    // Strip active state from all possible buttons
    ['tabAll', 'tabPrevious', 'tabTop', 'tabRecentWinners'].forEach(id => {
        const b = document.getElementById(id);
        if (b) b.classList.remove('active');
    });
    
    let btnId = 'tabAll';
    if (tab === 'previous') btnId = 'tabPrevious';
    if (tab === 'top') btnId = 'tabTop';
    if (tab === 'recent_wins') btnId = 'tabRecentWinners';
    
    const activeBtn = document.getElementById(btnId);
    if (activeBtn) activeBtn.classList.add('active');
    
    if (tab === 'all') {
        renderAllBets();
    } else if (tab === 'previous') {
        renderMyBets();
    } else if (tab === 'top') {
        renderTopBets();
    } else if (tab === 'recent_wins') {
        renderRecentWinnersTab();
    }
}

async function renderMyBets() {
    const el = document.getElementById('allBetsList');
    if (!el) return;
    
    if (isDemoMode) {
        myBetsPage = 1;
        renderMyBetsPage();
        return;
    }
    
    // Use cached list if present
    if (myBetsList && myBetsList.length > 0) {
        renderMyBetsPage();
        return;
    }
    
    el.innerHTML = `<div style="text-align: center; padding: 24px;"><span class="text-muted">Loading your bets...</span></div>`;
    
    try {
        const { data: bList, error } = await supabase
            .from('bets')
            .select('*')
            .eq('user_id', currentUser.id)
            .order('created_at', { ascending: false })
            .limit(100);
            
        if (error) throw error;
        
        myBetsList = bList || [];
        myBetsPage = 1;
        renderMyBetsPage();
    } catch (e) {
        el.innerHTML = `<div style="text-align: center; padding: 24px; color: var(--error);">Error loading bets</div>`;
    }
}

window.changeMyBetsPage = (page) => {
    myBetsPage = page;
    renderMyBetsPage();
};

function renderMyBetsPage() {
    const el = document.getElementById('allBetsList');
    if (!el) return;

    if (!myBetsList || myBetsList.length === 0) {
        el.innerHTML = `
            <div class="empty-state">
                <i data-lucide="history"></i>
                <span>No bets placed yet</span>
            </div>
        `;
        if (window.lucide) window.lucide.createIcons();
        return;
    }

    const totalPages = Math.max(1, Math.ceil(myBetsList.length / SIDEBAR_BET_PAGE_SIZE));
    if (myBetsPage < 1) myBetsPage = 1;
    if (myBetsPage > totalPages) myBetsPage = totalPages;

    const startIdx = (myBetsPage - 1) * SIDEBAR_BET_PAGE_SIZE;
    const pBets = myBetsList.slice(startIdx, startIdx + SIDEBAR_BET_PAGE_SIZE);

    let html = pBets.map(b => {
        const winningsText = b.status === 'cashed' ? `KES ${parseFloat(b.winnings || 0).toLocaleString()}` : b.status === 'lost' ? 'Lost' : 'Playing';
        const multText = b.status === 'cashed' ? `${parseFloat(b.multiplier_cashed).toFixed(2)}x` : '—';
        const stateClass = b.status === 'cashed' ? 'win' : b.status === 'lost' ? 'lost' : 'playing';
        
        return `
            <div class="bet-row">
                <div class="player-info">
                    <div class="player-avatar" style="background: linear-gradient(135deg, var(--blue), #8B5CF6);">${(currentUser.username || 'P').charAt(0)}</div>
                    <span>${currentUser.username || 'Me'}</span>
                </div>
                <span>${parseFloat(b.amount).toFixed(0)}</span>
                <span class="bet-multiplier ${stateClass}">${multText}</span>
                <span class="${stateClass === 'win' ? 'text-success' : 'text-muted'}">${winningsText}</span>
            </div>
        `;
    }).join('');

    html += `
        <div style="display:flex; justify-content:space-between; align-items:center; padding:8px 12px; background:rgba(0,0,0,0.15); border-top:1px solid rgba(255,255,255,0.05); font-size:0.7rem; color:var(--text-muted); margin-top:8px;">
            <span>Page ${myBetsPage} of ${totalPages}</span>
            <div style="display:flex; gap:6px;">
                <button onclick="changeMyBetsPage(${myBetsPage - 1})" class="quick-btn" style="padding:2px 8px; width:auto; text-transform:none; font-size:0.65rem;" ${myBetsPage === 1 ? 'disabled style="opacity:0.3; cursor:not-allowed;"' : ''}>Prev</button>
                <button onclick="changeMyBetsPage(${myBetsPage + 1})" class="quick-btn" style="padding:2px 8px; width:auto; text-transform:none; font-size:0.65rem;" ${myBetsPage === totalPages ? 'disabled style="opacity:0.3; cursor:not-allowed;"' : ''}>Next</button>
            </div>
        </div>
    `;

    el.innerHTML = html;
}

async function renderTopBets() {
    const el = document.getElementById('allBetsList');
    if (!el) return;
    
    el.innerHTML = `<div style="text-align: center; padding: 24px;"><span class="text-muted">Loading top wins...</span></div>`;
    
    try {
        const { data: bList, error } = await supabase
            .from('bets')
            .select('*, profiles(username, phone)')
            .eq('status', 'cashed')
            .order('winnings', { ascending: false })
            .limit(30);
            
        if (error || !bList || bList.length === 0) {
            el.innerHTML = `
                <div class="empty-state">
                    <i data-lucide="trophy"></i>
                    <span>No big wins recorded yet</span>
                </div>
            `;
            lucide.createIcons();
            return;
        }
        
        el.innerHTML = bList.map(b => {
             const rawName = b.profiles ? (b.profiles.username ? `@${b.profiles.username}` : b.profiles.phone.slice(0, 7) + '***') : 'User';
             const name = escapeHTML(rawName);
             const winningsText = `KES ${parseFloat(b.winnings || 0).toLocaleString()}`;
             const multText = `${parseFloat(b.multiplier_cashed).toFixed(2)}x`;
             
             return `
                 <div class="bet-row">
                     <div class="player-info">
                         <div class="player-avatar" style="background: linear-gradient(135deg, #F59E0B, #FF2D55);">${name.replace('@','').charAt(0)}</div>
                         <span style="font-weight: 600;">${name}</span>
                     </div>
                     <span>${parseFloat(b.amount).toFixed(0)}</span>
                     <span class="bet-multiplier win">${multText}</span>
                     <span class="text-success" style="font-weight: 700;">${winningsText}</span>
                 </div>
             `;
        }).join('');
    } catch (e) {
        el.innerHTML = `<div style="text-align: center; padding: 24px; color: var(--error);">Error loading top bets</div>`;
    }
}

// Debounce flag: prevents the 60 FPS rAF loop from hammering the API
// when the countdown expires but the server hasn't sent 'playing' yet.
let _countdownSyncPending = false;

function updateWaitingCountdown() {
    if (gameState !== 'waiting') {
        _countdownSyncPending = false; // reset on state change
        return;
    }
    const now = Date.now() + serverTimeOffset;
    const elapsed = now - serverRoundStartTime;
    const remaining = Math.max(0, COUNTDOWN_DURATION - elapsed);
    
    const statusEl = document.getElementById('status');
    if (statusEl) {
        if (remaining > 0) {
            _countdownSyncPending = false; // allow re-trigger on the NEXT expiry
            statusEl.innerHTML = `STARTING IN <span class="countdown-sec">${(remaining / 1000).toFixed(1)}s</span>`;
        } else {
            // Show a distinct 'starting soon' text while waiting for server confirmation.
            // 'WAITING FOR NEXT ROUND...' is only shown in startNewRound() (initial state).
            statusEl.textContent = 'STARTING SOON...';
        }
    }

    const fillEl = document.getElementById('waitingProgressBar');
    if (fillEl) {
        const percent = Math.min(100, Math.max(0, (elapsed / COUNTDOWN_DURATION) * 100));
        fillEl.style.width = `${percent}%`;
    }
    
    // Auto-trigger sync when countdown expires to immediately initiate takeoff.
    // DEBOUNCED: Only fire once per expiry, not on every animation frame (60fps),
    // to avoid hammering the REST API while waiting for the server 'playing' event.
    if (remaining <= 0 && !isDemoMode && !_countdownSyncPending) {
        _countdownSyncPending = true;
        fetchServerState();
    }
}

function syncGameBoardOverlay() {
    const partnerEl = document.getElementById('partnershipOverlay');
    const overlayEl = document.querySelector('.game-state-overlay');
    const boardEl = document.getElementById('gameBoard');
    const crashedOverlay = document.getElementById('crashedOverlay');
    
    if (gameState === 'waiting') {
        if (partnerEl) partnerEl.classList.add('active');
        if (overlayEl) overlayEl.classList.add('hidden');
        if (boardEl) boardEl.classList.remove('playing-mode');
        if (crashedOverlay) crashedOverlay.classList.add('hidden');
    } else if (gameState === 'playing') {
        if (partnerEl) partnerEl.classList.remove('active');
        if (overlayEl) overlayEl.classList.remove('hidden');
        if (boardEl) boardEl.classList.add('playing-mode');
        if (crashedOverlay) crashedOverlay.classList.add('hidden');
    } else {
        // crashed
        if (partnerEl) partnerEl.classList.remove('active');
        if (overlayEl) overlayEl.classList.add('hidden'); // HIDDEN during crash to prevent overlapping text
        if (boardEl) boardEl.classList.remove('playing-mode');
        if (crashedOverlay) crashedOverlay.classList.remove('hidden');
    }
}

async function refreshHistoryTicker() {
    if (isDemoMode) {
        renderTicker();
        return;
    }
    try {
        const { data: history } = await supabase
            .from('game_history')
            .select('multiplier')
            .order('id', { ascending: false })
            .limit(20);
        
        if (history && history.length > 0) {
            const dbHistory = history.map(h => parseFloat(h.multiplier));
            
            // Preserve the locally-calculated crash point (crashHistory[0]) which was
            // set by crash() using the server's crash_point at the exact moment of crash.
            // The DB record can differ slightly due to timing — always trust the local value
            // for the most recent entry and use DB for the older entries behind it.
            if (crashHistory.length > 0) {
                const localLatest = crashHistory[0];
                // Use DB history starting from index 1 (keep our local [0])
                const merged = [localLatest, ...dbHistory.filter(v => Math.abs(v - localLatest) > 0.015)].slice(0, 20);
                crashHistory = merged;
            } else {
                crashHistory = dbHistory;
            }
            renderTicker();
        }
    } catch (e) {
        console.error("Failed to refresh round history", e);
    }
}

// Utility functions showToast and haptic are imported from ./utils/toast.js and ./utils/haptics.js

function resetBetStates() {
    traceEngineEvent("resetBetStates:enter");
    const isCrashCleanup = (gameState === 'crashed');
    [1, 2].forEach(num => {
        const fsm = num === 1 ? sm1 : sm2;

        // A QUEUED_FOR_NEXT_ROUND bet: its round hasn't started yet.
        // When startNewRound fires and serverRoundId has advanced to that round,
        // promote it to WAITING_FOR_ROUND so it participates in the next betting window.
        if (fsm.state === BetState.QUEUED_FOR_NEXT_ROUND) {
            if (Number(fsm.roundId) === Number(serverRoundId)) {
                fsm.transitionTo(BetState.WAITING_FOR_ROUND, 'Queued bet promoted — betting window now open');
            }
            // Otherwise it's for an even further future round — leave it queued.
            syncBetObjectFromFSM(num);
            return;
        }

        // Settled terminal states (CASHED_OUT, ROUND_FINISHED, CANCELLED) MUST reset to IDLE when new round waiting phase starts.
        if (fsm.state === BetState.CASHED_OUT || fsm.state === BetState.ROUND_FINISHED || fsm.state === BetState.CANCELLED) {
            fsm.reset('Bet settled — resetting to IDLE for new round');
            syncBetObjectFromFSM(num);
            return;
        }

        // Determine which bets to keep through a crash/reset cycle.
        // During crash cleanup: keep bets for future rounds (roundId > current).
        // During new-round start: keep active bets matching current serverRoundId.
        const shouldKeep = isCrashCleanup
            ? (fsm.roundId && Number(fsm.roundId) > Number(serverRoundId))
            : (fsm.roundId && Number(fsm.roundId) === Number(serverRoundId) && fsm.state !== BetState.IDLE);

        if (!shouldKeep) {
            if (fsm.state !== BetState.IDLE) {
                fsm.reset('Bet settled or reset by round boundary');
            }
        }
        syncBetObjectFromFSM(num);
    });
}

// Persisted Statistics Engine
function loadPlayerStats() {
    let stats = localStorage.getItem('metricwin_player_stats');
    if (!stats) {
        stats = {
            gamesPlayed: 0,
            wins: 0,
            losses: 0,
            totalWagered: 0,
            totalWon: 0,
            maxMult: 1.0,
            maxWin: 0
        };
        localStorage.setItem('metricwin_player_stats', JSON.stringify(stats));
    } else {
        stats = JSON.parse(stats);
    }
    return stats;
}

function updateStatsForUser(wager, netProfit) {
    const stats = loadPlayerStats();
    stats.gamesPlayed++;
    stats.totalWagered += wager;
    
    if (netProfit > 0) {
        stats.wins++;
        stats.totalWon += (wager + netProfit);
        if (wager + netProfit > stats.maxWin) {
            stats.maxWin = wager + netProfit;
        }
    } else {
        stats.losses++;
    }
    
    localStorage.setItem('metricwin_player_stats', JSON.stringify(stats));
}

function finalizeCrashedBets() {
    [1, 2].forEach(num => {
        const fsm = num === 1 ? sm1 : sm2;
        const config = num === 1 ? autoConfig1 : autoConfig2;
        const betObj = num === 1 ? bet1 : bet2;
        
        // Finalize bets that are active in the current crashed round
        const isLiveThisRound = (fsm.state === BetState.ROUND_ACTIVE || fsm.state === BetState.CASHED_OUT || fsm.state === BetState.CASHING_OUT) && (fsm.roundId === serverRoundId);
        
        if (isLiveThisRound) {
            const hasWon = fsm.state === BetState.CASHED_OUT;
            
            fsm.transitionTo(BetState.ROUND_FINISHED, `Round crashed. Outcome: ${hasWon ? 'WON' : 'LOST'}`, {
                roundId: serverRoundId
            });

            if (isDemoMode) {
                const demoBetObj = myBetsList.find(b => b.id === fsm.betId);
                if (demoBetObj && !demoBetObj.winnings) {
                    demoBetObj.status = 'lost';
                }
            }
            
            const stakeInput = document.getElementById(`betAmount${num}`);
            const stakeVal = parseFloat(stakeInput ? stakeInput.value : 50) || 50;
            const netProfit = hasWon ? (betObj.winnings - stakeVal) : -stakeVal;
            
            updateStatsForUser(stakeVal, netProfit);
            
            const bet = num === 1 ? bet1 : bet2;
            if (bet.auto && config.active) {
                if (config.roundsRemaining > 0) {
                    config.roundsRemaining--;
                    document.getElementById(`autoRoundLimit${num}`).value = config.roundsRemaining;
                }
                
                config.accumulatedProfit += netProfit;
                
                let stopTriggered = false;
                if (config.profitTarget && config.accumulatedProfit >= config.profitTarget) {
                    showToast(`Auto Bet ${num}: Target profit reached!`, 'success');
                    stopTriggered = true;
                } else if (config.lossLimit && config.accumulatedProfit <= -config.lossLimit) {
                    showToast(`Auto Bet ${num}: Stop loss limit triggered!`, 'warning');
                    stopTriggered = true;
                } else if (config.roundsRemaining <= 0) {
                    showToast(`Auto Bet ${num}: Target rounds completed!`, 'info');
                    stopTriggered = true;
                }
                
                if (stopTriggered) {
                    config.active = false;
                    fsm.transitionTo(BetState.IDLE, 'Auto bet target or limit hit');
                } else {
                    const nextStakeInput = document.getElementById(`betAmount${num}`);
                    let baseVal = config.baseAmount;
                    let currentVal = parseFloat(nextStakeInput.value) || baseVal;
                    
                    if (hasWon) {
                        if (config.winStrategy === 'martingale') {
                            nextStakeInput.value = Math.min(50000, currentVal * 2);
                        } else if (config.winStrategy === 'custom') {
                            nextStakeInput.value = Math.min(50000, Math.floor(currentVal * config.winFactor));
                        } else {
                            nextStakeInput.value = baseVal;
                        }
                    } else {
                        if (config.lossStrategy === 'martingale') {
                            nextStakeInput.value = Math.min(50000, currentVal * 2);
                        } else if (config.lossStrategy === 'custom') {
                            nextStakeInput.value = Math.min(50000, Math.floor(currentVal * config.lossFactor));
                        } else {
                            nextStakeInput.value = baseVal;
                        }
                    }
                    
                    fsm.transitionTo(BetState.IDLE, 'Auto bet ready for next round');
                }
            } else {
                fsm.transitionTo(BetState.IDLE, 'Bet settled and returned to IDLE');
            }
        }
    });
}

// ── MOCK SIMULATION ────────────────────────────────────────────────────────

function spawnSimulatedBets() {
    allBets = generateSimulatedBetsForRound(serverRoundId || Math.floor(Date.now() / 15000));
    
    currentLobbyCount = getActivePlayersBadgeValue(serverRoundId || Math.floor(Date.now() / 15000));
    const badgeCount = document.getElementById('livePlayerCount');
    if (badgeCount) badgeCount.textContent = currentLobbyCount.toLocaleString();
    
    if (currentActiveTab === 'all') {
        renderAllBets();
    }
}

function renderAllBets() {
    const el = document.getElementById('allBetsList');
    if (!el) return;
    
    el.innerHTML = allBets.map(b => {
        const isCashed = b.status === 'cashed';
        const multText = isCashed ? `${b.mult.toFixed(2)}x` : '';
        const formattedAmt = b.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        const winText = isCashed ? (b.win ? b.win.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '') : '-';
        const stateColorClass = isCashed ? 'win' : '';
        const labelStyle = isCashed ? 'color: #10b981; font-weight:700;' : 'color: var(--text-muted);';
        
        const betContent = b.isFreeBet
            ? `<span class="free-bet-badge">FREE BET</span>`
            : formattedAmt;
            
        const avBg = (b.avatar && typeof b.avatar === 'object') ? b.avatar.bg : 'linear-gradient(135deg, #0284c7, #38bdf8)';
        const avLabel = (b.avatar && typeof b.avatar === 'object') ? b.avatar.label : (typeof b.avatar === 'string' ? b.avatar : '👤');
        
        return `
            <div class="bet-row" style="${isCashed ? 'background: rgba(16, 185, 129, 0.12); border: 1px solid rgba(16, 185, 129, 0.22);' : ''}">
                <div class="player-info">
                    <div class="player-avatar" style="background: ${avBg};">${avLabel}</div>
                    <span style="font-weight: 600; color: var(--text-primary);">${b.name}</span>
                </div>
                <span style="color: var(--text-secondary); font-family: var(--font-mono);">${betContent}</span>
                <span class="bet-multiplier ${stateColorClass}" style="${isCashed ? 'color: #38bdf8; font-weight: 700;' : 'color: var(--text-muted);'}">${multText}</span>
                <span style="${labelStyle}">${winText}</span>
            </div>
        `;
    }).join('');
}

function renderRecentWinnersTab() {
    const el = document.getElementById('allBetsList');
    if (!el) return;
    
    if (recentWinners.length === 0) {
        el.innerHTML = `
            <div class="empty-state">
                <i data-lucide="trophy"></i>
                <span>No winners this session</span>
            </div>
        `;
        lucide.createIcons();
        return;
    }
    
    el.innerHTML = recentWinners.map(b => {
        const isBig = b.win >= 3000;
        return `
            <div class="bet-row" style="${isBig ? 'background: rgba(245, 158, 11, 0.06); border-left: 2px solid #F59E0B;' : ''}">
                <div class="player-info">
                    <div class="player-avatar" style="background:#F59E0B;">🏆</div>
                    <span style="font-weight:${isBig ? '700' : '500'};">${b.name}</span>
                </div>
                <span>${b.amount}</span>
                <span class="bet-multiplier win">${b.mult.toFixed(2)}x</span>
                <span class="text-success" style="font-weight:700;">KES ${b.win.toLocaleString()}</span>
            </div>
        `;
    }).join('');
}

// ── CANVAS FLIGHT ENGINE ───────────────────────────────────────────────────
// FlightScene is defined in ./modules/game/FlightScene.js and imported by
// gameEngine.js. It reads exclusively from gameBridge (no window.* access).
// The duplicate inline class that previously existed here has been removed
// as part of Phase 2 (Root Cause #2 fix).
// The phaserGame and flightScene variables below are only kept for legacy
// references elsewhere in this file; they are not used by FlightScene.
let phaserGame = null;
let flightScene = null;

// initCanvas is imported from ./modules/game/gameEngine.js

function updateGraph() {
    // Stubbed — handled dynamically by FlightScene update thread
}

// Expose helpers to window for HTML onclicks
window.adjustBet = (num, delta) => {
    const bet = num === 1 ? bet1 : bet2;
    if (bet.active && !bet.cashed) return;
    const input = document.getElementById(`betAmount${num}`);
    let current = parseFloat(input.value) || 50;
    input.value = Math.max(50, current + delta).toFixed(2);
};

window.setBet = (num, val) => {
    const bet = num === 1 ? bet1 : bet2;
    if (bet.active && !bet.cashed) return;
    document.getElementById(`betAmount${num}`).value = parseFloat(val).toFixed(2);
};

window.doubleBet = (num) => {
    const bet = num === 1 ? bet1 : bet2;
    if (bet.active && !bet.cashed) return;
    const input = document.getElementById(`betAmount${num}`);
    if (input) {
        let val = parseFloat(input.value) || 50;
        input.value = Math.min(50000, val * 2).toFixed(2);
    }
};

window.halveBet = (num) => {
    const bet = num === 1 ? bet1 : bet2;
    if (bet.active && !bet.cashed) return;
    const input = document.getElementById(`betAmount${num}`);
    if (input) {
        let val = parseFloat(input.value) || 50;
        input.value = Math.max(50, val / 2).toFixed(2);
    }
};

window.minBet = (num) => {
    const bet = num === 1 ? bet1 : bet2;
    if (bet.active && !bet.cashed) return;
    const input = document.getElementById(`betAmount${num}`);
    if (input) input.value = "50.00";
};

window.maxBet = (num) => {
    const bet = num === 1 ? bet1 : bet2;
    if (bet.active && !bet.cashed) return;
    const input = document.getElementById(`betAmount${num}`);
    if (input) input.value = "50000.00";
};

window.toggleBetMode = (num, mode) => {
    const isAuto = mode === 'auto';
    document.getElementById(`tabBet${num}`).classList.toggle('active', !isAuto);
    document.getElementById(`tabAuto${num}`).classList.toggle('active', isAuto);
    document.getElementById(`autoSettings${num}`).classList.toggle('hidden', !isAuto);
    
    // Hide inline auto cashout row when in Auto tab to prevent duplicate UI controls
    const inlineEl = document.getElementById(`autoCashoutInline${num}`);
    if (inlineEl) inlineEl.classList.toggle('hidden', isAuto);

    const bet = num === 1 ? bet1 : bet2;
    bet.auto = isAuto;
    
    updateUI();
};

window.setAutoStrategy = (num, triggerType, strategy) => {
    const prefix = triggerType === 'loss' ? 'loss' : 'win';
    
    document.getElementById(`${prefix}Flat${num}`).classList.remove('active');
    document.getElementById(`${prefix}Mart${num}`).classList.remove('active');
    document.getElementById(`${prefix}Custom${num}`).classList.remove('active');
    
    let btnId = `${prefix}Flat${num}`;
    if (strategy === 'martingale') btnId = `${prefix}Mart${num}`;
    if (strategy === 'custom') btnId = `${prefix}Custom${num}`;
    
    document.getElementById(btnId).classList.add('active');
    
    // Toggle multiplier input container
    const wrap = document.getElementById(`${prefix}CustomInputWrap${num}`);
    if (wrap) wrap.classList.toggle('hidden', strategy !== 'custom');
    
    const config = num === 1 ? autoConfig1 : autoConfig2;
    const factorInput = document.getElementById(`${prefix}CustomFactor${num}`);
    const factor = parseFloat(factorInput ? factorInput.value : 2.0) || 2.0;

    if (triggerType === 'loss') {
        config.lossStrategy = strategy;
        config.lossFactor = factor;
    } else {
        config.winStrategy = strategy;
        config.winFactor = factor;
    }
};

window.toggleAutoBet = (num) => {
    const config = num === 1 ? autoConfig1 : autoConfig2;
    const bet = num === 1 ? bet1 : bet2;
    
    if (config.active) {
        config.active = false;
        showToast(`Auto Bet ${num} deactivated`, 'warning');
        updateUI();
    } else {
        const inputAmount = parseFloat(document.getElementById(`betAmount${num}`).value);
        if (isNaN(inputAmount) || inputAmount < 50) {
            showToast("Enter a starting bet of KES 50+", 'error');
            return;
        }
        
        config.active = true;
        config.baseAmount = inputAmount;
        config.roundsRemaining = parseInt(document.getElementById(`autoRoundLimit${num}`).value) || 999;
        // Capture settings at activation time — checkAutoCashOut reads these directly
        // instead of DOM inputs so the target is stable for the entire round.
        const autoCheckEl = document.getElementById(`autoBetEnableCash${num}`) || document.getElementById(`enableAutoCash${num}`);
        const autoValEl = document.getElementById(`autoBetCashVal${num}`) || document.getElementById(`autoCashVal${num}`);
        config.enableAutoCash = autoCheckEl ? autoCheckEl.checked : true;
        config.autoCashVal = autoValEl ? (parseFloat(autoValEl.value) || 2.0) : 2.0;
        config.profitTarget = parseFloat(document.getElementById(`autoProfitTarget${num}`).value) || null;
        config.lossLimit = parseFloat(document.getElementById(`autoLossLimit${num}`).value) || null;
        
        config.startBalance = balance;
        config.accumulatedProfit = 0;
        
        showToast(`Auto Bet ${num} running!`, 'success');
        updateUI();
        
        // Place a bet immediately if we are in the waiting phase.
        // If the game is currently flying or crashed and the bet slot is free,
        // queue a bet for the NEXT round so auto-bet kicks in right away.
        if (!bet.active) {
            placeAutoBet(num);
        }
    }
};

window.placeBet = placeBet;
window.cashOutBet = cashOutBet;

window.closeModal = () => {
    document.getElementById('modalBackdrop').classList.remove('show');
    if (window.activePaymentPollId) {
        clearInterval(window.activePaymentPollId);
        window.activePaymentPollId = null;
    }
    if (window.activePaymentTimeoutId) {
        clearTimeout(window.activePaymentTimeoutId);
        window.activePaymentTimeoutId = null;
    }
    const windowEl = document.getElementById('modalWindow');
    if (windowEl) {
        windowEl.style.backgroundColor = '';
        windowEl.style.color = '';
    }
    // Clean hash route from URL completely
    window.history.replaceState(null, null, window.location.pathname + window.location.search);
};

window.activePaymentPollId = null;
window.activePaymentTimeoutId = null;

window.showWaitingPaymentScreen = (phone, amount, transactionId) => {
    const backdrop = document.getElementById('modalBackdrop');
    if (backdrop) backdrop.classList.add('show');

    const windowEl = document.getElementById('modalWindow');
    if (!windowEl) return;

    windowEl.className = 'modal-window profile-modal';

    let formattedPhone = phone;
    if (phone.startsWith('254') && phone.length === 12) {
        formattedPhone = `0${phone.slice(3)}`;
    }

    const renderPendingState = () => {
        windowEl.innerHTML = `
            <style>
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
            </style>
            <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 32px 24px; text-align: center; color: #fff; min-height: 350px; position: relative;">
                <button onclick="closeModal()" style="position: absolute; top: 12px; right: 12px; background: transparent; border: none; color: var(--text-muted); cursor: pointer; font-size: 1.5rem; padding: 5px; display: flex; align-items: center; justify-content: center; z-index: 10;">
                    &times;
                </button>

                <div style="position: relative; width: 64px; height: 64px; margin-bottom: 24px; display: flex; align-items: center; justify-content: center;">
                    <div style="box-sizing: border-box; width: 60px; height: 60px; border: 4px solid rgba(76, 128, 20, 0.15); border-top: 4px solid #4C8014; border-radius: 50%; animation: spin 1s linear infinite;"></div>
                </div>

                <h3 style="font-size: 1.3rem; font-weight: 800; color: #fff; margin: 0 0 10px;">Waiting for payment...</h3>

                <p style="font-size: 0.85rem; color: var(--text-secondary); line-height: 1.5; margin: 0 0 24px; max-width: 280px;">
                    Check your phone and enter your M-PESA PIN to complete the KES ${parseInt(amount).toLocaleString()} payment.
                </p>

                <div style="background: rgba(76, 128, 20, 0.1); border: 1px solid rgba(76, 128, 20, 0.2); padding: 10px 18px; border-radius: 30px; display: flex; align-items: center; gap: 8px; justify-content: center; max-width: 95%;">
                    <span style="font-size: 0.78rem; font-weight: 700; color: #76c720; display: flex; align-items: center; gap: 6px;">
                        📱 A prompt has been sent to ${formattedPhone}
                    </span>
                </div>
            </div>
        `;
    };

    renderPendingState();

    if (window.activePaymentPollId) {
        clearInterval(window.activePaymentPollId);
        window.activePaymentPollId = null;
    }
    if (window.activePaymentTimeoutId) {
        clearTimeout(window.activePaymentTimeoutId);
        window.activePaymentTimeoutId = null;
    }

    let secondsElapsed = 0;
    const maxSeconds = 90; // 90 seconds timeout for M-Pesa STK PIN prompt
    const initialBalance = typeof balance === 'number' ? balance : 0;

    const performPoll = async () => {
        try {
            let status = '';
            const { data, error } = await supabase
                .from('transactions')
                .select('status')
                .eq('reference', transactionId)
                .maybeSingle();

            if (!error && data?.status) {
                status = String(data.status).toLowerCase();
            }

            // Also check if wallet balance has updated
            if (typeof refreshBalance === 'function') {
                await refreshBalance();
                if (typeof balance === 'number' && balance >= initialBalance + parseInt(amount)) {
                    status = 'completed';
                }
            }

            if (status === 'completed' || status === 'success') {
                if (window.activePaymentPollId) {
                    clearInterval(window.activePaymentPollId);
                    window.activePaymentPollId = null;
                }
                if (window.activePaymentTimeoutId) {
                    clearTimeout(window.activePaymentTimeoutId);
                    window.activePaymentTimeoutId = null;
                }

                if (typeof playSoundCashOut === 'function') playSoundCashOut();

                windowEl.innerHTML = `
                    <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 32px 24px; text-align: center; color: #fff; min-height: 350px;">
                        <div style="width: 64px; height: 64px; border-radius: 50%; background: #4C8014; display: flex; align-items: center; justify-content: center; margin-bottom: 24px; box-shadow: 0 4px 15px rgba(76, 128, 20, 0.4);">
                            <svg style="width: 32px; height: 32px; stroke: #fff; fill: none; stroke-width: 3;" viewBox="0 0 24 24">
                                <polyline points="20 6 9 17 4 12"></polyline>
                            </svg>
                        </div>

                        <h3 style="font-size: 1.3rem; font-weight: 800; color: #fff; margin: 0 0 10px;">Payment successful!</h3>

                        <p style="font-size: 0.85rem; color: var(--text-secondary); line-height: 1.5; margin: 0 0 24px; max-width: 280px;">
                            KES ${parseInt(amount).toLocaleString()} has been credited to your wallet balance.
                        </p>
                    </div>
                `;

                if (typeof refreshBalance === 'function') await refreshBalance();
                if (typeof updateUI === 'function') updateUI();

                setTimeout(() => {
                    window.closeModal();
                }, 2500);

            } else if (status === 'failed' || status === 'reversed' || status === 'cancelled') {
                if (window.activePaymentPollId) {
                    clearInterval(window.activePaymentPollId);
                    window.activePaymentPollId = null;
                }
                if (window.activePaymentTimeoutId) {
                    clearTimeout(window.activePaymentTimeoutId);
                    window.activePaymentTimeoutId = null;
                }

                windowEl.innerHTML = `
                    <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 32px 24px; text-align: center; color: #fff; min-height: 350px; position: relative;">
                        <button onclick="closeModal()" style="position: absolute; top: 12px; right: 12px; background: transparent; border: none; color: var(--text-muted); cursor: pointer; font-size: 1.5rem; padding: 5px;">
                            &times;
                        </button>

                        <div style="width: 64px; height: 64px; border-radius: 50%; background: #ea580c; display: flex; align-items: center; justify-content: center; margin-bottom: 24px; box-shadow: 0 4px 15px rgba(234, 88, 12, 0.4);">
                            <svg style="width: 32px; height: 32px; stroke: #fff; fill: none; stroke-width: 3;" viewBox="0 0 24 24">
                                <line x1="18" y1="6" x2="6" y2="18"></line>
                                <line x1="6" y1="6" x2="18" y2="18"></line>
                            </svg>
                        </div>

                        <h3 style="font-size: 1.3rem; font-weight: 800; color: #fff; margin: 0 0 10px;">Payment Failed</h3>

                        <p style="font-size: 0.85rem; color: var(--text-secondary); line-height: 1.5; margin: 0 0 24px; max-width: 280px;">
                            The M-Pesa transaction was cancelled or declined on your handset.
                        </p>
                    </div>
                `;
            }
        } catch (pollErr) {
            console.error("Error during status polling:", pollErr);
        }
    };

    // Poll every 3 seconds up to 90 seconds
    window.activePaymentPollId = setInterval(async () => {
        secondsElapsed += 3;
        await performPoll();

        if (secondsElapsed >= maxSeconds) {
            if (window.activePaymentPollId) {
                clearInterval(window.activePaymentPollId);
                window.activePaymentPollId = null;
            }
            if (window.activePaymentTimeoutId) {
                clearTimeout(window.activePaymentTimeoutId);
                window.activePaymentTimeoutId = null;
            }

            windowEl.style.backgroundColor = '#ffffff';
            windowEl.style.color = '#111827';
            windowEl.innerHTML = `
                <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 32px 24px; text-align: center; color: #111827; background: #ffffff; border-radius: 20px; min-height: 280px; position: relative; font-family: sans-serif;">
                    <!-- Close visual cross at top right -->
                    <button onclick="closeModal()" style="position: absolute; top: 16px; right: 16px; background: #F3F4F6; border: none; color: #9CA3AF; width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 1.1rem; z-index: 10;">
                        &times;
                    </button>

                    <!-- Red Circle with X -->
                    <div style="width: 56px; height: 56px; border-radius: 50%; border: 3px solid #EF4444; display: flex; align-items: center; justify-content: center; margin-bottom: 16px;">
                        <svg style="width: 24px; height: 24px; stroke: #EF4444; stroke-width: 3.5; fill: none; stroke-linecap: round; stroke-linejoin: round;" viewBox="0 0 24 24">
                            <line x1="18" y1="6" x2="6" y2="18"></line>
                            <line x1="6" y1="6" x2="18" y2="18"></line>
                        </svg>
                    </div>

                    <!-- Title -->
                    <h3 style="font-size: 1.25rem; font-weight: 800; color: #111827; margin: 0 0 8px;">Payment Failed</h3>

                    <!-- Description -->
                    <p style="font-size: 0.85rem; color: #4B5563; line-height: 1.45; margin: 0 0 24px; max-width: 260px;">
                        STK Push timed out on your phone. Please try again.
                    </p>

                    <!-- Side-by-side buttons -->
                    <div style="display: flex; gap: 12px; width: 100%; max-width: 280px; justify-content: center;">
                        <button onclick="openDeposit()" style="flex: 1; border: 1.5px solid #0F9F48; background: #ffffff; color: #0F9F48; font-weight: 700; padding: 11px 16px; border-radius: 10px; font-size: 0.88rem; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all 0.2s;">
                            Try Again
                        </button>
                        <button onclick="closeModal()" style="flex: 1; border: none; background: #F3F4F6; color: #374151; font-weight: 700; padding: 11px 16px; border-radius: 10px; font-size: 0.88rem; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: all 0.2s;">
                            Dismiss
                        </button>
                    </div>
                </div>
            `;
        }
    }, 3000);
};

window.showWithdrawalSuccessScreen = (phone, amount) => {
    // Make sure modal backdrop is active
    const backdrop = document.getElementById('modalBackdrop');
    if (backdrop) backdrop.classList.add('show');

    const windowEl = document.getElementById('modalWindow');
    if (!windowEl) return;

    // Reset layout configuration style
    windowEl.className = 'modal-window profile-modal';

    let formattedPhone = phone;
    if (phone.startsWith('254') && phone.length === 12) {
        formattedPhone = `0${phone.slice(3)}`;
    }

    windowEl.innerHTML = `
        <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 32px 24px; text-align: center; color: #fff; min-height: 350px; position: relative;">
            <button onclick="closeModal()" style="position: absolute; top: 12px; right: 12px; background: transparent; border: none; color: var(--text-muted); cursor: pointer; font-size: 1.5rem; padding: 5px; display: flex; align-items: center; justify-content: center; z-index: 10;">
                &times;
            </button>

            <div style="width: 64px; height: 64px; border-radius: 50%; background: #10B981; display: flex; align-items: center; justify-content: center; margin-bottom: 24px; box-shadow: 0 4px 15px rgba(16, 185, 129, 0.35);">
                <svg style="width: 32px; height: 32px; stroke: #fff; fill: none; stroke-width: 2.5;" viewBox="0 0 24 24">
                    <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
            </div>

            <h3 style="font-size: 1.3rem; font-weight: 800; color: #fff; margin: 0 0 12px;">Withdrawal Processed!</h3>

            <p style="font-size: 0.88rem; color: var(--text-secondary); line-height: 1.55; margin: 0 0 20px; max-width: 320px;">
                Your withdrawal of <strong>KES ${parseInt(amount).toLocaleString()}</strong> to ${formattedPhone} has been processed. Funds sent to M-Pesa.
            </p>

            <div style="background: rgba(16, 185, 129, 0.08); border: 1px solid rgba(16, 185, 129, 0.25); padding: 14px 16px; border-radius: 12px; max-width: 320px; text-align: left; display: flex; gap: 10px; align-items: flex-start;">
                <span style="font-size: 1.2rem; line-height: 1;">📱</span>
                <span style="font-size: 0.78rem; color: #34D399; line-height: 1.45; font-weight: 500;">
                    You will receive an M-Pesa SMS notification instantly.
                </span>
            </div>
        </div>
    `;
};

function CryptoJS_SHA256(str) {
    let h = 0;
    for (let i = 0; i < str.length; i++) {
        h = (h << 5) - h + str.charCodeAt(i);
        h |= 0;
    }
    const hex = Math.abs(h).toString(16).padEnd(8, '0');
    return `sha256_${hex}5cbbf5e9f80a424e8e19c72e29367468${hex}`;
}

// Volume adjust helper
window.setVolume = (val) => {
    localStorage.setItem('sound_volume', val);
    showToast(`Volume adjusted to ${val}%`, 'info');
};

// --- SYSTEM NOTIFICATIONS ---
window.openNotifications = async () => {
    const backdrop = document.getElementById('modalBackdrop');
    const windowEl = document.getElementById('modalWindow');
    if (!backdrop || !windowEl) return;

    backdrop.classList.add('show');
    windowEl.className = 'modal-window profile-modal';

    windowEl.innerHTML = `
        <div style="text-align:left; position:relative;">
            <button onclick="toggleSidebarMenu()" class="pm-menu" style="position:absolute; top:-10px; left:-10px;" aria-label="Open Navigation Menu" title="Menu"><i data-lucide="menu" style="width: 15px; height: 15px;"></i></button>
            <button onclick="closeModal()" class="pm-close" style="position:absolute; top:-10px; right:-10px;">&times;</button>
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px; flex-wrap:wrap; gap:8px; padding-top:20px;">
                <h2 style="font-weight:700; font-size:1.15rem; display:flex; align-items:center; gap:8px; margin:0;">🔔 Notifications Center</h2>
                <button id="markAllReadBtn" style="background:none; border:none; color:var(--primary); font-size:0.7rem; cursor:pointer; font-weight:700; text-transform:uppercase; letter-spacing:0.5px; padding:4px 8px; border-radius:4px; display:none;" onclick="window.markAllNotifsAsRead()">Mark all as read</button>
            </div>
            <p style="color:var(--text-secondary); font-size:0.78rem; margin-bottom:18px;">Stay informed on account activities, financial clearances, and platform alerts.</p>
            <div id="notifListLoader" style="text-align:center; padding:30px; color:var(--text-muted); font-size:0.8rem;">Loading notifications...</div>
            <div id="notifListContent" style="max-height:280px; overflow-y:auto; margin-bottom:16px; display:flex; flex-direction:column; gap:8px;"></div>
            <button class="auth-btn ghost" onclick="closeModal()">CLOSE PANEL</button>
        </div>
    `;

    try {
        if (!currentUser) return;
        if (isDemoMode) {
            const loader = document.getElementById('notifListLoader');
            if (loader) loader.style.display = 'none';
            const content = document.getElementById('notifListContent');
            if (content) {
                content.innerHTML = `<div style="text-align:center; padding:24px; color:var(--text-muted); font-size:0.75rem;">Notifications are disabled in Demo Mode.</div>`;
            }
            return;
        }
        const { data: notices, error } = await supabase
            .from('notifications')
            .select('*')
            .or(`user_id.is.null,user_id.eq.${currentUser.id}`)
            .order('created_at', { ascending: false })
            .limit(30);

        const loader = document.getElementById('notifListLoader');
        if (loader) loader.style.display = 'none';

        if (error) throw error;

        const content = document.getElementById('notifListContent');
        if (!content) return;

        window.currentNotices = notices || [];

        if (!notices || notices.length === 0) {
            content.innerHTML = `<div style="text-align:center; padding:24px; color:var(--text-muted); font-size:0.75rem;">You have no notifications yet.</div>`;
            return;
        }

        // Get read ids
        let readIds = [];
        try {
            readIds = JSON.parse(localStorage.getItem('read_notifications')) || [];
        } catch(e) { readIds = []; }

        // Only show "Mark All as Read" if there actually are unread notifications in this batch
        const unreadCount = notices.filter(n => !readIds.includes(n.id)).length;
        const markBtn = document.getElementById('markAllReadBtn');
        if (markBtn) {
            markBtn.style.display = unreadCount > 0 ? 'inline-block' : 'none';
        }

        content.innerHTML = notices.map(n => {
            const isRead = readIds.includes(n.id);
            const timeStr = new Date(n.created_at).toLocaleString('en-KE', {
                day: 'numeric',
                month: 'short',
                hour: '2-digit',
                minute: '2-digit'
            });
            const unreadDot = isRead ? '' : `<span style="width: 7px; height: 7px; background: var(--primary); border-radius: 50%; display: inline-block;"></span>`;
            const cardBg = isRead ? 'rgba(255,255,255,0.015)' : 'rgba(255,255,255,0.04)';
            const cardBorder = isRead ? '1px solid var(--border)' : '1px solid var(--primary)';
            
            const actionAttr = n.action_url 
                ? `onclick="window.handleNotifClick('${n.id}', '${n.action_url}')"` 
                : `onclick="window.handleNotifClick('${n.id}', null)"`;
            
            let actionText = '';
            if (n.action_url) {
                if (n.action_url.startsWith('claim:')) {
                    actionText = `<div style="margin-top:6px; font-size:0.68rem; font-weight:700; color:#ec4899; display:flex; align-items:center; gap:4px;">🎁 Claim Bonus Code ➜</div>`;
                } else {
                    actionText = `<div style="margin-top:6px; font-size:0.68rem; font-weight:700; color:var(--primary); display:flex; align-items:center; gap:4px;">Visit Link ➜</div>`;
                }
            }

            return `
                <div ${actionAttr} style="cursor:pointer; background:${cardBg}; border:${cardBorder}; padding:10px 12px; border-radius:6px; text-align:left; transition: all 0.2s; position:relative;">
                    <div style="display:flex; justify-content:space-between; font-size:0.75rem; font-weight:700; margin-bottom:3px; align-items:center; gap:8px;">
                        <span style="color:#fff; display:flex; align-items:center; gap:6px;">${unreadDot} ${n.title}</span>
                        <span style="color:var(--text-muted); font-size:0.65rem; white-space:nowrap;">${timeStr}</span>
                    </div>
                    <div style="font-size:0.72rem; color:var(--text-secondary); line-height:1.35; word-break:break-word;">${n.message}</div>
                    ${actionText}
                </div>
            `;
        }).join('');
    } catch(e) {
        console.error("Failed to load notifications:", e);
        const content = document.getElementById('notifListContent');
        if (content) content.innerHTML = `<div style="color:var(--error); font-size:0.72rem;">Error loading notifications.</div>`;
    }
};

window.handleNotifClick = (id, url) => {
    let readIds = [];
    try {
        readIds = JSON.parse(localStorage.getItem('read_notifications')) || [];
    } catch(e) {}
    if (!readIds.includes(id)) {
        readIds.push(id);
        localStorage.setItem('read_notifications', JSON.stringify(readIds));
    }
    
    // Refresh unreadBadge
    if (typeof window.initNotificationsRealtime === 'function') {
        window.initNotificationsRealtime();
    }
    
    // Navigate/switch tab if URL exists
    if (url) {
        closeModal();
        if (url.startsWith('claim:')) {
            const code = url.substring(6);
            setTimeout(() => {
                const backdrop = document.getElementById('modalBackdrop');
                if (backdrop) backdrop.classList.add('show');
                renderProfileTab('promocode', code);
            }, 100);
        } else if (url.startsWith('/#') || url.startsWith('#')) {
            const cleanHash = url.substring(url.indexOf('#') + 1);
            if (cleanHash === 'deposit') {
                renderProfileTab('deposit');
            } else if (cleanHash === 'referral' || cleanHash === 'referrals') {
                renderProfileTab('referrals');
            } else {
                window.location.href = url;
            }
        } else {
            window.open(url, '_blank');
        }
    } else {
        // Toggle the visual read state immediately
        window.openNotifications();
    }
};

window.markAllNotifsAsRead = () => {
    const list = window.currentNotices || [];
    let readIds = [];
    try {
        readIds = JSON.parse(localStorage.getItem('read_notifications')) || [];
    } catch(e) {}
    list.forEach(n => {
        if (!readIds.includes(n.id)) {
            readIds.push(n.id);
        }
    });
    localStorage.setItem('read_notifications', JSON.stringify(readIds));
    
    // Update badge immediately
    const badge = document.getElementById('unreadBadge');
    if (badge) {
        badge.classList.add('hidden');
        badge.textContent = '0';
    }
    
    // Re-render
    window.openNotifications();
};

window.initNotificationsRealtime = async () => {
    if (!currentUser || isDemoMode) return;

    const query = async () => {
        try {
            const { data: notices, error } = await supabase
                .from('notifications')
                .select('id')
                .or(`user_id.is.null,user_id.eq.${currentUser.id}`);

            if (error) return;

            let readIds = [];
            try {
                readIds = JSON.parse(localStorage.getItem('read_notifications')) || [];
            } catch(e) { readIds = []; }

            const unreadCount = notices.filter(n => !readIds.includes(n.id)).length;
            const badge = document.getElementById('unreadBadge');
            if (badge) {
                if (unreadCount > 0) {
                    badge.classList.remove('hidden');
                    badge.textContent = unreadCount;
                } else {
                    badge.classList.add('hidden');
                    badge.textContent = '0';
                }
            }
        } catch(e) {}
    };

    await query();

    // Subscribe to realtime notification changes
    supabase
        .channel('realtime_user_notifications')
        .on(
            'postgres_changes',
            { event: 'INSERT', schema: 'public', table: 'notifications' },
            (payload) => {
                const newNotif = payload.new;
                if (newNotif && (newNotif.user_id === null || newNotif.user_id === currentUser.id)) {
                    query();
                    showToast(`🔔 New message: ${newNotif.title}`, 'info');
                }
            }
        )
        .subscribe();
};

window.handlePromoAction = (actionType, actionUrl) => {
    if (actionType === 'play') {
        closeModal();
    } else if (actionType === 'deposit') {
        renderProfileTab('deposit');
    } else if (actionType === 'refer' || actionType === 'referrals') {
        renderProfileTab('referrals');
    } else if (actionType === 'claim') {
        renderProfileTab('promocode', actionUrl);
    } else if (actionUrl) {
        if (actionUrl.startsWith('/#') || actionUrl.startsWith('#')) {
            const cleanHash = actionUrl.substring(actionUrl.indexOf('#') + 1);
            if (cleanHash === 'deposit') {
                renderProfileTab('deposit');
            } else if (cleanHash === 'referral' || cleanHash === 'referrals') {
                renderProfileTab('referrals');
            } else {
                window.location.href = actionUrl;
                closeModal();
            }
        } else {
            window.open(actionUrl, '_blank');
        }
    } else {
        closeModal();
    }
};

// --- EXPANDED MULTI-TAB USER PROFILE ---
window.openProfile = () => {
    window.location.href = '/account';
};

window.renderProfileTab = async (tab, codeToClaim = '') => {
    if (!currentUser) {
        showToast("Loading account details...", "error");
        return;
    }

    if (isDemoMode) {
        if (tab === 'transactions' || tab === 'promotions' || tab === 'promocode' || tab === 'referrals' || tab === 'password') {
            const windowEl = document.getElementById('modalWindow');
            if (windowEl) {
                windowEl.className = 'modal-window profile-modal';
                windowEl.innerHTML = `
                    <div class="profile-layout" style="padding: 24px; color: #fff; background: var(--bg-card); border-radius: 20px; text-align: left; position: relative;">
                        <button onclick="toggleSidebarMenu()" class="pm-menu" style="position: absolute; top: 16px; left: 16px;" aria-label="Open Navigation Menu" title="Menu"><i data-lucide="menu" style="width: 15px; height: 15px;"></i></button>
                        <button onclick="closeModal()" class="pm-close" style="position: absolute; top: 16px; right: 16px; background: none; border: none; color: var(--text-muted); font-size: 1.5rem; cursor: pointer;">&times;</button>
                        
                        <div style="display: flex; flex-direction: column; gap: 8px; margin-bottom: 24px; text-align: center; align-items: center;">
                            <div class="pm-avatar" style="width: 56px; height: 56px; border-radius: 50%; background: linear-gradient(135deg, var(--accent-red), #b91c1c); display: flex; align-items: center; justify-content: center; margin-bottom: 8px;">
                                <i data-lucide="user" style="width: 24px; height: 24px; stroke: #fff;"></i>
                            </div>
                            <span style="font-size: 1.1rem; font-weight: 800; color: #fff;">Demo Account</span>
                            <span style="font-size: 0.95rem; font-weight: 700; color: #10b981;">KES ${balance.toLocaleString()} (DEMO BALANCE)</span>
                        </div>
                        
                        <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.25); padding: 16px; border-radius: 12px; margin-bottom: 20px; font-size: 0.85rem; line-height: 1.5; color: var(--text-secondary);">
                            <p style="color: var(--accent-red); font-weight: 700; margin: 0 0 6px;">Feature Unavailable in Demo Mode</p>
                            Depositing, withdrawing real money, claiming promotions/promo codes, and referral bonuses are disabled for Practice Demo profiles.
                        </div>
                        
                        <p style="font-size: 0.82rem; color: var(--text-muted); text-align: center; margin-bottom: 20px;">
                            Switch to a Real Account to play, win, and withdraw real cash!
                        </p>
                        
                        <div style="display: flex; flex-direction: column; gap: 12px;">
                            <a href="/auth#login" class="pm-cta" style="display: flex; align-items: center; justify-content: center; gap: 8px; text-decoration: none; font-weight: 800; background: linear-gradient(135deg, var(--accent-red) 0%, #b91c1c 100%); color: white; padding: 14px; border-radius: 12px; font-size: 0.9rem; text-align: center; border: none; cursor: pointer; box-shadow: 0 4px 15px rgba(239, 68, 68, 0.3);">
                                <i data-lucide="log-in" style="width: 18px; height: 18px;"></i> Log In / Register Now
                            </a>
                            <button onclick="closeModal()" class="auth-btn ghost" style="width: 100%; border: 1px solid rgba(255,255,255,0.1); height: 46px; border-radius: 12px; background: transparent; color: var(--text-secondary); cursor: pointer; font-size: 0.85rem; font-weight: 700;">Continue Demo</button>
                        </div>
                    </div>
                `;
                if (typeof lucide !== 'undefined') {
                    lucide.createIcons();
                }
            }
            return;
        }
    }

    const windowEl = document.getElementById('modalWindow');
    if (!windowEl) return;

    if (tab === 'logout') {
        logout();
        return;
    }

    // Apply fade-out class for transition
    windowEl.classList.add('tab-switching');
    
    // Wait for the transition to finish
    await new Promise(resolve => setTimeout(resolve, 140));
    
    // Clear any custom white background/timeout styles
    windowEl.style.backgroundColor = '';
    windowEl.style.color = '';

    // Set browser address hash route
    const validTabs = ['deposit', 'withdraw', 'profile', 'transactions', 'support', 'password', 'community', 'promotions', 'promocode', 'referrals'];
    if (validTabs.includes(tab)) {
        window.history.replaceState(null, null, `#/${tab}`);
    }

    const isDashboardTab = (tab === 'deposit' || tab === 'withdraw' || tab === 'profile');

    if (isDashboardTab) {
        windowEl.className = 'modal-window profile-modal';

        let rawPhone = (currentUser.phone || '').replace(/[\s\-()]/g, '').replace(/^\+/, '');
        if (rawPhone.startsWith('0') && rawPhone.length === 10) {
            rawPhone = '254' + rawPhone.slice(1);
        } else if ((rawPhone.startsWith('7') || rawPhone.startsWith('1')) && rawPhone.length === 9) {
            rawPhone = '254' + rawPhone;
        }

        let formattedPhone = rawPhone;
        if (rawPhone.startsWith('254') && rawPhone.length === 12) {
            formattedPhone = `(${rawPhone.slice(0, 3)}) ${rawPhone.slice(3, 6)}-${rawPhone.slice(6)}`;
        }

        const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
        const isDataSaver = localStorage.getItem('data_saver_mode') === 'true';

        windowEl.innerHTML = `
            <div style="position: relative; text-align: center; color: var(--text-primary); padding-top: 10px;">
                <button onclick="toggleSidebarMenu()" class="pm-menu" aria-label="Open Navigation Menu" title="Menu"><i data-lucide="menu" style="width: 15px; height: 15px;"></i></button>
                <button onclick="closeModal()" class="pm-close">&times;</button>

                <div style="display: flex; flex-direction: column; align-items: center; gap: 8px; margin-bottom: 24px;">
                    <div class="pm-avatar">
                        <i data-lucide="user" style="width: 24px; height: 24px; stroke: #0C1017;"></i>
                    </div>
                    <span style="font-size: 1.05rem; font-weight: 700; color: var(--text-primary);">${formattedPhone}</span>
                </div>

                <div style="display: flex; gap: 12px; margin-bottom: 16px;">
                    <div class="pm-card" style="flex: 1; display: flex; align-items: center; gap: 10px;">
                        <i data-lucide="shopping-bag" style="width: 20px; height: 20px; color: var(--accent); stroke-width: 2; flex-shrink:0;"></i>
                        <div style="text-align: left;">
                            <div style="font-size: 0.68rem; color: var(--text-muted); font-weight: 700; text-transform: uppercase; letter-spacing: 0.4px;">Balance</div>
                            <div id="metricwinBalanceBox" style="font-size: 0.95rem; font-weight: 800; color: var(--text-primary); margin-top: 1px;">KES ${Math.floor(balance).toLocaleString()}</div>
                        </div>
                    </div>
                    <div class="pm-card" style="flex: 1; display: flex; align-items: center; gap: 10px;">
                        <i data-lucide="gift" style="width: 20px; height: 20px; color: var(--accent); stroke-width: 2; flex-shrink:0;"></i>
                        <div style="text-align: left;">
                            <div style="font-size: 0.68rem; color: var(--text-muted); font-weight: 700; text-transform: uppercase; letter-spacing: 0.4px;">Bonus</div>
                            <div style="font-size: 0.95rem; font-weight: 800; color: var(--text-primary); margin-top: 1px;">KES 0</div>
                        </div>
                    </div>
                </div>

                <div style="margin-bottom: 16px;">
                    <div class="pm-card" style="display: flex; justify-content: space-between; align-items: center; text-align: left;">
                        <div>
                            <div style="font-size: 0.82rem; font-weight: 700; color: var(--text-primary);">Promotions</div>
                            <div style="font-size: 0.65rem; color: var(--text-muted); margin-top: 2px;"><span id="promoSubtitle">Loading promotions...</span></div>
                        </div>
                        <button onclick="renderProfileTab('promotions')" class="pm-promo-pill">View all</button>
                    </div>
                </div>

                <div id="sectionDeposit" class="pm-card" style="margin-bottom: 14px; text-align: left;">
                    <p class="pm-section-title">Deposit</p>
                    <p class="pm-section-sub">Send money into your Metricwin account</p>
                    
                    <div style="font-size: 0.68rem; color: var(--text-muted); font-weight: 700; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 0.4px;">Phone Number</div>
                    <div class="pm-input-row">
                        <input type="text" id="metricwinDepPhone" value="${isDemoMode ? '0700000000' : (currentUser.phone || '')}" placeholder="e.g. 0712345678" ${isDemoMode ? 'readonly disabled style="cursor: not-allowed; opacity: 0.65; background: rgba(255,255,255,0.03);"' : ''}>
                    </div>

                    <div style="font-size: 0.68rem; color: var(--text-muted); font-weight: 700; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 0.4px;">Amount (KES)</div>
                    <div class="pm-input-row">
                        <button class="pm-adj-btn" onclick="adjustDepositAmount(-100)">−</button>
                        <input type="number" id="metricwinDepAmount" value="500" min="${window.cachedFinancialLimits?.minDeposit || 99}" placeholder="Enter amount" style="text-align: center;">
                        <button class="pm-adj-btn" onclick="adjustDepositAmount(100)">+</button>
                    </div>
                    
                    <p id="metricwinDepNotice" style="font-size: 0.65rem; color: var(--text-muted); margin: 0 0 12px;">Minimum deposit is KES ${window.cachedFinancialLimits?.minDeposit || 99}. All transactions are subject to 5% tax.</p>
                    
                    <div class="pm-chips">
                        <button class="pm-chip" onclick="setDepositAmount(100)">+100</button>
                        <button class="pm-chip" onclick="setDepositAmount(200)">+200</button>
                        <button class="pm-chip" onclick="setDepositAmount(500)">+500</button>
                        <button class="pm-chip" onclick="setDepositAmount(1000)">+1000</button>
                    </div>
                    
                    <button id="depMpesaBtn" class="pm-cta" onclick="processMetricwinDeposit('mpesa')">
                        <i data-lucide="smartphone" style="width: 16px; height: 16px;"></i> Deposit with M-Pesa
                    </button>
                </div>

                <div id="sectionWithdraw" class="pm-card" style="margin-bottom: 14px; text-align: left;">
                    <p class="pm-section-title">Withdrawals</p>
                    <p class="pm-section-sub">Withdraw money from your Metricwin wallet</p>
                    
                    <div style="font-size: 0.68rem; color: var(--text-muted); font-weight: 700; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 0.4px;">Phone Number</div>
                    <div class="pm-input-row">
                        <input type="text" id="metricwinWdPhone" value="${isDemoMode ? '0700000000' : (currentUser.phone || '')}" placeholder="e.g. 0712345678" ${isDemoMode ? 'readonly disabled style="cursor: not-allowed; opacity: 0.65; background: rgba(255,255,255,0.03);"' : ''}>
                    </div>

                    <div style="font-size: 0.68rem; color: var(--text-muted); font-weight: 700; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 0.4px;">Amount (KES)</div>
                    <div class="pm-input-row">
                        <button class="pm-adj-btn" onclick="adjustWithdrawAmount(-100)">−</button>
                        <input type="number" id="metricwinWdAmount" value="500" min="1" max="300000" placeholder="Enter amount" style="text-align: center;">
                        <button class="pm-adj-btn" onclick="adjustWithdrawAmount(100)">+</button>
                    </div>
                    
                    <p style="font-size: 0.65rem; color: var(--text-muted); margin: 0 0 12px;">Automated fast payouts via M-Pesa. All transactions subject to 5% tax.</p>
                    
                    <button id="wdMpesaBtn" class="pm-cta" onclick="processMetricwinWithdraw('mpesa')">
                        <i data-lucide="smartphone" style="width: 16px; height: 16px;"></i> Withdraw via M-Pesa
                    </button>
                </div>

                <div class="pm-nav-row" onclick="renderProfileTab('transactions')">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <i data-lucide="folder" class="pm-nav-icon" style="width: 20px; height: 20px; stroke-width: 2;"></i>
                        <div style="text-align: left;">
                            <div style="font-size: 0.82rem; font-weight: 700; color: var(--text-primary);">My Transactions</div>
                            <div style="font-size: 0.72rem; color: var(--text-secondary);">View all your debits and credits</div>
                        </div>
                    </div>
                    <i data-lucide="chevron-right" style="width: 16px; height: 16px; color: var(--text-muted);"></i>
                </div>

                <div class="pm-card" style="text-align: left; margin-bottom: 16px;">
                    <p class="pm-section-title">Preferences</p>
                    <p class="pm-section-sub">Customise your experience</p>
                    
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 8px 0; border-bottom: 1px solid var(--border-subtle);">
                        <div style="text-align: left;">
                            <div style="font-size: 0.78rem; font-weight: 700; color: var(--text-primary);">Display</div>
                            <div style="font-size: 0.7rem; color: var(--text-secondary);">Switch between light theme and dark theme</div>
                        </div>
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <i data-lucide="sun" style="width: 16px; height: 16px; color: var(--accent);"></i>
                            <label class="switch-toggle" style="margin-bottom: 0;">
                                <input type="checkbox" id="profileThemeToggle" ${isDark ? 'checked' : ''} onchange="toggleDarkLightMode(this)">
                                <span class="switch-slider"></span>
                            </label>
                        </div>
                    </div>
                    
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 8px 0;">
                        <div style="text-align: left;">
                            <div style="font-size: 0.78rem; font-weight: 700; color: var(--text-primary);">Data Saver</div>
                            <div style="font-size: 0.7rem; color: var(--text-secondary);">Turn on to save data bundles</div>
                        </div>
                        <label class="switch-toggle" style="margin-bottom: 0;">
                            <input type="checkbox" id="profileDataSaver" ${isDataSaver ? 'checked' : ''} onchange="toggleDataSaver(this)">
                            <span class="switch-slider"></span>
                        </label>
                    </div>
                </div>

                <div class="pm-card" style="text-align: left; margin-bottom: 20px;">
                    <p class="pm-section-title">Account Info</p>
                    <p class="pm-section-sub">Critical details for managing your account</p>
                    
                    <div style="display: flex; justify-content: space-between; font-size: 0.72rem; padding: 6px 0; border-bottom: 1px solid var(--border-subtle);">
                        <span style="color: var(--text-secondary);">Account Verification Status</span>
                        <span style="color: var(--success); font-weight: 700;">VERIFIED</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; font-size: 0.72rem; padding: 6px 0; border-bottom: 1px solid var(--border-subtle);">
                        <span style="color: var(--text-secondary);">Registered Wallet Number</span>
                        <span style="color: var(--text-primary);">${currentUser.phone}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; font-size: 0.72rem; padding: 6px 0;">
                        <span style="color: var(--text-secondary);">Hash Signature (MD5)</span>
                        <span style="font-family: var(--font-mono); font-size: 0.65rem; color: var(--text-muted); max-width: 140px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${CryptoJS_SHA256(currentUser.phone || '').substring(0, 16)}</span>
                    </div>
                </div>

                <div style="display: flex; gap: 8px;">
                    <button class="auth-btn danger" style="flex: 1;" onclick="logout()">Log Out</button>
                    <button class="auth-btn ghost" style="flex: 1;" onclick="closeModal()">Close</button>
                </div>
            </div>
        `;


        // Dynamic promotions counter/preview loader
        setTimeout(async () => {
            const promoEl = document.getElementById('promoSubtitle');
            if (promoEl) {
                try {
                    const { data: promos, error } = await supabase.from('promotions').select('title');
                    if (error || !promos || promos.length === 0) {
                        promoEl.textContent = 'No active promotions';
                    } else if (promos.length === 1) {
                        promoEl.textContent = promos[0].title;
                    } else {
                        promoEl.textContent = `${promos.length} promotions active today`;
                    }
                } catch (e) {
                    promoEl.textContent = 'Failed to load promotions';
                }
            }
        }, 50);

        if (tab === 'deposit') {
            setTimeout(() => {
                const el = document.getElementById('sectionDeposit');
                if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }, 100);
        } else if (tab === 'withdraw') {
            setTimeout(() => {
                const el = document.getElementById('sectionWithdraw');
                if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }, 100);
        }

    } else {
        windowEl.className = 'modal-window profile-modal';
        
        let contentHtml = '';
        if (tab === 'referrals') {
            // Build skeleton immediately, then hydrate async
            const refCode = (currentUser.referral_code || ('REF' + currentUser.id.replace(/-/g, '').slice(0, 7).toUpperCase()));
            const refLink = `${window.location.origin}/auth?ref=${refCode}`;
            contentHtml = `
                <h3 style="margin-top:0; font-size:1rem; font-weight:800; letter-spacing:0.5px;">🤝 Affiliates Referral Network</h3>
                <p style="font-size:0.75rem; color:var(--text-secondary); line-height:1.5; margin-bottom:16px;" id="refRewardDesc">
                    Invite friends and earn referral bonuses when they sign up.
                </p>

                <div style="display:flex; flex-direction:column; gap:12px; text-align:left;">
                    <div>
                        <label style="display:block; font-size:0.70rem; color:var(--text-muted); margin-bottom:4px; text-transform:uppercase; letter-spacing:1px;">YOUR REFERRAL LINK</label>
                        <div style="display:flex; gap:6px;">
                            <input type="text" class="auto-input" id="refLinkInput" value="${refLink}" readonly style="font-size:0.65rem; color:var(--text-secondary);">
                            <button class="option-btn" style="width:70px; padding:0; flex-shrink:0;" onclick="copyReferralLink()">COPY</button>
                            <button class="option-btn" id="shareRefBtn" style="width:70px; padding:0; flex-shrink:0; display:none;" onclick="shareReferralLink()">SHARE</button>
                        </div>
                    </div>

                    <div>
                        <label style="display:block; font-size:0.70rem; color:var(--text-muted); margin-bottom:4px; text-transform:uppercase; letter-spacing:1px;">YOUR REFERRAL CODE</label>
                        <div style="display:flex; gap:6px; align-items:center;">
                            <input type="text" class="auto-input" id="refCodeDisplay" value="${refCode}" readonly style="font-size:0.78rem; font-weight:800; letter-spacing:2px; color:var(--accent); text-align:center; cursor:default;">
                            <button class="option-btn" style="width:70px; padding:0; flex-shrink:0;" onclick="copyReferralCode()">COPY</button>
                        </div>
                    </div>

                    <div class="info-stats-grid" style="margin-top:4px; margin-bottom:0;" id="refStatsGrid">
                        <div class="info-stat-item">
                            <span class="info-stat-label">REWARD</span>
                            <span class="info-stat-value" id="refRewardAmount" style="color:var(--success);">Loading...</span>
                        </div>
                        <div class="info-stat-item">
                            <span class="info-stat-label">STATUS</span>
                            <span class="info-stat-value" id="refStatus">—</span>
                        </div>
                        <div class="info-stat-item">
                            <span class="info-stat-label">REFERRED</span>
                            <span class="info-stat-value" id="refCount">—</span>
                        </div>
                        <div class="info-stat-item">
                            <span class="info-stat-label">EARNINGS</span>
                            <span class="info-stat-value" id="refEarnings" style="color:var(--success);">—</span>
                        </div>
                    </div>
                </div>
            `;

            // Show share button if Web Share API available
            setTimeout(() => {
                const shareBtn = document.getElementById('shareRefBtn');
                if (shareBtn && navigator.share) shareBtn.style.display = 'block';

                // Async hydration: load reward settings + referral stats
                (async () => {
                    try {
                        const [settingsRes, statsData] = await Promise.all([
                            supabase.from('system_settings').select('value').eq('key', 'referral_rewards').single(),
                            supabase.from('transactions').select('amount', { count: 'exact' })
                                .eq('user_id', currentUser.id).eq('type', 'referral_bonus')
                        ]);

                        // Reward config
                        const cfg = settingsRes.data?.value || {};
                        const enabled = cfg.enabled === true;
                        const bonus = parseFloat(cfg.referrer_bonus_kes || 0);
                        const requireDeposit = cfg.require_first_deposit === true;

                        const descEl = document.getElementById('refRewardDesc');
                        const amountEl = document.getElementById('refRewardAmount');
                        const statusEl = document.getElementById('refStatus');

                        if (descEl) {
                            descEl.textContent = enabled
                                ? `Invite friends and earn KES ${bonus.toLocaleString()} for every friend that signs up${requireDeposit ? ' & makes their first deposit' : ''}!`
                                : 'Invite friends to join Metricwin! Referral rewards are coming soon.';
                        }
                        if (amountEl) {
                            amountEl.textContent = enabled ? `KES ${bonus.toLocaleString()}` : 'Soon';
                        }
                        if (statusEl) {
                            statusEl.textContent = enabled ? 'ACTIVE' : 'INACTIVE';
                            statusEl.style.color = enabled ? 'var(--success)' : 'var(--text-muted)';
                        }

                        // Referral stats
                        const totalEarnings = (statsData.data || []).reduce((s, t) => s + parseFloat(t.amount || 0), 0);
                        const countEl = document.getElementById('refCount');
                        const earningsEl = document.getElementById('refEarnings');

                        // Count how many profiles have referred_by pointing to this user
                        const { count } = await supabase.from('profiles')
                            .select('id', { count: 'exact', head: true })
                            .eq('referred_by', currentUser.id);

                        if (countEl) countEl.textContent = `${count || 0} Users`;
                        if (earningsEl) earningsEl.textContent = `KES ${totalEarnings.toLocaleString()}`;
                    } catch (_) {}
                })();
            }, 50);

        } else if (tab === 'stats') {
            const pStats = loadPlayerStats();
            const totalProfitLossVal = pStats.totalWon - pStats.totalWagered;
            const winRateVal = pStats.gamesPlayed > 0 ? ((pStats.wins / pStats.gamesPlayed) * 100).toFixed(0) : '0';
            
            contentHtml = `
                <h3 style="margin-top:0;">📈 Detailed Play Statistics</h3>
                <div class="profile-details-box" style="display:flex; flex-direction:column; gap:8px; background:rgba(0,0,0,0.15); border:1px solid var(--border); padding:12px; border-radius:8px; text-align:left;">
                    <div style="display:flex; justify-content:space-between; font-size:0.75rem;"><span style="color:var(--text-secondary);">Rounds Played</span><span>${pStats.gamesPlayed}</span></div>
                    <div style="display:flex; justify-content:space-between; font-size:0.75rem;"><span style="color:var(--text-secondary);">Wins / Losses</span><span style="color:var(--success); font-weight:700;">${pStats.wins} W <span style="color:var(--text-muted);">/</span> <span style="color:var(--error);">${pStats.losses} L</span></span></div>
                    <div style="display:flex; justify-content:space-between; font-size:0.75rem;"><span style="color:var(--text-secondary);">Win Rate Percentage</span><span>${winRateVal}%</span></div>
                    <div style="display:flex; justify-content:space-between; font-size:0.75rem;"><span style="color:var(--text-secondary);">Total Wagered Volume</span><span>KES ${pStats.totalWagered.toLocaleString()}</span></div>
                    <div style="display:flex; justify-content:space-between; font-size:0.75rem;"><span style="color:var(--text-secondary);">Total Winnings Returned</span><span>KES ${pStats.totalWon.toLocaleString()}</span></div>
                    <div style="display:flex; justify-content:space-between; font-size:0.75rem;"><span style="color:var(--text-secondary);">Net Profit / Loss</span><span style="font-weight:700; color:${totalProfitLossVal >= 0 ? 'var(--success)' : 'var(--error)'};">${totalProfitLossVal >= 0 ? '+' : ''}KES ${totalProfitLossVal.toLocaleString()}</span></div>
                    <div style="display:flex; justify-content:space-between; font-size:0.75rem;"><span style="color:var(--text-secondary);">Highest Win Cashout</span><span style="color:var(--success); font-weight:700;">KES ${pStats.maxWin.toLocaleString()}</span></div>
                </div>
            `;
        } else if (tab === 'password') {
            contentHtml = `
                <h3 style="margin-top:0;">🔒 Update Security Password</h3>
                <p style="font-size:0.75rem; color:var(--text-secondary); line-height:1.4; margin-bottom:16px;">Set a strong, new security credential to protect your wallet and account funds.</p>
                <form id="changePasswordForm" onsubmit="window.handleChangePassword(event)" style="display:flex; flex-direction:column; gap:12px; text-align:left;">
                    <div>
                        <label style="display:block; font-size:0.70rem; color:var(--text-muted); margin-bottom:4px; font-weight:700;">NEW PASSWORD</label>
                        <input type="password" id="changeNewPw" required placeholder="Minimum 8 characters" style="width:100%; background:var(--bg-input, #0c1622); border:1px solid var(--border); border-radius:8px; padding:10px 12px; color:#fff; font-size:0.92rem; outline:none;">
                    </div>
                    <div>
                        <label style="display:block; font-size:0.70rem; color:var(--text-muted); margin-bottom:4px; font-weight:700;">CONFIRM PASSWORD</label>
                        <input type="password" id="changeConfirmPw" required placeholder="Repeat the password" style="width:100%; background:var(--bg-input, #0c1622); border:1px solid var(--border); border-radius:8px; padding:10px 12px; color:#fff; font-size:0.92rem; outline:none;">
                    </div>
                    <button type="submit" id="changePwBtn" class="pm-cta">UPDATE PASSWORD</button>
                </form>
            `;
        } else if (tab === 'transactions') {
            contentHtml = `
                <h3 style="margin-top:0;">📝 Transaction History</h3>
                <p style="font-size:0.75rem; color:var(--text-secondary); margin-bottom:16px;">Viewing your recent deposits and withdrawals.</p>
                <div id="txHistoryLoader" style="display:flex; justify-content:center; padding:20px;">
                    <span style="font-size:0.8rem; color:var(--text-muted);">Loading transactions...</span>
                </div>
                <div id="txHistoryContent" style="display:flex; flex-direction:column; gap:8px; max-height:280px; overflow-y:auto; padding-right:4px;">
                </div>
                <div id="txPaginationWrap" style="margin-top:12px;"></div>
            `;
            
            setTimeout(async () => {
                const loader = document.getElementById('txHistoryLoader');
                const content = document.getElementById('txHistoryContent');
                if (!content) return;
                
                try {
                    const { data: txs, error } = await supabase
                        .from('transactions')
                        .select('*')
                        .order('created_at', { ascending: false })
                        .limit(200);
                        
                    if (loader) loader.style.display = 'none';
                    if (error) throw error;
                    
                    profileTxList = txs || [];
                    profileTxPage = 1;
                    renderProfileTxPage();
                } catch (e) {
                    if (loader) loader.style.display = 'none';
                    content.innerHTML = `<span style="font-size:0.75rem; color:var(--error);">Failed to load history list.</span>`;
                }
            }, 50);
        } else if (tab === 'support') {
            contentHtml = `<div id="supportLoading" style="text-align:center; padding:30px; color:var(--text-muted);">Loading support contacts...</div>`;
            setTimeout(async () => {
                try {
                    const { data } = await supabase.from('system_settings').select('key, value').in('key', ['support', 'community']);
                    const settings = {};
                    (data || []).forEach(r => { settings[r.key] = r.value; });
                    const support = settings.support || {};
                    const community = settings.community || {};
                    const waNum = support.whatsapp || '+254700000000';
                    const tgUser = support.telegram_username || 'metricwin_support';
                    const tgChannel = community.telegram_channel || 'https://t.me/metricwin';
                    const waChannel = community.whatsapp_channel || '';
                    const el = document.getElementById('supportLoading');
                    if (el) el.outerHTML = `
                        <h3 style="margin-top:0;">🛟 Contact Support</h3>
                        <p style="font-size:0.75rem; color:var(--text-secondary); line-height:1.5; margin-bottom:18px;">Reach our support team 24/7 through any of the channels below.</p>
                        <div style="display:flex; flex-direction:column; gap:12px;">
                            <a href="https://wa.me/${waNum.replace('+','')}" target="_blank" rel="noopener noreferrer" style="display:flex; align-items:center; gap:12px; background:rgba(37,211,102,0.08); border:1px solid rgba(37,211,102,0.25); padding:12px 14px; border-radius:10px; text-decoration:none;">
                                <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="16" cy="16" r="16" fill="#25D366"/>
                                    <path d="M16 5.5C10.201 5.5 5.5 10.201 5.5 16c0 1.86.487 3.607 1.34 5.12L5.5 26.5l5.52-1.317A10.453 10.453 0 0016 26.5c5.799 0 10.5-4.701 10.5-10.5S21.799 5.5 16 5.5zm5.278 14.472c-.22.617-1.29 1.18-1.78 1.254-.49.072-1.103.1-1.78-.112-.41-.13-.937-.302-1.61-.593-2.83-1.22-4.678-4.05-4.82-4.24-.143-.19-1.163-1.547-1.163-2.95 0-1.403.735-2.08 1-2.358a1.06 1.06 0 01.765-.358c.19 0 .38.004.547.01.175.008.41-.066.642.49.235.562.8 1.938.87 2.078.07.14.115.304.022.49-.093.186-.14.302-.28.464-.14.162-.293.362-.418.486-.14.14-.285.29-.123.57.163.28.723 1.19 1.552 1.928 1.067.95 1.966 1.245 2.244 1.383.277.14.44.117.601-.07.163-.186.698-.813.884-1.093.187-.28.373-.233.63-.14.257.093 1.63.768 1.91.908.278.14.463.21.532.325.07.116.07.673-.15 1.29z" fill="white"/>
                                </svg>
                                <div style="text-align:left;">
                                    <div style="font-size:0.82rem; font-weight:700; color:#25D366;">WhatsApp Support</div>
                                    <div style="font-size:0.68rem; color:var(--text-muted);">Tap to chat on WhatsApp</div>
                                </div>
                            </a>
                            <a href="https://t.me/${tgUser}" target="_blank" rel="noopener noreferrer" style="display:flex; align-items:center; gap:12px; background:rgba(0,136,204,0.08); border:1px solid rgba(0,136,204,0.25); padding:12px 14px; border-radius:10px; text-decoration:none;">
                                <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="16" cy="16" r="16" fill="#229ED9"/>
                                    <path d="M23.6 9.2l-2.9 13.7c-.2.9-.8 1.2-1.6.7l-4.4-3.2-2.1 2c-.2.2-.5.3-.9.3l.3-4.5 7.9-7.1c.3-.3 0-.5-.5-.2L8.3 17.4l-4.3-1.3c-.9-.3-.9-.9.2-1.4l16.9-6.5c.8-.3 1.5.2 1.5 1z" fill="white"/>
                                </svg>
                                <div style="text-align:left;">
                                    <div style="font-size:0.82rem; font-weight:700; color:#229ED9;">Telegram Support</div>
                                    <div style="font-size:0.68rem; color:var(--text-muted);">@${tgUser}</div>
                                </div>
                            </a>
                            <a href="mailto:${support.email || 'support@metricwin.com'}" style="display:flex; align-items:center; gap:12px; background:rgba(239,68,68,0.08); border:1px solid rgba(239,68,68,0.25); padding:12px 14px; border-radius:10px; text-decoration:none;">
                                <svg width="32" height="32" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="16" cy="16" r="16" fill="#EA4335"/>
                                    <path d="M7 11.5C7 10.67 7.67 10 8.5 10h15c.83 0 1.5.67 1.5 1.5v9c0 .83-.67 1.5-1.5 1.5h-15C7.67 22 7 21.33 7 20.5v-9zm1.5 0v.9l7.5 5.1 7.5-5.1v-.9h-15zm0 2.52V20.5h15v-6.48l-6.97 4.74a1 1 0 01-1.06 0L8.5 14.02z" fill="white"/>
                                </svg>
                                <div style="text-align:left;">
                                    <div style="font-size:0.82rem; font-weight:700; color:#EA4335;">Email Support</div>
                                    <div style="font-size:0.68rem; color:var(--text-muted);">${support.email || 'support@metricwin.com'}</div>
                                </div>
                            </a>
                        </div>`;
                } catch(e) {
                    const el = document.getElementById('supportLoading');
                    if(el) el.textContent = 'Failed to load support contacts.';
                }
            }, 50);
        } else if (tab === 'community') {
            contentHtml = `<div id="communityLoading" style="text-align:center; padding:30px; color:var(--text-muted);">Loading community channels...</div>`;
            setTimeout(async () => {
                try {
                    const { data } = await supabase.from('system_settings').select('key, value').eq('key', 'community').single();
                    const community = data?.value || {};
                    const tgChannel = community.telegram_channel || 'https://t.me/metricwin';
                    const waChannel = community.whatsapp_channel || '';
                    const el = document.getElementById('communityLoading');
                    if (el) el.outerHTML = `
                        <h3 style="margin-top:0;">🌐 Official Communities</h3>
                        <p style="font-size:0.75rem; color:var(--text-secondary); line-height:1.5; margin-bottom:18px;">Join our official channels to connect with players, get tips, and stay updated.</p>
                        <div style="display:flex; flex-direction:column; gap:12px;">
                            ${tgChannel ? `
                            <a href="${tgChannel}" target="_blank" rel="noopener noreferrer" style="display:flex; align-items:center; gap:12px; background:rgba(34,158,217,0.08); border:1px solid rgba(34,158,217,0.25); padding:12px 14px; border-radius:10px; text-decoration:none;">
                                <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="16" cy="16" r="16" fill="#229ED9"/>
                                    <path d="M23.6 9.2l-2.9 13.7c-.2.9-.8 1.2-1.6.7l-4.4-3.2-2.1 2c-.2.2-.5.3-.9.3l.3-4.5 7.9-7.1c.3-.3 0-.5-.5-.2L8.3 17.4l-4.3-1.3c-.9-.3-.9-.9.2-1.4l16.9-6.5c.8-.3 1.5.2 1.5 1z" fill="white"/>
                                </svg>
                                <div style="text-align:left;">
                                    <div style="font-size:0.82rem; font-weight:700; color:#229ED9;">Telegram Community Channel</div>
                                    <div style="font-size:0.68rem; color:var(--text-muted);">Join for daily tips &amp; announcements</div>
                                </div>
                            </a>` : ''}
                            ${waChannel ? `
                            <a href="${waChannel}" target="_blank" rel="noopener noreferrer" style="display:flex; align-items:center; gap:12px; background:rgba(37,211,102,0.08); border:1px solid rgba(37,211,102,0.25); padding:12px 14px; border-radius:10px; text-decoration:none;">
                                <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="16" cy="16" r="16" fill="#25D366"/>
                                    <path d="M16 5.5C10.201 5.5 5.5 10.201 5.5 16c0 1.86.487 3.607 1.34 5.12L5.5 26.5l5.52-1.317A10.453 10.453 0 0016 26.5c5.799 0 10.5-4.701 10.5-10.5S21.799 5.5 16 5.5zm5.278 14.472c-.22.617-1.29 1.18-1.78 1.254-.49.072-1.103.1-1.78-.112-.41-.13-.937-.302-1.61-.593-2.83-1.22-4.678-4.05-4.82-4.24-.143-.19-1.163-1.547-1.163-2.95 0-1.403.735-2.08 1-2.358a1.06 1.06 0 01.765-.358c.19 0 .38.004.547.01.175.008.41-.066.642.49.235.562.8 1.938.87 2.078.07.14.115.304.022.49-.093.186-.14.302-.28.464-.14.162-.293.362-.418.486-.14.14-.285.29-.123.57.163.28.723 1.19 1.552 1.928 1.067.95 1.966 1.245 2.244 1.383.277.14.44.117.601-.07.163-.186.698-.813.884-1.093.187-.28.373-.233.63-.14.257.093 1.63.768 1.91.908.278.14.463.21.532.325.07.116.07.673-.15 1.29z" fill="white"/>
                                </svg>
                                <div style="text-align:left;">
                                    <div style="font-size:0.82rem; font-weight:700; color:#25D366;">WhatsApp Community Channel</div>
                                    <div style="font-size:0.68rem; color:var(--text-muted);">Follow for live platform updates</div>
                                </div>
                            </a>` : ''}
                        </div>`;
                } catch(e) {
                    const el = document.getElementById('communityLoading');
                    if(el) el.textContent = 'Failed to load community links.';
                }
            }, 50);
        } else if (tab === 'promotions') {
            contentHtml = `
                <h3 style="margin-top:0;">🎁 Active Promotions</h3>
                <div id="promoListLoading" style="text-align:center; padding:20px; color:var(--text-muted); font-size:0.8rem;">Loading promotions...</div>
                <div id="promoListContent" style="display:flex; flex-direction:column; gap:14px;"></div>
            `;
            setTimeout(async () => {
                const loader = document.getElementById('promoListLoading');
                const content = document.getElementById('promoListContent');
                try {
                    const { data: promos, error } = await supabase.from('promotions').select('*').order('created_at', { ascending: false });
                    if (loader) loader.style.display = 'none';
                    if (error || !promos || promos.length === 0) {
                        if (content) content.innerHTML = `<div style="text-align:center; padding:24px; color:var(--text-muted); font-size:0.78rem;">No active promotions at the moment. Check back soon!</div>`;
                        return;
                    }
                    const ACTION_LABEL = { play: 'Play Now', deposit: 'Deposit', refer: 'Refer Now', external: 'Learn More' };
                    if (content) content.innerHTML = promos.map(p => `
                        <div style="background:var(--bg-elevated,#1a2838); border:1px solid var(--border); border-radius:12px; overflow:hidden;">
                            ${p.image_url ? `<img src="${p.image_url}" style="width:100%; height:150px; object-fit:cover; display:block;" onerror="this.style.display='none'">` : ''}
                            <div style="padding:14px;">
                                <div style="font-weight:900; font-size:0.9rem; color:#fff; margin-bottom:6px;">${p.title}</div>
                                <div style="font-size:0.73rem; color:var(--text-secondary); margin-bottom:12px; line-height:1.5;">${p.description || ''}</div>
                                <button onclick="window.handlePromoAction('${p.action_type}', '${(p.action_url || '').replace(/'/g, "\\'")}')" class="pm-cta" style="width: auto; padding: 8px 18px;">
                                    ${ACTION_LABEL[p.action_type] || 'Play Now'}
                                </button>
                            </div>
                        </div>`).join('');
                } catch(e) {
                    if (loader) loader.style.display = 'none';
                    if (content) content.innerHTML = `<div style="color:var(--error); font-size:0.78rem;">Failed to load promotions.</div>`;
                }
            }, 50);
        } else if (tab === 'promocode') {
            contentHtml = `
                <h3 style="margin-top:0; display:flex; align-items:center; gap:8px;">
                    <i data-lucide="tag" style="width:20px; height:20px; color:#ec4899;"></i> Claim Promo Code
                </h3>
                <p style="font-size:0.75rem; color:var(--text-secondary); line-height:1.5; margin-bottom:16px;">
                    Enter an official promo code below to claim instant bonus payouts credited directly into your account wallet.
                </p>
                <div style="display:flex; flex-direction:column; gap:12px; text-align:left;">
                    <div>
                        <label style="display:block; font-size:0.70rem; color:var(--text-muted); margin-bottom:4px; font-weight:700; text-transform:uppercase;">PROMO CODE</label>
                        <input type="text" id="promoCodeClaimInput" placeholder="e.g. WELCOME100" style="width:100%; background:var(--bg-input, #0c1622); border:1px solid var(--border); border-radius:8px; padding:10px 12px; color:#fff; font-size:0.92rem; outline:none; text-transform:uppercase; font-family:var(--font-mono, monospace); font-weight:bold;">
                    </div>
                    <button id="promoCodeClaimBtn" onclick="window.claimPromoCode()" class="pm-cta">
                        CLAIM CODE
                    </button>
                </div>
            `;
        }

        windowEl.innerHTML = `
            <div style="text-align:left; position:relative;">
                <button onclick="toggleSidebarMenu()" class="pm-menu" style="position:absolute; top:-12px; left:-10px;" aria-label="Open Navigation Menu" title="Menu">
                    <i data-lucide="menu" style="width: 15px; height: 15px;"></i>
                </button>
                <button onclick="renderProfileTab('profile')" class="pm-back-btn" style="position:absolute; top:-12px; left:28px;">
                    &larr; Back
                </button>
                <button onclick="closeModal()" class="pm-close" style="position:absolute; top:-12px; right:-10px;">
                    &times;
                </button>
                <div style="padding-top:24px;">
                    ${contentHtml}
                </div>
            </div>
        `;
    }

    // Trigger tab-transition fade back in
    setTimeout(() => {
        windowEl.classList.remove('tab-switching');
    }, 20);

    lucide.createIcons();

    // Auto-fill & auto-claim promo code if provided (from claim CTA redirect)
    if (tab === 'promocode' && codeToClaim) {
        const input = document.getElementById('promoCodeClaimInput');
        if (input) {
            input.value = codeToClaim.toUpperCase();
            window.claimPromoCode();
        }
    }
};

window.adjustDepositAmount = (offset) => {
    const el = document.getElementById('metricwinDepAmount');
    if (el) {
        const val = Math.max(100, (parseFloat(el.value) || 0) + offset);
        el.value = val;
    }
};

window.setDepositAmount = (val) => {
    const el = document.getElementById('metricwinDepAmount');
    if (el) el.value = val;
};

window.adjustWithdrawAmount = (offset) => {
    const el = document.getElementById('metricwinWdAmount');
    if (el) {
        const val = Math.max(100, (parseFloat(el.value) || 0) + offset);
        el.value = val;
    }
};

window.toggleDataSaver = (elem) => {
    localStorage.setItem('data_saver_mode', elem.checked);
    showToast(`Data Saver ${elem.checked ? 'Enabled' : 'Disabled'}`, 'success');
};

window.processMetricwinDeposit = async (method) => {
    const amountInput = document.getElementById('metricwinDepAmount');
    const amount = parseFloat(amountInput ? amountInput.value : 0);
    const minDep = window.cachedFinancialLimits?.minDeposit || 99;
    if (isNaN(amount) || amount < minDep) {
        showToast(`Minimum deposit is KES ${minDep}`, "error");
        return;
    }
    
    if (isDemoMode) {
        balance = parseFloat((balance + amount).toFixed(2));
        localStorage.setItem('demo_balance', balance);
        updateUI();
        showToast(`Mock Deposit of KES ${amount} successful!`, 'success');
        const balanceBox = document.getElementById('metricwinBalanceBox');
        if (balanceBox) balanceBox.textContent = `KES ${Math.floor(balance).toLocaleString()}`;
        return;
    }
    
    // Read phone from field
    const phoneInput = document.getElementById('metricwinDepPhone');
    const rawVal = phoneInput ? phoneInput.value : '';
    const rawPhone = rawVal.replace(/[\s\-()]/g, '').replace(/^\+/, '');
    
    // Normalize format
    let normalizedPhone = null;
    if (/^254[71]\d{8}$/.test(rawPhone)) {
        normalizedPhone = rawPhone;
    } else if (/^0[71]\d{8}$/.test(rawPhone)) {
        normalizedPhone = '254' + rawPhone.slice(1);
    } else if (/^[71]\d{8}$/.test(rawPhone)) {
        normalizedPhone = '254' + rawPhone;
    } else {
        showToast("Enter a valid Safaricom number (e.g. 0712345678)", "error");
        return;
    }
    
    const btnId = 'depMpesaBtn';
    const btn = document.getElementById(btnId);
    const originalText = btn ? btn.innerHTML : '';
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = 'Processing...';
    }
    try {
        const { data: { session } } = await supabase.auth.getSession();
        if (!session) {
            showToast('You must be logged in to make deposits.', 'error');
            return;
        }

        const res = await fetch('/api/deposit', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${session.access_token}`
            },
            body: JSON.stringify({
                phone: normalizedPhone,
                amount: Math.floor(amount),
                userId: currentUser.id
            })
        });
        
        let data;
        try {
            data = await res.json();
        } catch (jsonErr) {
            console.error('Response is not JSON:', jsonErr);
            showToast(`Deposit service error (${res.status})`, "error");
            return;
        }
        
        if (res.ok && data.success) {
            if (data.transactionId || data.checkoutRequestId) {
                showToast(`Payment request sent! Check your phone for STK Prompt to complete MPESA deposit.`, 'success');
                window.showWaitingPaymentScreen(normalizedPhone, amount, data.transactionId || data.checkoutRequestId);
            } else {
                if (typeof data.newBalance === 'number') balance = data.newBalance;
                updateUI();
                showToast(`Mock Deposit of KES ${amount} successful!`, 'success');
                const balanceBox = document.getElementById('metricwinBalanceBox');
                if (balanceBox) balanceBox.textContent = `KES ${Math.floor(balance).toLocaleString()}`;
            }
        } else {
            showToast(data.message || data.error || 'Deposit initiation failed', 'error');
        }
    } catch (e) {
        console.error('Deposit request failed:', e);
        showToast("Network request timed out", "error");
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = originalText;
        }
    }
};

window.processMetricwinWithdraw = async (method) => {
    if (isDemoMode) {
        showToast("❌ Practice/Demo funds cannot be withdrawn.", "error");
        return;
    }
    const amountInput = document.getElementById('metricwinWdAmount');
    const amount = parseFloat(amountInput ? amountInput.value : 0);
    if (isNaN(amount) || amount <= 0) {
        showToast("Please enter a valid withdrawal amount", "error");
        return;
    }
    if (amount > balance) {
        showToast("Insufficient wallet balance", "error");
        return;
    }
    
    // Read phone from field
    const phoneInput = document.getElementById('metricwinWdPhone');
    const rawVal = phoneInput ? phoneInput.value : '';
    const rawPhone = rawVal.replace(/[\s\-()]/g, '').replace(/^\+/, '');
    
    // Normalize format
    let normalizedPhone = null;
    if (/^254[71]\d{8}$/.test(rawPhone)) {
        normalizedPhone = rawPhone;
    } else if (/^0[71]\d{8}$/.test(rawPhone)) {
        normalizedPhone = '254' + rawPhone.slice(1);
    } else if (/^[71]\d{8}$/.test(rawPhone)) {
        normalizedPhone = '254' + rawPhone;
    } else {
        showToast("Enter a valid Safaricom number (e.g. 0712345678)", "error");
        return;
    }
    
    const btnId = 'wdMpesaBtn';
    const btn = document.getElementById(btnId);
    const originalText = btn ? btn.innerHTML : '';
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = 'Processing...';
    }
    try {
        const { data: { session } } = await supabase.auth.getSession();
        const token = session?.access_token || localStorage.getItem('metrowins_auth_token');
        if (!token) {
            showToast('You must be logged in to withdraw funds.', 'error');
            return;
        }

        const res = await fetch('/api/withdraw', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                phone: normalizedPhone,
                amount: Math.floor(amount),
                userId: currentUser?.id
            })
        });
        
        let data;
        try {
            data = await res.json();
        } catch (jsonErr) {
            console.error('Response is not JSON:', jsonErr);
            showToast("Server configuration error (500)", "error");
            return;
        }
        
        if (data.success) {
            const newBal = (data.newBalance !== undefined && data.newBalance !== null)
                ? Number(data.newBalance)
                : ((data.balance !== undefined && data.balance !== null) ? Number(data.balance) : null);
            if (newBal !== null && !isNaN(newBal)) {
                balance = newBal;
                localStorage.setItem('metrowins_user_balance', String(balance));
                localStorage.setItem('metrowins_balance_sync', JSON.stringify({ balance, time: Date.now() }));
                window.dispatchEvent(new CustomEvent('balance_updated', { detail: { balance } }));
                if (currentUser) {
                    currentUser.balance = balance;
                    localStorage.setItem('metrowins_auth_user', JSON.stringify(currentUser));
                }
            }
            updateUI();
            showToast(data.message || 'Withdrawal processed. Funds sent to M-Pesa. You will receive an M-Pesa SMS notification instantly.', 'success');
            window.showWithdrawalSuccessScreen(normalizedPhone, amount);
            const balanceBox = document.getElementById('metricwinBalanceBox');
            if (balanceBox) balanceBox.textContent = `KES ${Math.floor(balance).toLocaleString()}`;
        } else {
            showToast(data.message || 'Withdrawal failed', 'error');
        }
    } catch (e) {
        console.error('Withdrawal request failed:', e);
        showToast("Network request timed out", "error");
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = originalText;
        }
    }
};

window.copyReferralLink = () => {
    const el = document.getElementById('refLinkInput');
    if (el) {
        navigator.clipboard?.writeText(el.value).catch(() => {
            el.select();
            document.execCommand('copy');
        });
        showToast("Referral link copied to clipboard!", "success");
    }
};

window.copyReferralCode = () => {
    const el = document.getElementById('refCodeDisplay');
    if (el) {
        navigator.clipboard?.writeText(el.value).catch(() => {
            el.select();
            document.execCommand('copy');
        });
        showToast("Referral code copied!", "success");
    }
};

window.shareReferralLink = async () => {
    const el = document.getElementById('refLinkInput');
    if (!el) return;
    const refLink = el.value;
    try {
        await navigator.share({
            title: 'Join Metricwin – Kenya\'s best Aviator game!',
            text: '🚀 I\'m playing Aviator on Metricwin and winning big! Join using my link and let\'s fly together.',
            url: refLink
        });
    } catch (_) {
        // User cancelled or API not supported — fallback to copy
        window.copyReferralLink();
    }
};

window.claimDailyReward = (btn) => {
    balance += 50;
    updateUI();
    playSoundCashOut();
    showToast("Daily Log In Roll: KES 50 added!", "success");
    btn.disabled = true;
    btn.textContent = "CLAIMED TODAY";
    btn.style.opacity = '0.55';
};

window.claimPromoCode = async () => {
    const codeInput = document.getElementById('promoCodeClaimInput');
    const code = codeInput ? codeInput.value.trim().toUpperCase() : '';
    if (!code) {
        showToast('Please enter a promo code.', 'error');
        return;
    }

    const btn = document.getElementById('promoCodeClaimBtn');
    const originalText = btn ? btn.textContent : 'CLAIM CODE';
    if (btn) {
        btn.disabled = true;
        btn.textContent = 'CLAIMING...';
    }

    try {
        const { data: { session } } = await supabase.auth.getSession();
        if (!session) {
            showToast('You must be logged in to claim promo codes.', 'error');
            return;
        }

        const res = await fetch('/api/claim-promo', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${session.access_token}`
            },
            body: JSON.stringify({ code })
        });
        const data = await res.json();
        
        if (res.ok && data.success) {
            showToast(`✓ Code claimed! KES ${data.amount} credited to your balance.`, 'success');
            if (codeInput) codeInput.value = '';
            
            // Increment local state balance
            balance += parseFloat(data.amount);
            updateUI();
            
            // Refresh balance boxes in profile page immediately
            const balanceBox = document.getElementById('metricwinBalanceBox');
            if (balanceBox) balanceBox.textContent = `KES ${Math.floor(balance).toLocaleString()}`;
        } else {
            showToast(data.error || 'Failed to claim promo code.', 'error');
        }
    } catch (e) {
        showToast(`Unexpected error: ${e.message}`, 'error');
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.textContent = originalText;
        }
    }
};

window.openDeposit = () => {
    window.location.href = '/account#deposit';
};

async function processDeposit() {
    const amt = parseFloat(document.getElementById('depAmount')?.value);
    const minDep = window.cachedFinancialLimits?.minDeposit || 99;
    if (isNaN(amt) || amt < minDep) {
        showToast(`Minimum deposit is KES ${minDep}`, 'error');
        return;
    }

    if (isDemoMode) {
        balance = parseFloat((balance + amt).toFixed(2));
        localStorage.setItem('demo_balance', balance);
        updateUI();
        showToast(`Mock Deposit of KES ${amt} successful!`, 'success');
        closeModal();
        return;
    }

    // Read phone from the editable input, normalise to 254XXXXXXXXX
    const rawPhone = (document.getElementById('depPhone')?.value || '').replace(/[\s\-()]/g, '');
    let normalizedPhone = null;

    // Comprehensive Safaricom/M-Pesa number normalization
    // Handles: +2547xx, +2541xx, 2547xx, 2541xx, 07xx, 01xx, 7xx, 1xx
    const digits = rawPhone.replace(/^\+/, ''); // strip leading +
    if (/^254[71]\d{8}$/.test(digits)) {
        // Already in international format: 254712345678 or 2541XXXXXXXX
        normalizedPhone = digits;
    } else if (/^0[71]\d{8}$/.test(digits)) {
        // Local 10-digit format: 0712345678 or 0112345678
        normalizedPhone = '254' + digits.slice(1);
    } else if (/^[71]\d{8}$/.test(digits)) {
        // 9-digit without country code: 712345678 or 112345678
        normalizedPhone = '254' + digits;
    } else {
        showToast("Enter a valid Safaricom number (e.g. 0712345678, 0112345678 or 712345678)", 'error');
        return;
    }

    const btn = document.getElementById('depBtn');
    btn.disabled = true;
    btn.textContent = "SENDING...";
    
    try {
        const res = await fetch('/api/deposit', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ phone: normalizedPhone, amount: amt, userId: currentUser.id })
        });
        let data;
        try {
            data = await res.json();
        } catch (jsonErr) {
            console.error('Response is not JSON:', jsonErr);
            showToast("Server configuration error (500)", "error");
            return;
        }

        if (data.success) {
            if (data.transactionId || data.checkoutRequestId) {
                showToast(data.message || "STK Push sent to your mobile phone! Confirm credentials.", "success");
                window.showWaitingPaymentScreen(normalizedPhone, amt, data.transactionId || data.checkoutRequestId);
            } else {
                if (typeof data.newBalance === 'number') balance = data.newBalance;
                updateUI();
                showToast(data.message || `Mock Deposit of KES ${amt} successful!`, "success");
                closeModal();
            }
        } else {
            showToast(data.message || "STK send failed", "error");
        }
    } catch (e) {
        showToast("M-Pesa gateway error", "error");
    } finally {
        if (document.getElementById('depBtn')) {
            const currentBtn = document.getElementById('depBtn');
            currentBtn.disabled = false;
            currentBtn.textContent = "SEND STK PUSH";
        }
    }
}

async function logout() {
    if (isDemoMode) {
        window.location.replace('/');
        return;
    }
    await supabase.auth.signOut();
    window.location.replace('/auth');
}
window.logout = logout;

window.openWithdraw = () => {
    window.location.href = '/account#withdraw';
};

async function processWithdraw() {
    if (isDemoMode) {
        showToast("❌ Practice/Demo funds cannot be withdrawn.", "error");
        return;
    }
    const amt = parseFloat(document.getElementById('wdAmount')?.value);
    if (isNaN(amt) || amt <= 0) {
        showToast("Please enter a valid withdrawal amount", 'error');
        return;
    }
    if (amt > balance) {
        showToast("Insufficient balance", 'error');
        return;
    }

    const limit = parseFloat(localStorage.getItem('daily_limit'));
    if (!isNaN(limit) && amt > limit) {
        showToast(`Exceeds daily self-limit: KES ${limit.toLocaleString()}`, 'error');
        return;
    }

    // Normalize phone from field
    const rawPhone = (document.getElementById('wdPhone')?.value || '').replace(/[\s\-()]/g, '').replace(/^\+/, '');
    let normalizedPhone = null;
    const digits = rawPhone;
    if (/^254[71]\d{8}$/.test(digits)) {
        normalizedPhone = digits;
    } else if (/^0[71]\d{8}$/.test(digits)) {
        normalizedPhone = '254' + digits.slice(1);
    } else if (/^[71]\d{8}$/.test(digits)) {
        normalizedPhone = '254' + digits;
    } else {
        showToast("Enter a valid Safaricom number (e.g. 0712345678)", 'error');
        return;
    }

    const btn = document.getElementById('wdBtn');
    if (btn) { btn.disabled = true; btn.textContent = 'PROCESSING...'; }

    try {
        const { data: { session } } = await supabase.auth.getSession();
        const token = session?.access_token || localStorage.getItem('metrowins_auth_token');
        if (!token) {
            showToast('You must be logged in to withdraw funds.', 'error');
            return;
        }

        const res = await fetch('/api/withdraw', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                phone:  normalizedPhone,
                amount: Math.floor(amt),
                userId: currentUser?.id
            })
        });
        const data = await res.json();

        if (data.success) {
            const newBal = (data.newBalance !== undefined && data.newBalance !== null)
                ? Number(data.newBalance)
                : ((data.balance !== undefined && data.balance !== null) ? Number(data.balance) : null);
            if (newBal !== null && !isNaN(newBal)) {
                balance = newBal;
                localStorage.setItem('metrowins_user_balance', String(balance));
                localStorage.setItem('metrowins_balance_sync', JSON.stringify({ balance, time: Date.now() }));
                window.dispatchEvent(new CustomEvent('balance_updated', { detail: { balance } }));
                if (currentUser) {
                    currentUser.balance = balance;
                    localStorage.setItem('metrowins_auth_user', JSON.stringify(currentUser));
                }
            }
            updateUI();
            showToast(data.message || 'Withdrawal processed. Funds sent to M-Pesa. You will receive an M-Pesa SMS notification instantly.', 'success');
            window.showWithdrawalSuccessScreen(normalizedPhone, amt);
            const balanceBox = document.getElementById('metricwinBalanceBox');
            if (balanceBox) balanceBox.textContent = `KES ${Math.floor(balance).toLocaleString()}`;
        } else {
            showToast(data.message || 'Withdrawal failed', 'error');
        }
    } catch (e) {
        showToast('Withdrawal gateway error', 'error');
    } finally {
        const b = document.getElementById('wdBtn');
        if (b) { b.disabled = false; b.textContent = '💸 CONFIRM WITHDRAWAL'; }
    }
}

window.handleChangePassword = async (e) => {
    e.preventDefault();
    const newPassword = document.getElementById('changeNewPw').value;
    const confirm     = document.getElementById('changeConfirmPw').value;
    
    if (newPassword.length < 8) {
        showToast("Password must be at least 8 characters", "error");
        return;
    }
    if (newPassword !== confirm) {
        showToast("Passwords do not match", "error");
        return;
    }
    
    const btn = document.getElementById('changePwBtn');
    if (btn) {
        btn.disabled = true;
        btn.textContent = "UPDATING...";
    }
    
    try {
        const { error } = await supabase.auth.updateUser({ password: newPassword });
        if (error) {
            showToast(error.message, "error");
        } else {
            showToast("Password updated successfully!", "success");
            renderProfileTab('profile');
        }
    } catch (err) {
        showToast("An error occurred updating password", "error");
    } finally {
        if (document.getElementById('changePwBtn')) {
            document.getElementById('changePwBtn').disabled = false;
            document.getElementById('changePwBtn').textContent = "UPDATE PASSWORD";
        }
    }
};

window.processDeposit = processDeposit;
window.processWithdraw = processWithdraw;

window.setThemeMode = (mode) => {
    localStorage.setItem('theme_mode', mode);
    applyThemeMode(mode);
    showToast(`Color Theme updated to ${mode.toUpperCase()} Mode!`, 'success');
};

window.applyThemeMode = (mode) => {
    let resolved = mode;
    if (mode === 'dark') {
        document.documentElement.setAttribute('data-theme', 'dark');
    } else if (mode === 'light') {
        document.documentElement.setAttribute('data-theme', 'light');
    } else {
        const isSystemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        resolved = isSystemDark ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', resolved);
    }
    
    // Sync the header and drawer toggle checkbox
    const headerToggle = document.getElementById('headerThemeToggle');
    if (headerToggle) {
        headerToggle.checked = (resolved === 'dark');
    }
    const drawerToggle = document.getElementById('drawerThemeToggle');
    if (drawerToggle) {
        drawerToggle.checked = (resolved === 'dark');
    }
    
    const select = document.getElementById('themeSelect');
    if (select) select.value = mode;
};

window.toggleDarkLightMode = (checkbox) => {
    const desired = checkbox.checked ? 'dark' : 'light';
    setThemeMode(desired);
};

// Monitor system scheme changes if system mode is active
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
    const active = localStorage.getItem('theme_mode') || 'dark';
    if (active === 'system') {
        applyThemeMode('system');
    }
});

// Toggle visibility of the second bet card
window.toggleCard2 = (show) => {
    const container = document.getElementById('betControlCards');
    const card2 = document.getElementById('betCard2');
    const addBtn = document.getElementById('addCard2Btn');
    
    if (!container || !card2) return;
    
    if (show) {
        card2.classList.remove('hidden');
        container.classList.remove('one-panel');
        if (addBtn) addBtn.classList.add('hidden');
        localStorage.setItem('show_card_2', 'true');
    } else {
        card2.classList.add('hidden');
        container.classList.add('one-panel');
        if (addBtn) addBtn.classList.remove('hidden');
        localStorage.setItem('show_card_2', 'false');
    }
    
    if (window.lucide) {
        window.lucide.createIcons();
    }
};

window.toggleSidebarMenu = () => {
    // Sidebar removed from Aviator game; single sidebar on sports page
};

window.handleDrawerAction = async (action) => {
    window.toggleSidebarMenu(); // auto close drawer
    
    if (action === 'profile') {
        window.openProfile();
        window.renderProfileTab('profile');
    } else if (action === 'deposit') {
        window.openDeposit();
    } else if (action === 'withdraw') {
        window.openWithdraw();
    } else if (action === 'password') {
        const backdrop = document.getElementById('modalBackdrop');
        if (backdrop) backdrop.classList.add('show');
        window.renderProfileTab('password');
    } else if (action === 'support') {
        window.openProfile();
        window.renderProfileTab('support');
    } else if (action === 'community') {
        window.openProfile();
        window.renderProfileTab('community');
    } else if (action === 'promotions') {
        window.openProfile();
        window.renderProfileTab('promotions');
    } else if (action === 'promocode') {
        window.openProfile();
        window.renderProfileTab('promocode');
    } else if (action === 'referrals') {
        window.openProfile();
        window.renderProfileTab('referrals');
    } else if (action === 'admin') {
        window.location.href = '/admin';
    } else if (action === 'super-admin') {
        window.location.href = '/super-admin';
    } else if (action === 'logout') {
        await window.logout();
    }
};

window.changeProfileTxPage = (page) => {
    profileTxPage = page;
    renderProfileTxPage();
};

function renderProfileTxPage() {
    const content = document.getElementById('txHistoryContent');
    const paginationWrap = document.getElementById('txPaginationWrap');
    if (!content) return;
    
    if (!profileTxList || profileTxList.length === 0) {
        content.innerHTML = `
            <div style="text-align:center; padding:30px 10px; color:var(--text-muted); font-size:0.75rem;">
                <i data-lucide="info" style="width:24px; height:24px; margin:0 auto 8px; stroke:var(--text-muted);"></i>
                No transactions found yet.
            </div>
        `;
        if (window.lucide) window.lucide.createIcons();
        if (paginationWrap) paginationWrap.innerHTML = '';
        return;
    }
    
    const totalPages = Math.max(1, Math.ceil(profileTxList.length / PROFILE_TX_PAGE_SIZE));
    if (profileTxPage < 1) profileTxPage = 1;
    if (profileTxPage > totalPages) profileTxPage = totalPages;
    
    const startIdx = (profileTxPage - 1) * PROFILE_TX_PAGE_SIZE;
    const paginatedTxs = profileTxList.slice(startIdx, startIdx + PROFILE_TX_PAGE_SIZE);
    
    content.innerHTML = paginatedTxs.map(t => {
        const isDep = t.type === 'deposit';
        const typeText = isDep ? 'DEPOSIT' : 'WITHDRAWAL';
        const typeColor = isDep ? 'var(--success, #10B981)' : 'var(--warning, #F59E0B)';
        const statusColor = t.status === 'completed' ? 'var(--success, #10B981)' : t.status === 'failed' ? 'var(--error, #EF4444)' : 'var(--text-muted)';
        const dateStr = new Date(t.created_at).toLocaleString('en-KE', {
            day: 'numeric',
            month: 'short',
            hour: '2-digit',
            minute: '2-digit'
        });
        
        return `
            <div style="background:rgba(255,255,255,0.015); border:1px solid var(--border); padding:10px 12px; border-radius:8px; display:flex; flex-direction:column; gap:4px; text-align:left;">
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <span style="font-size:0.75rem; font-weight:800; color:${typeColor}">${typeText}</span>
                    <span style="font-size:0.8rem; font-weight:700; color:#fff;">KES ${Number(t.amount || 0).toLocaleString()}</span>
                </div>
                <div style="display:flex; justify-content:space-between; align-items:center; font-size:0.68rem; color:var(--text-secondary);">
                    <span>Ref: <span style="font-family:var(--font-mono); color:var(--text-muted);">${t.reference || 'N/A'}</span></span>
                    <span style="font-weight:700; color:${statusColor}; text-transform:uppercase;">${t.status || 'PENDING'}</span>
                </div>
                <div style="font-size:0.65rem; color:var(--text-muted); text-align:left;">
                    ${dateStr} ${t.phone ? `• to/from ${t.phone}` : ''}
                </div>
            </div>
        `;
    }).join('');
    
    if (window.lucide) window.lucide.createIcons();
    
    if (paginationWrap) {
        paginationWrap.innerHTML = `
            <div style="display:flex; justify-content:space-between; align-items:center; padding:8px 12px; background:rgba(0,0,0,0.15); border:1px solid var(--border); border-radius:8px; font-size:0.7rem; color:var(--text-muted);">
                <span>Page ${profileTxPage} of ${totalPages}</span>
                <div style="display:flex; gap:6px;">
                    <button onclick="changeProfileTxPage(${profileTxPage - 1})" class="quick-btn" style="padding:2px 8px; width:auto; text-transform:none; font-size:0.65rem;" ${profileTxPage === 1 ? 'disabled style="opacity:0.3; cursor:not-allowed;"' : ''}>Prev</button>
                    <button onclick="changeProfileTxPage(${profileTxPage + 1})" class="quick-btn" style="padding:2px 8px; width:auto; text-transform:none; font-size:0.65rem;" ${profileTxPage === totalPages ? 'disabled style="opacity:0.3; cursor:not-allowed;"' : ''}>Next</button>
                </div>
            </div>
        `;
    }
}

// ── PREDICTOR PANEL SYSTEM ──────────────────────────────────────────────────
let isPredictorModeActive = false;
let predictorPollInterval = null;
let predictorSignalHistory = [];

function renderPredictorUI(data) {
    if (!data) return;
    const roundIdEl = document.getElementById('predictorRoundId');
    const signalTextEl = document.getElementById('predictorSignalText');
    const statusTextEl = document.getElementById('predictorStatusText');
    const cashoutTargetEl = document.getElementById('predictorCashoutTarget');
    const historyListEl = document.getElementById('predictorHistoryList');
    
    if (roundIdEl) roundIdEl.textContent = `ROUND #${data.roundId}`;
    
    if (data.status === 'crashed') {
        if (statusTextEl) statusTextEl.textContent = 'COMPILING NEXT SIGNAL...';
        if (signalTextEl) {
            signalTextEl.textContent = '--.--x';
            signalTextEl.style.textShadow = '0 0 10px rgba(168, 85, 247, 0.4)';
            signalTextEl.style.color = 'rgba(255, 255, 255, 0.4)';
        }
        if (cashoutTargetEl) cashoutTargetEl.textContent = 'WAITING FOR NEW ROUND';
    } else {
        const multVal = parseFloat(parseFloat(data.crashPoint).toFixed(2));
        const safeTarget = Math.max(1.01, (multVal * 0.88)).toFixed(2);

        if (statusTextEl) statusTextEl.textContent = 'SIGNAL SECURED & ENCRYPTED';
        if (cashoutTargetEl) cashoutTargetEl.textContent = `${safeTarget}x (SAFETY MARGIN)`;

        if (signalTextEl) {
            signalTextEl.textContent = `${multVal.toFixed(2)}x`;
            
            if (multVal >= 10.0) {
                signalTextEl.style.color = '#f472b6';
                signalTextEl.style.textShadow = '0 0 25px rgba(244, 114, 182, 0.95), 0 0 50px rgba(244, 114, 182, 0.6)';
            } else if (multVal >= 3.0) {
                signalTextEl.style.color = '#34d399';
                signalTextEl.style.textShadow = '0 0 25px rgba(52, 211, 153, 0.95), 0 0 50px rgba(52, 211, 153, 0.6)';
            } else if (multVal >= 2.0) {
                signalTextEl.style.color = '#38bdf8';
                signalTextEl.style.textShadow = '0 0 25px rgba(56, 189, 248, 0.95), 0 0 50px rgba(56, 189, 248, 0.6)';
            } else {
                signalTextEl.style.color = '#e9d5ff';
                signalTextEl.style.textShadow = '0 0 25px rgba(168, 85, 247, 0.9), 0 0 45px rgba(168, 85, 247, 0.5)';
            }
        }

        // Append to history log if not already logged for this round
        if (!predictorSignalHistory.some(h => h.roundId === data.roundId)) {
            predictorSignalHistory.unshift({
                roundId: data.roundId,
                predicted: multVal.toFixed(2)
            });
            if (predictorSignalHistory.length > 10) predictorSignalHistory.pop();
            
            if (historyListEl) {
                historyListEl.innerHTML = predictorSignalHistory.map(h => `
                    <div class="predictor-history-pill">
                        <span>#${h.roundId}</span>
                        <strong style="color: #fff;">${h.predicted}x</strong>
                        <span style="color: #10b981;">✓</span>
                    </div>
                `).join('');
            }
        }
    }
}

async function fetchPredictorSignal() {
    if (!isPredictorModeActive) return;

    // 1. Immediately render local engine telemetry (0ms instant response)
    const activeRoundId = serverRoundId || Math.floor(Date.now() / 10000);
    const activePoint = serverCrashPoint || (crashHistory.length > 0 ? crashHistory[0] : 2.45);
    const activeStatus = gameState || 'waiting';

    renderPredictorUI({
        success: true,
        roundId: activeRoundId,
        crashPoint: activePoint,
        status: activeStatus
    });

    // 2. Perform API sync in background for overrides or server updates
    try {
        const { data: { session } } = await supabase.auth.getSession();
        if (session) {
            const response = await fetch('/api/signal', {
                headers: {
                    'Authorization': `Bearer ${session.access_token}`
                }
            });
            if (response.ok) {
                const resJson = await response.json();
                if (resJson && resJson.success) {
                    renderPredictorUI(resJson);
                }
            }
        }
    } catch (err) {
        // Fallback already rendered above
    }
}


function startPredictorSignalPolling() {
    if (predictorPollInterval) clearInterval(predictorPollInterval);
    fetchPredictorSignal(); // initial fetch
    predictorPollInterval = setInterval(fetchPredictorSignal, 1500);
}

function stopPredictorSignalPolling() {
    if (predictorPollInterval) {
        clearInterval(predictorPollInterval);
        predictorPollInterval = null;
    }
}

window.togglePredictorMode = (isActive, isInitialAutoResume = false) => {
    if (isActive) {
        if (!currentUser || !['Predictor', 'Admin', 'Super Admin'].includes(currentUser.role)) {
            console.error("Unauthorized entry attempt to Predictor Panel");
            localStorage.setItem('isPredictorModeActive', 'false');
            window.location.replace('/auth');
            return;
        }
    }

    isPredictorModeActive = isActive;
    localStorage.setItem('isPredictorModeActive', isActive ? 'true' : 'false');
    
    // Select normal game layout components
    const sidebar = document.querySelector('aside.sidebar');
    const mainContent = document.querySelector('main.main-content:not(#predictorApp)');
    const predictorApp = document.getElementById('predictorApp');
    const balanceCard = document.querySelector('.balance-card');
    
    if (isActive) {
        document.getElementById('app')?.classList.add('predictor-mode-active');
        // Toggle view
        if (sidebar) sidebar.style.display = 'none';
        if (mainContent) mainContent.style.display = 'none';
        if (predictorApp) {
            predictorApp.classList.remove('hidden');
            predictorApp.style.display = 'flex';
        }
        if (balanceCard) {
            balanceCard.style.display = 'none';
        }
        
        // Start polling
        startPredictorSignalPolling();
        if (!isInitialAutoResume) {
            showToast("Connected to Cyber-Signal telemetry stream.", "success");
        }
        if (window.lucide) window.lucide.createIcons();
    } else {
        document.getElementById('app')?.classList.remove('predictor-mode-active');
        // Stop polling
        stopPredictorSignalPolling();
        
        // Toggle view back
        if (sidebar) sidebar.style.display = '';
        if (mainContent) mainContent.style.display = '';
        if (predictorApp) {
            predictorApp.classList.add('hidden');
            predictorApp.style.display = 'none';
        }
        if (balanceCard) {
            balanceCard.style.display = '';
        }
        if (!isInitialAutoResume) {
            showToast("Disconnected from telemetry stream.", "info");
        }
    }
};

