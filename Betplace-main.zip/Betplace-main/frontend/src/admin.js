/**
 * src/admin.js
 * 
 * Expanded Admin Dashboard Logic
 * Provides full control over User Sovereignty, Financial Ledger, Promotions, Notifications, Support, and Global settings.
 * Mirrors super-admin capabilities for synced administrative operation.
 */

import { supabase } from './config/supabase.js';
import { injectVercelAnalytics } from './utils/analytics.js';
import { showNotFound } from './utils/notFound.js';
import { initGuard } from './utils/routeGuard.js';

const IS_ADMIN_SUBDOMAIN = window.location.hostname.startsWith('admin.');

injectVercelAnalytics();

let currentUser = null;
let allUsers = [];
let allAuditLogs = [];
let allTransactions = [];
let activeTab = 'overview';

// ── PAGINATION SYSTEM CONFIGURATION ───────────────────────────
const PAGE_SIZE = 15;
const OVERVIEW_PAGE_SIZE = 10;

let userPage = 1;
let currentUsersList = [];

let ledgerPage = 1;
let currentLedgerList = [];

let overviewAuditPage = 1;
let currentOverviewAuditList = [];

/** Non-blocking toast notification */
function showToast(message, isError = false) {
    const existing = document.getElementById('__adminToast');
    if (existing) existing.remove();
    const toast = document.createElement('div');
    toast.id = '__adminToast';
    toast.textContent = message;
    toast.style.cssText = `
        position:fixed; top:18px; right:18px; z-index:99999;
        background:${isError ? 'rgba(24, 16, 22, 0.96)' : 'rgba(14, 24, 20, 0.96)'};
        color:${isError ? '#FDA4AF' : '#BBF7D0'};
        padding:8px 14px; border-radius:8px; font-weight:500;
        font-size:0.8125rem; letter-spacing:-0.1px;
        box-shadow:0 4px 16px rgba(0,0,0,0.35);
        border:1px solid ${isError ? 'rgba(244, 63, 94, 0.28)' : 'rgba(34, 197, 94, 0.25)'};
        max-width:320px; word-break:break-word;
        transition:opacity 0.25s ease, transform 0.25s cubic-bezier(0.16, 1, 0.3, 1);
        backdrop-filter:blur(12px); -webkit-backdrop-filter:blur(12px);
    `;
    document.body.appendChild(toast);
    setTimeout(() => { toast.style.opacity = '0'; setTimeout(() => toast.remove(), 250); }, 3000);
}

function buildPaginationMarkup(totalItems, currentPage, pageSize, onPageChangeName) {
    const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
    let html = `
        <div class="pagination-controls" style="display:flex; justify-content:space-between; align-items:center; padding:16px; background:var(--bg-sheet); border:1px solid var(--border-pill); border-top:none; border-radius: 0 0 var(--radius-md) var(--radius-md); margin-top:-1px;">
            <div style="font-size:0.75rem; color:var(--text-muted);">
                Showing ${totalItems === 0 ? 0 : (currentPage - 1) * pageSize + 1} - ${Math.min(currentPage * pageSize, totalItems)} of ${totalItems} entries
            </div>
            <div style="display:flex; gap:6px; align-items:center;">
                <button class="quick-btn" style="padding:4px 10px; width:auto; font-weight:700; background:var(--bg-input); border:1px solid var(--border-pill); color:var(--text-primary); border-radius:6px; cursor:pointer;" 
                    ${currentPage === 1 ? 'disabled style="opacity:0.4; cursor:not-allowed;"' : `onclick="${onPageChangeName}(${currentPage - 1})"`}>
                    Prev
                </button>
    `;
    
    const startPage = Math.max(1, currentPage - 2);
    const endPage = Math.min(totalPages, startPage + 4);
    
    for (let i = startPage; i <= endPage; i++) {
        const isActive = i === currentPage;
        html += `
            <button class="quick-btn" 
                style="padding:4px 10px; width:auto; font-weight:700; border-radius:6px; cursor:pointer; ${isActive ? 'background:var(--accent-blue); color:white; border:1px solid var(--accent-blue);' : 'background:var(--bg-input); border:1px solid var(--border-pill); color:var(--text-primary);'}" 
                onclick="${onPageChangeName}(${i})">
                ${i}
            </button>
        `;
    }
    
    html += `
                <button class="quick-btn" style="padding:4px 10px; width:auto; font-weight:700; background:var(--bg-input); border:1px solid var(--border-pill); color:var(--text-primary); border-radius:6px; cursor:pointer;" 
                    ${currentPage === totalPages ? 'disabled style="opacity:0.4; cursor:not-allowed;"' : `onclick="${onPageChangeName}(${currentPage + 1})"`}>
                    Next
                </button>
            </div>
        </div>
    `;
    return html;
}


// ── INITIALIZATION ─────────────────────────────────────────────────────────

window.addEventListener('load', async () => {
    const authorized = await initGuard();
    if (!authorized) return;

    document.title = 'Admin Control Center | Betplace';

    const { data: { session } } = await supabase.auth.getSession();
    currentUser = session.user;

    window.handleAdminLogout = () => {
        localStorage.removeItem('metrowins_auth_token');
        localStorage.removeItem('metrowins_auth_user');
        document.cookie = 'metrowins_auth_token=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT';
        window.location.replace('/admin/login');
    };
    
    // Subscribe to game state realtime changes
    subscribeToGameState();

    // Bind Tab Click Handlers
    const buttons = document.querySelectorAll('.admin-nav-btn');
    const tabs = ['overview', 'users', 'ledger', 'global_settings', 'promotions', 'notifications', 'support', 'community', 'settings'];
    
    buttons.forEach((btn, index) => {
        btn.addEventListener('click', () => {
            window.location.hash = '#' + tabs[index];
        });
    });

    window.addEventListener('hashchange', () => {
        const hashTab = window.location.hash.replace('#/', '').replace('#', '') || 'overview';
        if (tabs.includes(hashTab)) {
            buttons.forEach((b, i) => {
                b.classList.toggle('active', i === tabs.indexOf(hashTab));
            });
            switchTab(hashTab);
        }
    });

    // Handle fresh reload with hash preservation
    const initialHash = window.location.hash.replace('#/', '').replace('#', '') || 'overview';
    const initialIndex = tabs.indexOf(initialHash);
    if (initialIndex !== -1) {
        buttons.forEach((b, i) => {
            b.classList.toggle('active', i === initialIndex);
        });
        switchTab(initialHash);
    } else {
        switchTab('overview');
    }
});

// ── REALTIME MONITORING ───────────────────────────────────────────────────

function subscribeToGameState() {
    supabase
        .channel('admin_game_monitor')
        .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'active_game_state', filter: 'id=eq.1' }, (payload) => {
            const newState = payload.new;
            
            // Sync live status labels if monitoring settings page
            const liveRoundEl = document.getElementById('liveRoundDisplay');
            const liveStatusEl = document.getElementById('liveGameStateDisplay');
            const liveCrashEl = document.getElementById('liveCrashPointDisplay');

            if (liveStatusEl && newState) {
                liveStatusEl.textContent = String(newState.status).toUpperCase();
                liveStatusEl.className = `status-pill ${newState.status === 'playing' ? 'status-approved' : (newState.status === 'waiting' ? 'status-pending' : 'status-rejected')}`;
            }
            if (liveCrashEl && newState) {
                liveCrashEl.textContent = `${parseFloat(newState.crash_point || 1.8).toFixed(2)}x`;
            }
            if (liveRoundEl && newState) {
                liveRoundEl.textContent = `#${newState.round_id}`;
            }
        })
        .subscribe();
}

async function switchTab(tab) {
    activeTab = tab;
    const contentEl = document.getElementById('adminContent');
    if (!contentEl) return;

    // Show loading spinner
    contentEl.innerHTML = `
        <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; padding:100px 0; gap:16px;">
            <div class="airplane-spinner" style="font-size: 2rem; animation: spin 1.5s linear infinite;">✈</div>
            <div style="color:var(--text-muted); font-size:0.8rem;">Loading administration interface...</div>
        </div>
    `;

    try {
        const { data: { session } } = await supabase.auth.getSession();
        const headers = { 'Authorization': `Bearer ${session.access_token}` };

        if (tab === 'overview') {
            const statsRes = await fetch('/api/admin/system?action=stats', { headers });
            const stats = await statsRes.json();
            if (stats.error) throw new Error(stats.error);
            
            const logsRes = await fetch('/api/admin/system?action=audit_logs', { headers });
            allAuditLogs = await logsRes.json();
            if (allAuditLogs.error) throw new Error(allAuditLogs.error);

            renderOverview(stats, allAuditLogs);
        }
        else if (tab === 'users') {
            const res = await fetch('/api/admin/system?action=users', { headers });
            allUsers = await res.json();
            if (allUsers.error) throw new Error(allUsers.error);
            renderUserSovereignty();
        }
        else if (tab === 'ledger') {
            const res = await fetch('/api/admin/system?action=transactions', { headers });
            allTransactions = await res.json();
            if (allTransactions.error) throw new Error(allTransactions.error);
            renderFinancialLedger();
        }
        else if (tab === 'settings') {
            await renderGlobalSettings();
        }
        else if (tab === 'promotions') {
            const res = await fetch('/api/admin/content?action=promotions', { headers });
            const data = await res.json();
            if (data.error) throw new Error(data.error);
            renderPromotions(Array.isArray(data) ? data : []);
        }
        else if (tab === 'notifications') {
            renderNotifications();
        }
        else if (tab === 'support') {
            const res = await fetch('/api/admin/content?action=settings', { headers });
            const settings = await res.json();
            renderSupport(settings);
        }
        else if (tab === 'community') {
            const res = await fetch('/api/admin/content?action=settings', { headers });
            const settings = await res.json();
            renderCommunity(settings);
        }
        else if (tab === 'global_settings') {
            await renderGlobalSettings();
        }
    } catch (e) {
        contentEl.innerHTML = `
            <div style="padding: 24px; text-align: center; color: var(--error);">
                <h3>Failed to load system workspace</h3>
                <p style="font-size:0.75rem; color:var(--text-muted); margin-top:8px;">${e.message}</p>
                <button class="danger-btn" style="width:auto; margin-top:16px; padding:6px 16px;" onclick="switchTab('${tab}')">TRY AGAIN</button>
            </div>
        `;
    }
}

window.switchTab = switchTab;

// ── TAB RENDERING ─────────────────────────────────────────────────────────────

function renderOverview(stats, logs) {
    const contentEl = document.getElementById('adminContent');
    contentEl.innerHTML = `
        <div class="admin-page-header">
            <div>
                <h1>Executive Overview</h1>
                <p>Real-time platform metrics and controls</p>
            </div>
            <button class="back-btn" onclick="window.location.href='/'">← Back to Game</button>
        </div>

        <div class="stat-grid">
            <div class="stat-card">
                <div class="stat-label">Total GGR</div>
                <div class="stat-value green">KES ${stats.ggr?.toLocaleString(undefined, {minimumFractionDigits:2}) || '0.00'}</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Registered Players</div>
                <div class="stat-value blue" id="activeUsersCount">${stats.users || '0'}</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">System Load</div>
                <div class="stat-value" style="color:var(--success);">STABLE</div>
            </div>
            <div class="stat-card highlight">
                <div class="stat-label">GGR Currency</div>
                <div class="stat-value green">KES</div>
            </div>
        </div>

        <div class="section-card" style="margin-bottom:0; border-bottom-left-radius:0; border-bottom-right-radius:0;">
            <div class="section-header">
                <h2>Recent Audit Trail</h2>
                <span>Awaiting review</span>
            </div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Timestamp</th>
                        <th>User</th>
                        <th>Action</th>
                        <th>Target</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody id="auditTrail">
                </tbody>
            </table>
        </div>
        <div id="overviewAuditPagination"></div>
    `;

    currentOverviewAuditList = logs || [];
    overviewAuditPage = 1;
    renderOverviewAuditPage();
}

window.changeOverviewAuditPage = (page) => {
    overviewAuditPage = page;
    renderOverviewAuditPage();
};

function renderOverviewAuditPage() {
    const startIdx = (overviewAuditPage - 1) * OVERVIEW_PAGE_SIZE;
    const paginatedLogs = currentOverviewAuditList.slice(startIdx, startIdx + OVERVIEW_PAGE_SIZE);
    
    const tbody = document.getElementById('auditTrail');
    if (tbody) {
        tbody.innerHTML = renderAuditRows(paginatedLogs);
    }
    
    const paginationContainer = document.getElementById('overviewAuditPagination');
    if (paginationContainer) {
        paginationContainer.innerHTML = buildPaginationMarkup(currentOverviewAuditList.length, overviewAuditPage, OVERVIEW_PAGE_SIZE, 'changeOverviewAuditPage');
    }
}

function renderAuditRows(logs) {
    if (!logs || logs.length === 0) {
        return `
            <tr>
                <td colspan="5" style="text-align: center; padding: 48px; color: var(--text-muted);">
                    <div style="font-size: 1.5rem; margin-bottom: 6px;">📋</div>
                    <div style="font-weight: 600; color: var(--text-primary);">Audit Trail Empty</div>
                    <div style="font-size: 0.72rem;">No system actions recorded.</div>
                </td>
            </tr>
        `;
    }
    return logs.map(log => {
        const timeStr = new Date(log.created_at).toLocaleString();
        const subject = log.profiles ? (log.profiles.username ? `@${log.profiles.username}` : log.profiles.phone) : 'SYSTEM';
        const detailsText = log.details ? (typeof log.details === 'object' ? JSON.stringify(log.details) : log.details) : '—';
        return `
            <tr>
                <td style="color: var(--text-muted); font-size:0.75rem;">${timeStr}</td>
                <td style="font-weight: 700; color: var(--blue);">${subject}</td>
                <td class="action-tag">${log.action}</td>
                <td style="color: var(--text-secondary); font-family: monospace;">${log.target_id || '—'}</td>
                <td style="font-size: 0.73rem; color: var(--text-secondary); font-family: monospace; max-width: 250px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${detailsText.replace(/"/g, '&quot;')}">${detailsText}</td>
            </tr>
        `;
    }).join('');
}

function renderUserSovereignty() {
    const contentEl = document.getElementById('adminContent');
    contentEl.innerHTML = `
        <div class="admin-page-header">
            <div>
                <h1>User Management</h1>
                <p>Search, manage balances, and freeze or unfreeze player accounts. Role assignments are managed by Super Admins.</p>
            </div>
        </div>

        <div style="margin-bottom: 20px; display:flex; gap:12px;">
            <input type="text" id="userSearch" class="amount-input" style="flex-grow:1; max-width:400px; text-transform:none;" placeholder="Search user by email, phone, username...">
        </div>

        <div class="section-card" style="box-shadow:none; margin-bottom:0; border-bottom-left-radius:0; border-bottom-right-radius:0;">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Username / Phone</th>
                        <th>Email / Reg Date</th>
                        <th>Balance (KES)</th>
                        <th>Status</th>
                        <th>Wallet Modification</th>
                        <th>Account Status</th>
                    </tr>
                </thead>
                <tbody id="userRows">
                </tbody>
            </table>
        </div>
        <div id="userPagination"></div>
    `;

    document.getElementById('userSearch').addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase();
        currentUsersList = allUsers.filter(u => 
            (u.phone && u.phone.toLowerCase().includes(query)) ||
            (u.email && u.email.toLowerCase().includes(query)) ||
            (u.username && u.username.toLowerCase().includes(query))
        );
        userPage = 1;
        renderUserPage();
    });

    currentUsersList = allUsers || [];
    userPage = 1;
    renderUserPage();
}

window.changeUserPage = (page) => {
    userPage = page;
    renderUserPage();
};

function renderUserPage() {
    const startIdx = (userPage - 1) * PAGE_SIZE;
    const paginatedUsers = currentUsersList.slice(startIdx, startIdx + PAGE_SIZE);
    
    const tbody = document.getElementById('userRows');
    if (tbody) {
        tbody.innerHTML = getUserRowsMarkup(paginatedUsers);
    }
    
    const paginationContainer = document.getElementById('userPagination');
    if (paginationContainer) {
        paginationContainer.innerHTML = buildPaginationMarkup(currentUsersList.length, userPage, PAGE_SIZE, 'changeUserPage');
    }
}

function getUserRowsMarkup(users) {
    if (!users || users.length === 0) {
        return `<tr><td colspan="6" style="text-align:center; padding:32px; color:var(--text-muted);">No matching profiles found</td></tr>`;
    }

    return users.map(u => {
        const uLabel = u.username ? `@${u.username}` : (u.phone || 'Guest User');
        const role = u.user_roles?.[0]?.roles?.name || (u.is_admin ? 'Admin' : 'User');
        const isFrozen = u.is_frozen === true;
        const joinedDate = new Date(u.created_at).toLocaleDateString();

        return `
            <tr data-user-id="${u.id}">
                <td>
                    <div style="font-weight:700; color:var(--text-primary);">${uLabel}</div>
                    <div style="font-size:0.68rem; color:var(--text-muted); margin-top:2px;">Role: ${role}</div>
                </td>
                <td>
                    <div style="font-size:0.75rem; color:var(--text-secondary);">${u.email || '—'}</div>
                    <div style="font-size:0.65rem; color:var(--text-muted); margin-top:2px;">Reg: ${joinedDate}</div>
                </td>
                <td style="font-weight:700; color:var(--success); font-size:0.85rem;">
                    KES ${parseFloat(u.balance || 0).toLocaleString(undefined, {minimumFractionDigits:2})}
                </td>
                <td>
                    <span class="status-pill ${isFrozen ? 'status-pending' : 'status-approved'}" style="padding: 2px 8px; border-radius:4px; font-size:0.65rem;">
                        ${isFrozen ? 'FROZEN' : 'ACTIVE'}
                    </span>
                </td>
                <td>
                    <div style="display:flex; align-items:center; gap:6px;">
                        <input type="number" class="amount-input" id="adjVal_${u.id}" style="width:80px; padding:4px 6px; font-size:0.75rem;" placeholder="KES">
                        <button class="action-btn approve" style="padding:4px 8px; font-weight:700;" onclick="submitBalanceAdjustment('${u.id}', 1)">+</button>
                        <button class="action-btn reject" style="padding:4px 8px; font-weight:700;" onclick="submitBalanceAdjustment('${u.id}', -1)">−</button>
                    </div>
                </td>
                <td>
                    <button class="action-btn ${isFrozen ? 'approve' : 'reject'}" onclick="submitToggleFreeze('${u.id}', ${isFrozen})">
                        ${isFrozen ? '🔓 Unfreeze' : '🔒 Freeze'}
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

function getLedgerRowsMarkup(transactions) {
    if (!transactions || transactions.length === 0) {
        return `<tr><td colspan="7" style="text-align:center; padding:32px; color:var(--text-muted);">No transaction records found</td></tr>`;
    }
    return transactions.map(t => {
        const timeStr = new Date(t.created_at).toLocaleString();
        const userLabel = t.profiles ? (t.profiles.username ? `@${t.profiles.username}` : t.profiles.phone) : (t.user_id || 'Unknown');
        const typeLabel = String(t.type).toUpperCase();
        const isSuccess = t.status === 'success' || t.status === 'approved' || t.status === 'completed';
        const isPendingWithdrawal = (t.type === 'withdrawal' || t.type === 'withdraw') && t.status === 'pending';

        let actionsMarkup = `<span style="color:var(--text-muted); font-size:0.75rem;">—</span>`;
        if (isPendingWithdrawal) {
            actionsMarkup = `
                <div style="display:flex; gap:6px; align-items:center;">
                    <button class="action-btn approve" onclick="window.approveWithdrawal('${t.id}')" title="Approve & Release M-Pesa Payout">
                        ✓ Release
                    </button>
                    <button class="action-btn reject" onclick="window.rejectWithdrawal('${t.id}')" title="Reject & Refund to User">
                        ✕ Reject
                    </button>
                </div>
            `;
        } else if (t.metadata?.approved_by) {
            actionsMarkup = `<span style="color:var(--success); font-size:0.72rem; font-weight:600;">✓ Approved</span>`;
        } else if (t.status === 'rejected') {
            const reason = t.metadata?.rejection_reason || 'Rejected';
            actionsMarkup = `<span style="color:var(--error); font-size:0.72rem;" title="${reason}">✕ ${reason.length > 20 ? reason.slice(0, 18) + '...' : reason}</span>`;
        }
        
        return `
            <tr>
                <td style="color:var(--text-muted);">${timeStr}</td>
                <td style="font-weight:600; color:var(--text-primary);">${userLabel}</td>
                <td>
                    <span style="font-weight:700; color:${typeLabel === 'DEPOSIT' ? 'var(--success)' : (typeLabel.includes('WITHDRAW') ? 'var(--warning)' : 'var(--text-primary)')};">
                        ${typeLabel}
                    </span>
                </td>
                <td style="font-weight:700;">KES ${parseFloat(t.amount || 0).toLocaleString(undefined, {minimumFractionDigits:2})}</td>
                <td>
                    <span class="status-pill ${isSuccess ? 'status-approved' : (t.status === 'pending' ? 'status-pending' : 'status-rejected')}" style="padding:2px 8px; border-radius:4px; font-size:0.65rem;">
                        ${String(t.status).toUpperCase()}
                    </span>
                </td>
                <td style="font-family:monospace; font-size:0.72rem; color:var(--text-secondary);">${t.reference || '—'}</td>
                <td>${actionsMarkup}</td>
            </tr>
        `;
    }).join('');
}

function renderFinancialLedger() {
    const contentEl = document.getElementById('adminContent');
    contentEl.innerHTML = `
        <div class="admin-page-header">
            <div>
                <h1>Financial Ledger Audit</h1>
                <p>Monitor all transaction ledger statements, deposit clearances, and payout actions.</p>
            </div>
            <div style="display:flex; gap:10px; align-items:center;">
                <button class="topbar-btn" onclick="switchTab('ledger')">
                    <i data-lucide="refresh-cw" style="width:14px; height:14px;"></i>
                    <span>Refresh</span>
                </button>
            </div>
        </div>

        <div style="margin-bottom: 20px; display:flex; gap:12px; flex-wrap:wrap; align-items:center;">
            <input type="text" id="ledgerSearch" class="amount-input" style="flex-grow:1; max-width:400px; text-transform:none;" placeholder="Search transaction by account, reference, type...">
            <div class="filter-chips" id="ledgerFilterChips" style="display:flex; gap:8px; flex-wrap:wrap;">
                <button class="chip active" onclick="window.filterLedgerByType('all', this)">All</button>
                <button class="chip" onclick="window.filterLedgerByType('pending_withdrawal', this)">Pending Withdrawals</button>
                <button class="chip" onclick="window.filterLedgerByType('deposit', this)">Deposits</button>
                <button class="chip" onclick="window.filterLedgerByType('withdrawal', this)">Withdrawals</button>
            </div>
        </div>

        <div class="section-card" style="margin-bottom:0; border-bottom-left-radius:0; border-bottom-right-radius:0;">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Timestamp</th>
                        <th>User Account</th>
                        <th>Type</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Reference</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="ledgerRows">
                </tbody>
            </table>
        </div>
        <div id="ledgerPagination"></div>
    `;

    window.filterLedgerByType = (typeFilter, btn) => {
        if (btn) {
            document.querySelectorAll('#ledgerFilterChips .chip').forEach(c => c.classList.remove('active'));
            btn.classList.add('active');
        }
        const query = (document.getElementById('ledgerSearch')?.value || '').toLowerCase();
        currentLedgerList = allTransactions.filter(t => {
            const username = t.profiles?.username || '';
            const phone = t.profiles?.phone || '';
            const uid = t.user_id || '';
            const type = t.type || '';
            const ref = t.reference || '';
            const status = (t.status || '').toLowerCase();
            const matchesQuery = !query ||
                   username.toLowerCase().includes(query) ||
                   phone.toLowerCase().includes(query) ||
                   uid.toLowerCase().includes(query) ||
                   type.toLowerCase().includes(query) ||
                   ref.toLowerCase().includes(query);
            if (!matchesQuery) return false;
            if (typeFilter === 'pending_withdrawal') {
                return (type.toLowerCase() === 'withdrawal' || type.toLowerCase() === 'withdraw') && status === 'pending';
            }
            if (typeFilter !== 'all') {
                return type.toLowerCase() === typeFilter;
            }
            return true;
        });
        ledgerPage = 1;
        renderLedgerPage();
    };

    document.getElementById('ledgerSearch').addEventListener('input', (e) => {
        const activeChip = document.querySelector('#ledgerFilterChips .chip.active');
        let typeFilter = 'all';
        if (activeChip) {
            const text = activeChip.textContent.toLowerCase();
            if (text.includes('pending')) typeFilter = 'pending_withdrawal';
            else if (text.includes('deposit')) typeFilter = 'deposit';
            else if (text.includes('withdrawal')) typeFilter = 'withdrawal';
        }
        window.filterLedgerByType(typeFilter);
    });

    currentLedgerList = allTransactions || [];
    ledgerPage = 1;
    renderLedgerPage();
    if (window.lucide) lucide.createIcons();
}

window.changeLedgerPage = (page) => {
    ledgerPage = page;
    renderLedgerPage();
};

function renderLedgerPage() {
    const startIdx = (ledgerPage - 1) * PAGE_SIZE;
    const paginatedTransactions = currentLedgerList.slice(startIdx, startIdx + PAGE_SIZE);

    const tbody = document.getElementById('ledgerRows');
    if (tbody) {
        tbody.innerHTML = getLedgerRowsMarkup(paginatedTransactions);
        if (window.lucide) lucide.createIcons();
    }

    const paginationContainer = document.getElementById('ledgerPagination');
    if (paginationContainer) {
        paginationContainer.innerHTML = buildPaginationMarkup(currentLedgerList.length, ledgerPage, PAGE_SIZE, 'changeLedgerPage');
    }
}

async function renderGlobalSettings() {
    const contentEl = document.getElementById('adminContent');

    // ── 1. Render skeleton instantly (no DB wait) ──────────────────
    contentEl.innerHTML = `
        <div class="admin-page-header">
            <div>
                <h1>Global Platform Settings</h1>
                <p>Configure parameters, force outcomes, and manage game signals.</p>
            </div>
        </div>

        <div style="background: var(--bg-surface); border: 1px solid var(--border); padding: 24px; border-radius: var(--radius-md); max-width:600px; display:flex; flex-direction:column; gap:20px;">

            <div style="background: var(--bg-elevated); border: 1px solid var(--border); padding: 16px; border-radius: var(--radius-sm); display:flex; justify-content:space-between; align-items:center; margin-bottom: 8px;">
                <div>
                    <div style="font-size:0.6rem; color:var(--text-muted); text-transform:uppercase; letter-spacing:1px; font-weight:700;">Active Round ID</div>
                    <div id="liveRoundDisplay" style="font-size:1.1rem; font-weight:800; color:var(--text-primary); margin-top:2px;">…</div>
                </div>
                <div>
                    <div style="font-size:0.6rem; color:var(--text-muted); text-transform:uppercase; letter-spacing:1px; font-weight:700;">Game Room Status</div>
                    <span id="liveGameStateDisplay" class="status-pill status-pending" style="padding:4px 10px; font-size:0.7rem; border-radius:4px; font-weight:700; display:inline-block; margin-top:4px;">…</span>
                </div>
                <div>
                    <div style="font-size:0.6rem; color:var(--text-muted); text-transform:uppercase; letter-spacing:1px; font-weight:700;">Active Outcome Signal</div>
                    <div id="liveCrashPointDisplay" style="font-size:1.1rem; font-weight:950; color:var(--accent); margin-top:2px; font-family:monospace;">…</div>
                </div>
            </div>

            <h3 style="margin-bottom:4px; font-size:0.92rem; font-weight:800;">🛰 Target Next Crash Point Signal</h3>
            <p style="color:var(--text-muted); font-size:0.75rem;">Force a specific crash multiplier for the incoming round. E.g. placing 100.00 will allow players to ride up to 100x before crash.</p>

            <div style="display:flex; flex-direction:column; gap:8px;">
                <label style="font-size:0.68rem; font-weight:700; color:var(--text-secondary); text-transform:uppercase;">Next Crash Point (Multiplier)</label>
                <div style="display:flex; gap:12px;">
                    <input type="number" id="nextCrashOverride" class="amount-input" style="width:140px; text-align:left;" value="1.80" min="1.01" step="0.05">
                    <button class="action-btn approve" onclick="submitCrashPointOverride()" style="margin:0; height:38px; width:auto; padding:0 24px; border-radius:var(--radius-sm);">
                        APPLY SIGNAL
                    </button>
                </div>
            </div>

            <hr style="border:none; border-bottom: 1px solid var(--border); margin: 8px 0;">

            <h3 style="margin-bottom:4px; font-size:0.92rem; font-weight:800; color:var(--error);">🚨 Platform Maintenance Lockdown</h3>
            <p style="color:var(--text-muted); font-size:0.75rem;">Configure safety system settings. This restricts access for all non-privileged players system-wide.</p>
            <div>
                <button class="action-btn reject" style="width:auto; padding:8px 24px;" onclick="toggleMaintenance()">
                    ⚠ ACTIVATE EMERGENCY MAINTENANCE
                </button>
            </div>

            <hr style="border:none; border-bottom: 1px solid var(--border); margin: 8px 0;">

            <h3 style="margin-bottom:4px; font-size:0.92rem; font-weight:800; color:var(--blue);">🔍 Profiles Registry Sync Diagnostics</h3>
            <p style="color:var(--text-muted); font-size:0.75rem;">Identify and repair newly created signups that failed to sync with the public profiles table.</p>
            <div style="display:flex; gap:12px;">
                <button class="action-btn approve" style="width:auto; padding:8px 16px; border-radius:var(--radius-sm); margin:0;" onclick="runUserDiagnostics()">
                    RUN DIAGNOSTICS
                </button>
                <button class="action-btn approve" style="width:auto; padding:8px 16px; border-radius:var(--radius-sm); margin:0; background:var(--success); color:black; border-color:var(--success);" onclick="runUserRepair()">
                    AUTO-REPAIR PROFILES
                </button>
            </div>
            <div id="diagnosticResults" style="font-size:0.72rem; font-family:monospace; background:var(--bg-elevated); padding:10px; border-radius:4px; border:1px solid var(--border); display:none; max-height: 150px; overflow-y: auto;">
            </div>
        </div>
    `;

    // ── 2. Fast DB sync — only 3 columns needed ────────────────────
    const syncState = async () => {
        const roundEl   = document.getElementById('liveRoundDisplay');
        if (!roundEl) return false; // panel is gone, stop polling
        
        try {
            await supabase.rpc('sync_and_get_game_state');
        } catch (e) {
            console.warn("Could not progress game state loop via settings sync:", e);
        }

        const { data: s } = await supabase
            .from('active_game_state')
            .select('round_id, crash_point, status')
            .eq('id', 1)
            .single();
        if (!s) return true;
        const statusEl  = document.getElementById('liveGameStateDisplay');
        const crashEl   = document.getElementById('liveCrashPointDisplay');
        const inputEl   = document.getElementById('nextCrashOverride');
        roundEl.textContent  = `#${s.round_id}`;
        if (statusEl) {
            statusEl.textContent = String(s.status).toUpperCase();
            statusEl.className   = `status-pill ${s.status === 'playing' ? 'status-approved' : s.status === 'waiting' ? 'status-pending' : 'status-rejected'}`;
        }
        if (crashEl)  crashEl.textContent = `${parseFloat(s.crash_point).toFixed(2)}x`;
        if (inputEl && document.activeElement !== inputEl)
            inputEl.value = parseFloat(s.crash_point).toFixed(2);
        return true;
    };

    await syncState(); // immediate first fetch

    // ── 3. Poll every 1.5 s — auto-clears when panel unmounts ─────
    const tid = setInterval(async () => {
        const alive = await syncState();
        if (!alive) clearInterval(tid);
    }, 1500);
}

// ── PROMOTIONS TAB ────────────────────────────────────────────────────────────

const ACTION_TYPES = {
    play:    { label: 'Play Now',   url: '/' },
    deposit: { label: 'Deposit',    url: '/#deposit' },
    refer:   { label: 'Refer Now',  url: '/#referral' },
    external:{ label: 'Learn More', url: '' }
};

function renderPromotions(promos) {
    const el = document.getElementById('adminContent');
    el.innerHTML = `
        <div class="admin-page-header">
            <div>
                <h1>Promotions Manager</h1>
                <p>Create and manage promotional banners displayed to all players.</p>
            </div>
        </div>
        <div style="background:var(--bg-surface); border:1px solid var(--border); border-radius:var(--radius-md); padding:24px; max-width:680px; margin-bottom:28px;">
            <h3 style="font-size:0.9rem; font-weight:800; margin-bottom:16px;">➕ Create New Promotion</h3>
            <div style="display:flex; flex-direction:column; gap:12px;">
                <input id="promoTitle" class="amount-input" placeholder="Promotion Title (e.g. DAILY FREE BETS!)" style="width:100%; text-align:left;">
                <textarea id="promoDesc" class="amount-input" placeholder="Description / Terms..." rows="3" style="width:100%; text-align:left; resize:vertical;"></textarea>
                <input id="promoImage" class="amount-input" placeholder="Banner Image URL (optional)" style="width:100%; text-align:left;">
                <div style="display:flex; gap:12px; flex-wrap:wrap;">
                    <div style="flex:1; min-width:200px;">
                        <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:4px;">Call-To-Action Button</label>
                        <select id="promoActionType" class="amount-input" style="width:100%; text-align:left; cursor:pointer;" onchange="toggleCustomUrl(this.value)">
                            <option value="play">▶ Play Now → Game Board</option>
                            <option value="deposit">💰 Deposit Now → Wallet</option>
                            <option value="refer">🤝 Refer Now → Referral Tab</option>
                            <option value="external">🔗 Custom External URL</option>
                        </select>
                    </div>
                    <div id="customUrlWrap" style="flex:1; min-width:200px; display:none;">
                        <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:4px;">External URL</label>
                        <input id="promoActionUrl" class="amount-input" placeholder="https://..." style="width:100%; text-align:left;">
                    </div>
                </div>
                <button class="action-btn approve" onclick="submitPromotion()" style="width:auto; align-self:flex-start; height:38px; padding:0 24px; margin:0; border-radius:var(--radius-sm);">
                    PUBLISH PROMOTION
                </button>
            </div>
        </div>
        <div class="section-title" style="margin-left:0; margin-bottom:12px; font-weight:700; font-size:1.1rem; color:var(--text-primary);">Active Promotions (${promos.length})</div>
        <div style="display:flex; flex-direction:column; gap:14px; max-width:680px;">
            ${promos.length === 0
                ? `<div style="color:var(--text-muted); font-size:0.8rem; padding:24px; text-align:center; background:var(--bg-surface); border:1px solid var(--border); border-radius:var(--radius-md);">No promotions yet. Create your first one above.</div>`
                : promos.map(p => `
                <div style="background:var(--bg-surface); border:1px solid var(--border); border-radius:var(--radius-md); overflow:hidden;">
                    ${p.image_url ? `<img src="${p.image_url}" style="width:100%; height:160px; object-fit:cover; display:block;" onerror="this.style.display='none'">` : ''}
                    <div style="padding:16px;">
                        <div style="font-weight:900; font-size:0.95rem; color:var(--text-primary); margin-bottom:6px;">${p.title}</div>
                        <div style="font-size:0.78rem; color:var(--text-muted); margin-bottom:12px;">${p.description || ''}</div>
                        <div style="display:flex; justify-content:space-between; align-items:center;">
                            <span class="status-pill status-approved" style="padding:4px 12px; font-size:0.7rem;">${ACTION_TYPES[p.action_type]?.label || p.action_type || 'Play Now'}</span>
                            <button onclick="deletePromotion('${p.id}')" class="action-btn reject" style="width:auto; padding:5px 14px; font-size:0.7rem; margin:0;">🗑 DELETE</button>
                        </div>
                    </div>
                </div>`).join('')}
        </div>
    `;
}

window.toggleCustomUrl = (val) => {
    document.getElementById('customUrlWrap').style.display = val === 'external' ? 'block' : 'none';
};

window.submitPromotion = async () => {
    const title = document.getElementById('promoTitle').value.trim();
    const description = document.getElementById('promoDesc').value.trim();
    const image_url = document.getElementById('promoImage').value.trim();
    const action_type = document.getElementById('promoActionType').value;
    const customUrl = document.getElementById('promoActionUrl')?.value?.trim();
    const action_url = action_type === 'external' ? customUrl : (ACTION_TYPES[action_type]?.url || '/');
    if (!title) { alert('Please enter a promotion title.'); return; }
    try {
        const { data: { session } } = await supabase.auth.getSession();
        const res = await fetch('/api/admin/content?action=create_promotion', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${session.access_token}` },
            body: JSON.stringify({ title, description, image_url, action_type, action_url })
        });
        const result = await res.json();
        if (result.success) { alert('Promotion published!'); switchTab('promotions'); }
        else alert(`Error: ${result.error}`);
    } catch (e) { alert(`Error: ${e.message}`); }
};

window.deletePromotion = async (id) => {
    if (!confirm('Delete this promotion?')) return;
    try {
        const { data: { session } } = await supabase.auth.getSession();
        const res = await fetch('/api/admin/content?action=delete_promotion', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${session.access_token}` },
            body: JSON.stringify({ id })
        });
        const result = await res.json();
        if (result.success) switchTab('promotions');
        else alert(`Error: ${result.error}`);
    } catch (e) { alert(`Error: ${e.message}`); }
};

// ── NOTIFICATIONS TAB ─────────────────────────────────────────────────────────

function renderNotifications() {
    const el = document.getElementById('adminContent');
    el.innerHTML = `
        <div class="admin-page-header">
            <div>
                <h1>Communications Center</h1>
                <p>Send system notifications to individual users or broadcast to all players.</p>
            </div>
        </div>
        <div style="background:var(--bg-surface); border:1px solid var(--border); border-radius:var(--radius-md); padding:24px; max-width:600px; display:flex; flex-direction:column; gap:16px;">
            <div>
                <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:4px;">Notification Title</label>
                <input id="notifTitle" class="amount-input" placeholder="e.g. Platform Maintenance Scheduled" style="width:100%; text-align:left;">
            </div>
            <div>
                <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:4px;">Message Body</label>
                <textarea id="notifMessage" class="amount-input" placeholder="Enter full notification message..." rows="4" style="width:100%; text-align:left; resize:vertical;"></textarea>
            </div>
            <div>
                <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:4px;">Attach Call-To-Action Link (Optional)</label>
                <div style="display:flex; gap:12px; flex-wrap:wrap;">
                    <div style="flex:1; min-width:200px;">
                        <select id="notifLinkType" class="amount-input" style="width:100%; text-align:left; cursor:pointer;" onchange="window.toggleNotifCustomUrl(this.value)">
                            <option value="">🚫 No Link (Text Only)</option>
                            <option value="play">▶ Play Now → Game Board</option>
                            <option value="deposit">💰 Deposit Now → Wallet</option>
                            <option value="refer">🤝 Refer Now → Referral Tab</option>
                            <option value="external">🔗 Custom External URL</option>
                        </select>
                    </div>
                    <div id="notifCustomUrlWrap" style="flex:1; min-width:200px; display:none;">
                        <input id="notifActionUrl" class="amount-input" placeholder="https://..." style="width:100%; text-align:left;">
                    </div>
                </div>
            </div>
            <div>
                <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:8px;">Target Audience</label>
                <div style="display:flex; gap:18px;">
                    <label style="display:flex; align-items:center; gap:6px; cursor:pointer; color:var(--text-secondary); font-size:0.8rem;">
                        <input type="radio" name="notifTarget" value="broadcast" checked onchange="document.getElementById('notifTargetUser').style.display='none'"> 📢 Broadcast to ALL Users
                    </label>
                    <label style="display:flex; align-items:center; gap:6px; cursor:pointer; color:var(--text-secondary); font-size:0.8rem;">
                        <input type="radio" name="notifTarget" value="targeted" onchange="document.getElementById('notifTargetUser').style.display='block'"> 🎯 Specific User
                    </label>
                </div>
            </div>
            <div id="notifTargetUser" style="display:none;">
                <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:4px;">Target User UUID</label>
                <input id="notifUserId" class="amount-input" placeholder="Paste user UUID here..." style="width:100%; text-align:left;">
            </div>
            <button class="action-btn approve" onclick="sendNotification()" style="width:auto; align-self:flex-start; height:38px; padding:0 28px; margin:0; border-radius:var(--radius-sm);">
                📤 SEND NOTIFICATION
            </button>
        </div>
    `;
}

window.toggleNotifCustomUrl = (val) => {
    document.getElementById('notifCustomUrlWrap').style.display = val === 'external' ? 'block' : 'none';
};

window.sendNotification = async () => {
    const title = document.getElementById('notifTitle').value.trim();
    const message = document.getElementById('notifMessage').value.trim();
    const targetType = document.querySelector('input[name="notifTarget"]:checked')?.value;
    const user_id = targetType === 'targeted' ? document.getElementById('notifUserId')?.value?.trim() : null;
    const linkType = document.getElementById('notifLinkType').value;
    const customUrl = document.getElementById('notifActionUrl')?.value?.trim();

    let action_url = null;
    if (linkType === 'play') action_url = '/';
    else if (linkType === 'deposit') action_url = '/#deposit';
    else if (linkType === 'refer') action_url = '/#referral';
    else if (linkType === 'external') action_url = customUrl;

    if (!title || !message) { alert('Please enter both a title and message.'); return; }
    if (targetType === 'targeted' && !user_id) { alert('Please enter a target User ID.'); return; }
    if (linkType === 'external' && !customUrl) { alert('Please enter a custom destination URL.'); return; }

    const confirmed = targetType === 'broadcast'
        ? confirm('This will send a notification to ALL registered users. Continue?')
        : confirm(`Send this notification to user ${user_id}?`);
    if (!confirmed) return;
    try {
        const { data: { session } } = await supabase.auth.getSession();
        const res = await fetch('/api/admin/content?action=send_notification', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${session.access_token}` },
            body: JSON.stringify({ title, message, user_id, action_url })
        });
        const result = await res.json();
        if (result.success) alert(targetType === 'broadcast' ? '✓ Notification broadcast to all users!' : '✓ Notification sent!');
        else alert(`Error: ${result.error}`);
    } catch (e) { alert(`Error: ${e.message}`); }
};

// ── SUPPORT TAB ───────────────────────────────────────────────────────────────

function renderSupport(settings) {
    const support = settings?.support || {};
    const el = document.getElementById('adminContent');
    el.innerHTML = `
        <div class="admin-page-header">
            <div>
                <h1>Support Contact Settings</h1>
                <p>Update the official support channels visible to users across the platform.</p>
            </div>
        </div>
        <div style="background:var(--bg-surface); border:1px solid var(--border); border-radius:var(--radius-md); padding:24px; max-width:540px; display:flex; flex-direction:column; gap:18px;">
            <div>
                <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:6px;">📞 WhatsApp Support Number</label>
                <input id="supportWhatsapp" class="amount-input" placeholder="+254700000000" value="${support.whatsapp || ''}" style="width:100%; text-align:left;">
                <div style="font-size:0.65rem; color:var(--text-muted); margin-top:4px;">Full number with country code, e.g. +254712345678</div>
            </div>
            <div>
                <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:6px;">✈ Telegram Support Username</label>
                <input id="supportTelegram" class="amount-input" placeholder="metricwin_support" value="${support.telegram_username || ''}" style="width:100%; text-align:left;">
                <div style="font-size:0.65rem; color:var(--text-muted); margin-top:4px;">Without the @, e.g. metricwin_support</div>
            </div>
            <div>
                <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:6px;">✉ Email Support Address</label>
                <input id="supportEmail" class="amount-input" placeholder="support@metricwin.com" value="${support.email || ''}" style="width:100%; text-align:left;">
                <div style="font-size:0.65rem; color:var(--text-muted); margin-top:4px;">Official email support, e.g. support@metricwin.app</div>
            </div>
            <button class="action-btn approve" onclick="saveSupportSettings()" style="width:auto; align-self:flex-start; height:38px; padding:0 28px; margin:0; border-radius:var(--radius-sm);">
                💾 SAVE SUPPORT CONTACTS
            </button>
        </div>
    `;
}

window.saveSupportSettings = async () => {
    const whatsapp = document.getElementById('supportWhatsapp').value.trim();
    const telegram_username = document.getElementById('supportTelegram').value.trim().replace('@', '');
    const email = document.getElementById('supportEmail').value.trim();
    const btn = document.querySelector('[onclick="saveSupportSettings()"]');
    if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }
    try {
        const { data: { session } } = await supabase.auth.getSession();
        const res = await fetch('/api/admin/content?action=update_settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${session.access_token}` },
            body: JSON.stringify({ key: 'support', value: { whatsapp, telegram_username, email } })
        });
        const result = await res.json();
        if (result.success) {
            // Re-fetch fresh settings and re-render the tab
            const freshRes = await fetch('/api/admin/content?action=settings', { headers: { 'Authorization': `Bearer ${session.access_token}` } });
            const freshSettings = await freshRes.json();
            renderSupport(freshSettings);
            // Brief success flash
            const fb = document.createElement('div');
            fb.textContent = '✓ Support contacts saved and refreshed!';
            fb.style.cssText = 'position:fixed;top:20px;right:20px;background:#166534;color:#d1fae5;padding:12px 20px;border-radius:8px;font-weight:700;font-size:0.8rem;z-index:9999;box-shadow:0 4px 16px rgba(0,0,0,0.4);';
            document.body.appendChild(fb);
            setTimeout(() => fb.remove(), 3000);
        } else {
            alert(`Error: ${result.error}`);
            if (btn) { btn.disabled = false; btn.textContent = '💾 SAVE SUPPORT CONTACTS'; }
        }
    } catch (e) {
        alert(`Error: ${e.message}`);
        if (btn) { btn.disabled = false; btn.textContent = '💾 SAVE SUPPORT CONTACTS'; }
    }
};

// ── COMMUNITY TAB ─────────────────────────────────────────────────────────────

function renderCommunity(settings) {
    const community = settings?.community || {};
    const el = document.getElementById('adminContent');
    el.innerHTML = `
        <div class="admin-page-header">
            <div>
                <h1>Community Channel Settings</h1>
                <p>Manage the official community channels visible to all platform users.</p>
            </div>
        </div>
        <div style="background:var(--bg-surface); border:1px solid var(--border); border-radius:var(--radius-md); padding:24px; max-width:540px; display:flex; flex-direction:column; gap:18px;">
            <div>
                <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:6px;">✈ Telegram Channel URL</label>
                <input id="commTelegram" class="amount-input" placeholder="https://t.me/metricwin" value="${community.telegram_channel || ''}" style="width:100%; text-align:left;">
            </div>
            <div>
                <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:6px;">📞 WhatsApp Channel URL</label>
                <input id="commWhatsapp" class="amount-input" placeholder="https://whatsapp.com/channel/..." value="${community.whatsapp_channel || ''}" style="width:100%; text-align:left;">
            </div>
            <button class="action-btn approve" onclick="saveCommunitySettings()" style="width:auto; align-self:flex-start; height:38px; padding:0 28px; margin:0; border-radius:var(--radius-sm);">
                💾 SAVE COMMUNITY LINKS
            </button>
        </div>
    `;
}

window.saveCommunitySettings = async () => {
    const telegram_channel = document.getElementById('commTelegram').value.trim();
    const whatsapp_channel = document.getElementById('commWhatsapp').value.trim();
    const btn = document.querySelector('[onclick="saveCommunitySettings()"]');
    if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }
    try {
        const { data: { session } } = await supabase.auth.getSession();
        const res = await fetch('/api/admin/content?action=update_settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${session.access_token}` },
            body: JSON.stringify({ key: 'community', value: { telegram_channel, whatsapp_channel } })
        });
        const result = await res.json();
        if (result.success) {
            const freshRes = await fetch('/api/admin/content?action=settings', { headers: { 'Authorization': `Bearer ${session.access_token}` } });
            const freshSettings = await freshRes.json();
            renderCommunity(freshSettings);
            const fb = document.createElement('div');
            fb.textContent = '✓ Community links saved and refreshed!';
            fb.style.cssText = 'position:fixed;top:20px;right:20px;background:#166534;color:#d1fae5;padding:12px 20px;border-radius:8px;font-weight:700;font-size:0.8rem;z-index:9999;box-shadow:0 4px 16px rgba(0,0,0,0.4);';
            document.body.appendChild(fb);
            setTimeout(() => fb.remove(), 3000);
        } else {
            alert(`Error: ${result.error}`);
            if (btn) { btn.disabled = false; btn.textContent = '💾 SAVE COMMUNITY LINKS'; }
        }
    } catch (e) {
        alert(`Error: ${e.message}`);
        if (btn) { btn.disabled = false; btn.textContent = '💾 SAVE COMMUNITY LINKS'; }
    }
};

// ── ACTION MUTATORS ─────────────────────────────────────────────────────────

window.submitCrashPointOverride = async () => {
    const inputVal = parseFloat(document.getElementById('nextCrashOverride').value);
    if (isNaN(inputVal) || inputVal < 1.01) {
        alert("Invalid crash point. Must be >= 1.01.");
        return;
    }

    try {
        const { data: { session } } = await supabase.auth.getSession();
        const res = await fetch('/api/admin/actions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${session.access_token}`
            },
            body: JSON.stringify({ action: 'override_crash_point', multiplier: inputVal })
        });
        const result = await res.json();
        
        if (result.success) {
            alert(`Signal set successfully! Next round crash point is locked to ${inputVal}x.`);
        } else {
            alert(`Override failed: ${result.error}`);
        }
    } catch(err) {
        alert(`Error: ${err.message}`);
    }
};

window.submitBalanceAdjustment = async (userId, direction) => {
    const input = document.getElementById(`adjVal_${userId}`);
    const amount = parseFloat(input ? input.value : 0);
    if (isNaN(amount) || amount <= 0) {
        alert("Enter a valid adjustment amount.");
        return;
    }

    const delta = amount * direction;

    try {
        const { data: { session } } = await supabase.auth.getSession();
        const res = await fetch('/api/admin/actions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${session.access_token}`
            },
            body: JSON.stringify({ action: 'adjust_balance', targetUserId: userId, delta })
        });
        const result = await res.json();
        
        if (result.success) {
            alert(`Wallet balance adjusted by KES ${delta.toLocaleString()}.`);
            switchTab(activeTab); // Reload
        } else {
            alert(`Write failed: ${result.error}`);
        }
    } catch (err) {
        alert(`Error Adjusting: ${err.message}`);
    }
};

window.submitToggleFreeze = async (userId, currentFrozen) => {
    const newFrozenState = !currentFrozen;
    const actionName = newFrozenState ? 'freeze_user' : 'unfreeze_user';

    try {
        const { data: { session } } = await supabase.auth.getSession();
        const res = await fetch('/api/admin/actions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${session.access_token}`
            },
            body: JSON.stringify({ action: actionName, targetUserId: userId })
        });
        const result = await res.json();
        
        if (result.success) {
            alert(`User account frozen state successfully updated.`);
            switchTab(activeTab); // Reload
        } else {
            alert(`Operation failed: ${result.error}`);
        }
    } catch (err) {
        alert(`Error operating status: ${err.message}`);
    }
};

window.submitSetRole = async (userId, targetRole) => {
    if (!targetRole) return;
    const confirm = window.confirm(`Are you sure you want to change this operator's role privileges to: ${targetRole}?`);
    if (!confirm) return;

    try {
        const { data: { session } } = await supabase.auth.getSession();
        const res = await fetch('/api/admin/actions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${session.access_token}`
            },
            body: JSON.stringify({ action: 'assign_role', targetUserId: userId, roleName: targetRole })
        });
        const result = await res.json();
        
        if (result.success) {
            alert(`User role assigned successfully.`);
            switchTab(activeTab); // Reload
        } else {
            alert(`Role write failed: ${result.error}`);
        }
    } catch (err) {
        alert(`Network Error: ${err.message}`);
    }
};

window.approveWithdrawal = async (txId) => {
    if (!confirm('Are you sure you want to approve this withdrawal and dispatch funds via M-Pesa?')) return;
    try {
        const { data } = await supabase.auth.getSession();
        const token = data?.session?.access_token || localStorage.getItem('metrowins_auth_token');
        if (!token) {
            alert('Not authenticated. Please log in again.');
            return;
        }
        const res = await fetch('/api/admin/actions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ action: 'approve_withdrawal', transactionId: txId })
        });
        const result = await res.json();
        if (result.success) {
            alert(result.message || 'Withdrawal approved and released successfully!');
            switchTab('ledger');
        } else {
            alert(`Approval failed: ${result.error}`);
        }
    } catch (err) {
        alert(`Network Error: ${err.message}`);
    }
};

window.rejectWithdrawal = async (txId) => {
    const reason = prompt('Please enter the reason for rejecting this withdrawal (funds will be refunded to user):', 'Admin rejected request');
    if (reason === null) return;
    try {
        const { data } = await supabase.auth.getSession();
        const token = data?.session?.access_token || localStorage.getItem('metrowins_auth_token');
        if (!token) {
            alert('Not authenticated. Please log in again.');
            return;
        }
        const res = await fetch('/api/admin/actions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                action: 'reject_withdrawal',
                transactionId: txId,
                reason: reason.trim() || 'Admin rejected request'
            })
        });
        const result = await res.json();
        if (result.success) {
            alert(result.message || 'Withdrawal rejected and funds refunded to user.');
            switchTab('ledger');
        } else {
            alert(`Rejection failed: ${result.error}`);
        }
    } catch (err) {
        alert(`Network Error: ${err.message}`);
    }
};

window.toggleMaintenance = async () => {
    const confirm = prompt("DANGER: This will lock the platform for all standard users. Type 'CONFIRM' to proceed:");
    if (confirm !== 'CONFIRM') return;
    alert("Maintenance Mode Activated System-Wide.");
};

window.runUserDiagnostics = async () => {
    const resultsBox = document.getElementById('diagnosticResults');
    if (!resultsBox) return;
    resultsBox.style.display = 'block';
    resultsBox.innerHTML = 'Running analytical scans on database schemas...';
    try {
        const { data: { session } } = await supabase.auth.getSession();
        if (!session) { resultsBox.innerHTML = `<span style="color:var(--error)">ERROR: Not authenticated. Please refresh the page.</span>`; return; }
        const headers = { 'Authorization': `Bearer ${session.access_token}` };
        const res = await fetch('/api/admin/system?action=diagnose_users', { headers });
        const data = await res.json();
        if (data.error) { resultsBox.innerHTML = `<span style="color:var(--error)">ERROR: ${data.error}</span>`; return; }
        if (!data.missing || data.missing.length === 0) {
            resultsBox.innerHTML = `<span style="color:var(--success)">✓ INTEGRITY CHECK PASSED: Auth users (${data.auth_count}) match Public profiles (${data.profile_count}).</span>`;
        } else {
            resultsBox.innerHTML = `<span style="color:var(--warning)">⚠ ${data.missing.length} users missing profile entries.</span><br><br>` +
                data.missing.map(m => `• ${m.email || 'No Email'} (${m.phone || 'No Phone'}) | ID: ${m.id}`).join('<br>');
        }
    } catch (e) {
        resultsBox.innerHTML = `<span style="color:var(--error)">RUN FAILURE: ${e.message}</span>`;
    }
};

window.runUserRepair = async () => {
    const resultsBox = document.getElementById('diagnosticResults');
    if (!resultsBox) return;
    resultsBox.style.display = 'block';
    resultsBox.innerHTML = 'Executing registry healing procedures...';

    try {
        const { data: { session } } = await supabase.auth.getSession();
        const headers = { 'Authorization': `Bearer ${session.access_token}` };
        
        const res = await fetch('/api/admin/system?action=repair_users', { headers });
        const data = await res.json();
        
        if (data.error) {
            resultsBox.innerHTML = `<span style="color:var(--error)">ERROR: ${data.error}</span>`;
            return;
        }

        resultsBox.innerHTML = `<span style="color:var(--success)">HEALING PROCESS COMPLETE. Successfully rebuilt/synced ${data.repaired?.length || 0} user profiles in DB.</span>`;
        if (data.repaired && data.repaired.length > 0) {
            resultsBox.innerHTML += `<br><br>` + data.repaired.map(r => `✓ Reconstructed: ${r.username} (${r.phone})`).join('<br>');
        }
    } catch (e) {
        resultsBox.innerHTML = `<span style="color:var(--error)">RUN FAILURE: ${e.message}</span>`;
    }
};
