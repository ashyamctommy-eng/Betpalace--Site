/**
 * backend/server.js
 *
 * MetroWins Standalone Backend Server (Zero Supabase).
 * Powered by Node.js, Express, PostgreSQL, and WebSockets.
 * Optimized for Render and Linux VPS.
 */

import express from 'express';
import http from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();

// Handlers
import authHandler from './api/auth.js';
import gameHandler from './api/game.js';
import walletHandler from './api/wallet.js';
import depositHandler from './api/deposit.js';
import depositCallbackHandler from './api/deposit-callback.js';
import withdrawHandler from './api/withdraw.js';
import withdrawCallbackHandler from './api/withdraw-callback.js';
import signalHandler from './api/signal.js';
import claimPromoHandler from './api/claim-promo.js';
import sendEmailHandler from './api/send-email.js';
import setupAdminHandler from './api/setup-admin.js';
import otpHandler from './api/otp.js';
import adminHandler from './api/admin.js';
import sportsHandler from './api/sports.js';

// Admin subhandlers
import systemHandler from './api/_admin/system.js';
import contentHandler from './api/_admin/content.js';
import promocodesHandler from './api/_admin/promocodes.js';
import actionsHandler from './api/_admin/actions.js';

// Database & CORS
import { query } from './api/_lib/db.js';
import { isOriginAllowed, getAllowedOrigins } from './api/_lib/cors.js';
import { verifyAuthToken, ensureSuperAdmin, ensureAdmin } from './api/_lib/auth.js';

const app = express();
const server = http.createServer(app);
const PORT = process.env.PORT || 3000;

app.set('trust proxy', 1);

// ── 1. CORS Configuration ─────────────────────────────────────────────────────
const allowedOrigins = getAllowedOrigins();
app.use(cors({
    origin: (origin, callback) => {
        if (!origin || isOriginAllowed(origin)) {
            callback(null, true);
        } else {
            console.warn(`[CORS] Rejected origin: ${origin}`);
            callback(new Error(`CORS origin not allowed: ${origin}`));
        }
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'x-palpluss-signature', 'x-signature']
}));

// ── 2. Request Parsing with rawBody ───────────────────────────────────────────
app.use(express.json({
    limit: '2mb',
    verify: (req, _res, buf) => {
        req.rawBody = buf.toString();
    }
}));
app.use(express.urlencoded({ extended: true, limit: '2mb' }));

// ── 3. Health & Telemetry ─────────────────────────────────────────────────────
app.get('/health', async (_req, res) => {
    let dbStatus = 'disconnected';
    try {
        await query('SELECT 1');
        dbStatus = 'connected';
    } catch (_) {}

    res.status(200).json({
        status: 'ok',
        database: dbStatus,
        uptime: Math.floor(process.uptime()),
        timestamp: new Date().toISOString(),
        environment: process.env.NODE_ENV || 'production'
    });
});

app.get('/', (_req, res) => {
    res.status(200).json({
        name: 'MetroWins Backend API',
        status: 'operational',
        version: '2.0.0',
        architecture: 'PostgreSQL + Express (Zero Supabase)',
        healthCheck: '/health'
    });
});

// ── 4. Webhooks ───────────────────────────────────────────────────────────────
app.post('/webhooks/mpesa', depositCallbackHandler);
app.post('/webhooks/stk', depositCallbackHandler);
app.post('/webhooks/b2c', withdrawCallbackHandler);

// ── 5. Primary API Routers ────────────────────────────────────────────────────
app.use('/api/auth', authHandler);
app.use('/api/game', gameHandler);
app.use('/api/wallet', walletHandler);
app.use('/api/sports', sportsHandler);

app.all('/api/deposit', depositHandler);
app.all('/api/deposit-callback', depositCallbackHandler);
app.all('/api/withdraw', withdrawHandler);
app.all('/api/withdraw-callback', withdrawCallbackHandler);
app.all('/api/signal', signalHandler);
app.all('/api/claim-promo', claimPromoHandler);
app.all('/api/send-email', sendEmailHandler);
app.all('/api/setup-admin', setupAdminHandler);
app.all('/api/otp', otpHandler);

// Admin Routes
app.all('/api/admin/system', (req, res) => { req.query.route = 'system'; return systemHandler(req, res); });
app.all('/api/admin/content', (req, res) => { req.query.route = 'content'; return contentHandler(req, res); });
app.all('/api/admin/promocodes', (req, res) => { req.query.route = 'promocodes'; return promocodesHandler(req, res); });
app.all('/api/admin/actions', (req, res) => { req.query.route = 'actions'; return actionsHandler(req, res); });
app.all('/api/admin', adminHandler);

// ── 6. Generic RPC Bridge for Frontend Compatibility ─────────────────────────
app.post('/api/rpc/:fn', async (req, res) => {
    const fn = req.params.fn;
    const body = req.body || {};

    try {
        if (fn === 'sync_and_get_game_state') {
            const { rows } = await query('SELECT sync_and_get_game_state() AS result');
            return res.status(200).json(rows[0]?.result);
        }

        if (fn === 'place_bet') {
            const auth = await verifyAuthToken(req);
            if (!auth.success) return res.status(auth.status).json({ success: false, error: auth.error });
            const { round_id, p_round_id, amount, p_amount, auto_cashout, p_auto_cashout } = body;
            const rId = round_id || p_round_id || 0;
            const amt = amount || p_amount;
            const autoC = auto_cashout || p_auto_cashout || null;
            const { rows } = await query('SELECT place_bet($1, $2, $3, $4) AS result', [auth.user.id, rId, amt, autoC]);
            return res.status(200).json(rows[0]?.result);
        }

        if (fn === 'cash_out') {
            const auth = await verifyAuthToken(req);
            if (!auth.success) return res.status(auth.status).json({ success: false, error: auth.error });
            const { bet_id, p_bet_id, multiplier, p_multiplier } = body;
            const bId = bet_id || p_bet_id;
            const mult = multiplier || p_multiplier;
            const { rows } = await query('SELECT cash_out($1, $2, $3) AS result', [auth.user.id, bId, mult]);
            return res.status(200).json(rows[0]?.result);
        }

        if (fn === 'cancel_bet') {
            const auth = await verifyAuthToken(req);
            if (!auth.success) return res.status(auth.status).json({ success: false, error: auth.error });
            const { bet_id, p_bet_id } = body;
            const bId = bet_id || p_bet_id;
            const { rows } = await query('SELECT cancel_bet($1, $2) AS result', [auth.user.id, bId]);
            return res.status(200).json(rows[0]?.result);
        }

        if (fn === 'has_permission') {
            const auth = await verifyAuthToken(req);
            if (!auth.success) return res.status(auth.status).json(false);
            if (auth.user.role === 'Super Admin') return res.status(200).json(true);
            const perm = body.p_permission || body.permission;
            const { rows } = await query('SELECT has_permission($1, $2) AS allowed', [auth.user.id, perm]);
            return res.status(200).json(rows[0]?.allowed === true);
        }

        return res.status(404).json({ error: `Unsupported RPC function: ${fn}` });
    } catch (err) {
        console.error(`[RPC Error: ${fn}]:`, err.message);
        return res.status(500).json({ error: err.message });
    }
});

// ── 7. 404 & Error Handlers ───────────────────────────────────────────────────
app.use((_req, res) => {
    res.status(404).json({ error: 'Not Found', message: 'Endpoint does not exist.' });
});

app.use((err, _req, res, _next) => {
    console.error('[Server Error]:', err);
    res.status(err.status || 500).json({ success: false, error: err.message || 'Internal Server Error' });
});

// ── 8. Real-Time WebSockets Server (Zero Supabase Realtime) ───────────────────
const wss = new WebSocketServer({ server, path: '/ws' });

let latestGameState = null;

wss.on('connection', (ws) => {
    // Send immediate current state upon connection
    if (latestGameState) {
        ws.send(JSON.stringify({ type: 'game_state', data: latestGameState }));
    }

    ws.on('message', (msg) => {
        try {
            const data = JSON.parse(msg.toString());
            if (data.type === 'ping') {
                ws.send(JSON.stringify({ type: 'pong', timestamp: Date.now() }));
            }
        } catch (_) {}
    });
});

// Broadcast game loop ticks to all connected WebSocket clients
async function broadcastGameTick() {
    try {
        const { rows } = await query('SELECT sync_and_get_game_state() AS state');
        const state = rows[0]?.state;
        if (state) {
            latestGameState = state;
            const payload = JSON.stringify({ type: 'game_state', data: state });
            wss.clients.forEach((client) => {
                if (client.readyState === WebSocket.OPEN) {
                    client.send(payload);
                }
            });
        }
    } catch (_) {}
}

// Tick loop every 300ms
setInterval(broadcastGameTick, 300);

// ── 9. Start Server ───────────────────────────────────────────────────────────
server.listen(PORT, '0.0.0.0', () => {
    console.log(`[MetroWins Backend] Running on http://0.0.0.0:${PORT}`);
    console.log(`[MetroWins Backend] WebSockets live on ws://0.0.0.0:${PORT}/ws`);
    console.log(`[MetroWins Backend] Allowed Origins: ${allowedOrigins.join(', ')}`);
    ensureSuperAdmin().catch(err => console.warn('[Super Admin Init Warning]:', err.message));
    ensureAdmin().catch(err => console.warn('[Admin Init Warning]:', err.message));
});

const shutdown = (signal) => {
    console.log(`[MetroWins Backend] ${signal} received. Closing gracefully...`);
    wss.close();
    server.close(() => {
        console.log('[MetroWins Backend] Closed.');
        process.exit(0);
    });
};

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

export default app;
