/**
 * src/config/platform.js
 * Centralized Platform Configuration fetched from environment variables
 */

export const PLATFORM_NAME = 
    (typeof import.meta !== 'undefined' && import.meta.env && (import.meta.env.VITE_PLATFORM_NAME || import.meta.env.VITE_APP_NAME)) 
    || (typeof window !== 'undefined' && window.__PLATFORM_NAME__)
    || 'Betplace';

if (typeof window !== 'undefined') {
    window.__PLATFORM_NAME__ = PLATFORM_NAME;
}

/**
 * Injects platform name into all elements with data-brand-name attribute or .brand-name class
 */
export function initPlatformBranding() {
    if (typeof document === 'undefined') return;
    
    // Update title if it contains brand placeholder
    if (document.title.includes('Metricwin') || document.title.includes('Betplace')) {
        document.title = document.title.replace(/Metricwin|Betplace/gi, PLATFORM_NAME);
    }
    
    document.querySelectorAll('[data-brand-name], .brand-name, .sb-brand span, #authBrandName').forEach(el => {
        el.textContent = PLATFORM_NAME;
    });
}
