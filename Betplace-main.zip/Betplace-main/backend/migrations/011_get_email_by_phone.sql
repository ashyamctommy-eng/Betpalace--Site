-- ══════════════════════════════════════════════
-- MIGRATION 011: Public Guest RPC to resolve email by phone
-- ══════════════════════════════════════════════

-- Create RPC to look up registration email by phone number safely
-- Runs with SECURITY DEFINER to bypass client RLS lookup limits for guest logins
CREATE OR REPLACE FUNCTION public.get_email_by_phone(p_phone TEXT)
RETURNS TEXT AS $$
DECLARE
    v_email TEXT;
    v_search_phone TEXT;
BEGIN
    v_search_phone := regexp_replace(p_phone, '\D', '', 'g');
    
    SELECT email INTO v_email
    FROM public.profiles
    WHERE regexp_replace(phone, '\D', '', 'g') = v_search_phone
    LIMIT 1;
    
    RETURN v_email;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
