-- ═══════════════════════════════════════════════════════════════
-- MetricWin Security & Game Engine Hardening Migration
-- Run this in Supabase SQL Editor (Dashboard → SQL Editor)
-- ═══════════════════════════════════════════════════════════════

SET lock_timeout = '10s';

-- ──────────────────────────────────────────────────────────────
-- 0. ENSURE TRANSACTION COLUMNS EXIST
-- ──────────────────────────────────────────────────────────────
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS description TEXT;
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS reference TEXT;
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS phone TEXT;
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS rejection_reason TEXT;

-- ──────────────────────────────────────────────────────────────
-- 1. HARDENED cash_out RPC
-- ──────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION public.cash_out(p_bet_id UUID, p_multiplier DECIMAL)
RETURNS JSON
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_user_id               UUID;
    v_bet_amount            DECIMAL;
    v_bet_round_id          BIGINT;
    v_winnings              DECIMAL;
    v_bet_status            TEXT;

    v_current_round_id      BIGINT;
    v_round_status          TEXT;
    v_crash_point           DECIMAL;
    v_start_time            TIMESTAMPTZ;
    v_elapsed_sec           DECIMAL;
    v_calculated_multiplier DECIMAL;
    v_actual_multiplier     DECIMAL;
BEGIN
    v_user_id := auth.uid();
    IF v_user_id IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Unauthorized');
    END IF;

    SELECT amount, status, round_id
    INTO   v_bet_amount, v_bet_status, v_bet_round_id
    FROM   public.bets
    WHERE  id = p_bet_id AND user_id = v_user_id;

    IF v_bet_amount IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Bet not found');
    END IF;

    IF v_bet_status != 'playing' THEN
        RETURN json_build_object('success', false, 'error', 'Bet already finalised');
    END IF;

    SELECT round_id, status, crash_point, start_time
    INTO   v_current_round_id, v_round_status, v_crash_point, v_start_time
    FROM   public.active_game_state
    WHERE  id = 1;

    IF v_bet_round_id != v_current_round_id THEN
        RETURN json_build_object('success', false, 'error', 'Bet is not for current active round');
    END IF;

    IF v_round_status != 'playing' THEN
        RETURN json_build_object('success', false, 'error', 'Round is not in playing phase');
    END IF;

    v_elapsed_sec := GREATEST(0, EXTRACT(EPOCH FROM (now() - v_start_time)));
    v_calculated_multiplier := round(power(1.06, v_elapsed_sec)::DECIMAL, 2);

    -- Calculate awarded multiplier cleanly: cap at server flight height to prevent cheating,
    -- but allow client requested multiplier if within tolerance so latency never rejects a valid cashout.
    IF p_multiplier <= (v_calculated_multiplier + 0.15) THEN
        v_actual_multiplier := LEAST(p_multiplier, v_calculated_multiplier);
    ELSE
        v_actual_multiplier := v_calculated_multiplier;
    END IF;

    IF v_actual_multiplier >= v_crash_point THEN
        UPDATE public.bets SET status = 'lost' WHERE id = p_bet_id;
        RETURN json_build_object('success', false, 'error', 'Round crashed before cashout');
    END IF;

    IF v_actual_multiplier < 1.00 THEN
        v_actual_multiplier := 1.00;
    END IF;

    v_winnings := round(v_bet_amount * v_actual_multiplier, 2);

    UPDATE public.bets
    SET    status = 'won', multiplier_cashed = v_actual_multiplier, winnings = v_winnings
    WHERE  id = p_bet_id AND status = 'playing';

    UPDATE public.profiles
    SET    balance = balance + v_winnings
    WHERE  id = v_user_id;

    INSERT INTO public.transactions (user_id, type, amount, status, description)
    VALUES (v_user_id, 'win', v_winnings, 'completed', 'Aviator cashout win @ ' || v_actual_multiplier || 'x');

    RETURN json_build_object(
        'success', true, 
        'winnings', v_winnings, 
        'multiplier', v_actual_multiplier,
        'new_balance', (SELECT balance FROM public.profiles WHERE id = v_user_id)
    );
END;
$$ LANGUAGE plpgsql;

GRANT EXECUTE ON FUNCTION public.cash_out(UUID, DECIMAL) TO authenticated;


-- ──────────────────────────────────────────────────────────────
-- 2. HARDENED cancel_bet RPC
-- ──────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION public.cancel_bet(p_bet_id UUID)
RETURNS JSON
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_user_id      UUID;
    v_bet_amount   DECIMAL;
    v_bet_round_id BIGINT;
    v_bet_status   TEXT;
    v_game_status  TEXT;
    v_is_free_bet  BOOLEAN;
BEGIN
    v_user_id := auth.uid();
    IF v_user_id IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Unauthorized');
    END IF;

    SELECT amount, round_id, status, is_free_bet
    INTO   v_bet_amount, v_bet_round_id, v_bet_status, v_is_free_bet
    FROM   public.bets
    WHERE  id = p_bet_id AND user_id = v_user_id;

    IF v_bet_amount IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Bet not found');
    END IF;

    IF v_bet_status != 'playing' THEN
        RETURN json_build_object('success', false, 'error', 'Bet cannot be cancelled');
    END IF;

    SELECT status INTO v_game_status FROM public.active_game_state WHERE id = 1;
    IF v_game_status != 'waiting' AND v_bet_round_id <= (SELECT round_id FROM public.active_game_state WHERE id = 1) THEN
        RETURN json_build_object('success', false, 'error', 'Cannot cancel bet after round has started');
    END IF;

    DELETE FROM public.bets WHERE id = p_bet_id AND user_id = v_user_id;

    IF NOT COALESCE(v_is_free_bet, false) AND v_bet_amount > 0 THEN
        UPDATE public.profiles
        SET    balance = balance + v_bet_amount
        WHERE  id = v_user_id;
    END IF;

    RETURN json_build_object(
        'success', true, 
        'refunded', v_bet_amount,
        'new_balance', (SELECT balance FROM public.profiles WHERE id = v_user_id)
    );
END;
$$ LANGUAGE plpgsql;

GRANT EXECUTE ON FUNCTION public.cancel_bet(UUID) TO authenticated;


-- ──────────────────────────────────────────────────────────────
-- 3. HARDENED place_bet RPC
-- ──────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION public.place_bet(
    p_round_id BIGINT, 
    p_amount DECIMAL, 
    p_use_free_bet BOOLEAN DEFAULT FALSE
)
RETURNS JSON
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_user_id      UUID;
    v_balance      DECIMAL;
    v_is_frozen    BOOLEAN;
    v_bet_id       UUID;
    v_game_round   BIGINT;
    v_game_status  TEXT;
    v_target_round BIGINT;
BEGIN
    v_user_id := auth.uid();
    IF v_user_id IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Unauthorized');
    END IF;

    IF p_amount < 50 THEN
        RETURN json_build_object('success', false, 'error', 'Minimum stake is KES 50');
    END IF;

    SELECT balance, COALESCE(is_frozen, FALSE)
    INTO   v_balance, v_is_frozen
    FROM   public.profiles
    WHERE  id = v_user_id;

    IF v_is_frozen THEN
        RETURN json_build_object('success', false, 'error', 'Your account is frozen. Contact support.');
    END IF;

    IF v_balance < p_amount THEN
        RETURN json_build_object('success', false, 'error', 'Insufficient balance');
    END IF;

    SELECT round_id, status
    INTO   v_game_round, v_game_status
    FROM   public.active_game_state
    WHERE  id = 1;

    v_target_round := p_round_id;
    IF v_target_round IS NULL OR v_target_round <= 0 OR v_target_round < v_game_round THEN
        IF v_game_status = 'waiting' THEN
            v_target_round := v_game_round;
        ELSE
            v_target_round := v_game_round + 1;
        END IF;
    ELSIF v_target_round > (v_game_round + 1) THEN
        v_target_round := v_game_round + 1;
    END IF;

    UPDATE public.profiles
    SET    balance = balance - p_amount
    WHERE  id = v_user_id;

    INSERT INTO public.bets (user_id, round_id, amount, is_free_bet)
    VALUES (v_user_id, v_target_round, p_amount, p_use_free_bet)
    RETURNING id INTO v_bet_id;

    RETURN json_build_object(
        'success', true, 
        'bet_id', v_bet_id, 
        'round_id', v_target_round,
        'new_balance', v_balance - p_amount
    );
END;
$$ LANGUAGE plpgsql;

GRANT EXECUTE ON FUNCTION public.place_bet(BIGINT, DECIMAL, BOOLEAN) TO authenticated;


-- ──────────────────────────────────────────────────────────────
-- 4. LOCK DOWN RLS
-- ──────────────────────────────────────────────────────────────
REVOKE EXECUTE ON FUNCTION public.cash_out(UUID, DECIMAL)         FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.cancel_bet(UUID)                FROM anon, public;
REVOKE EXECUTE ON FUNCTION public.place_bet(BIGINT, DECIMAL, BOOLEAN) FROM anon, public;


-- ──────────────────────────────────────────────────────────────
-- 5. PROFILES RLS
-- ──────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update own safe fields" ON public.profiles;
CREATE POLICY "Users can update own safe fields"
ON public.profiles
FOR UPDATE
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);


-- ──────────────────────────────────────────────────────────────
-- 6. TRANSACTIONS RLS
-- ──────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "Users can insert transactions" ON public.transactions;
DROP POLICY IF EXISTS "Users can update transactions" ON public.transactions;


-- ──────────────────────────────────────────────────────────────
-- 7. BETS RLS
-- ──────────────────────────────────────────────────────────────
DROP POLICY IF EXISTS "Users can insert bets"  ON public.bets;
DROP POLICY IF EXISTS "Users can update bets"  ON public.bets;
DROP POLICY IF EXISTS "Users can delete bets"  ON public.bets;


-- ──────────────────────────────────────────────────────────────
-- 8. SERVER-AUTHORITATIVE GAME STATE TICKER (DEADLOCK-FREE)
-- ──────────────────────────────────────────────────────────────
INSERT INTO public.active_game_state (id, round_id, start_time, crash_point, status, server_time)
VALUES (1, 1, now(), 2.50, 'waiting', now())
ON CONFLICT (id) DO UPDATE SET
  status = CASE WHEN public.active_game_state.status IS NULL THEN 'waiting' ELSE public.active_game_state.status END;

CREATE OR REPLACE FUNCTION public.sync_and_get_game_state()
RETURNS JSON AS $$
DECLARE
    v_state              RECORD;
    v_now                TIMESTAMPTZ;
    v_elapsed            INT;
    v_needs_update       BOOLEAN := false;
    v_status             TEXT;
    v_round_id           BIGINT;
    v_crash_point        DECIMAL;
    v_start_time         TIMESTAMPTZ;
    v_waiting_ms         INT := 5000;
    v_max_flight_ms      INT := 300000;
    v_post_crash_ms      INT := 1200;
    v_elapsed_sec        DECIMAL;
    v_calc_mult          DECIMAL;
    v_random             DECIMAL;
    v_new_crash_point    DECIMAL;
    v_instant_crash_rate DECIMAL := 0.03;
    v_total_bets         DECIMAL := 0;
    v_high_bet_limit     DECIMAL := 100000;
    v_extreme_bet_limit  DECIMAL := 500000;
    v_dynamic_mode       BOOLEAN := true;
    v_history_json       JSONB;
BEGIN
    v_now := now();

    SELECT * INTO v_state FROM public.active_game_state WHERE id = 1 LIMIT 1;

    IF v_state IS NULL THEN
        INSERT INTO public.active_game_state (id, round_id, start_time, crash_point, status, server_time)
        VALUES (1, 1, v_now, 2.50, 'waiting', v_now)
        ON CONFLICT (id) DO NOTHING;

        SELECT * INTO v_state FROM public.active_game_state WHERE id = 1 LIMIT 1;
    END IF;

    IF v_dynamic_mode AND v_state IS NOT NULL THEN
        SELECT COALESCE(SUM(amount), 0) INTO v_total_bets
        FROM public.bets
        WHERE round_id = v_state.round_id;
    END IF;

    SELECT * INTO v_state FROM public.active_game_state WHERE id = 1 LIMIT 1 FOR UPDATE;

    v_status      := v_state.status;
    v_round_id    := v_state.round_id;
    v_crash_point := v_state.crash_point;
    v_start_time  := v_state.start_time;

    v_elapsed := EXTRACT(EPOCH FROM (v_now - v_start_time)) * 1000;

    IF v_status = 'waiting' THEN
        IF v_elapsed >= v_waiting_ms THEN
            v_status     := 'playing';
            v_start_time := v_now;
            v_elapsed    := 0;

            IF v_dynamic_mode THEN
                IF v_total_bets >= v_extreme_bet_limit THEN
                    IF random() < 0.85 THEN
                        v_crash_point := round(1.00 + (random() * 0.19), 2);
                    ELSE
                        v_crash_point := 1.00;
                    END IF;
                ELSIF v_total_bets >= v_high_bet_limit THEN
                    IF random() < 0.70 THEN
                        v_crash_point := round(1.01 + (random() * 0.79), 2);
                    END IF;
                END IF;
            END IF;

            v_needs_update := true;
        END IF;

    ELSIF v_status = 'playing' THEN
        IF v_elapsed >= v_max_flight_ms THEN
            v_calc_mult := v_crash_point;
        ELSE
            v_elapsed_sec := v_elapsed::DECIMAL / 1000.0;
            v_calc_mult   := power(1.06, v_elapsed_sec);
        END IF;

        IF v_calc_mult >= v_crash_point OR v_elapsed >= v_max_flight_ms THEN
            INSERT INTO public.game_history (multiplier, round_id)
            VALUES (v_crash_point, v_round_id)
            ON CONFLICT (round_id) DO NOTHING;

            DELETE FROM public.game_history
            WHERE id NOT IN (
                SELECT id FROM public.game_history ORDER BY id DESC LIMIT 200
            );

            v_status     := 'crashed';
            v_start_time := v_now;
            v_elapsed    := 0;
            v_needs_update := true;
        END IF;

    ELSIF v_status = 'crashed' THEN
        IF v_elapsed >= v_post_crash_ms THEN
            v_status   := 'waiting';
            v_round_id := v_round_id + 1;
            v_start_time := v_now;
            v_elapsed  := 0;

            IF v_state.next_crash_point IS NOT NULL AND v_state.next_crash_point > 1.00 THEN
                v_new_crash_point := v_state.next_crash_point;
            ELSE
                v_random := random();
                IF v_random < v_instant_crash_rate THEN
                    v_new_crash_point := 1.00;
                ELSIF v_random < 0.40 THEN
                    v_new_crash_point := 1.01 + (random() * 0.79);
                ELSIF v_random < 0.80 THEN
                    v_new_crash_point := 1.80 + (random() * 5.20);
                ELSIF v_random < 0.95 THEN
                    v_new_crash_point := 7.00 + (random() * 18.00);
                ELSE
                    v_new_crash_point := 25.00 + (random() * 175.00);
                END IF;
            END IF;

            v_crash_point  := round(v_new_crash_point, 2);
            v_needs_update := true;
        END IF;
    END IF;

    SELECT COALESCE(
        json_agg(multiplier ORDER BY id DESC)::jsonb,
        '[]'::jsonb
    ) INTO v_history_json
    FROM (
        SELECT id, multiplier FROM public.game_history ORDER BY id DESC LIMIT 20
    ) sub;

    IF v_needs_update THEN
        UPDATE public.active_game_state
        SET status      = v_status,
            round_id    = v_round_id,
            crash_point = v_crash_point,
            start_time  = v_start_time,
            server_time = v_now,
            history     = v_history_json,
            next_crash_point = CASE
                WHEN v_status = 'waiting' THEN NULL
                ELSE next_crash_point
            END
        WHERE id = 1;
    ELSE
        UPDATE public.active_game_state
        SET server_time = v_now
        WHERE id = 1;
    END IF;

    RETURN json_build_object(
        'roundId',        v_round_id,
        'round_id',       v_round_id,
        'roundStartTime', EXTRACT(EPOCH FROM v_start_time) * 1000,
        'start_time',     v_start_time,
        'crashPoint',     v_crash_point,
        'crash_point',    v_crash_point,
        'gameStatus',     v_status,
        'status',         v_status,
        'serverTime',     EXTRACT(EPOCH FROM v_now) * 1000,
        'server_time',    EXTRACT(EPOCH FROM v_now) * 1000,
        'elapsedMs',      v_elapsed,
        'history',        v_history_json
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION public.sync_and_get_game_state() TO authenticated, anon;

NOTIFY pgrst, 'reload schema';
