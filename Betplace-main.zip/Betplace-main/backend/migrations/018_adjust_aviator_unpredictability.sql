-- Migration: 018_adjust_aviator_unpredictability.sql
-- Configure settings and adjust game loop RPC to introduce unpredictable house edge and dynamic bet-based caps on game multipliers.

-- 1. Initialize config in system settings
INSERT INTO public.system_settings (key, value)
VALUES (
    'aviator_config',
    '{"instant_crash_rate": 0.12, "dynamic_mode": true, "high_bet_limit": 1000.00, "extreme_bet_limit": 2500.00}'
)
ON CONFLICT (key) DO NOTHING;

-- 2. Modify game state loop function
CREATE OR REPLACE FUNCTION public.sync_and_get_game_state()
RETURNS JSON AS $$
DECLARE
    v_state RECORD;
    v_now TIMESTAMPTZ;
    v_elapsed INT;
    v_needs_update BOOLEAN := false;
    v_status TEXT;
    v_round_id BIGINT;
    v_crash_point DECIMAL;
    v_start_time TIMESTAMPTZ;
    v_waiting_ms INT := 5000;
    v_max_flight_ms INT := 300000;
    v_post_crash_ms INT := 3000;
    v_elapsed_sec DECIMAL;
    v_calc_mult DECIMAL;
    v_random DECIMAL;
    v_new_crash_point DECIMAL;
    
    -- Config & dynamics
    v_config JSONB;
    v_instant_crash_rate DECIMAL := 0.12; -- default 12% instant crash rate
    v_dynamic_mode BOOLEAN := true;
    v_high_bet_limit DECIMAL := 1000.00;
    v_extreme_bet_limit DECIMAL := 2500.00;
    v_total_bets DECIMAL := 0.00;
BEGIN
    v_now := now();
    
    -- Read config
    SELECT value INTO v_config FROM public.system_settings WHERE key = 'aviator_config' LIMIT 1;
    IF v_config IS NOT NULL THEN
        v_instant_crash_rate := COALESCE((v_config->>'instant_crash_rate')::DECIMAL, 0.12);
        v_dynamic_mode       := COALESCE((v_config->>'dynamic_mode')::BOOLEAN, true);
        v_high_bet_limit     := COALESCE((v_config->>'high_bet_limit')::DECIMAL, 1000.00);
        v_extreme_bet_limit  := COALESCE((v_config->>'extreme_bet_limit')::DECIMAL, 2500.00);
    END IF;

    -- Get current state
    SELECT * INTO v_state FROM public.active_game_state WHERE id = 1 LIMIT 1;
    
    -- If no row exists, initialize it
    IF v_state IS NULL THEN
        INSERT INTO public.active_game_state (id, round_id, start_time, crash_point, status, server_time)
        VALUES (1, 1, v_now, 1.50, 'waiting', v_now)
        RETURNING * INTO v_state;
    END IF;

    v_status := v_state.status;
    v_round_id := v_state.round_id;
    v_crash_point := v_state.crash_point;
    v_start_time := v_state.start_time;

    -- Calculate elapsed milliseconds since last phase transition
    v_elapsed := EXTRACT(EPOCH FROM (v_now - v_start_time)) * 1000;

    -- Phase advance logic
    IF v_status = 'waiting' THEN
        IF v_elapsed >= v_waiting_ms THEN
            v_status := 'playing';
            v_start_time := v_now;
            v_elapsed := 0;
            v_needs_update := true;
            
            -- Dynamic bet-based capping (prevent high wins on large stakes)
            IF v_dynamic_mode THEN
                SELECT COALESCE(SUM(amount), 0) INTO v_total_bets 
                FROM public.bets 
                WHERE round_id = v_round_id;
                
                IF v_total_bets >= v_extreme_bet_limit THEN
                    -- Extreme stakes: Force instant crash (1.00) or under 1.10
                    IF random() < 0.90 THEN
                        v_crash_point := round(1.00 + (random() * 0.09), 2);
                    ELSE
                        v_crash_point := 1.00;
                    END IF;
                ELSIF v_total_bets >= v_high_bet_limit THEN
                    -- High stakes: Crash early (under 1.35)
                    IF random() < 0.85 THEN
                        v_crash_point := round(1.01 + (random() * 0.34), 2);
                    END IF;
                ELSIF v_total_bets > 0.00 THEN
                    -- Any bet placed: 25% chance of crash compression in play phase
                    IF random() < 0.25 AND v_crash_point > 2.00 THEN
                        v_crash_point := round(1.05 + (random() * 0.95), 2);
                    END IF;
                END IF;
            END IF;
        END IF;
    ELSIF v_status = 'playing' THEN
        -- Multiplier growth mapping: 1.06^seconds
        v_elapsed_sec := v_elapsed::DECIMAL / 1000.0;
        v_calc_mult := power(1.06, v_elapsed_sec);
        
        IF v_calc_mult >= v_crash_point OR v_elapsed >= v_max_flight_ms THEN
            v_status := 'crashed';
            v_start_time := v_now;
            v_elapsed := 0;
            v_needs_update := true;
        END IF;
    ELSIF v_status = 'crashed' THEN
        IF v_elapsed >= v_post_crash_ms + 2000 THEN -- Add 2s flight buffer
            v_status := 'waiting';
            v_round_id := v_round_id + 1;
            v_start_time := v_now;
            v_elapsed := 0;
            
            -- Generate unpredictable, casino-like crash point
            v_random := random();
            IF v_random < v_instant_crash_rate THEN
                -- 12% instant crash house edge
                v_new_crash_point := 1.00;
            ELSIF v_random < 0.60 THEN
                -- 48% chance: Tighter low multipliers (1.01 to 1.75)
                v_new_crash_point := 1.01 + (random() * 0.74);
            ELSIF v_random < 0.88 THEN
                -- 28% chance: Moderate multipliers (1.75 to 4.50)
                v_new_crash_point := 1.75 + (random() * 2.75);
            ELSIF v_random < 0.97 THEN
                -- 9% chance: High multipliers (4.50 to 12.00)
                v_new_crash_point := 4.50 + (random() * 7.50);
            ELSE
                -- 3% chance: sky-high multipliers (12.00 to 75.00)
                v_new_crash_point := 12.00 + (random() * 63.00);
            END IF;
            v_crash_point := round(v_new_crash_point, 2);
            
            v_needs_update := true;
        END IF;
    END IF;

    -- Save changes if state transitioned
    IF v_needs_update THEN
        UPDATE public.active_game_state
        SET status = v_status,
            round_id = v_round_id,
            crash_point = v_crash_point,
            start_time = v_start_time,
            server_time = v_now
        WHERE id = 1;
        
        -- If transitioned to crashed, insert into game history
        IF v_status = 'crashed' THEN
            INSERT INTO public.game_history (multiplier)
            VALUES (v_crash_point);
        END IF;
    END IF;

    RETURN json_build_object(
        'roundId', v_round_id,
        'roundStartTime', EXTRACT(EPOCH FROM v_start_time) * 1000,
        'crashPoint', v_crash_point,
        'gameStatus', v_status,
        'serverTime', EXTRACT(EPOCH FROM v_now) * 1000,
        'elapsedMs', v_elapsed
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
