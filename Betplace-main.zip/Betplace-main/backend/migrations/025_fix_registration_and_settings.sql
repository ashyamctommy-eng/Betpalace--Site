-- ═══════════════════════════════════════════════════════════════
-- MIGRATION 025: Harden handle_new_user Trigger Against All Conflicts
-- ═══════════════════════════════════════════════════════════════
--
-- PROBLEM 1: The previous trigger used ON CONFLICT (id) DO NOTHING.
--   This only handles PK conflicts. If the profiles table has UNIQUE(phone)
--   and the phone already exists (e.g. from a duplicate signup attempt),
--   the INSERT throws an unhandled exception, silently preventing
--   the auth.users row from being created (Supabase rolls back the trigger).
--
-- PROBLEM 2: Username truncation at 20chars may still produce invalid format
--   if the user-supplied username contains special characters.
--
-- FIX: Wrap the INSERT in an EXCEPTION handler so any conflict (phone, username)
--   is caught and handled gracefully. The profile will either be inserted
--   or skipped (DO NOTHING on any constraint violation).
--
-- PROBLEM 3: system_settings table policy may block anon reads.
--   Confirm the public SELECT policy exists.
-- ═══════════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
    v_phone    TEXT;
    v_username TEXT;
    v_email    TEXT;
BEGIN
    -- ── Resolve phone ──────────────────────────────────────────────────────────
    -- Priority: metadata phone > auth phone > unique placeholder
    v_phone := COALESCE(
        NULLIF(TRIM(NEW.raw_user_meta_data->>'phone'), ''),
        NULLIF(TRIM(NEW.phone::TEXT), ''),
        '+25400' || REPLACE(NEW.id::text, '-', '')
    );
    -- Clamp placeholder to reasonable length (max 20 chars for phone col)
    v_phone := LEFT(v_phone, 20);

    -- ── Resolve username ───────────────────────────────────────────────────────
    -- Strip any characters that don't match '^[a-z0-9_\.]{3,20}$' from user input
    v_username := COALESCE(
        NULLIF(TRIM(NEW.raw_user_meta_data->>'username'), ''),
        'usr_' || REPLACE(substring(NEW.id::text from 1 for 8), '-', '')
    );
    -- Remove illegal chars, enforce lowercase, limit to 20 chars
    v_username := LEFT(LOWER(REGEXP_REPLACE(v_username, '[^a-z0-9_\.]', '', 'gi')), 20);
    -- Ensure minimum length of 3
    IF LENGTH(v_username) < 3 THEN
        v_username := 'usr_' || REPLACE(substring(NEW.id::text from 1 for 8), '-', '');
    END IF;

    -- ── Resolve email ──────────────────────────────────────────────────────────
    v_email := COALESCE(
        NULLIF(TRIM(NEW.email), ''),
        v_phone || '@metricwin.app'
    );

    -- ── Insert profile — handle ALL constraint violations gracefully ───────────
    BEGIN
        INSERT INTO public.profiles (
            id,
            phone,
            username,
            email,
            balance,
            role
        )
        VALUES (
            NEW.id,
            v_phone,
            v_username,
            v_email,
            0.00,
            'User'
        )
        ON CONFLICT (id) DO NOTHING;

    EXCEPTION
        WHEN unique_violation THEN
            -- Phone or username conflict: try with a fully unique fallback
            BEGIN
                INSERT INTO public.profiles (
                    id,
                    phone,
                    username,
                    email,
                    balance,
                    role
                )
                VALUES (
                    NEW.id,
                    -- Unique phone placeholder using UUID
                    '+25400' || REPLACE(NEW.id::text, '-', ''),
                    -- Unique username using UUID
                    'usr_' || REPLACE(REPLACE(NEW.id::text, '-', ''), ' ', ''),
                    v_email,
                    0.00,
                    'User'
                )
                ON CONFLICT (id) DO NOTHING;
            EXCEPTION
                WHEN OTHERS THEN
                    -- Still failing: log and return gracefully, never block auth
                    RAISE WARNING 'handle_new_user: Fallback insert failed for user %: %', NEW.id, SQLERRM;
            END;

        WHEN OTHERS THEN
            -- Any other DB error: log but never block the auth user creation
            RAISE WARNING 'handle_new_user: Unexpected error for user %: %', NEW.id, SQLERRM;
    END;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Re-bind the trigger (idempotent)
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ═══════════════════════════════════════════════════════════════
-- Ensure system_settings is publicly readable (anon + authenticated)
-- ═══════════════════════════════════════════════════════════════
-- Drop and recreate idempotently
DROP POLICY IF EXISTS "Public system settings read access" ON public.system_settings;
CREATE POLICY "Public system settings read access"
    ON public.system_settings FOR SELECT USING (true);

-- Make sure RLS is enabled
ALTER TABLE public.system_settings ENABLE ROW LEVEL SECURITY;

-- Grant SELECT to all roles
GRANT SELECT ON public.system_settings TO anon, authenticated;
