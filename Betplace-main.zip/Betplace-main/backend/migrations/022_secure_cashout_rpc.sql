-- ═══════════════════════════════════════════════════════════════
-- MIGRATION 022: Secure Cashout and Cancel Bet RPCs
-- ═══════════════════════════════════════════════════════════════

-- Hardened cash_out RPC: validates multiplier client snapshots against server-authoritative flight times
CREATE OR REPLACE FUNCTION public.cash_out(p_bet_id UUID, p_multiplier DECIMAL)
RETURNS JSON
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_user_id UUID;
    v_bet_amount DECIMAL;
    v_bet_round_id BIGINT;
    v_winnings DECIMAL;
    v_bet_status TEXT;
    
    -- Active round state variables
    v_current_round_id BIGINT;
    v_round_status TEXT;
    v_crash_point DECIMAL;
    v_start_time TIMESTAMPTZ;
    v_elapsed_sec DECIMAL;
    v_calculated_multiplier DECIMAL;
    v_actual_multiplier DECIMAL;
BEGIN
    v_user_id := auth.uid();
    IF v_user_id IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Unauthorized');
    END IF;

    -- Fetch bet to verify ownership and status
    SELECT amount, status, round_id INTO v_bet_amount, v_bet_status, v_bet_round_id
    FROM public.bets WHERE id = p_bet_id AND user_id = v_user_id;

    IF v_bet_amount IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Bet not found');
    END IF;

    IF v_bet_status != 'playing' THEN
        RETURN json_build_object('success', false, 'error', 'Bet already finalized');
    END IF;

    -- Get authoritative game loop state
    SELECT round_id, status, crash_point, start_time 
    INTO v_current_round_id, v_round_status, v_crash_point, v_start_time
    FROM public.active_game_state WHERE id = 1;

    -- Guard: bet must be for the active round
    IF v_bet_round_id != v_current_round_id THEN
        RETURN json_build_object('success', false, 'error', 'This round is not currently playing');
    END IF;

    -- Guard: active game status must be 'playing'
    IF v_round_status != 'playing' THEN
        RETURN json_build_object('success', false, 'error', 'Game is not in a flight state');
    END IF;

    -- Verify the flight multiplier in the DB matching growth: 1.06^seconds
    v_elapsed_sec := GREATEST(0, EXTRACT(EPOCH FROM (now() - v_start_time)));
    v_calculated_multiplier := round(power(1.06, v_elapsed_sec)::DECIMAL, 2);

    IF p_multiplier <= (v_calculated_multiplier + 0.15) THEN
        v_actual_multiplier := LEAST(p_multiplier, v_calculated_multiplier);
    ELSE
        v_actual_multiplier := v_calculated_multiplier;
    END IF;

    IF v_actual_multiplier >= v_crash_point THEN
        UPDATE public.bets SET status = 'lost' WHERE id = p_bet_id;
        RETURN json_build_object('success', false, 'error', 'Too late! The plane crashed at ' || v_crash_point || 'x');
    END IF;

    IF v_actual_multiplier < 1.00 THEN
        v_actual_multiplier := 1.00;
    END IF;

    v_winnings := floor(v_bet_amount * v_actual_multiplier);

    -- Update bet
    UPDATE public.bets 
    SET status = 'won', multiplier_cashed = v_actual_multiplier, winnings = v_winnings
    WHERE id = p_bet_id AND status = 'playing';

    -- Credit balance
    UPDATE public.profiles SET balance = balance + v_winnings WHERE id = v_user_id;

    RETURN json_build_object(
        'success', true, 
        'winnings', v_winnings,
        'multiplier', v_actual_multiplier,
        'new_balance', (SELECT balance FROM public.profiles WHERE id = v_user_id)
    );
END;
$$ LANGUAGE plpgsql;

-- Hardened cancel_bet RPC: prevents cancelling bet once the flight phase starts
CREATE OR REPLACE FUNCTION public.cancel_bet(p_bet_id UUID)
RETURNS JSON
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_user_id UUID;
    v_amount DECIMAL;
    v_bet_status TEXT;
    v_bet_round_id BIGINT;
    v_balance DECIMAL;
    
    v_current_round_id BIGINT;
    v_game_status TEXT;
BEGIN
    v_user_id := auth.uid();
    IF v_user_id IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Unauthorized');
    END IF;

    -- Get bet status, amount, and round
    SELECT amount, status, round_id INTO v_amount, v_bet_status, v_bet_round_id 
    FROM public.bets WHERE id = p_bet_id AND user_id = v_user_id;

    IF v_amount IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Bet not found');
    END IF;

    IF v_bet_status != 'playing' THEN
        RETURN json_build_object('success', false, 'error', 'Bet cannot be cancelled at this stage');
    END IF;

    -- Get actual game status
    SELECT round_id, status INTO v_current_round_id, v_game_status
    FROM public.active_game_state WHERE id = 1;

    -- Guard: can only cancel if target round hasn't started yet.
    -- (i.e. it's for a future round, or it's for current round but the game is still 'waiting' or 'crashed' phase)
    IF v_bet_round_id = v_current_round_id AND v_game_status != 'waiting' AND v_game_status != 'crashed' THEN
        RETURN json_build_object('success', false, 'error', 'Cannot cancel bet once the round has started');
    END IF;

    -- Delete the bet
    DELETE FROM public.bets WHERE id = p_bet_id;

    -- Return stake back
    UPDATE public.profiles SET balance = balance + v_amount WHERE id = v_user_id;
    
    -- Get updated balance
    SELECT balance INTO v_balance FROM public.profiles WHERE id = v_user_id;

    RETURN json_build_object('success', true, 'new_balance', v_balance);
END;
$$ LANGUAGE plpgsql;

-- Grant execution permissions explicitly
GRANT EXECUTE ON FUNCTION public.cash_out(UUID, DECIMAL) TO public;
GRANT EXECUTE ON FUNCTION public.cash_out(UUID, DECIMAL) TO anon;
GRANT EXECUTE ON FUNCTION public.cash_out(UUID, DECIMAL) TO authenticated;

GRANT EXECUTE ON FUNCTION public.cancel_bet(UUID) TO public;
GRANT EXECUTE ON FUNCTION public.cancel_bet(UUID) TO anon;
GRANT EXECUTE ON FUNCTION public.cancel_bet(UUID) TO authenticated;
