-- Migration: atomic_claim_promo
-- Purpose: Atomically records a promo code claim AND credits the user's balance
--          in a single transaction, eliminating the partial-failure window that
--          previously existed when claim-promo.js used 3 sequential DB calls.
--
-- Called by: api/claim-promo.js (falls back to legacy path if this doesn't exist)
-- Created:   2026-08-28

CREATE OR REPLACE FUNCTION atomic_claim_promo(
    p_user_id       UUID,
    p_promo_code_id UUID,
    p_reward_amount NUMERIC,
    p_phone         TEXT,
    p_tx_reference  TEXT
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- 1. Insert the claim record (will raise an exception on duplicate due to UNIQUE constraint)
    IF p_promo_code_id IS NOT NULL THEN
        INSERT INTO promo_code_claims (promo_code_id, user_id)
        VALUES (p_promo_code_id, p_user_id);
    END IF;

    -- 2. Credit the user's balance atomically
    UPDATE profiles
    SET balance = balance + p_reward_amount
    WHERE id = p_user_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'User profile not found: %', p_user_id;
    END IF;

    -- 3. Insert the ledger transaction record
    INSERT INTO transactions (user_id, type, amount, status, phone, reference)
    VALUES (p_user_id, 'deposit', p_reward_amount, 'completed', p_phone, p_tx_reference);

    RETURN TRUE;
END;
$$;

-- Grant execution to the service role used by Vercel functions
GRANT EXECUTE ON FUNCTION atomic_claim_promo(UUID, UUID, NUMERIC, TEXT, TEXT) TO service_role;
