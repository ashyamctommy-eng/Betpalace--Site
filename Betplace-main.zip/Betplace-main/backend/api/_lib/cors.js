/**
 * api/_lib/cors.js
 *
 * Configurable CORS helper for Metricwin Backend.
 * Supports:
 *  - Environment variable CORS_ORIGIN or FRONTEND_URL (comma-separated origins)
 *  - Wildcard '*' for open development/testing
 *  - Default fallback origins (localhost, known production and staging domains)
 */

export const DEFAULT_ALLOWED_ORIGINS = [
    'http://localhost:3000',
    'http://localhost:5173',
    'http://127.0.0.1:5173',
    'http://localhost:4173',
    'https://metricwins.com',
    'https://www.metricwins.com',
    'https://aviator.metricwins.com',
    'https://demo.metricwins.com',
    'https://predictor.metricwins.com',
    'https://admin.metricwins.com',
    'https://superadmin.metricwins.com',
    'https://metricwin.vercel.app'
];

/**
 * Returns dynamic list of allowed origins from process.env and defaults.
 */
export function getAllowedOrigins() {
    const custom = process.env.CORS_ORIGIN || process.env.FRONTEND_URL || '';
    if (custom === '*') return ['*'];

    const origins = custom
        .split(',')
        .map(s => s.trim())
        .filter(Boolean);

    return Array.from(new Set([...origins, ...DEFAULT_ALLOWED_ORIGINS]));
}

/**
 * Checks if a given request origin is permitted.
 */
export function isOriginAllowed(origin) {
    if (!origin) return true; // Non-browser / same-origin requests
    const allowed = getAllowedOrigins();
    if (allowed.includes('*')) return true;
    return allowed.includes(origin);
}

/**
 * Sets CORS headers on the response object.
 * @param {object} req - HTTP request object
 * @param {object} res - HTTP response object
 * @param {string} methods - Comma-separated HTTP methods
 */
export function setCorsHeaders(req, res, methods = 'GET, POST, PUT, DELETE, OPTIONS') {
    const origin = req.headers.origin || req.headers.Origin;
    const allowed = getAllowedOrigins();

    if (allowed.includes('*')) {
        res.setHeader('Access-Control-Allow-Origin', '*');
    } else if (origin && isOriginAllowed(origin)) {
        res.setHeader('Access-Control-Allow-Origin', origin);
        res.setHeader('Vary', 'Origin');
    }

    res.setHeader('Access-Control-Allow-Methods', methods);
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With, apikey, x-client-info');
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Access-Control-Max-Age', '86400'); // Cache preflight 24h
}
