/**
 * gameLoop.js — Single Unified Animation & Telemetry Loop
 *
 * Responsibilities:
 *   - Runs a SINGLE continuous requestAnimationFrame loop (no multiple accumulated loops)
 *   - Computes FPS and updates gameBridge telemetry
 *   - Dispatches state ticks to provided UI callbacks based on gameBridge.gameState
 *   - Integrates live telemetry with debugPanel
 *
 * Guarantees:
 *   - Only one animation frame request active at any given time (Root Cause #4 & #6 fix)
 *   - Clean start/stop lifecycle with error handling
 */

import { gameBridge } from './gameBridge.js';
import { updateDebugPanel } from './debugPanel.js';

let rafId = null;
let lastFrameTime = performance.now();
let frameCount = 0;
let fpsTimer = performance.now();
let activeCallbacks = {
    onFlyingTick: null,
    onWaitingTick: null,
};

function tick(now) {
    // ── FPS Calculation ──────────────────────────────────────────────────────
    frameCount++;
    if (now - fpsTimer >= 1000) {
        gameBridge.fps = Math.round((frameCount * 1000) / (now - fpsTimer));
        frameCount = 0;
        fpsTimer = now;
    }
    lastFrameTime = now;

    // ── Execute State-Specific Callbacks ──────────────────────────────────────
    const state = gameBridge.gameState;

    if (state === 'FLYING' && typeof activeCallbacks.onFlyingTick === 'function') {
        try {
            activeCallbacks.onFlyingTick();
        } catch (err) {
            console.error('[GameLoop] Flying tick error:', err);
        }
    } else if ((state === 'WAITING' || state === 'COUNTDOWN') && typeof activeCallbacks.onWaitingTick === 'function') {
        try {
            activeCallbacks.onWaitingTick();
        } catch (err) {
            console.error('[GameLoop] Waiting tick error:', err);
        }
    }

    // ── Update Debug Telemetry Panel ─────────────────────────────────────────
    updateDebugPanel();

    // ── Continue Loop ────────────────────────────────────────────────────────
    rafId = requestAnimationFrame(tick);
}

export function startGameLoop(callbacks = {}) {
    activeCallbacks = { ...activeCallbacks, ...callbacks };

    if (!gameBridge.rafRunning || !rafId) {
        if (rafId) cancelAnimationFrame(rafId);
        gameBridge.rafRunning = true;
        lastFrameTime = performance.now();
        fpsTimer = performance.now();
        frameCount = 0;
        rafId = requestAnimationFrame(tick);
        console.log('[GameLoop] Unified single rAF loop started');
    }
}

export function stopGameLoop() {
    if (rafId) {
        cancelAnimationFrame(rafId);
        rafId = null;
    }
    gameBridge.rafRunning = false;
    console.log('[GameLoop] Loop stopped');
}

export function isGameLoopRunning() {
    return gameBridge.rafRunning && rafId !== null;
}
