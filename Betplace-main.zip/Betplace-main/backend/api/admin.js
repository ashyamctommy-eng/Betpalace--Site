/**
 * api/admin.js
 *
 * Consolidated Router for Super Admin & Admin functionalities.
 * Maps routes to their corresponding sub-handlers to keep overall Vercel
 * serverless function count below Hobby plan limits.
 *
 * SECURITY HARDENED:
 *  - Restricts CORS access to whitelisted domains only
 */

import { setCorsHeaders } from './_lib/cors.js';
import systemHandler from './_admin/system.js';
import contentHandler from './_admin/content.js';
import promocodesHandler from './_admin/promocodes.js';
import actionsHandler from './_admin/actions.js';

export default async function handler(req, res) {
    // Enable CORS for allowed domains (with authorization support)
    setCorsHeaders(req, res, 'GET, POST, DELETE, OPTIONS');
    if (req.method === 'OPTIONS') return res.status(200).end();

    const url = req.url || '';
    const pathPart = url.split('?')[0] || '';

    // Route based on URL/Path suffix or query parameter
    if (req.query.route === 'system' || pathPart.endsWith('/system') || pathPart.includes('/system/')) {
        return systemHandler(req, res);
    }
    if (req.query.route === 'content' || pathPart.endsWith('/content') || pathPart.includes('/content/')) {
        return contentHandler(req, res);
    }
    if (req.query.route === 'promocodes' || pathPart.endsWith('/promocodes') || pathPart.includes('/promocodes/')) {
        return promocodesHandler(req, res);
    }
    if (req.query.route === 'actions' || pathPart.endsWith('/actions') || pathPart.includes('/actions/')) {
        return actionsHandler(req, res);
    }

    // Default fallback: return mismatch
    return res.status(404).json({ error: `Admin routing mismatch: Path not handled: ${pathPart}` });
}
