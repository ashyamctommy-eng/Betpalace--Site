-- ═══════════════════════════════════════════════════════════════════
-- MIGRATION 031: Auto-resolve place_bet round ID to prevent invalid round errors
-- ═══════════════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION public.place_bet(
    p_round_id     BIGINT,
    p_amount       DECIMAL,
    p_use_free_bet  BOOLEAN DEFAULT FALSE
)
RETURNS JSON
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_user_id      UUID;
    v_balance      DECIMAL;
    v_is_frozen    BOOLEAN;
    v_bet_id       UUID;
    v_game_round   BIGINT;
    v_game_status  TEXT;
    v_target_round BIGINT;
BEGIN
    v_user_id := auth.uid();
    IF v_user_id IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Unauthorized');
    END IF;

    -- Minimum stake guard
    IF p_amount < 50 THEN
        RETURN json_build_object('success', false, 'error', 'Minimum stake is KES 50');
    END IF;

    -- Fetch profile: balance + frozen status
    SELECT balance, COALESCE(is_frozen, FALSE)
    INTO   v_balance, v_is_frozen
    FROM   public.profiles
    WHERE  id = v_user_id;

    IF v_is_frozen THEN
        RETURN json_build_object('success', false, 'error', 'Your account is frozen. Contact support.');
    END IF;

    IF v_balance < p_amount THEN
        RETURN json_build_object('success', false, 'error', 'Insufficient balance');
    END IF;

    -- Fetch current authoritative active game state
    SELECT round_id, status
    INTO   v_game_round, v_game_status
    FROM   public.active_game_state
    WHERE  id = 1;

    -- Auto-resolve target round_id:
    -- If p_round_id is missing, <= 0, or lagging behind v_game_round:
    --   - during 'waiting': bet on current waiting round (v_game_round)
    --   - during 'playing' or 'crashed': queue bet for next round (v_game_round + 1)
    -- If p_round_id is far ahead, clamp to next round (v_game_round + 1)
    v_target_round := p_round_id;
    IF v_target_round IS NULL OR v_target_round <= 0 OR v_target_round < v_game_round THEN
        IF v_game_status = 'waiting' THEN
            v_target_round := v_game_round;
        ELSE
            v_target_round := v_game_round + 1;
        END IF;
    ELSIF v_target_round > (v_game_round + 1) THEN
        v_target_round := v_game_round + 1;
    END IF;

    -- Deduct balance atomically
    UPDATE public.profiles
    SET    balance = balance - p_amount
    WHERE  id = v_user_id;

    -- Create bet record
    INSERT INTO public.bets (user_id, round_id, amount, is_free_bet)
    VALUES (v_user_id, v_target_round, p_amount, p_use_free_bet)
    RETURNING id INTO v_bet_id;

    RETURN json_build_object(
        'success', true, 
        'bet_id', v_bet_id, 
        'round_id', v_target_round,
        'new_balance', v_balance - p_amount
    );
END;
$$ LANGUAGE plpgsql;

GRANT EXECUTE ON FUNCTION public.place_bet(BIGINT, DECIMAL, BOOLEAN) TO authenticated;
REVOKE EXECUTE ON FUNCTION public.place_bet(BIGINT, DECIMAL, BOOLEAN) FROM anon, public;

NOTIFY pgrst, 'reload schema';
