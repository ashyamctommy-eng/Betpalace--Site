/**
 * backend/api/claim-promo.js
 *
 * User-facing Promo Code claiming endpoint.
 * Zero Supabase dependency. Uses pure PostgreSQL transactions.
 */

import { verifyAuthToken } from './_lib/auth.js';
import { setCorsHeaders } from './_lib/cors.js';
import { query, getClient } from './_lib/db.js';

export default async function claimPromoHandler(req, res) {
    setCorsHeaders(req, res, 'POST, OPTIONS');

    if (req.method === 'OPTIONS') return res.status(200).end();
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

    const auth = await verifyAuthToken(req);
    if (!auth.success) {
        return res.status(auth.status).json({ error: auth.error });
    }
    const userId = auth.user.id;

    const { code } = req.body || {};
    if (!code || typeof code !== 'string' || code.trim().length === 0) {
        return res.status(400).json({ error: 'Promo code is required.' });
    }

    const sanitizedCode = code.trim().toUpperCase().replace(/[^A-Z0-9\-]/g, '');

    // Brute-force protection: max 5 failed attempts in 15 mins
    const windowStart = new Date(Date.now() - 15 * 60 * 1000).toISOString();
    const { rows: attemptRows } = await query(
        `SELECT COUNT(*) AS count FROM promo_code_attempts
         WHERE user_id = $1 AND attempted_at >= $2`,
        [userId, windowStart]
    );

    if (parseInt(attemptRows[0]?.count, 10) >= 5) {
        return res.status(429).json({ error: 'Too many failed attempts. Please wait 15 minutes before trying again.' });
    }

    const client = await getClient();

    try {
        await client.query('BEGIN');

        // Check promo code
        const { rows: promoRows } = await client.query(
            `SELECT * FROM promo_codes
             WHERE code = $1 AND is_active = true
             FOR UPDATE`,
            [sanitizedCode]
        );

        if (promoRows.length === 0) {
            // Log failed attempt
            await client.query(
                'INSERT INTO promo_code_attempts (user_id, attempted_code) VALUES ($1, $2)',
                [userId, sanitizedCode]
            );
            await client.query('COMMIT');
            return res.status(404).json({ error: 'Invalid or inactive promo code.' });
        }

        const promo = promoRows[0];

        if (promo.current_uses >= promo.max_uses) {
            await client.query('COMMIT');
            return res.status(400).json({ error: 'This promo code has reached its maximum redemptions.' });
        }

        // Check already redeemed
        const { rows: redemptions } = await client.query(
            'SELECT id FROM promo_code_redemptions WHERE promo_code_id = $1 AND user_id = $2',
            [promo.id, userId]
        );

        if (redemptions.length > 0) {
            await client.query('COMMIT');
            return res.status(400).json({ error: 'You have already redeemed this promo code.' });
        }

        const rewardAmount = parseFloat(promo.amount);

        // Credit user balance
        const { rows: updatedProfile } = await client.query(
            'UPDATE profiles SET balance = balance + $1, updated_at = NOW() WHERE id = $2 RETURNING balance',
            [rewardAmount, userId]
        );

        // Update promo code uses
        await client.query(
            'UPDATE promo_codes SET current_uses = current_uses + 1 WHERE id = $1',
            [promo.id]
        );

        // Record redemption
        await client.query(
            'INSERT INTO promo_code_redemptions (promo_code_id, user_id, amount) VALUES ($1, $2, $3)',
            [promo.id, userId, rewardAmount]
        );

        // Record transaction
        await client.query(
            `INSERT INTO transactions (user_id, type, amount, status, metadata)
             VALUES ($1, 'bonus', $2, 'completed', $3)`,
            [userId, rewardAmount, JSON.stringify({ code: sanitizedCode })]
        );

        await client.query('COMMIT');

        return res.status(200).json({
            success: true,
            amount: rewardAmount,
            newBalance: parseFloat(updatedProfile[0].balance),
            message: `Congratulations! KES ${rewardAmount.toFixed(2)} bonus has been added to your account.`
        });
    } catch (err) {
        await client.query('ROLLBACK');
        console.error('[Claim Promo Error]:', err);
        return res.status(500).json({ error: 'Failed to process promo code.' });
    } finally {
        client.release();
    }
}
