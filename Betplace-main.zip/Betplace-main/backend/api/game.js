/**
 * backend/api/game.js
 *
 * Authoritative Aviator Game API Router.
 * Handles state synchronization, betting, cashouts, cancellations, and round history.
 * Powered directly by PostgreSQL stored procedures.
 */

import { query } from './_lib/db.js';
import { verifyAuthToken } from './_lib/auth.js';
import { getFinancialLimits } from './_lib/limits.js';

export default async function gameHandler(req, res) {
    const url = req.url || '';
    const pathPart = url.split('?')[0] || '';

    // Route matching
    if (pathPart.endsWith('/bet')) {
        return handlePlaceBet(req, res);
    }
    if (pathPart.endsWith('/cashout')) {
        return handleCashOut(req, res);
    }
    if (pathPart.endsWith('/cancel')) {
        return handleCancelBet(req, res);
    }
    if (pathPart.endsWith('/history')) {
        return handleHistory(req, res);
    }
    if (pathPart.endsWith('/my-bets')) {
        return handleMyBets(req, res);
    }

    // Default: GET /api/game or GET /api/game/state
    return handleGetState(req, res);
}

/**
 * Authoritative Game Loop State
 * GET /api/game
 */
export async function handleGetState(_req, res) {
    try {
        const { rows } = await query('SELECT sync_and_get_game_state() AS state');
        const state = rows[0]?.state;
        return res.status(200).json(state);
    } catch (err) {
        console.error('[Game State Error]:', err.message);
        return res.status(500).json({ error: 'Failed to fetch authoritative game state.' });
    }
}

/**
 * Place Bet
 * POST /api/game/bet
 */
export async function handlePlaceBet(req, res) {
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

    const auth = await verifyAuthToken(req);
    if (!auth.success) {
        return res.status(auth.status).json({ success: false, message: auth.error });
    }

    const body = req.body || {};
    const roundId = body.roundId ?? body.round_id ?? body.p_round_id ?? 0;
    const amount = body.amount ?? body.p_amount;
    const autoCashout = body.autoCashout ?? body.auto_cashout ?? body.p_auto_cashout ?? null;
    const betAmount = Number(amount);

    const limits = await getFinancialLimits();
    const minBet = limits.minBetAviator || 10;
    const maxBet = limits.maxBetAviator || 50000;

    if (!betAmount || isNaN(betAmount) || betAmount < minBet || betAmount > maxBet) {
        return res.status(400).json({
            success: false,
            message: `Invalid bet amount (Min ${minBet}, Max ${maxBet.toLocaleString()}).`
        });
    }

    try {
        const { rows } = await query(
            'SELECT place_bet($1, $2, $3, $4) AS result',
            [auth.user.id, roundId || 0, betAmount, autoCashout || null]
        );

        const result = rows[0]?.result;
        if (!result || result.success === false) {
            return res.status(400).json(result || { success: false, message: 'Failed to place bet.' });
        }

        const normalized = {
            ...result,
            success: true,
            betId: result.betId || result.bet_id,
            bet_id: result.bet_id || result.betId,
            roundId: Number(result.roundId || result.round_id || roundId),
            round_id: Number(result.round_id || result.roundId || roundId),
            newBalance: typeof (result.newBalance ?? result.new_balance) === 'number'
                ? (result.newBalance ?? result.new_balance)
                : parseFloat(result.newBalance ?? result.new_balance),
            new_balance: typeof (result.new_balance ?? result.newBalance) === 'number'
                ? (result.new_balance ?? result.newBalance)
                : parseFloat(result.new_balance ?? result.newBalance)
        };

        return res.status(200).json(normalized);
    } catch (err) {
        console.error('[Place Bet Error]:', err.message);
        return res.status(500).json({ success: false, message: err.message || 'Server error placing bet.' });
    }
}

/**
 * Cash Out
 * POST /api/game/cashout
 */
export async function handleCashOut(req, res) {
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

    const auth = await verifyAuthToken(req);
    if (!auth.success) {
        return res.status(auth.status).json({ success: false, message: auth.error });
    }

    const body = req.body || {};
    const betId = body.betId ?? body.bet_id ?? body.p_bet_id;
    const multiplier = body.multiplier ?? body.p_multiplier;
    const mult = Number(multiplier);

    if (!betId || !mult || isNaN(mult) || mult < 1.01) {
        return res.status(400).json({ success: false, message: 'Invalid cashout parameters.' });
    }

    try {
        const { rows } = await query(
            'SELECT cash_out($1, $2, $3) AS result',
            [auth.user.id, betId, mult]
        );

        const result = rows[0]?.result;
        if (!result || result.success === false) {
            return res.status(400).json(result || { success: false, message: 'Failed to cash out.' });
        }

        const finalPayout = result.payout ?? result.winnings;
        const normalized = {
            ...result,
            success: true,
            payout: typeof finalPayout === 'number' ? finalPayout : parseFloat(finalPayout),
            winnings: typeof finalPayout === 'number' ? finalPayout : parseFloat(finalPayout),
            multiplier: result.multiplier ?? mult,
            newBalance: typeof (result.newBalance ?? result.new_balance) === 'number'
                ? (result.newBalance ?? result.new_balance)
                : parseFloat(result.newBalance ?? result.new_balance),
            new_balance: typeof (result.new_balance ?? result.newBalance) === 'number'
                ? (result.new_balance ?? result.newBalance)
                : parseFloat(result.new_balance ?? result.newBalance)
        };

        return res.status(200).json(normalized);
    } catch (err) {
        console.error('[Cash Out Error]:', err.message);
        return res.status(500).json({ success: false, message: err.message || 'Server error cashing out.' });
    }
}

/**
 * Cancel Bet
 * POST /api/game/cancel
 */
export async function handleCancelBet(req, res) {
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

    const auth = await verifyAuthToken(req);
    if (!auth.success) {
        return res.status(auth.status).json({ success: false, message: auth.error });
    }

    const body = req.body || {};
    const betId = body.betId ?? body.bet_id ?? body.p_bet_id;
    if (!betId) {
        return res.status(400).json({ success: false, message: 'Bet ID is required.' });
    }

    try {
        const { rows } = await query(
            'SELECT cancel_bet($1, $2) AS result',
            [auth.user.id, betId]
        );

        const result = rows[0]?.result;
        if (!result || result.success === false) {
            return res.status(400).json(result || { success: false, message: 'Failed to cancel bet.' });
        }

        const normalized = {
            ...result,
            success: true,
            refunded: result.refunded,
            newBalance: typeof (result.newBalance ?? result.new_balance) === 'number'
                ? (result.newBalance ?? result.new_balance)
                : parseFloat(result.newBalance ?? result.new_balance),
            new_balance: typeof (result.new_balance ?? result.newBalance) === 'number'
                ? (result.new_balance ?? result.newBalance)
                : parseFloat(result.new_balance ?? result.newBalance)
        };

        return res.status(200).json(normalized);
    } catch (err) {
        console.error('[Cancel Bet Error]:', err.message);
        return res.status(500).json({ success: false, message: err.message || 'Server error cancelling bet.' });
    }
}

/**
 * Game Crash History
 * GET /api/game/history
 */
export async function handleHistory(_req, res) {
    try {
        const { rows } = await query(
            'SELECT round_id, crash_point, created_at FROM crash_history ORDER BY round_id DESC LIMIT 50'
        );
        return res.status(200).json(rows);
    } catch (err) {
        console.error('[History Error]:', err.message);
        return res.status(500).json({ error: 'Failed to fetch game history.' });
    }
}

/**
 * User's Bets
 * GET /api/game/my-bets
 */
export async function handleMyBets(req, res) {
    const auth = await verifyAuthToken(req);
    if (!auth.success) {
        return res.status(auth.status).json({ success: false, message: auth.error });
    }

    try {
        const { rows } = await query(
            'SELECT * FROM bets WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50',
            [auth.user.id]
        );
        return res.status(200).json(rows);
    } catch (err) {
        console.error('[My Bets Error]:', err.message);
        return res.status(500).json({ error: 'Failed to fetch bets.' });
    }
}
