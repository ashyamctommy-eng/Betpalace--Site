/**
 * test_game_loop.js — 10,000-Round Simulation Runner (v2)
 *
 * Simulates the full Aviator server game loop at 200ms intervals (fast-forwarded),
 * checking correctness invariants AND validating that the new square-root
 * multiplierToT formula satisfies all required visual positions.
 *
 * Run with: node test_game_loop.js
 */

'use strict';

const TARGET_ROUNDS   = 10_000;
const WAITING_MS      = 5_000;
const POST_CRASH_MS   = 1_200;
const TICK_INTERVAL   = 200;   // ms per simulation step
const GROWTH_RATE     = 1.06;  // multiplier per second

// ── multiplierToT: MUST match FlightScene.js exactly ─────────────────────────
function multiplierToT(mult) {
    const m = Math.max(1.00, mult);
    return Math.min(0.96, 0.553 * Math.sqrt(m - 1.00));
}

// ── Formula validation table ──────────────────────────────────────────────────
const SPEC_TARGETS = [
    { mult: 1.00, minT: 0.000, maxT: 0.001, label: '1.00x → at origin'             },
    { mult: 1.10, minT: 0.150, maxT: 0.200, label: '1.10x → 15–20% screen'         },
    { mult: 1.30, minT: 0.250, maxT: 0.350, label: '1.30x → 25–35% screen'         },
    { mult: 1.40, minT: 0.250, maxT: 0.350, label: '1.40x → 25–35% screen'         },
    { mult: 2.00, minT: 0.450, maxT: 0.600, label: '2.00x → ~50% screen'           },
    { mult: 4.00, minT: 0.850, maxT: 0.960, label: '4.00x → near top (capped)'     },
    { mult:10.00, minT: 0.950, maxT: 0.960, label: '10.0x → at cap (0.96)'         },
];

// ── Pseudo-random PRNG ────────────────────────────────────────────────────────
function makeRng(seed = 42) {
    let s = seed;
    return () => {
        s = (s * 1664525 + 1013904223) & 0xffffffff;
        return Math.abs(s) / 0xffffffff;
    };
}

function generateCrashPoint(rng) {
    const r = rng();
    if (r < 0.03) return 1.00;
    if (r < 0.40) return parseFloat((1.01 + rng() * 0.79).toFixed(2));
    if (r < 0.80) return parseFloat((1.80 + rng() * 5.20).toFixed(2));
    if (r < 0.95) return parseFloat((7.00 + rng() * 18.00).toFixed(2));
    return parseFloat((25.00 + rng() * 175.00).toFixed(2));
}

const PASS = '\x1b[32m✓\x1b[0m';
const FAIL = '\x1b[31m✗\x1b[0m';
const WARN = '\x1b[33m⚠\x1b[0m';

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 1: Formula validation
// ─────────────────────────────────────────────────────────────────────────────
console.log('\n🔬 FORMULA VALIDATION — multiplierToT(mult)\n');
console.log('  ' + 'Multiplier'.padEnd(12) + 'Got t'.padEnd(10) + 'Expected Range'.padEnd(22) + 'Result');
console.log('  ' + '─'.repeat(54));

let formulaOk = true;
SPEC_TARGETS.forEach(({ mult, minT, maxT, label }) => {
    const t = multiplierToT(mult);
    const pass = t >= minT && t <= maxT;
    if (!pass) formulaOk = false;
    const icon = pass ? PASS : FAIL;
    console.log(`  ${icon} ${label.padEnd(32)} t=${t.toFixed(4)}  [${minT.toFixed(3)}–${maxT.toFixed(3)}]`);
});

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 2: FPS independence — verify t is identical at 30, 60, 120 FPS
// ─────────────────────────────────────────────────────────────────────────────
console.log('\n🖥️  FPS INDEPENDENCE CHECK\n');

// Simulate 3 seconds of flight at different frame rates
const TEST_FLIGHT_SECS = 3.0;
const FPS_VARIANTS = [30, 60, 120, 144];
const flyStartMs = 0;

// gameTick EWMA parameters (from main.js)
const EWMA_FREQ = 15; // characteristic frequency

function simulateMultiplier(fps, durationSec) {
    let mult = 1.00;
    let currentMult = 1.00;
    const dtMs = 1000 / fps;
    const steps = Math.round(durationSec * fps);
    let lastNowPerf = 0;

    for (let i = 1; i <= steps; i++) {
        const simMs = i * dtMs;
        const target = Math.pow(GROWTH_RATE, simMs / 1000);
        const dtSec = Math.min(0.05, dtMs / 1000);
        const lerpFactor = 1 - Math.exp(-EWMA_FREQ * dtSec);
        if (currentMult <= 1.001 && target > 1.05) {
            currentMult = target;
        } else {
            currentMult += (target - currentMult) * lerpFactor;
            currentMult = Math.max(1.00, currentMult);
        }
        lastNowPerf = simMs;
    }
    return { fps, finalMult: currentMult, finalT: multiplierToT(currentMult) };
}

const fpsResults = FPS_VARIANTS.map(fps => simulateMultiplier(fps, TEST_FLIGHT_SECS));
const referenceT = fpsResults[0].finalT;

let fpsOk = true;
fpsResults.forEach(r => {
    const drift = Math.abs(r.finalT - referenceT);
    const pass = drift < 0.005; // less than 0.5% curve position drift between FPS modes
    if (!pass) fpsOk = false;
    const icon = pass ? PASS : FAIL;
    console.log(`  ${icon} ${r.fps} FPS after ${TEST_FLIGHT_SECS}s: mult=${r.finalMult.toFixed(4)}  t=${r.finalT.toFixed(4)}  drift from 30 FPS: ${(drift*100).toFixed(2)}%`);
});

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 3: 10,000-round game loop simulation
// ─────────────────────────────────────────────────────────────────────────────
console.log('\n🚀 10,000-ROUND GAME LOOP SIMULATION\n');

const rng = makeRng(0xBEEF_CAFE);

let roundId       = 1;
let status        = 'waiting';
let startTime     = 0;
let crashPoint    = generateCrashPoint(rng);
let simTime       = 0;

let completedRounds = 0;
let errors          = [];
let crashHistory    = [];
const seenRoundIds  = new Set();
let prevMultiplier  = 1.00;
let monotonicity_violations = 0;
let state_machine_violations = 0;
let duplicate_history_entries = 0;
let crashDistribution = { instant: 0, low: 0, mid: 0, high: 0, extreme: 0 };
const STATE_RANK = { waiting: 0, playing: 1, crashed: 2 };

// Track t progression per round for position verification
let roundSamples = [];

const wallStart = Date.now();

while (completedRounds < TARGET_ROUNDS) {
    simTime += TICK_INTERVAL;
    const elapsed = simTime - startTime;

    if (status === 'waiting') {
        if (elapsed >= WAITING_MS) {
            status     = 'playing';
            startTime  = simTime;
            prevMultiplier = 1.00;
            roundSamples   = [];
        }
    } else if (status === 'playing') {
        const elapsedSec = (simTime - startTime) / 1000;
        const mult       = Math.pow(GROWTH_RATE, elapsedSec);

        if (mult < prevMultiplier - 0.001) {
            monotonicity_violations++;
            errors.push(`Round ${roundId}: Multiplier went backwards`);
        }
        prevMultiplier = mult;

        // Sample t for position check
        const t = multiplierToT(mult);
        roundSamples.push({ mult, t });

        if (mult >= crashPoint) {
            if (seenRoundIds.has(roundId)) {
                duplicate_history_entries++;
                errors.push(`Round ${roundId}: Duplicate history entry!`);
            }
            seenRoundIds.add(roundId);
            crashHistory.unshift({ roundId, multiplier: crashPoint });
            if (crashHistory.length > 200) crashHistory.pop();

            if (crashPoint === 1.00)     crashDistribution.instant++;
            else if (crashPoint < 1.80)  crashDistribution.low++;
            else if (crashPoint < 7.00)  crashDistribution.mid++;
            else if (crashPoint < 25.00) crashDistribution.high++;
            else                         crashDistribution.extreme++;

            status = 'crashed';
            startTime = simTime;
            completedRounds++;
        }
    } else if (status === 'crashed') {
        if (elapsed >= POST_CRASH_MS) {
            roundId++;
            crashPoint = generateCrashPoint(rng);
            status     = 'waiting';
            startTime  = simTime;
        }
    }
}

const wallEnd  = Date.now();
const wallTime = ((wallEnd - wallStart) / 1000).toFixed(2);
const totalErrors = errors.length;

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 4: Final report
// ─────────────────────────────────────────────────────────────────────────────
const check = (label, value, pass) => {
    const icon = pass ? PASS : FAIL;
    console.log(`  ${icon} ${label}: ${value}`);
};

console.log(`  Rounds simulated:   ${completedRounds.toLocaleString()}`);
console.log(`  Wall-clock time:    ${wallTime}s`);
console.log(`  Speedup:            ${Math.round(simTime / 1000 / parseFloat(wallTime))}x realtime\n`);

check('Multiplier monotonicity violations', monotonicity_violations, monotonicity_violations === 0);
check('State machine violations',           state_machine_violations, state_machine_violations === 0);
check('Duplicate history entries',          duplicate_history_entries, duplicate_history_entries === 0);
check('Total simulation errors',            totalErrors, totalErrors === 0);

const totalCrashes = Object.values(crashDistribution).reduce((a, b) => a + b, 0);
const instantPct = (crashDistribution.instant / totalCrashes * 100).toFixed(1);
const lowPct     = (crashDistribution.low     / totalCrashes * 100).toFixed(1);
const midPct     = (crashDistribution.mid     / totalCrashes * 100).toFixed(1);
const highPct    = (crashDistribution.high    / totalCrashes * 100).toFixed(1);
const extremePct = (crashDistribution.extreme / totalCrashes * 100).toFixed(1);

console.log('\n📈 CRASH DISTRIBUTION');
console.log(`  1.00x instant:  ${crashDistribution.instant.toLocaleString().padStart(6)} = ${instantPct}%`);
console.log(`  1.01–1.79x low: ${crashDistribution.low.toLocaleString().padStart(6)} = ${lowPct}%`);
console.log(`  1.80–6.99x mid: ${crashDistribution.mid.toLocaleString().padStart(6)} = ${midPct}%`);
console.log(`  7.00–24.9x high:${crashDistribution.high.toLocaleString().padStart(6)} = ${highPct}%`);
console.log(`  25.0x+ extreme: ${crashDistribution.extreme.toLocaleString().padStart(6)} = ${extremePct}%`);

// ─────────────────────────────────────────────────────────────────────────────
console.log('\n═══════════════════════════════════════════════════════════');
console.log('                       OVERALL RESULT');
console.log('═══════════════════════════════════════════════════════════');

const allPassed = formulaOk && fpsOk && totalErrors === 0
    && monotonicity_violations === 0 && state_machine_violations === 0
    && duplicate_history_entries === 0;

if (allPassed) {
    console.log('\x1b[32m✅  ALL CHECKS PASSED\x1b[0m');
    console.log('    Formula verified | FPS-independent | 10,000 rounds clean\n');
} else {
    if (!formulaOk) console.log('\x1b[31m❌  Formula targets not met\x1b[0m');
    if (!fpsOk)     console.log('\x1b[31m❌  FPS drift too large\x1b[0m');
    if (totalErrors > 0) {
        console.log('\x1b[31m❌  Simulation errors:\x1b[0m');
        errors.slice(0, 10).forEach(e => console.log('    ', e));
    }
}
console.log('═══════════════════════════════════════════════════════════\n');
