-- ═══════════════════════════════════════════════════════════════
-- MIGRATION 023: Fix handle_new_user Trigger — Username Constraint Violation
-- ═══════════════════════════════════════════════════════════════
--
-- BUG: The trigger was using `substring(NEW.id::text from 1 for 8)` to build a
--      fallback username like 'player_XXXXXXXX'. UUIDs contain hyphens (e.g.
--      bf59-43d0…) which violate the `username_format_check` constraint:
--          CHECK (username ~* '^[a-z0-9_\.]{3,20}$')
--      This caused a 500 Internal Server Error on every signup.
--
-- FIX: Strip hyphens from the UUID portion (REPLACE(…, '-', '')), so the
--      fallback username only contains characters valid under the regex.
--      Also trim the metadata-provided username to stay within 20 chars.
-- ═══════════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
    v_phone    TEXT;
    v_username TEXT;
    v_email    TEXT;
BEGIN
    -- Resolve phone: prefer explicit phone meta, fall back to a safe placeholder
    v_phone := COALESCE(
        NEW.raw_user_meta_data->>'phone',
        NEW.phone,
        '+2540000' || REPLACE(substring(NEW.id::text from 1 for 6), '-', '')
    );

    -- Resolve username: strip hyphens so it passes the regex constraint
    -- `^[a-z0-9_\.]{3,20}$`
    v_username := COALESCE(
        NULLIF(TRIM(NEW.raw_user_meta_data->>'username'), ''),
        'usr_' || REPLACE(substring(NEW.id::text from 1 for 8), '-', '')
    );
    -- Enforce max 20-char limit
    v_username := LEFT(v_username, 20);

    -- Resolve email
    v_email := COALESCE(
        NEW.email,
        v_phone || '@metricwin.app'
    );

    INSERT INTO public.profiles (
        id,
        phone,
        username,
        email,
        balance,
        role
    )
    VALUES (
        NEW.id,
        v_phone,
        v_username,
        v_email,
        0.00,
        'User'
    )
    ON CONFLICT (id) DO NOTHING;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Re-bind the trigger (DROP + CREATE is idempotent via DROP IF EXISTS)
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
