/**
 * Bot Simulator - Simulated bets generator & Lobby count engine
 */

const botUsernames = [
    '2•••8', '2•••0', '2•••9', '2•••2', '2•••7', '2•••1', '2•••3',
    'C•••k', 'A•••n', 'M•••n', 'K•••a', '7•••2', '1•••9', '5•••4',
    '8•••1', 'R•••t', 'V•••x', 'L•••y', 'T•••o', 'S•••r'
];

const avatarsPool = [
    { bg: 'linear-gradient(135deg, #0284c7, #38bdf8)', label: '👤' },
    { bg: 'linear-gradient(135deg, #166534, #22c55e)', label: '👤' },
    { bg: 'linear-gradient(135deg, #991b1b, #ef4444)', label: '👤' },
    { bg: 'linear-gradient(135deg, #6b21a8, #a855f7)', label: '👤' },
    { bg: 'linear-gradient(135deg, #854d0e, #eab308)', label: '👤' },
    { bg: 'linear-gradient(135deg, #1e293b, #475569)', label: '👤' }
];

export function getActivePlayersBadgeValue(roundId) {
    const seed = (roundId || 1) * 9871;
    const base = 2050 + (seed % 1200);
    return base;
}

export function generateSimulatedBetsForRound(roundId) {
    if (!roundId) return [];

    let seed = roundId * 1793;
    function randomVal() {
        seed = (seed * 9301 + 49297) % 233280;
        return seed / 233280;
    }

    const count = 22 + Math.floor(randomVal() * 18);
    const simulatedBets = [];

    for (let i = 0; i < count; i++) {
        const name = botUsernames[Math.floor(randomVal() * botUsernames.length)];
        const rawAmt = randomVal();

        let amount;
        if (rawAmt < 0.35) {
            amount = parseFloat((50 + Math.floor(rawAmt * 450)).toFixed(2));
        } else if (rawAmt < 0.70) {
            amount = parseFloat((500 + Math.floor(rawAmt * 1000)).toFixed(2));
        } else if (rawAmt < 0.90) {
            amount = parseFloat((1250 + Math.floor(rawAmt * 1750)).toFixed(2));
        } else {
            amount = parseFloat((3000 + Math.floor(rawAmt * 2000)).toFixed(2));
        }

        const rawRand = randomVal();
        let cashOutTarget;
        if (rawRand < 0.60) {
            cashOutTarget = parseFloat((1.05 + rawRand * 0.9).toFixed(2));
        } else if (rawRand < 0.88) {
            cashOutTarget = parseFloat((1.6 + (rawRand - 0.60) * 2.2).toFixed(2));
        } else {
            cashOutTarget = parseFloat((2.2 + (rawRand - 0.88) * 15.0).toFixed(2));
        }

        const av = avatarsPool[Math.floor(randomVal() * avatarsPool.length)];

        simulatedBets.push({
            name: name,
            amount: amount,
            isFreeBet: false,
            cashOutTarget: cashOutTarget,
            mult: null,
            win: null,
            status: 'playing',
            avatar: av
        });
    }

    simulatedBets.sort((a, b) => b.amount - a.amount);
    return simulatedBets;
}
