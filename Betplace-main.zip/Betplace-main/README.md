# Betplace#

Betplace is an Aviator-style real-time gaming platform with M-Pesa automated deposits & withdrawals, live flight multipliers, predictor signal telemetry, and comprehensive administration panels.

The platform is completely standalone (**Zero Supabase Dependency**):
- **Frontend**: Vite Multi-Page Application deployed to **Vercel**.
- **Backend**: Express + PostgreSQL + Native WebSockets server deployed to **Render** or a **Linux VPS**.
- **Database**: Pure PostgreSQL (Render PostgreSQL, VPS PostgreSQL, AWS RDS, Neon).

---

## Directory Structure

```
MetroWins/
├── frontend/               # Client-Side Application (Vercel Ready)
│   ├── index.html          # Main Dashboard
│   ├── landing.html        # Public Marketing Landing Page
│   ├── play.html           # Aviator Flight Scene & Betting Controls
│   ├── auth.html           # Player Authentication & Registration
│   ├── admin.html          # Staff Admin Dashboard
│   ├── super-admin.html    # Super Administrator Control Console
│   ├── src/                # Modular client components, audio, and state
│   ├── public/             # PWA icons, manifest, service worker
│   ├── .env.example        # Frontend environment variables (VITE_API_URL only)
│   ├── vercel.json         # Vercel clean URL rewrites & CSP headers
│   └── DEPLOYMENT.md       # Complete Vercel deployment guide
│
└── backend/                # Standalone Server Logic (Render & VPS Ready)
    ├── server.js           # Production Express HTTP & WebSocket server
    ├── api/                # Endpoints (Auth, Game, Wallet, Deposits, Payouts, Admin, Signals)
    ├── schema.sql          # Clean, self-contained PostgreSQL schema & stored procedures
    ├── scripts/migrate.js  # Automated schema runner (npm run db:setup)
    ├── Dockerfile          # Production Docker container
    ├── docker-compose.yml  # Backend + PostgreSQL container setup
    ├── ecosystem.config.cjs# PM2 cluster process file for Linux VPS
    ├── .env.example        # Backend environment variables
    └── DEPLOYMENT.md       # Complete Render & Linux VPS deployment guide
```

---

## Deployment Guides

- **Frontend on Vercel**: See [`frontend/DEPLOYMENT.md`](file:///home/wiseman/Downloads/Metricwin-main/frontend/DEPLOYMENT.md) for step-by-step instructions on deploying the UI to Vercel with custom domains.
- **Backend on Render & VPS**: See [`backend/DEPLOYMENT.md`](file:///home/wiseman/Downloads/Metricwin-main/backend/DEPLOYMENT.md) for step-by-step instructions on setting up Render Web Service or an Ubuntu VPS (PM2, Nginx reverse proxy, and SSL).

---

## Local Development Quickstart

### 1. Backend Setup
```bash
cd backend
cp .env.example .env
# Set DATABASE_URL and JWT_SECRET in .env
npm install
npm run db:setup   # Initializes tables and stored procedures
npm run dev        # Starts server on http://localhost:3000 (Health check: http://localhost:3000/health)
```

### 2. Frontend Setup
```bash
cd frontend
cp .env.example .env
# VITE_API_URL=http://localhost:3000
npm install
npm run dev        # Starts Vite dev server on http://localhost:5173
```

---

## Root Monorepo Commands

- `npm run dev:backend` — Start backend in watch mode
- `npm run dev:frontend` — Start Vite dev server
- `npm run build:frontend` — Build optimized frontend bundle (`frontend/dist`)
- `npm run db:setup` — Initialize PostgreSQL database schema
- `npm run test:game-loop` — Run the 10,000-round game loop simulation
