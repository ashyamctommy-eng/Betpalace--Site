/**
 * Haptic Feedback Controller
 */

export function haptic(type) {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
        const patterns = { 
            light: 10, 
            medium: 30, 
            crash: [50, 50, 50], 
            success: [10, 20, 10] 
        };
        navigator.vibrate(patterns[type] || 10);
    }
}

if (typeof window !== 'undefined') {
    window.haptic = haptic;
}
