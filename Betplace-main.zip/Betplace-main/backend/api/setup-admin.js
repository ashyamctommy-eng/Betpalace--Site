/**
 * backend/api/setup-admin.js
 *
 * Bootstraps the initial Super Admin account using MASTER_SETUP_KEY.
 * Pure PostgreSQL + bcrypt. Zero Supabase.
 */

import { query, getClient } from './_lib/db.js';
import { hashPassword, generateToken, logAdminAction } from './_lib/auth.js';

export default async function setupAdminHandler(req, res) {
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

    const { email, password, phone, secretKey } = req.body || {};
    const clientIp = (req.headers['x-forwarded-for'] || req.socket?.remoteAddress || 'unknown').split(',')[0].trim();

    // 1. IP rate limiting: max 5 calls/hour per IP
    const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    try {
        const { rows: attempts } = await query(
            `SELECT COUNT(*) AS count FROM audit_logs
             WHERE action = 'SETUP_ADMIN_ATTEMPT' AND details->>'ip' = $1 AND created_at >= $2`,
            [clientIp, oneHourAgo]
        );
        if (parseInt(attempts[0]?.count, 10) >= 5) {
            return res.status(429).json({ error: 'Too many setup attempts from this IP. Please try again later.' });
        }
    } catch (_) {}

    await logAdminAction(null, 'SETUP_ADMIN_ATTEMPT', null, { email, ip: clientIp });

    // 2. Check if Super Admin exists
    const { rows: superAdmins } = await query(
        `SELECT ur.user_id FROM user_roles ur
         JOIN roles r ON ur.role_id = r.id
         WHERE r.name = 'Super Admin'
         LIMIT 1`
    );

    const hasSuperAdmin = superAdmins.length > 0;
    const masterKey = process.env.MASTER_SETUP_KEY;

    if (hasSuperAdmin && (!secretKey || secretKey !== masterKey)) {
        await logAdminAction(null, 'UNAUTHORIZED_SETUP_ADMIN_ATTEMPT', null, { email, ip: clientIp });
        return res.status(403).json({
            error: 'Super Admin already initialized. Valid secretKey required to create another administrator.'
        });
    }

    if (!hasSuperAdmin && secretKey && masterKey && secretKey !== masterKey) {
        return res.status(403).json({ error: 'Invalid secret key.' });
    }

    if (!phone || !password) {
        return res.status(400).json({ error: 'Phone and password are required.' });
    }

    const cleanPhone = String(phone).replace(/[\s\-()]/g, '');
    const cleanEmail = email ? email.trim().toLowerCase() : `admin_${cleanPhone.slice(-4)}@metrowins.app`;
    const cleanUsername = `superadmin_${cleanPhone.slice(-4)}`;

    const client = await getClient();

    try {
        await client.query('BEGIN');

        const passwordHash = await hashPassword(password);

        // Upsert profile
        const { rows: profileRows } = await client.query(
            `INSERT INTO profiles (phone, email, username, password_hash, balance)
             VALUES ($1, $2, $3, $4, 1000.00)
             ON CONFLICT (phone) DO UPDATE
             SET password_hash = EXCLUDED.password_hash, updated_at = NOW()
             RETURNING id, phone, email, username, balance`,
            [cleanPhone, cleanEmail, cleanUsername, passwordHash]
        );

        const adminUser = profileRows[0];

        // Ensure Super Admin role exists
        const { rows: roleRows } = await client.query("SELECT id FROM roles WHERE name = 'Super Admin'");
        let superAdminRoleId;
        if (roleRows.length > 0) {
            superAdminRoleId = roleRows[0].id;
        } else {
            const { rows: newRole } = await client.query(
                "INSERT INTO roles (name, description) VALUES ('Super Admin', 'Full platform control') RETURNING id"
            );
            superAdminRoleId = newRole[0].id;
        }

        // Assign Super Admin role
        await client.query(
            `INSERT INTO user_roles (user_id, role_id)
             VALUES ($1, $2)
             ON CONFLICT (user_id, role_id) DO NOTHING`,
            [adminUser.id, superAdminRoleId]
        );

        await client.query('COMMIT');

        const token = generateToken({
            id: adminUser.id,
            phone: adminUser.phone,
            email: adminUser.email,
            username: adminUser.username,
            role: 'Super Admin'
        });

        await logAdminAction(adminUser.id, 'SUPER_ADMIN_SETUP_SUCCESS', adminUser.id, { email: cleanEmail });

        return res.status(200).json({
            success: true,
            message: 'Super Admin account created and granted full system permissions successfully.',
            token,
            user: {
                id: adminUser.id,
                email: adminUser.email,
                phone: adminUser.phone,
                username: adminUser.username,
                role: 'Super Admin'
            }
        });
    } catch (err) {
        await client.query('ROLLBACK');
        console.error('[Setup Admin Error]:', err);
        return res.status(500).json({ error: 'Failed to create Super Admin: ' + err.message });
    } finally {
        client.release();
    }
}
