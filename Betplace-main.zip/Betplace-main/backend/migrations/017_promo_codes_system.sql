-- ============================================================
-- 017_promo_codes_system.sql
-- Promo Codes System with brute-force / rate-limit protection
-- Run this in Supabase SQL Editor (Dashboard → SQL Editor → New Query)
-- ============================================================

-- ── 1. PROMO CODES TABLE ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.promo_codes (
    id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    code         TEXT        UNIQUE NOT NULL,
    amount       DECIMAL     NOT NULL DEFAULT 0 CHECK (amount > 0),
    max_uses     INT         NOT NULL DEFAULT 1 CHECK (max_uses > 0),
    current_uses INT         NOT NULL DEFAULT 0,
    require_deposit BOOLEAN  NOT NULL DEFAULT FALSE,
    created_at   TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.promo_codes ADD COLUMN IF NOT EXISTS require_deposit BOOLEAN NOT NULL DEFAULT FALSE;

-- Index for fast case-insensitive lookups
CREATE UNIQUE INDEX IF NOT EXISTS idx_promo_codes_upper_code
    ON public.promo_codes (UPPER(code));

-- ── 2. PROMO CODE CLAIMS TABLE ───────────────────────────────
-- Tracks which user has claimed which code (one claim per user per code)
CREATE TABLE IF NOT EXISTS public.promo_code_claims (
    id            UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    promo_code_id UUID        NOT NULL REFERENCES public.promo_codes(id) ON DELETE CASCADE,
    user_id       UUID        NOT NULL REFERENCES public.profiles(id)    ON DELETE CASCADE,
    claimed_at    TIMESTAMPTZ DEFAULT now(),
    UNIQUE (promo_code_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_promo_claims_user
    ON public.promo_code_claims (user_id);

-- ── 3. PROMO CODE FAILED ATTEMPTS TABLE (brute-force guard) ──
-- Each row is throttled per (user_id, window).
-- A user is blocked from trying codes for 15 minutes after 5 wrong tries.
CREATE TABLE IF NOT EXISTS public.promo_code_attempts (
    id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     UUID        NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    attempted_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_promo_attempts_user_time
    ON public.promo_code_attempts (user_id, attempted_at DESC);

-- Auto-clean old rows nightly (optional; keeps the table lean)
-- If you have pg_cron enabled: SELECT cron.schedule('clean-promo-attempts', '0 3 * * *', $$DELETE FROM public.promo_code_attempts WHERE attempted_at < now() - INTERVAL '24 hours'$$);

-- ── 4. RLS POLICIES ──────────────────────────────────────────
-- promo_codes: only service role can read/write (all via RPC)
ALTER TABLE public.promo_codes     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.promo_code_claims ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.promo_code_attempts ENABLE ROW LEVEL SECURITY;

-- Users need NO direct table access — everything goes through SECURITY DEFINER RPCs
-- Admins access via the service-role key in API endpoints (bypasses RLS anyway)

-- Allow authenticated users to read their own claims (e.g. for display)
DO $$ BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_policies
        WHERE schemaname='public' AND tablename='promo_code_claims' AND policyname='Users can read own claims'
    ) THEN
        CREATE POLICY "Users can read own claims"
        ON public.promo_code_claims FOR SELECT
        USING (user_id = auth.uid());
    END IF;
END $$;

-- ── 5. ATOMIC CLAIM RPC (with brute-force protection) ────────
CREATE OR REPLACE FUNCTION public.claim_promo_code(p_user_id UUID, p_code TEXT)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_promo_id        UUID;
    v_amount          DECIMAL;
    v_max_uses        INT;
    v_current_uses    INT;
    v_already_claimed INT;
    v_recent_fails    INT;
    v_require_deposit BOOLEAN;
    v_window_minutes  CONSTANT INT := 15;  -- lockout window
    v_max_attempts    CONSTANT INT := 5;   -- max wrong tries before lockout
BEGIN
    -- ── Guard 1: user profile must exist ──
    IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = p_user_id) THEN
        RETURN json_build_object('success', false, 'error', 'User profile not found');
    END IF;

    -- ── Guard 2: brute-force rate limit ──
    -- Count failed attempts by this user in the last [v_window_minutes] minutes
    SELECT COUNT(*) INTO v_recent_fails
    FROM public.promo_code_attempts
    WHERE user_id = p_user_id
      AND attempted_at > now() - (v_window_minutes || ' minutes')::INTERVAL;

    IF v_recent_fails >= v_max_attempts THEN
        RETURN json_build_object(
            'success', false,
            'error',   'Too many failed attempts. Please wait ' || v_window_minutes || ' minutes before trying again.'
        );
    END IF;

    -- ── Lookup the code (exact, case-insensitive) ──
    SELECT id, amount, max_uses, current_uses, require_deposit
    INTO   v_promo_id, v_amount, v_max_uses, v_current_uses, v_require_deposit
    FROM   public.promo_codes
    WHERE  UPPER(code) = UPPER(p_code);

    -- ── Guard 3: code not found → log failed attempt ──
    IF v_promo_id IS NULL THEN
        INSERT INTO public.promo_code_attempts (user_id) VALUES (p_user_id);
        -- Tell the user how many tries remain (don't confirm whether code exists)
        RETURN json_build_object(
            'success', false,
            'error',   'Invalid promo code. ' || (v_max_attempts - v_recent_fails - 1) || ' attempt(s) remaining before temporary lockout.'
        );
    END IF;

    -- ── Guard 3.5: deposit requirement ──
    IF v_require_deposit IS TRUE THEN
        IF NOT EXISTS (
            SELECT 1 FROM public.transactions 
            WHERE user_id = p_user_id 
              AND type = 'deposit' 
              AND status = 'completed'
              AND reference NOT LIKE 'PROMO-%'
              AND reference NOT LIKE 'SIGNUP-%'
              AND reference NOT LIKE 'REFERRAL-%'
        ) THEN
            RETURN json_build_object('success', false, 'error', 'You must have made at least one deposit to claim this promo code');
        END IF;
    END IF;

    -- ── Guard 4: code exhausted ──
    IF v_current_uses >= v_max_uses THEN
        RETURN json_build_object('success', false, 'error', 'This promo code has reached its usage limit');
    END IF;

    -- ── Guard 5: user already claimed this code ──
    SELECT COUNT(*) INTO v_already_claimed
    FROM public.promo_code_claims
    WHERE promo_code_id = v_promo_id AND user_id = p_user_id;

    IF v_already_claimed > 0 THEN
        RETURN json_build_object('success', false, 'error', 'You have already claimed this promo code');
    END IF;

    -- ── Atomically increment usage (race-condition safe) ──
    UPDATE public.promo_codes
    SET    current_uses = current_uses + 1
    WHERE  id = v_promo_id AND current_uses < max_uses;

    IF NOT FOUND THEN
        RETURN json_build_object('success', false, 'error', 'Promo code limit exceeded by another user. Try another code.');
    END IF;

    -- ── Record the claim ──
    INSERT INTO public.promo_code_claims (promo_code_id, user_id)
    VALUES (v_promo_id, p_user_id);

    -- ── Credit the user's balance ──
    UPDATE public.profiles
    SET balance = balance + v_amount
    WHERE id = p_user_id;

    -- ── Audit ledger entry ──
    INSERT INTO public.transactions (user_id, type, amount, status, reference)
    VALUES (
        p_user_id,
        'deposit',
        v_amount,
        'completed',
        'PROMO-' || UPPER(p_code) || '-' || substring(md5(random()::text), 1, 8)
    );

    -- ── On success: clear this user's failed attempts (reset the counter) ──
    DELETE FROM public.promo_code_attempts WHERE user_id = p_user_id;

    RETURN json_build_object('success', true, 'amount', v_amount);

EXCEPTION
    WHEN OTHERS THEN
        RETURN json_build_object('success', false, 'error', SQLERRM);
END;
$$;

-- ── 6. NOTIFY PG REST TO RELOAD SCHEMA ───────────────────────
NOTIFY pgrst, 'reload schema';
