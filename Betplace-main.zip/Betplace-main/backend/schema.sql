-- ==============================================================================
-- METROWINS / METRICWIN POSTGRESQL SCHEMA (ZERO SUPABASE DEPENDENCY)
-- Production Ready for Render PostgreSQL, VPS PostgreSQL, AWS RDS, Neon
-- ==============================================================================

-- Enable UUID extension if available
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ── 1. ROLES & PERMISSIONS ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS roles (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS permissions (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT
);

CREATE TABLE IF NOT EXISTS role_permissions (
    role_id INT REFERENCES roles(id) ON DELETE CASCADE,
    permission_id INT REFERENCES permissions(id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);

-- ── 2. PROFILES / USERS ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    phone VARCHAR(20) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE,
    username VARCHAR(50) UNIQUE,
    password_hash TEXT NOT NULL,
    balance NUMERIC(14, 2) DEFAULT 0.00 CHECK (balance >= 0),
    is_frozen BOOLEAN DEFAULT FALSE,
    referred_by UUID REFERENCES profiles(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS user_roles (
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    role_id INT REFERENCES roles(id) ON DELETE CASCADE,
    assigned_by UUID REFERENCES profiles(id) ON DELETE SET NULL,
    assigned_at TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (user_id, role_id)
);

-- ── 3. ACTIVE GAME STATE & CRASH HISTORY ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS active_game_state (
    id INT PRIMARY KEY DEFAULT 1,
    round_id BIGINT DEFAULT 1,
    start_time TIMESTAMPTZ DEFAULT NOW(),
    crash_point NUMERIC(8, 2) DEFAULT 2.00,
    status VARCHAR(20) DEFAULT 'waiting', -- waiting, playing, crashed
    server_time TIMESTAMPTZ DEFAULT NOW(),
    next_crash_point NUMERIC(8, 2) DEFAULT NULL,
    CONSTRAINT single_row CHECK (id = 1)
);

CREATE TABLE IF NOT EXISTS crash_history (
    round_id BIGINT PRIMARY KEY,
    crash_point NUMERIC(8, 2) NOT NULL,
    server_seed TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── 4. BETS ───────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS bets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
    round_id BIGINT NOT NULL,
    amount NUMERIC(12, 2) NOT NULL CHECK (amount >= 10),
    auto_cashout NUMERIC(8, 2) DEFAULT NULL,
    multiplier NUMERIC(8, 2) DEFAULT NULL,
    cashout_multiplier NUMERIC(8, 2) DEFAULT NULL,
    payout NUMERIC(12, 2) DEFAULT 0.00,
    status VARCHAR(20) DEFAULT 'active', -- active, cashed_out, lost, cancelled
    created_at TIMESTAMPTZ DEFAULT NOW(),
    cashed_out_at TIMESTAMPTZ DEFAULT NULL
);

-- ── 5. TRANSACTIONS & AUDIT LOGS ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
    type VARCHAR(30) NOT NULL, -- deposit, withdrawal, bet, payout, bonus, referral
    amount NUMERIC(12, 2) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending', -- pending, completed, failed, refunded
    reference VARCHAR(100) UNIQUE,
    phone VARCHAR(20),
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS audit_logs (
    id BIGSERIAL PRIMARY KEY,
    admin_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    action VARCHAR(100) NOT NULL,
    target_id UUID,
    details JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── 6. PROMOTIONS & PROMO CODES ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS promo_codes (
    id SERIAL PRIMARY KEY,
    code VARCHAR(50) UNIQUE NOT NULL,
    amount NUMERIC(10, 2) NOT NULL CHECK (amount > 0),
    max_uses INT DEFAULT 100,
    current_uses INT DEFAULT 0,
    require_deposit BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS promo_code_redemptions (
    id BIGSERIAL PRIMARY KEY,
    promo_code_id INT REFERENCES promo_codes(id) ON DELETE CASCADE,
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    amount NUMERIC(10, 2) NOT NULL,
    redeemed_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT one_redemption_per_user UNIQUE (promo_code_id, user_id)
);

CREATE TABLE IF NOT EXISTS promo_code_attempts (
    id BIGSERIAL PRIMARY KEY,
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    attempted_code VARCHAR(50),
    attempted_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS promotions (
    id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    image_url TEXT,
    action_type VARCHAR(50),
    action_url TEXT,
    badge_text VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS system_settings (
    key VARCHAR(50) PRIMARY KEY,
    value JSONB NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS password_resets (
    id BIGSERIAL PRIMARY KEY,
    phone VARCHAR(20) NOT NULL,
    otp_hash TEXT NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    used BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ── 7. INDEXES ────────────────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_bets_round_id ON bets(round_id);
CREATE INDEX IF NOT EXISTS idx_bets_user_id ON bets(user_id);
CREATE INDEX IF NOT EXISTS idx_transactions_user_id ON transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_crash_history_round_id ON crash_history(round_id DESC);

-- ── 8. SEEDS ──────────────────────────────────────────────────────────────────
INSERT INTO roles (name, description) VALUES
    ('Super Admin', 'Full unrestricted platform access'),
    ('Admin', 'Staff access to users and content'),
    ('Agent', 'Affiliate and referral management'),
    ('Player', 'Standard gaming player')
ON CONFLICT (name) DO NOTHING;

INSERT INTO permissions (name, description) VALUES
    ('all_access', 'Super Admin full access'),
    ('manage_users', 'Can view, freeze, edit users'),
    ('manage_finances', 'Can manage ledger and transactions'),
    ('manage_admins', 'Can assign and modify admin roles'),
    ('view_signals', 'Access to predictor signals')
ON CONFLICT (name) DO NOTHING;

-- Grant permissions to Super Admin role
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r CROSS JOIN permissions p
WHERE r.name = 'Super Admin'
ON CONFLICT DO NOTHING;

-- Initialize active_game_state row
INSERT INTO active_game_state (id, round_id, start_time, crash_point, status, server_time)
VALUES (1, 1, NOW(), 2.00, 'waiting', NOW())
ON CONFLICT (id) DO NOTHING;

-- Initialize system settings
INSERT INTO system_settings (key, value) VALUES
    ('support', '{"whatsapp": "+254700000000", "email": "support@metrowins.app", "telegram": "@metrowins"}'::jsonb),
    ('community', '{"telegram_channel": "https://t.me/metrowins", "whatsapp_group": ""}'::jsonb),
    ('game_limits', '{"min_bet": 10, "max_bet": 50000, "min_withdrawal": 200, "max_withdrawal": 100000}'::jsonb)
ON CONFLICT (key) DO NOTHING;

-- ── 9. STORED PROCEDURES / BUSINESS LOGIC (PURE PL/PGSQL) ─────────────────────

-- Checks if a user has a specific permission
CREATE OR REPLACE FUNCTION has_permission(p_user_id UUID, p_permission VARCHAR)
RETURNS BOOLEAN AS $$
DECLARE
    v_has BOOLEAN := FALSE;
BEGIN
    SELECT EXISTS (
        SELECT 1
        FROM user_roles ur
        JOIN role_permissions rp ON ur.role_id = rp.role_id
        JOIN permissions p ON rp.permission_id = p.id
        WHERE ur.user_id = p_user_id
          AND (p.name = p_permission OR p.name = 'all_access')
    ) INTO v_has;

    RETURN v_has;
END;
$$ LANGUAGE plpgsql;

-- Total Gross Gaming Revenue calculation
CREATE OR REPLACE FUNCTION calculate_total_ggr()
RETURNS NUMERIC AS $$
DECLARE
    v_total_in NUMERIC := 0;
    v_total_out NUMERIC := 0;
BEGIN
    SELECT COALESCE(SUM(amount), 0) INTO v_total_in FROM bets WHERE status IN ('cashed_out', 'lost');
    SELECT COALESCE(SUM(payout), 0) INTO v_total_out FROM bets WHERE status = 'cashed_out';
    RETURN v_total_in - v_total_out;
END;
$$ LANGUAGE plpgsql;

-- Generates crash point using deterministic algorithm
CREATE OR REPLACE FUNCTION generate_crash_multiplier(p_round_id BIGINT)
RETURNS NUMERIC AS $$
DECLARE
    v_seed BIGINT;
    v_rnd NUMERIC;
BEGIN
    v_seed := (p_round_id * 9301 + 49297) % 233280;
    v_rnd := (v_seed::NUMERIC) / 233280.0;

    -- Aviator crash curve distribution
    IF v_rnd < 0.04 THEN
        RETURN 1.00;
    ELSIF v_rnd < 0.45 THEN
        RETURN ROUND(1.01 + ((v_rnd * 10.0) % 1.0) * 0.98, 2);
    ELSIF v_rnd < 0.80 THEN
        RETURN ROUND(2.00 + ((v_rnd * 100.0) % 1.0) * 3.00, 2);
    ELSIF v_rnd < 0.95 THEN
        RETURN ROUND(5.00 + ((v_rnd * 100.0) % 1.0) * 15.00, 2);
    ELSE
        RETURN ROUND(20.00 + ((v_rnd * 100.0) % 1.0) * 80.00, 2);
    END IF;
END;
$$ LANGUAGE plpgsql;

-- Serverless Authoritative Game Loop: Advances phase and returns authoritative state
CREATE OR REPLACE FUNCTION sync_and_get_game_state()
RETURNS JSON AS $$
DECLARE
    v_state RECORD;
    v_now TIMESTAMPTZ := NOW();
    v_elapsed_ms INT;
    v_waiting_duration_ms INT := 5000;
    v_post_crash_duration_ms INT := 2500;
    v_growth_rate NUMERIC := 1.06;
    v_current_mult NUMERIC;
    v_flight_sec NUMERIC;
    v_max_duration_ms INT;
    v_new_crash_point NUMERIC;
BEGIN
    -- Row lock to synchronize state transitions
    SELECT * INTO v_state FROM active_game_state WHERE id = 1 FOR UPDATE;

    IF v_state IS NULL THEN
        INSERT INTO active_game_state (id, round_id, start_time, crash_point, status, server_time)
        VALUES (1, 1, v_now, 2.00, 'waiting', v_now)
        RETURNING * INTO v_state;
    END IF;

    v_elapsed_ms := EXTRACT(EPOCH FROM (v_now - v_state.start_time)) * 1000;

    -- State Machine Transitions
    IF v_state.status = 'waiting' THEN
        IF v_elapsed_ms >= v_waiting_duration_ms THEN
            -- Transition: waiting -> playing
            UPDATE active_game_state
            SET status = 'playing',
                start_time = v_now,
                server_time = v_now
            WHERE id = 1
            RETURNING * INTO v_state;
            v_elapsed_ms := 0;
        END IF;

    ELSIF v_state.status = 'playing' THEN
        -- Calculate flight time and multiplier
        v_flight_sec := v_elapsed_ms / 1000.0;
        v_current_mult := ROUND(POWER(v_growth_rate, v_flight_sec)::NUMERIC, 2);

        -- Check crash condition
        IF v_current_mult >= v_state.crash_point THEN
            -- Transition: playing -> crashed
            UPDATE active_game_state
            SET status = 'crashed',
                start_time = v_now,
                server_time = v_now
            WHERE id = 1
            RETURNING * INTO v_state;

            -- Mark lost bets
            UPDATE bets
            SET status = 'lost'
            WHERE round_id = v_state.round_id AND status = 'active';

            -- Record in crash history
            INSERT INTO crash_history (round_id, crash_point, created_at)
            VALUES (v_state.round_id, v_state.crash_point, v_now)
            ON CONFLICT (round_id) DO NOTHING;

            v_elapsed_ms := 0;
        END IF;

    ELSIF v_state.status = 'crashed' THEN
        IF v_elapsed_ms >= v_post_crash_duration_ms THEN
            -- Transition: crashed -> waiting (New Round)
            IF v_state.next_crash_point IS NOT NULL THEN
                v_new_crash_point := v_state.next_crash_point;
            ELSE
                v_new_crash_point := generate_crash_multiplier(v_state.round_id + 1);
            END IF;

            UPDATE active_game_state
            SET round_id = v_state.round_id + 1,
                status = 'waiting',
                crash_point = v_new_crash_point,
                next_crash_point = NULL,
                start_time = v_now,
                server_time = v_now
            WHERE id = 1
            RETURNING * INTO v_state;
            v_elapsed_ms := 0;
        END IF;
    END IF;

    RETURN json_build_object(
        'roundId', v_state.round_id,
        'roundStartTime', EXTRACT(EPOCH FROM v_state.start_time) * 1000,
        'crashPoint', v_state.crash_point,
        'gameStatus', v_state.status,
        'serverTime', EXTRACT(EPOCH FROM v_now) * 1000,
        'elapsedMs', v_elapsed_ms
    );
END;
$$ LANGUAGE plpgsql;

-- Place Bet RPC
CREATE OR REPLACE FUNCTION place_bet(
    p_user_id UUID,
    p_round_id BIGINT,
    p_amount NUMERIC,
    p_auto_cashout NUMERIC DEFAULT NULL
)
RETURNS JSON AS $$
DECLARE
    v_balance NUMERIC;
    v_is_frozen BOOLEAN;
    v_status VARCHAR;
    v_bet_id UUID;
BEGIN
    -- Check user balance and frozen state
    SELECT balance, is_frozen INTO v_balance, v_is_frozen
    FROM profiles WHERE id = p_user_id FOR UPDATE;

    IF v_is_frozen THEN
        RETURN json_build_object('success', false, 'error', 'Account is frozen.');
    END IF;

    IF v_balance < p_amount THEN
        RETURN json_build_object('success', false, 'error', 'Insufficient balance.');
    END IF;

    -- Verify current game state is 'waiting'
    SELECT status INTO v_status FROM active_game_state WHERE id = 1;
    IF v_status != 'waiting' THEN
        RETURN json_build_object('success', false, 'error', 'Bets can only be placed during the waiting phase.');
    END IF;

    -- Deduct balance
    UPDATE profiles SET balance = balance - p_amount, updated_at = NOW() WHERE id = p_user_id;

    -- Insert bet record
    INSERT INTO bets (user_id, round_id, amount, auto_cashout, status)
    VALUES (p_user_id, p_round_id, p_amount, p_auto_cashout, 'active')
    RETURNING id INTO v_bet_id;

    -- Record transaction
    INSERT INTO transactions (user_id, type, amount, status, metadata)
    VALUES (p_user_id, 'bet', p_amount, 'completed', json_build_object('bet_id', v_bet_id, 'round_id', p_round_id));

    RETURN json_build_object(
        'success', true,
        'betId', v_bet_id,
        'newBalance', v_balance - p_amount
    );
END;
$$ LANGUAGE plpgsql;

-- Cash Out RPC
CREATE OR REPLACE FUNCTION cash_out(
    p_user_id UUID,
    p_bet_id UUID,
    p_multiplier NUMERIC
)
RETURNS JSON AS $$
DECLARE
    v_bet RECORD;
    v_game RECORD;
    v_payout NUMERIC;
    v_new_balance NUMERIC;
BEGIN
    -- Lock bet
    SELECT * INTO v_bet FROM bets WHERE id = p_bet_id AND user_id = p_user_id FOR UPDATE;
    IF v_bet IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Bet not found.');
    END IF;

    IF v_bet.status != 'active' THEN
        RETURN json_build_object('success', false, 'error', 'Bet is not active.');
    END IF;

    -- Verify game is still playing
    SELECT * INTO v_game FROM active_game_state WHERE id = 1;
    IF v_game.status != 'playing' THEN
        RETURN json_build_object('success', false, 'error', 'Round has already ended.');
    END IF;

    IF p_multiplier > v_game.crash_point THEN
        RETURN json_build_object('success', false, 'error', 'Plane already flew away.');
    END IF;

    v_payout := ROUND(v_bet.amount * p_multiplier, 2);

    -- Update bet
    UPDATE bets
    SET status = 'cashed_out',
        cashout_multiplier = p_multiplier,
        payout = v_payout,
        cashed_out_at = NOW()
    WHERE id = p_bet_id;

    -- Credit user balance
    UPDATE profiles
    SET balance = balance + v_payout,
        updated_at = NOW()
    WHERE id = p_user_id
    RETURNING balance INTO v_new_balance;

    -- Record transaction
    INSERT INTO transactions (user_id, type, amount, status, metadata)
    VALUES (p_user_id, 'payout', v_payout, 'completed', json_build_object('bet_id', p_bet_id, 'multiplier', p_multiplier));

    RETURN json_build_object(
        'success', true,
        'payout', v_payout,
        'multiplier', p_multiplier,
        'newBalance', v_new_balance
    );
END;
$$ LANGUAGE plpgsql;

-- Cancel Bet RPC
CREATE OR REPLACE FUNCTION cancel_bet(
    p_user_id UUID,
    p_bet_id UUID
)
RETURNS JSON AS $$
DECLARE
    v_bet RECORD;
    v_game RECORD;
    v_new_balance NUMERIC;
BEGIN
    SELECT * INTO v_bet FROM bets WHERE id = p_bet_id AND user_id = p_user_id FOR UPDATE;
    IF v_bet IS NULL OR v_bet.status != 'active' THEN
        RETURN json_build_object('success', false, 'error', 'Active bet not found.');
    END IF;

    -- Can only cancel while game is in waiting phase
    SELECT status INTO v_game FROM active_game_state WHERE id = 1;
    IF v_game.status != 'waiting' THEN
        RETURN json_build_object('success', false, 'error', 'Cannot cancel bet once the round begins.');
    END IF;

    -- Mark cancelled
    UPDATE bets SET status = 'cancelled' WHERE id = p_bet_id;

    -- Refund balance
    UPDATE profiles
    SET balance = balance + v_bet.amount,
        updated_at = NOW()
    WHERE id = p_user_id
    RETURNING balance INTO v_new_balance;

    RETURN json_build_object(
        'success', true,
        'refunded', v_bet.amount,
        'newBalance', v_new_balance
    );
END;
$$ LANGUAGE plpgsql;
