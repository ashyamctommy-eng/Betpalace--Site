/**
 * frontend/src/utils/analytics.js
 *
 * Analytics stub — Vercel Analytics removed (Phase 3 Cloudflare migration).
 * This file retains the same export signature so all callers continue to
 * compile without changes.
 *
 * If a provider-neutral analytics solution is adopted in future (e.g., Plausible
 * or Cloudflare Web Analytics via a beacon snippet), it should be wired in here.
 */

// No-op: previously injected @vercel/analytics. Safe to call anywhere.
export function injectVercelAnalytics() {
  // intentionally empty — Vercel Analytics removed
}
