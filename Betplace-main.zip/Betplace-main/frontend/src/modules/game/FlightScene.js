/**
 * FlightScene.js — Phaser 3 Flight Animation Scene
 *
 * Responsibilities:
 *   - Render the Bézier flight curve
 *   - Position and animate the plane sprite
 *   - Spin the propeller
 *   - Emit jet exhaust particles
 *   - Trigger crash fly-away animation
 *
 * Data contract:
 *   READS from gameBridge:  gameState, currentMultiplier, serverRoundStartTime, serverTimeOffset
 *   WRITES to gameBridge:   bezierT, planeX, planeY (for debug panel only)
 *
 * FIX NOTES (v2 — sync overhaul):
 *   - Replaced exponential decay curve formula (which plateaued at ~10x) with a
 *     rational function  t = 0.96 * (mult-1) / (mult-1 + 5.0)  that keeps the
 *     plane moving across the full canvas for any multiplier up to 200x+.
 *   - Frame-rate independent lerp using capped deltaTime so 30/60/120/144 FPS
 *     all produce identical smooth motion.
 *   - Snap to target on cold-start or mid-flight reconnect (currentT === 0).
 *   - GSAP interference removed — no external library fights the lerp.
 */

import { gameBridge } from './gameBridge.js';

let flightSceneInstance = null;

export class FlightScene extends Phaser.Scene {
    constructor() {
        super({ key: 'FlightScene' });
        this.currentT = 0;
        this.targetT  = 0;
    }

    preload() {
        // ── Aviator red plane — faithful SVG of the Spribe Aviator logo aircraft ──
        // Top-wing monoplane, faces right, nose-up climbing attitude.
        // Large round engine cowl, swept-back top wing, 4-blade yellow propeller.
        const planeBody = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 260 120" width="260" height="120">
  <!-- Shadow/depth layer -->
  <ellipse cx="130" cy="80" rx="100" ry="12" fill="#000" opacity="0.12"/>

  <!-- Tail horizontal stabilizer -->
  <path d="M 14,58 L 14,40 Q 18,38 24,40 L 48,55 L 48,58 Z" fill="#CC001A"/>
  <path d="M 14,62 L 14,80 Q 18,82 24,80 L 48,65 L 48,62 Z" fill="#AA0015"/>

  <!-- Tail vertical fin -->
  <path d="M 14,60 L 28,25 Q 32,18 38,20 L 52,58 Z" fill="#E8001E"/>
  <path d="M 36,22 L 50,55 L 52,58 L 38,20 Z" fill="#C0001A"/>

  <!-- Main fuselage — long torpedo shape -->
  <path d="M 22,52 Q 28,38 52,36 L 190,36 Q 215,37 228,58 Q 215,79 190,80 L 52,80 Q 28,78 22,68 Z"
        fill="#E8001E" stroke="#C0001A" stroke-width="1.5"/>
  <!-- Fuselage underside shading -->
  <path d="M 22,66 Q 28,78 52,80 L 190,80 Q 215,79 228,58 Q 220,68 200,72 L 56,74 Q 34,74 22,66 Z"
        fill="#B80018" opacity="0.6"/>
  <!-- Fuselage top highlight -->
  <path d="M 30,52 Q 40,41 60,40 L 185,40 Q 205,41 218,52 Q 205,44 185,43 L 62,43 Q 42,44 30,52 Z"
        fill="#FF3355" opacity="0.35"/>

  <!-- Top wing — single large swept-back monoplane wing -->
  <path d="M 90,36 L 72,5 Q 76,2 86,3 L 145,36 Z" fill="#E8001E" stroke="#C0001A" stroke-width="1"/>
  <path d="M 145,36 L 86,3 Q 96,2 105,4 L 152,36 Z" fill="#C0001A"/>
  <!-- Wing underside detail -->
  <path d="M 92,36 L 75,9 Q 78,6 82,6 L 92,36 Z" fill="#FF3355" opacity="0.3"/>

  <!-- Wing strut -->
  <rect x="108" y="3" width="5" height="33" rx="2" fill="#FFCC00"/>

  <!-- Cockpit canopy -->
  <ellipse cx="172" cy="53" rx="22" ry="14" fill="#0d1b3e" stroke="#C0001A" stroke-width="2"/>
  <ellipse cx="175" cy="50" rx="13" ry="9" fill="#1a3a8a" opacity="0.95"/>
  <ellipse cx="180" cy="47" rx="6" ry="5" fill="#5b9bd5" opacity="0.7"/>
  <ellipse cx="183" cy="45" rx="3" ry="2.5" fill="#aad4f5" opacity="0.5"/>

  <!-- Engine cowl (round, prominent) -->
  <ellipse cx="224" cy="58" rx="20" ry="19" fill="#CC001A" stroke="#AA0015" stroke-width="1.5"/>
  <ellipse cx="231" cy="58" rx="12" ry="11" fill="#AA0015"/>
  <ellipse cx="236" cy="58" rx="6" ry="6" fill="#880012"/>

  <!-- Propeller hub -->
  <circle cx="242" cy="58" r="6.5" fill="#1a1a1a"/>
  <circle cx="242" cy="58" r="4" fill="#FFCC00"/>
  <circle cx="242" cy="58" r="2" fill="#222"/>

  <!-- Exhaust pipes under cowl -->
  <rect x="210" y="76" width="14" height="4" rx="2" fill="#660010"/>
  <rect x="207" y="72" width="8" height="3" rx="1.5" fill="#880012"/>
</svg>`;
        this.load.svg('plane', 'data:image/svg+xml;base64,' + btoa(planeBody));

        // ── 4-blade yellow propeller matching the Aviator logo ──
        const propSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="-40 -40 80 80" width="80" height="80">
  <!-- Blade 1 - up -->
  <path d="M -5,-6 Q -9,-22 -5,-38 Q 0,-40 5,-38 Q 9,-22 5,-6 Z" fill="#FFCC00" stroke="#D4A800" stroke-width="0.5"/>
  <!-- Blade 2 - right -->
  <path d="M 6,-5 Q 22,-9 38,-5 Q 40,0 38,5 Q 22,9 6,5 Z" fill="#FFCC00" stroke="#D4A800" stroke-width="0.5"/>
  <!-- Blade 3 - down -->
  <path d="M 5,6 Q 9,22 5,38 Q 0,40 -5,38 Q -9,22 -5,6 Z" fill="#FFCC00" stroke="#D4A800" stroke-width="0.5"/>
  <!-- Blade 4 - left -->
  <path d="M -6,5 Q -22,9 -38,5 Q -40,0 -38,-5 Q -22,-9 -6,-5 Z" fill="#FFCC00" stroke="#D4A800" stroke-width="0.5"/>
  <!-- Center hub -->
  <circle r="8" fill="#1a1a1a"/>
  <circle r="5" fill="#FFCC00"/>
  <circle r="2.5" fill="#333"/>
</svg>`;
        this.load.svg('propeller', 'data:image/svg+xml;base64,' + btoa(propSvg));
    }

    create() {
        flightSceneInstance = this;
        this.graphics = this.add.graphics();
        this.crashAnimActive = false;
        this.crashTimer = 0;
        this.propAngle  = 0;

        const pg = this.make.graphics({ x: 0, y: 0, add: false });
        pg.fillStyle(0xFF4400, 1);
        pg.fillCircle(10, 10, 10);
        pg.generateTexture('jet_particle', 20, 20);
        pg.destroy();

        this.plane = this.add.sprite(0, 0, 'plane');
        this.plane.setOrigin(0.5, 0.5);
        this.plane.setScale(0.55);
        this.plane.setVisible(false);

        try {
            this.plane.postFX.addGlow(0xFF0022, 6, 0, false, 0.06, 12);
        } catch (_) {}

        this.propeller = this.add.sprite(0, 0, 'propeller');
        this.propeller.setOrigin(0.5, 0.5);
        this.propeller.setScale(0.55);
        this.propeller.setVisible(false);
        this.propeller.setAlpha(0.85);

        this.exhaustParticles = this.add.particles(0, 0, 'jet_particle', {
            lifespan:  { min: 300, max: 600 },
            scale:     { start: 0.45, end: 0.0 },
            alpha:     { start: 0.7, end: 0.0 },
            blendMode: 'ADD',
            tint:      [0xFFCC00, 0xFF8800, 0xFF4400, 0xFFAA00],
            speed:     { min: 30, max: 90 },
            frequency: 15,
            emitting:  false
        });
    }

    triggerCrashFlyAway(x, y, angle) {
        this.crashAnimActive = true;
        this.crashTimer = 0;
        this.flyAwayX = x;
        this.flyAwayY = y;

        const baseSpeed = 480;
        this.flyAwayVx = Math.cos(angle) * baseSpeed + 350;
        this.flyAwayVy = Math.sin(angle) * baseSpeed - 250;

        this.plane.setVisible(true);
        this.propeller.setVisible(true);
        this.plane.setAlpha(1);
        this.plane.setScale(0.75);
        this.propeller.setAlpha(1);
        this.propeller.setScale(0.5);

        this.exhaustParticles.start();
    }

    getCurvePosition(t, w, h) {
        const P0 = { x: 0.05 * w, y: 0.86 * h };
        const P1 = { x: 0.38 * w, y: 0.84 * h };
        const P2 = { x: 0.86 * w, y: 0.16 * h };

        const s    = Math.min(1.0, Math.max(0, t));
        const invS = 1 - s;

        const x = invS * invS * P0.x + 2 * invS * s * P1.x + s * s * P2.x;
        const y = invS * invS * P0.y + 2 * invS * s * P1.y + s * s * P2.y;

        const dx = 2 * invS * (P1.x - P0.x) + 2 * s * (P2.x - P1.x);
        const dy = 2 * invS * (P1.y - P0.y) + 2 * s * (P2.y - P1.y);

        let angle = Math.atan2(dy, dx);
        angle = Math.max(-0.85, Math.min(-0.08, angle));

        return { x, y, angle, startX: P0.x, startY: P0.y };
    }

    /**
     * multiplierToT — maps the server multiplier to a Bézier curve parameter t ∈ [0, 0.96].
     *
     * Formula:  t = min(0.96,  0.553 × √(mult − 1))
     *
     * Derived from the following target positions required by the spec:
     *   mult 1.10x  →  t ≈ 0.175  (15–20% of screen)  → √0.10 × 0.553 = 0.175 ✓
     *   mult 1.35x  →  t ≈ 0.327  (25–35% of screen)  → √0.35 × 0.553 = 0.327 ✓
     *   mult 2.00x  →  t ≈ 0.553  (~50% of screen)    → √1.00 × 0.553 = 0.553 ✓
     *   mult 4.00x  →  t ≈ 0.96   (near top, capped)  → √3.00 × 0.553 = 0.958 ✓
     *
     * The square-root shape gives a naturaly decelerating curve — fast initial
     * acceleration (plane leaps off the runway) that eases toward the top of the
     * screen as the multiplier climbs further.
     *
     * Why NOT the rational function 0.96*(m-1)/(m-1+5)?
     *   At m=1.35: 0.96 × 0.35 / 5.35 ≈ 0.063 — plane at only 6% of screen.
     *   That formula is 5× too slow at the low-multiplier range.
     */
    multiplierToT(mult) {
        const m = Math.max(1.00, mult);
        return Math.min(0.96, 0.553 * Math.sqrt(m - 1.00));
    }

    drawFlightCurve(t, w, h) {
        if (t <= 0) return;
        const { x: currentX, y: currentY, startX, startY } = this.getCurvePosition(t, w, h);
        const steps = 60;

        // Rich semi-transparent red fill below Bézier curve
        this.graphics.fillStyle(0xCC0029, 0.45);
        this.graphics.beginPath();
        this.graphics.moveTo(startX, startY);
        for (let i = 0; i <= steps; i++) {
            const sT  = (i / steps) * t;
            const pos = this.getCurvePosition(sT, w, h);
            this.graphics.lineTo(pos.x, pos.y);
        }
        this.graphics.lineTo(currentX, startY);
        this.graphics.lineTo(startX, startY);
        this.graphics.closePath();
        this.graphics.fillPath();

        // Neon outer glow stroke
        this.graphics.lineStyle(16, 0xFF0033, 0.20);
        this.graphics.beginPath();
        this.graphics.moveTo(startX, startY);
        for (let i = 1; i <= steps; i++) {
            const sT  = (i / steps) * t;
            const pos = this.getCurvePosition(sT, w, h);
            this.graphics.lineTo(pos.x, pos.y);
        }
        this.graphics.strokePath();

        // Bright red neon main stroke
        this.graphics.lineStyle(4, 0xFF1744, 1.0);
        this.graphics.beginPath();
        this.graphics.moveTo(startX, startY);
        for (let i = 1; i <= steps; i++) {
            const sT  = (i / steps) * t;
            const pos = this.getCurvePosition(sT, w, h);
            this.graphics.lineTo(pos.x, pos.y);
        }
        this.graphics.strokePath();

        // White core highlight stroke
        this.graphics.lineStyle(1.5, 0xFFFFFF, 0.40);
        this.graphics.beginPath();
        this.graphics.moveTo(startX, startY);
        for (let i = 1; i <= steps; i++) {
            const sT  = (i / steps) * t;
            const pos = this.getCurvePosition(sT, w, h);
            this.graphics.lineTo(pos.x, pos.y);
        }
        this.graphics.strokePath();
    }

    update(time, delta) {
        this.graphics.clear();
        const w = this.sys.game.config.width;
        const h = this.sys.game.config.height;

        // ── Read ALL state from gameBridge — never from window.* ──────────
        const currentGameState = gameBridge.gameState;

        // ── Post-crash fly-away animation ─────────────────────────────────
        if (this.crashAnimActive) {
            this.crashTimer += delta;

            this.flyAwayX += this.flyAwayVx * (delta / 1000);
            this.flyAwayY += this.flyAwayVy * (delta / 1000);

            this.flyAwayVx += 350 * (delta / 1000);
            this.flyAwayVy -= 250 * (delta / 1000);

            this.plane.setPosition(this.flyAwayX, this.flyAwayY);

            this.propAngle += delta * 0.035;
            const angle       = this.plane.rotation;
            // Nose of 260x120 plane (scale 0.55): nose at x=242, center=130 → (+112 * 0.55) ≈ +62px
            const propOffsetX = Math.cos(angle) * 62;
            const propOffsetY = Math.sin(angle) * 62;
            this.propeller.setPosition(this.flyAwayX + propOffsetX, this.flyAwayY + propOffsetY);
            this.propeller.setRotation(this.propAngle);

            // Exhaust from tail (~64px behind center)
            const tailX = this.flyAwayX - Math.cos(angle) * 64;
            const tailY = this.flyAwayY - Math.sin(angle) * 64;
            this.exhaustParticles.setPosition(tailX, tailY);

            const exhaustAngleDeg = Phaser.Math.RadToDeg(angle);
            this.exhaustParticles.setAngle({ min: exhaustAngleDeg + 155, max: exhaustAngleDeg + 205 });

            this.drawFlightCurve(this.currentT, w, h);

            if (this.crashTimer > 1800) {
                this.crashAnimActive = false;
                this.plane.setVisible(false);
                this.propeller.setVisible(false);
                this.exhaustParticles.stop();
            }
            return;
        }

        // ── Crashed state: trigger fly-away if plane is still visible ─────
        if (currentGameState === 'CRASHED') {
            if (this.plane.visible && !this.crashAnimActive) {
                this.triggerCrashFlyAway(this.plane.x, this.plane.y, this.plane.rotation);
            } else if (!this.crashAnimActive) {
                this.plane.setVisible(false);
                this.propeller.setVisible(false);
                this.exhaustParticles.stop();
            }
            this.drawFlightCurve(this.currentT, w, h);
            return;
        }

        // ── Non-flying states: hide everything, reset position ────────────
        if (currentGameState !== 'FLYING') {
            this.plane.setVisible(false);
            this.propeller.setVisible(false);
            this.exhaustParticles.stop();
            this.currentT = 0;
            this.targetT  = 0;
            this.crashAnimActive = false;
            gameBridge.bezierT = 0;
            gameBridge.planeX  = 0;
            gameBridge.planeY  = 0;
            return;
        }

        // ── FLYING state: compute target position from authoritative multiplier ─
        //
        // gameTick() in main.js already applies EWMA smoothing to currentMultiplier
        // so it never jumps abruptly between server ticks. We map that smooth value
        // directly to a Bézier t parameter using the square-root formula above.
        //
        // We do NOT add a second lerp layer here. A double-lerp compounds lag:
        //   gameTick lerp: currentMultiplier → targetMultiplier (smooth)
        //   scene lerp:    currentT → targetT          (adds more delay)
        // The net effect was the plane lagging 300–800ms behind the multiplier.
        //
        // Instead: t is derived directly and instantly from currentMultiplier.
        // The only smoothing is the lightweight snap-on-cold-start guard below.
        const mult = Math.max(1.00, gameBridge.currentMultiplier);
        const newT = this.multiplierToT(mult);

        // Snap to target on cold start or mid-flight reconnect
        if (this.currentT === 0 && newT > 0.01) {
            this.currentT = newT;
        } else {
            // Apply a single, very fast micro-smooth only to suppress single-frame
            // pixel jitter from float precision, not to delay the position.
            // At 60 FPS and dt≈16ms: lerpFactor = 1 - exp(-80*0.016) ≈ 0.724
            // This resolves in under 2 frames — imperceptible latency.
            const dt = Math.min(0.05, delta / 1000);
            const lerpFactor = 1 - Math.exp(-80 * dt);
            this.currentT += (newT - this.currentT) * lerpFactor;
        }
        const t = this.currentT;
        const { x: currentX, y: currentY, angle } = this.getCurvePosition(t, w, h);

        this.drawFlightCurve(t, w, h);

        // Micro engine vibration for realistic flight feel
        const vibeX  = Math.sin(time * 0.04) * 0.85;
        const vibeY  = Math.cos(time * 0.05) * 0.85;
        const finalX = currentX + vibeX;
        const finalY = currentY + vibeY;

        this.plane.setVisible(true);
        this.plane.setPosition(finalX, finalY);
        this.plane.setRotation(angle);

        this.propAngle += delta * 0.028;
        // Nose of 260x120 plane (scale 0.55): (+112 * 0.55) ≈ +62px ahead of center
        const propOffsetX = Math.cos(angle) * 62;
        const propOffsetY = Math.sin(angle) * 62;
        this.propeller.setVisible(true);
        this.propeller.setPosition(finalX + propOffsetX, finalY + propOffsetY);
        this.propeller.setRotation(this.propAngle);

        this.exhaustParticles.start();
        const exhaustAngleDeg = Phaser.Math.RadToDeg(angle);
        this.exhaustParticles.setAngle({ min: exhaustAngleDeg + 155, max: exhaustAngleDeg + 205 });
        // Exhaust from tail (~64px behind center)
        const tailX = finalX - Math.cos(angle) * 64;
        const tailY = finalY - Math.sin(angle) * 64;
        this.exhaustParticles.setPosition(tailX, tailY);

        // ── Write telemetry back to bridge (debug panel reads these) ──────
        gameBridge.bezierT = t;
        gameBridge.planeX  = Math.round(finalX);
        gameBridge.planeY  = Math.round(finalY);
    }
}

export function getFlightSceneInstance() {
    return flightSceneInstance;
}
