/**
 * Modal Controllers & Provably Fair Verification
 */

export function closeModal() {
    const backdrop = document.getElementById('modalBackdrop');
    if (backdrop) backdrop.classList.remove('show');
    
    if (window.activePaymentPollId) {
        clearInterval(window.activePaymentPollId);
        window.activePaymentPollId = null;
    }
    if (window.activePaymentTimeoutId) {
        clearTimeout(window.activePaymentTimeoutId);
        window.activePaymentTimeoutId = null;
    }
    const windowEl = document.getElementById('modalWindow');
    if (windowEl) {
        windowEl.style.backgroundColor = '';
        windowEl.style.color = '';
    }
    window.history.replaceState(null, null, window.location.pathname + window.location.search);
}

/** Provably Fair Crash Point Verification Calculator */
export function verifyProvablyFair(seed) {
    const num = Number(seed) || 1;
    const x = Math.sin(num) * 10000;
    const r = x - Math.floor(x);
    let cp = 1.05;
    if (r < 0.1) cp = 1.05;
    else if (r < 0.5) cp = 1.2 + r * 3;
    else if (r < 0.8) cp = 5.0 + r * 15;
    else cp = 20.0 + r * 100;
    return parseFloat(cp.toFixed(2));
}

if (typeof window !== 'undefined') {
    window.closeModal = closeModal;
    window.verifyProvablyFair = verifyProvablyFair;
}
