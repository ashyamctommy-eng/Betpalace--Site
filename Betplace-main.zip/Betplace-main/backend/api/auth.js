/**
 * backend/api/auth.js
 *
 * Native Authentication Router for MetroWins.
 * Supports Phone + Password login, Registration, Session verification, Password reset.
 * Completely replaces Supabase Auth.
 */

import { query } from './_lib/db.js';
import { hashPassword, comparePassword, generateToken, verifyAuthToken, getPhoneVariants, ensureSuperAdmin, ensureAdmin } from './_lib/auth.js';

export default async function authHandler(req, res) {
    const url = req.url || '';
    const pathPart = url.split('?')[0] || '';

    // Route matching
    if (pathPart.endsWith('/super-admin/login') || req.query.action === 'super_admin_login') {
        return handleSuperAdminLogin(req, res);
    }
    if (pathPart.endsWith('/admin/login') || req.query.action === 'admin_login') {
        return handleAdminLogin(req, res);
    }
    if (pathPart.endsWith('/register') || req.query.action === 'register') {
        return handleRegister(req, res);
    }
    if (pathPart.endsWith('/login') || req.query.action === 'login') {
        return handleLogin(req, res);
    }
    if (pathPart.endsWith('/me') || req.query.action === 'me') {
        return handleMe(req, res);
    }
    if (pathPart.endsWith('/logout') || req.query.action === 'logout') {
        return res.status(200).json({ success: true, message: 'Logged out successfully.' });
    }
    if (pathPart.endsWith('/reset-password') || req.query.action === 'reset_password') {
        return handleResetPassword(req, res);
    }

    return res.status(404).json({ error: `Auth endpoint not found: ${pathPart}` });
}

/**
 * User Registration
 * POST /api/auth/register
 */
async function handleRegister(req, res) {
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

    const { phone, password, username, email, referralCode } = req.body || {};

    if (!phone || !password) {
        return res.status(400).json({ success: false, message: 'Phone and password are required.' });
    }

    if (password.length < 6) {
        return res.status(400).json({ success: false, message: 'Password must be at least 6 characters long.' });
    }

    // Clean phone number format
    const cleanPhone = String(phone).replace(/[\s\-()]/g, '');

    try {
        // Check for duplicate phone
        const { rows: existingPhone } = await query(
            'SELECT id FROM profiles WHERE phone = $1',
            [cleanPhone]
        );
        if (existingPhone.length > 0) {
            return res.status(409).json({ success: false, message: 'A user with this phone number already exists.' });
        }

        // Check for duplicate email if provided
        if (email) {
            const { rows: existingEmail } = await query(
                'SELECT id FROM profiles WHERE email = $1',
                [email.trim().toLowerCase()]
            );
            if (existingEmail.length > 0) {
                return res.status(409).json({ success: false, message: 'A user with this email address already exists.' });
            }
        }

        // Check for duplicate username if provided
        const cleanUsername = username ? username.trim() : `user_${cleanPhone.slice(-4)}_${Math.floor(1000 + Math.random() * 9000)}`;
        const { rows: existingUser } = await query(
            'SELECT id FROM profiles WHERE username = $1',
            [cleanUsername]
        );
        if (existingUser.length > 0) {
            return res.status(409).json({ success: false, message: 'Username is already taken.' });
        }

        // Hash password
        const passwordHash = await hashPassword(password);

        // Check referral
        let referrerId = null;
        if (referralCode) {
            const { rows: referrer } = await query(
                'SELECT id FROM profiles WHERE username = $1 OR phone = $1',
                [referralCode.trim()]
            );
            if (referrer.length > 0) {
                referrerId = referrer[0].id;
            }
        }

        // Insert new profile
        const { rows: newProfiles } = await query(
            `INSERT INTO profiles (phone, email, username, password_hash, referred_by, balance)
             VALUES ($1, $2, $3, $4, $5, 0.00)
             RETURNING id, phone, email, username, balance, is_frozen, created_at`,
            [cleanPhone, email ? email.trim().toLowerCase() : null, cleanUsername, passwordHash, referrerId]
        );

        const newUser = newProfiles[0];

        // Assign default role 'User'
        const { rows: userRole } = await query("SELECT id FROM roles WHERE name = 'User'");
        if (userRole.length > 0) {
            await query(
                'INSERT INTO user_roles (user_id, role_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
                [newUser.id, userRole[0].id]
            );
        }

        newUser.role = 'User';

        // Generate JWT token
        const token = generateToken({
            id: newUser.id,
            phone: newUser.phone,
            email: newUser.email,
            username: newUser.username,
            role: 'User'
        });

        return res.status(201).json({
            success: true,
            message: 'Registration successful.',
            token,
            user: {
                id: newUser.id,
                phone: newUser.phone,
                email: newUser.email,
                username: newUser.username,
                balance: parseFloat(newUser.balance),
                role: 'User'
            }
        });
    } catch (err) {
        console.error('[Registration Error]:', err);
        return res.status(500).json({ success: false, message: 'Registration failed due to a server error.' });
    }
}

/**
 * User Login
 * POST /api/auth/login
 */
async function handleLogin(req, res) {
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

    const { identifier, phone, email, password } = req.body || {};
    const inputId = (identifier || phone || email || '').trim();

    if (!inputId || !password) {
        return res.status(400).json({ success: false, message: 'Phone/email and password are required.' });
    }

    try {
        // 1. Direct Super Admin environment credentials check
        const envAdminPhone = process.env.SUPER_ADMIN_PHONE;
        const envAdminPass = process.env.SUPER_ADMIN_PASSWORD;
        if (envAdminPhone && envAdminPass && password === envAdminPass) {
            const adminVariants = getPhoneVariants(envAdminPhone);
            const cleanInput = inputId.replace(/[\s\-()]/g, '');
            const isMatch = adminVariants.includes(cleanInput) ||
                            adminVariants.some(v => cleanInput.includes(v)) ||
                            inputId.toLowerCase() === 'superadmin' ||
                            inputId.toLowerCase().includes('superadmin') ||
                            inputId.toLowerCase() === 'superadmin@betplace.app';
            if (isMatch) {
                const adminUser = await ensureSuperAdmin();
                if (adminUser) {
                    const token = generateToken({
                        id: adminUser.id,
                        phone: adminUser.phone,
                        email: adminUser.email,
                        username: adminUser.username,
                        role: 'Super Admin'
                    });
                    return res.status(200).json({
                        success: true,
                        message: 'Super Admin login successful.',
                        token,
                        user: {
                            id: adminUser.id,
                            phone: adminUser.phone,
                            email: adminUser.email,
                            username: adminUser.username,
                            balance: parseFloat(adminUser.balance || 0),
                            role: 'Super Admin'
                        }
                    });
                }
            }
        }

        // 2. Direct Staff Admin environment credentials check
        const envStaffPhone = process.env.ADMIN_PHONE;
        const envStaffPass = process.env.ADMIN_PASSWORD;
        if (envStaffPhone && envStaffPass && password === envStaffPass) {
            const staffVariants = getPhoneVariants(envStaffPhone);
            const cleanInput = inputId.replace(/[\s\-()]/g, '');
            const isMatch = staffVariants.includes(cleanInput) ||
                            staffVariants.some(v => cleanInput.includes(v)) ||
                            inputId.toLowerCase() === 'admin' ||
                            inputId.toLowerCase() === 'admin@betplace.app';
            if (isMatch) {
                const adminUser = await ensureAdmin();
                if (adminUser) {
                    const token = generateToken({
                        id: adminUser.id,
                        phone: adminUser.phone,
                        email: adminUser.email,
                        username: adminUser.username,
                        role: 'Admin'
                    });
                    return res.status(200).json({
                        success: true,
                        message: 'Admin login successful.',
                        token,
                        user: {
                            id: adminUser.id,
                            phone: adminUser.phone,
                            email: adminUser.email,
                            username: adminUser.username,
                            balance: parseFloat(adminUser.balance || 0),
                            role: 'Admin'
                        }
                    });
                }
            }
        }

        // 3. Find user by phone variants, email, or username
        const variants = getPhoneVariants(inputId);
        const { rows } = await query(
            `SELECT p.id, p.phone, p.email, p.username, p.password_hash, p.balance, p.is_frozen,
                    COALESCE(r.name, 'User') AS role
             FROM profiles p
             LEFT JOIN user_roles ur ON p.id = ur.user_id
             LEFT JOIN roles r ON ur.role_id = r.id
             WHERE p.phone = ANY($1::text[]) OR p.email = $2 OR p.username = $2`,
            [variants, inputId]
        );

        if (rows.length === 0) {
            return res.status(401).json({ success: false, message: 'Invalid credentials.' });
        }

        const user = rows[0];

        if (user.is_frozen) {
            return res.status(403).json({ success: false, message: 'Your account has been frozen. Please contact customer support.' });
        }

        // Compare password
        const passwordMatches = await comparePassword(password, user.password_hash);
        if (!passwordMatches) {
            return res.status(401).json({ success: false, message: 'Invalid credentials.' });
        }

        // Generate token
        const token = generateToken({
            id: user.id,
            phone: user.phone,
            email: user.email,
            username: user.username,
            role: user.role
        });

        return res.status(200).json({
            success: true,
            message: 'Login successful.',
            token,
            user: {
                id: user.id,
                phone: user.phone,
                email: user.email,
                username: user.username,
                balance: parseFloat(user.balance),
                role: user.role
            }
        });
    } catch (err) {
        console.error('[Login Error]:', err);
        return res.status(500).json({ success: false, message: 'Login failed due to a server error.' });
    }
}

/**
 * Dedicated Super Admin Login Handler
 * POST /api/auth/super-admin/login
 */
async function handleSuperAdminLogin(req, res) {
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
    const { phone, identifier, email, password } = req.body || {};
    const inputId = (identifier || phone || email || '').trim();

    if (!inputId || !password) {
        return res.status(400).json({ success: false, message: 'Super Admin identifier and password are required.' });
    }

    try {
        const envAdminPhone = process.env.SUPER_ADMIN_PHONE;
        const envAdminPass = process.env.SUPER_ADMIN_PASSWORD;

        if (envAdminPhone && envAdminPass && password === envAdminPass) {
            const adminVariants = getPhoneVariants(envAdminPhone);
            const cleanInput = inputId.replace(/[\s\-()]/g, '');
            const isMatch = adminVariants.includes(cleanInput) ||
                            adminVariants.some(v => cleanInput.includes(v)) ||
                            inputId.toLowerCase() === 'superadmin' ||
                            inputId.toLowerCase() === 'superadmin@betplace.app';
            if (isMatch) {
                const adminUser = await ensureSuperAdmin();
                if (adminUser) {
                    const token = generateToken({
                        id: adminUser.id,
                        phone: adminUser.phone,
                        email: adminUser.email,
                        username: adminUser.username,
                        role: 'Super Admin'
                    });
                    return res.status(200).json({
                        success: true,
                        message: 'Super Admin authentication verified.',
                        token,
                        user: {
                            id: adminUser.id,
                            phone: adminUser.phone,
                            email: adminUser.email,
                            username: adminUser.username,
                            balance: parseFloat(adminUser.balance || 0),
                            role: 'Super Admin'
                        }
                    });
                }
            }
        }

        // Check DB for Super Admin user
        const variants = getPhoneVariants(inputId);
        const { rows } = await query(
            `SELECT p.id, p.phone, p.email, p.username, p.password_hash, p.balance, p.is_frozen,
                    COALESCE(r.name, 'User') AS role
             FROM profiles p
             LEFT JOIN user_roles ur ON p.id = ur.user_id
             LEFT JOIN roles r ON ur.role_id = r.id
             WHERE p.phone = ANY($1::text[]) OR p.email = $2 OR p.username = $2`,
            [variants, inputId]
        );

        if (rows.length === 0) {
            return res.status(401).json({ success: false, message: 'Invalid Super Admin credentials.' });
        }

        const user = rows[0];
        if (user.role !== 'Super Admin') {
            return res.status(403).json({ success: false, message: 'Access Denied: Super Admin privileges required.' });
        }

        if (user.is_frozen) {
            return res.status(403).json({ success: false, message: 'Account is frozen.' });
        }

        const matches = await comparePassword(password, user.password_hash);
        if (!matches) {
            return res.status(401).json({ success: false, message: 'Invalid Super Admin credentials.' });
        }

        const token = generateToken({
            id: user.id,
            phone: user.phone,
            email: user.email,
            username: user.username,
            role: 'Super Admin'
        });

        return res.status(200).json({
            success: true,
            message: 'Super Admin authentication verified.',
            token,
            user: {
                id: user.id,
                phone: user.phone,
                email: user.email,
                username: user.username,
                balance: parseFloat(user.balance || 0),
                role: 'Super Admin'
            }
        });
    } catch (err) {
        console.error('[Super Admin Login Error]:', err);
        return res.status(500).json({ success: false, message: 'Authentication server error.' });
    }
}

/**
 * Dedicated Staff Admin Login Handler
 * POST /api/auth/admin/login
 */
async function handleAdminLogin(req, res) {
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
    const { phone, identifier, email, password } = req.body || {};
    const inputId = (identifier || phone || email || '').trim();

    if (!inputId || !password) {
        return res.status(400).json({ success: false, message: 'Admin identifier and password are required.' });
    }

    try {
        // 1. Check direct ADMIN env credentials
        const envStaffPhone = process.env.ADMIN_PHONE;
        const envStaffPass = process.env.ADMIN_PASSWORD;

        if (envStaffPhone && envStaffPass && password === envStaffPass) {
            const staffVariants = getPhoneVariants(envStaffPhone);
            const cleanInput = inputId.replace(/[\s\-()]/g, '');
            const isMatch = staffVariants.includes(cleanInput) ||
                            staffVariants.some(v => cleanInput.includes(v)) ||
                            inputId.toLowerCase() === 'admin' ||
                            inputId.toLowerCase() === 'admin@betplace.app';
            if (isMatch) {
                const adminUser = await ensureAdmin();
                if (adminUser) {
                    const token = generateToken({
                        id: adminUser.id,
                        phone: adminUser.phone,
                        email: adminUser.email,
                        username: adminUser.username,
                        role: 'Admin'
                    });
                    return res.status(200).json({
                        success: true,
                        message: 'Admin authentication verified.',
                        token,
                        user: {
                            id: adminUser.id,
                            phone: adminUser.phone,
                            email: adminUser.email,
                            username: adminUser.username,
                            balance: parseFloat(adminUser.balance || 0),
                            role: 'Admin'
                        }
                    });
                }
            }
        }

        // 2. Also allow Super Admin creds on Admin portal
        const envSuperPhone = process.env.SUPER_ADMIN_PHONE;
        const envSuperPass = process.env.SUPER_ADMIN_PASSWORD;
        if (envSuperPhone && envSuperPass && password === envSuperPass) {
            const superVariants = getPhoneVariants(envSuperPhone);
            const cleanInput = inputId.replace(/[\s\-()]/g, '');
            const isMatch = superVariants.includes(cleanInput) ||
                            superVariants.some(v => cleanInput.includes(v)) ||
                            inputId.toLowerCase() === 'superadmin';
            if (isMatch) {
                const superUser = await ensureSuperAdmin();
                if (superUser) {
                    const token = generateToken({
                        id: superUser.id,
                        phone: superUser.phone,
                        email: superUser.email,
                        username: superUser.username,
                        role: 'Super Admin'
                    });
                    return res.status(200).json({
                        success: true,
                        message: 'Super Admin authenticated to Admin Portal.',
                        token,
                        user: {
                            id: superUser.id,
                            phone: superUser.phone,
                            email: superUser.email,
                            username: superUser.username,
                            balance: parseFloat(superUser.balance || 0),
                            role: 'Super Admin'
                        }
                    });
                }
            }
        }

        // 3. Check DB user
        const variants = getPhoneVariants(inputId);
        const { rows } = await query(
            `SELECT p.id, p.phone, p.email, p.username, p.password_hash, p.balance, p.is_frozen,
                    COALESCE(r.name, 'User') AS role
             FROM profiles p
             LEFT JOIN user_roles ur ON p.id = ur.user_id
             LEFT JOIN roles r ON ur.role_id = r.id
             WHERE p.phone = ANY($1::text[]) OR p.email = $2 OR p.username = $2`,
            [variants, inputId]
        );

        if (rows.length === 0) {
            return res.status(401).json({ success: false, message: 'Invalid Admin credentials.' });
        }

        const user = rows[0];
        if (user.role !== 'Admin' && user.role !== 'Super Admin') {
            return res.status(403).json({ success: false, message: 'Access Denied: Staff Administrative privileges required.' });
        }

        if (user.is_frozen) {
            return res.status(403).json({ success: false, message: 'Account is frozen.' });
        }

        const matches = await comparePassword(password, user.password_hash);
        if (!matches) {
            return res.status(401).json({ success: false, message: 'Invalid Admin credentials.' });
        }

        const token = generateToken({
            id: user.id,
            phone: user.phone,
            email: user.email,
            username: user.username,
            role: user.role
        });

        return res.status(200).json({
            success: true,
            message: 'Admin authentication verified.',
            token,
            user: {
                id: user.id,
                phone: user.phone,
                email: user.email,
                username: user.username,
                balance: parseFloat(user.balance || 0),
                role: user.role
            }
        });
    } catch (err) {
        console.error('[Admin Login Error]:', err);
        return res.status(500).json({ success: false, message: 'Authentication server error.' });
    }
}

/**
 * Current User Profile / Session
 * GET /api/auth/me
 */
async function handleMe(req, res) {
    const auth = await verifyAuthToken(req);
    if (!auth.success) {
        return res.status(auth.status).json({ success: false, message: auth.error });
    }

    return res.status(200).json({
        success: true,
        user: {
            id: auth.user.id,
            phone: auth.user.phone,
            email: auth.user.email,
            username: auth.user.username,
            balance: parseFloat(auth.user.balance),
            role: auth.user.role
        }
    });
}

/**
 * Password Reset
 * POST /api/auth/reset-password
 */
async function handleResetPassword(req, res) {
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

    const { phone, newPassword } = req.body || {};
    if (!phone || !newPassword) {
        return res.status(400).json({ success: false, message: 'Phone and new password are required.' });
    }

    if (newPassword.length < 6) {
        return res.status(400).json({ success: false, message: 'Password must be at least 6 characters.' });
    }

    const cleanPhone = String(phone).replace(/[\s\-()]/g, '');

    try {
        const passwordHash = await hashPassword(newPassword);

        const { rowCount } = await query(
            'UPDATE profiles SET password_hash = $1, updated_at = NOW() WHERE phone = $2',
            [passwordHash, cleanPhone]
        );

        if (rowCount === 0) {
            return res.status(404).json({ success: false, message: 'No account found with that phone number.' });
        }

        return res.status(200).json({ success: true, message: 'Password reset successfully. You can now log in.' });
    } catch (err) {
        console.error('[Reset Password Error]:', err);
        return res.status(500).json({ success: false, message: 'Failed to reset password.' });
    }
}
