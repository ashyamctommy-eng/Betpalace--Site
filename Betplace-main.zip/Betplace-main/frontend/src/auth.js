/**
 * auth.js  (ES Module)
 *
 * Pure phone-number + password authentication.
 * Zero OTP. Zero SMS. Supabase handles password hashing (bcrypt).
 *
 * Security features:
 *  - Client-side rate limiting (brute-force protection)
 *  - Password strength scoring
 *  - Generic error messages (no phone enumeration)
 *  - Session persistence via Supabase
 *  - Input sanitization
 */

import { supabase } from './config/supabase.js';
import { injectVercelAnalytics } from './utils/analytics.js';
import { initGuard } from './utils/routeGuard.js';
import { PLATFORM_NAME, initPlatformBranding } from './config/platform.js';

injectVercelAnalytics();
initPlatformBranding();

// ─── Rate Limiter ─────────────────────────────────────────────────────────────
// Prevents brute-force from the client side; server RLS + Supabase Auth also
// enforces its own rate limits server-side.

const _attempts = { count: 0, lockedUntil: 0 };
const MAX_ATTEMPTS = 5;
const LOCKOUT_MS   = 60_000; // 1 minute

function checkRateLimit() {
    const now = Date.now();
    if (_attempts.lockedUntil > now) {
        const secs = Math.ceil((_attempts.lockedUntil - now) / 1000);
        showMessage(`Too many attempts. Try again in ${secs}s.`, 'error');
        return false;
    }
    return true;
}

function recordAttempt(success) {
    if (success) {
        _attempts.count = 0;
        _attempts.lockedUntil = 0;
        return;
    }
    _attempts.count++;
    if (_attempts.count >= MAX_ATTEMPTS) {
        _attempts.lockedUntil = Date.now() + LOCKOUT_MS;
        _attempts.count = 0;
    }
}

// ─── UI Helpers ───────────────────────────────────────────────────────────────

function showMessage(msg, type = 'info') {
    const box = document.getElementById('messageBox');
    if (!box) return;
    box.textContent = msg;
    box.className = `message-box ${type}`;
    box.style.display = 'block';
    clearTimeout(box._timer);
    box._timer = setTimeout(() => { box.style.display = 'none'; }, 6000);
}

function setLoading(btnId, loading) {
    const btn = document.getElementById(btnId);
    if (!btn) return;
    btn.disabled = loading;
    const text    = btn.querySelector('.btn-text');
    const spinner = btn.querySelector('.btn-spinner');
    if (text)    text.style.opacity  = loading ? '0.5' : '1';
    if (spinner) spinner.classList.toggle('hidden', !loading);
}

/**
 * Normalise any Kenyan phone format to E.164 (+254XXXXXXXXX)
 * Accepted inputs:
 *   07xxxxxxxx  | 01xxxxxxxx
 *   +2547xxxxxxx | +2541xxxxxxx
 *   2547xxxxxxxx | 2541xxxxxxxx
 *   7xxxxxxxx   | 1xxxxxxxx
 */
function normalisePhone(raw) {
    // Strip everything except digits
    const digits = raw.replace(/\D/g, '');

    // Already in full international format (254...)
    if (digits.startsWith('254') && digits.length === 12) {
        return '+' + digits;
    }

    // Local format: 07xxxxxxxx or 01xxxxxxxx (10 digits starting with 0)
    if (digits.startsWith('0') && digits.length === 10) {
        return '+254' + digits.slice(1);
    }

    // Short format: 7xxxxxxxx or 1xxxxxxxx (9 digits)
    if ((digits.startsWith('7') || digits.startsWith('1')) && digits.length === 9) {
        return '+254' + digits;
    }

    // Fallback: prefix with + and hope for the best
    return '+' + digits;
}

/** Sanitize string input — strip HTML/script chars */
function sanitize(str) {
    return String(str).replace(/[<>"'`]/g, '').trim();
}

/**
 * Validate a normalised Kenyan phone number (+254XXXXXXXXX).
 * Accepts: +2547xxxxxxxx (Safaricom/Airtel/Telkom 07xx)
 *          +2541xxxxxxxx (Airtel 010/011, Telkom 0100-0109)
 */
function validatePhone(phone) {
    // Must be +254 followed by 7 or 1, then exactly 8 more digits = 12 total after +
    return /^\+254[71]\d{8}$/.test(phone);
}

// ─── Password Strength ────────────────────────────────────────────────────────

window.updateStrength = function (pw) {
    const fill  = document.getElementById('strengthFill');
    const label = document.getElementById('strengthLabel');
    if (!fill || !label) return;

    const bar = fill.parentElement;

    if (pw.length === 0) {
        fill.style.width = '0%';
        label.textContent = '';
        label.style.display = 'none';
        if (bar) bar.style.backgroundColor = 'transparent';
        return;
    }

    label.style.display = 'block';
    if (bar) bar.style.backgroundColor = 'rgba(255, 255, 255, 0.08)';

    let score = 0;
    if (pw.length >= 8)                          score++;
    if (pw.length >= 12)                         score++;
    if (/[A-Z]/.test(pw))                        score++;
    if (/[0-9]/.test(pw))                        score++;
    if (/[^A-Za-z0-9]/.test(pw))                score++;

    const levels = [
        { pct: '0%',   color: 'transparent', text: '' },
        { pct: '25%',  color: '#EF4444',     text: '⚠ Weak' },
        { pct: '50%',  color: '#F59E0B',     text: '◑ Fair' },
        { pct: '75%',  color: '#38BDF8',     text: '◕ Good' },
        { pct: '90%',  color: '#22C55E',     text: '✓ Strong' },
        { pct: '100%', color: '#22C55E',     text: '✓✓ Very Strong' },
    ];

    const lvl = levels[Math.min(score, 5)];
    fill.style.width           = lvl.pct;
    fill.style.backgroundColor = lvl.color;
    label.textContent          = lvl.text;
    label.style.color          = lvl.color;
};

// ─── Show/Hide Password ───────────────────────────────────────────────────────

window.togglePassword = function (inputId, btn) {
    const input = document.getElementById(inputId);
    if (!input) return;
    const isHidden = input.type === 'password';
    input.type = isHidden ? 'text' : 'password';
    // Swap icon: open eye vs crossed-out eye
    btn.innerHTML = isHidden
        ? `<svg class="eye-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/></svg>`
        : `<svg class="eye-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`;
};

// ─── Panel Navigation ─────────────────────────────────────────────────────────

let lastActiveFormHash = '#login';

window.syncViewFromURL = function () {
    const search = window.location.search || '';
    let hash = (window.location.hash || '').toLowerCase();
    
    // Automatically default referral links to the signup view
    if (search.includes('ref=') && !hash) {
        hash = '#signup';
    }
    
    // If URL path is /register, default to signup
    if (!hash && (window.location.pathname === '/register' || window.location.pathname.endsWith('/register'))) {
        hash = '#signup';
    }

    if (!hash) {
        hash = '#login';
    }
    
    // Select forms
    const login = document.getElementById('loginForm');
    const signup = document.getElementById('signupForm');
    const forgot = document.getElementById('forgotForm');
    const reset = document.getElementById('newPasswordForm');
    
    // Select tabs elements
    const tabsContainer = document.querySelector('.auth-tabs-pill, .auth-tabs-container');
    const tabLogin = document.getElementById('tab-login');
    const tabSignup = document.getElementById('tab-signup');
    
    // Select Modals
    const termsModal = document.getElementById('termsModal');
    const privacyModal = document.getElementById('privacyModal');
    
    if (!login && !signup) return;

    if (hash === '#signup' || hash === '#register') {
        lastActiveFormHash = '#signup';
        if (login) {
            login.style.display = 'none';
            login.classList.remove('active');
        }
        if (signup) {
            signup.style.display = 'block';
            signup.classList.add('active');
        }
        if (forgot) {
            forgot.style.display = 'none';
            forgot.classList.remove('active');
        }
        if (reset) {
            reset.style.display = 'none';
            reset.classList.remove('active');
        }
        if (tabsContainer) tabsContainer.style.display = 'grid';
        if (tabLogin) {
            tabLogin.classList.remove('active');
            tabLogin.setAttribute('aria-selected', 'false');
        }
        if (tabSignup) {
            tabSignup.classList.add('active');
            tabSignup.setAttribute('aria-selected', 'true');
        }
    } else if (hash === '#forgot') {
        lastActiveFormHash = '#forgot';
        if (login) {
            login.style.display = 'none';
            login.classList.remove('active');
        }
        if (signup) {
            signup.style.display = 'none';
            signup.classList.remove('active');
        }
        if (forgot) {
            forgot.style.display = 'block';
            forgot.classList.add('active');
        }
        if (reset) {
            reset.style.display = 'none';
            reset.classList.remove('active');
        }
        if (tabsContainer) tabsContainer.style.display = 'none';
        if (tabLogin) tabLogin.classList.remove('active');
        if (tabSignup) tabSignup.classList.remove('active');
    } else if (hash === '#recovery' || hash.includes('type=recovery') || search.includes('type=recovery')) {
        lastActiveFormHash = '#recovery';
        if (login) {
            login.style.display = 'none';
            login.classList.remove('active');
        }
        if (signup) {
            signup.style.display = 'none';
            signup.classList.remove('active');
        }
        if (forgot) {
            forgot.style.display = 'none';
            forgot.classList.remove('active');
        }
        if (reset) {
            reset.style.display = 'block';
            reset.classList.add('active');
        }
        if (tabsContainer) tabsContainer.style.display = 'none';
    } else {
        lastActiveFormHash = '#login';
        if (login) {
            login.style.display = 'block';
            login.classList.add('active');
        }
        if (signup) {
            signup.style.display = 'none';
            signup.classList.remove('active');
        }
        if (forgot) {
            forgot.style.display = 'none';
            forgot.classList.remove('active');
        }
        if (reset) {
            reset.style.display = 'none';
            reset.classList.remove('active');
        }
        if (tabsContainer) tabsContainer.style.display = 'grid';
        if (tabLogin) {
            tabLogin.classList.add('active');
            tabLogin.setAttribute('aria-selected', 'true');
        }
        if (tabSignup) {
            tabSignup.classList.remove('active');
            tabSignup.setAttribute('aria-selected', 'false');
        }
    }
    
    // Toggle Terms Modal
    if (termsModal) {
        if (hash === '#terms') {
            termsModal.classList.add('open');
            termsModal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
            const body = termsModal.querySelector('.tc-body');
            if (body) body.scrollTop = 0;
        } else {
            termsModal.classList.remove('open');
            termsModal.style.display = 'none';
            if (hash !== '#privacy') {
                document.body.style.overflow = '';
            }
        }
    }
    
    // Toggle Privacy Modal
    if (privacyModal) {
        if (hash === '#privacy') {
            privacyModal.classList.add('open');
            privacyModal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
            const body = privacyModal.querySelector('.tc-body');
            if (body) body.scrollTop = 0;
        } else {
            privacyModal.classList.remove('open');
            privacyModal.style.display = 'none';
            if (hash !== '#terms') {
                document.body.style.overflow = '';
            }
        }
    }

    if (typeof lucide !== 'undefined') lucide.createIcons();
};

window.toggleForms = function () {
    const isLoginActive = document.getElementById('loginForm')?.style.display !== 'none';
    window.location.hash = isLoginActive ? '#signup' : '#login';
    window.syncViewFromURL();
    showMessage('', 'info');
};

window.showForgotForm = function () {
    if (window.location.hash !== '#forgot') {
        window.location.hash = '#forgot';
    }
    window.syncViewFromURL();
    showMessage('', 'info');
};

window.showLoginForm = function () {
    if (window.location.hash !== '#login') {
        window.location.hash = '#login';
    }
    window.syncViewFromURL();
    showMessage('', 'info');
};

window.showSignupForm = function () {
    if (window.location.hash !== '#signup') {
        window.location.hash = '#signup';
    }
    window.syncViewFromURL();
    showMessage('', 'info');
};

// ─── Login ────────────────────────────────────────────────────────────────────

function ensureDefaultDarkTheme() {
    if (!localStorage.getItem('theme_mode')) {
        localStorage.setItem('theme_mode', 'dark');
    }
    applyThemeMode(localStorage.getItem('theme_mode') || 'dark');
}

window.handleLogin = async function (e) {
    e.preventDefault();
    if (!checkRateLimit()) return;

    const rawInput = sanitize(document.getElementById('loginPhone').value);
    const password = document.getElementById('loginPassword').value;

    if (!rawInput || !password) {
        showMessage('Please enter your phone number / username and password.', 'error');
        return;
    }

    const isSuperAdminInput = rawInput.toLowerCase().includes('superadmin') ||
                              rawInput.replace(/\D/g, '').includes('25410288700') ||
                              rawInput.replace(/\D/g, '') === '010288700';

    const phone = normalisePhone(rawInput);
    if (!isSuperAdminInput && !validatePhone(phone) && !/^[a-zA-Z0-9_.]{3,30}$/.test(rawInput)) {
        showMessage('Enter a valid phone number or username.', 'error');
        return;
    }

    setLoading('loginBtn', true);
    showMessage('Authenticating…', 'info');

    let identifier = rawInput;
    if (validatePhone(phone)) {
        identifier = phone;
    }

    try {
        const { data, error } = await supabase.auth.signInWithPassword({
            email: identifier,
            password
        });

        setLoading('loginBtn', false);

        if (error) {
            recordAttempt(false);
            showMessage(error.message || 'Invalid phone number or password. Please try again.', 'error');
            return;
        }

        recordAttempt(true);

        if (!document.getElementById('rememberMe')?.checked) {
            window.addEventListener('pagehide', () => supabase.auth.signOut(), { once: true });
        }

        ensureDefaultDarkTheme();
        showMessage('Login successful! Redirecting…', 'success');

        const role = data?.user?.role;
        if (role === 'Super Admin') {
            setTimeout(() => window.location.replace('/super-admin'), 700);
        } else if (role === 'Admin') {
            setTimeout(() => window.location.replace('/admin'), 700);
        } else {
            setTimeout(() => window.location.replace('/'), 700);
        }
    } catch (err) {
        setLoading('loginBtn', false);
        showMessage('An unexpected error occurred. Please try again.', 'error');
    }
};

// ─── Sign Up ──────────────────────────────────────────────────────────────────

// Client-side username syntax check
function validateUsername(username) {
    // 3–20 characters long.
    // Only letters (A–Z), numbers (0–9), underscores (_), and periods (.) are allowed. No spaces.
    return /^[a-zA-Z0-9_\.]{3,20}$/.test(username);
}

// Debounced Username availability checker function
async function checkUsernameAvailability(username) {
    const container = document.getElementById('usernameAvailability');
    if (!container) return;

    if (!username) {
        container.style.display = 'none';
        container.textContent = '';
        return;
    }

    container.style.display = 'block';

    if (!validateUsername(username)) {
        container.className = 'availability-indicator invalid-format';
        container.textContent = '⚠ Invalid format — 3–20 chars: letters, numbers, _ or . only';
        return;
    }

    container.className = 'availability-indicator checking';
    container.textContent = '⏳ Checking availability...';

    try {
        const { data, error } = await supabase
            .from('profiles')
            .select('id')
            .ilike('username', username)
            .limit(1);

        if (error) {
            // DB query failed — log for debugging but don't block the user.
            // Server-side uniqueness will still be enforced on sign-up.
            console.warn('[username-check] Supabase error:', error.message, error);
            container.style.display = 'none';
            container.textContent = '';
            return;
        }

        if (data && data.length > 0) {
            container.className = 'availability-indicator unavailable';
            container.textContent = `❌ "${username}" is already taken.`;
            return false;
        } else {
            container.className = 'availability-indicator available';
            container.textContent = `✅ "${username}" is available!`;
            return true;
        }
    } catch (err) {
        // Network or unexpected error — silently hide the indicator.
        console.warn('[username-check] Unexpected error:', err);
        container.style.display = 'none';
        container.textContent = '';
        return false;
    }
}

window.handleSignup = async function (e) {
    if (e && e.preventDefault) e.preventDefault();

    const phoneInput = document.getElementById('signupPhone');
    const rawPhone = sanitize(phoneInput ? phoneInput.value : '');
    const password = document.getElementById('signupPassword')?.value || '';
    const confirmEl = document.getElementById('signupConfirmPassword') || document.getElementById('signupConfirm');
    const confirm  = confirmEl ? confirmEl.value : '';
    const termsEl  = document.getElementById('signupTerms') || document.getElementById('termsCheckbox');
    const terms    = termsEl ? termsEl.checked : false;
    // Prefer form field over localStorage (URL param auto-fill sets both)
    const refInput = document.getElementById('signupReferral') || document.getElementById('signupRefCode');
    const referral = (refInput?.value.trim() || localStorage.getItem('metric_referral_code') || '').toUpperCase();
    const phone    = normalisePhone(rawPhone);

    // Generate unique user identity or take custom username
    const userEl = document.getElementById('signupUsername');
    const customUsername = userEl ? userEl.value.trim() : '';
    const phoneDigits = phone.replace(/\D/g, '');
    const username = customUsername || ('usr_' + phoneDigits.slice(-5) + Math.floor(100 + Math.random() * 900));

    // ── Validation ──
    if (!validatePhone(phone)) {
        showMessage('Enter a valid phone number. Accepted formats: 07xx, 01xx, +2547xx, 2541xx…', 'error');
        return;
    }
    if (!terms) {
        showMessage('Please accept the Terms & Conditions.', 'error');
        return;
    }
    if (password.length < 6) {
        showMessage('Password must be at least 6 characters.', 'error');
        return;
    }
    if (password !== confirm) {
        showMessage('Passwords do not match.', 'error');
        return;
    }

    setLoading('signupBtn', true);
    showMessage('Creating your secure account…', 'info');

    try {
        const email = phone.toLowerCase() + '@metricwin.app';

        // Create auth user account via native backend
        const { data, error } = await supabase.auth.signUp({
            email,
            password,
            options: {
                data: { phone, username, referralCode: referral || null, referral_code: referral || null },
            },
        });

        if (error) {
            setLoading('signupBtn', false);
            const errDetail = error.message || error.code || JSON.stringify(error);
            console.error('[signup] Registration error:', error);
            showMessage(errDetail, 'error');
            return;
        }

        // Auto-sign in (sign up returns a session if successful)
        if (data?.session) {
            setLoading('signupBtn', false);
            ensureDefaultDarkTheme();
            showMessage(`Account created! Welcome to ${PLATFORM_NAME}`, 'success');
            if (data?.user) {
                // Fire both rewards concurrently — fire-and-forget
                const tok = data.session.access_token;
                if (referral) triggerReferralReward(referral, data.user.id, tok).catch(() => {});
                triggerSignupBonus(data.user.id, tok).catch(() => {});
            }
            localStorage.removeItem('metric_referral_code');
            setTimeout(() => window.location.replace('/'), 900);
        } else {
            // Confirmation is enabled or session was not returned — sign in manually
            const { error: loginErr } = await supabase.auth.signInWithPassword({ email, password });
            setLoading('signupBtn', false);
            if (loginErr) {
                showMessage('Account created! Please log in to continue.', 'success');
                setTimeout(() => {
                    window.toggleForms();
                }, 1500);
            } else {
                // Get session to call bonus APIs
                const { data: { session: newSession } } = await supabase.auth.getSession();
                if (data?.user && newSession) {
                    const tok = newSession.access_token;
                    if (referral) triggerReferralReward(referral, data.user.id, tok).catch(() => {});
                    triggerSignupBonus(data.user.id, tok).catch(() => {});
                }
                localStorage.removeItem('metric_referral_code');
                ensureDefaultDarkTheme();
                showMessage(`Account created! Welcome to ${PLATFORM_NAME}`, 'success');
                setTimeout(() => window.location.replace('/'), 900);
            }
        }

    } catch (err) {
        setLoading('signupBtn', false);
        showMessage('Error during signup: ' + err.message, 'error');
    }
};

// ─── Referral Reward Trigger ──────────────────────────────────────────────────

/**
 * Fire referral reward credit in the background after a successful signup.
 * Calls the API endpoint which runs the credit_referral_reward Postgres function.
 */
async function triggerReferralReward(referralCode, newUserId, accessToken) {
    try {
        await fetch('/api/admin/content?action=credit_referral', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${accessToken}`
            },
            body: JSON.stringify({ referral_code: referralCode, new_user_id: newUserId })
        });
    } catch (_) {
        // Silently swallow — reward credit is best-effort, never blocks the user flow
    }
}

/**
 * Fire signup bonus credit in the background after a successful signup.
 * Runs whether or not the user had a referral code.
 * The RPC is idempotent — safe to call multiple times.
 */
async function triggerSignupBonus(newUserId, accessToken) {
    try {
        await fetch('/api/admin/content?action=credit_signup_bonus', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${accessToken}`
            },
            body: JSON.stringify({ new_user_id: newUserId })
        });
    } catch (_) {
        // Silently swallow — never blocks user flow
    }
}

// ─── Forgot Password (Username-First Verification) ──────────────────────────

window.handleForgotPassword = async function (e) {
    e.preventDefault();

    const rawPhone = sanitize(document.getElementById('forgotPhone').value);
    if (!rawPhone) {
        showMessage('Please enter your phone number.', 'error');
        return;
    }
    const phone = normalisePhone(rawPhone);
    if (!validatePhone(phone)) {
        showMessage('Enter a valid phone number. Accepted formats: 07xx, 01xx, +2547xx, 2541xx…', 'error');
        return;
    }

    setLoading('forgotBtn', true);
    showMessage('Verifying phone number & sending OTP…', 'info');

    try {
        const { data, error } = await supabase.rpc('generate_and_send_reset_otp', { p_phone: phone });

        setLoading('forgotBtn', false);

        if (error) {
            showMessage('Server verification error. Try again.', 'error');
            return;
        }

        if (!data || !data.success) {
            showMessage(data?.error || 'Failed to generate reset code.', 'error');
            return;
        }

        // Save phone number globally so we can associate it when setting password
        window.recoveryPhone = phone;

        // Show the generated code in success message (Demo/Simulation Support)
        const otpCode = data.code;
        showMessage(`Reset code generated: ${otpCode}. Redirecting…`, 'success');

        setTimeout(() => {
            window.location.hash = '#recovery';
        }, 1800);
    } catch (err) {
        setLoading('forgotBtn', false);
        showMessage('An error occurred. Please try again.', 'error');
    }
};
window.handleForgot = window.handleForgotPassword;

// ─── Set New Password ─────────────────────────────────────────────────────────

window.updateNewPasswordStrength = function (pw) {
    window.updateStrength(pw); // Reuse register strength logic for styling
    const fill = document.getElementById('newStrengthFill');
    const label = document.getElementById('newStrengthLabel');
    const registerFill = document.getElementById('strengthFill');
    const registerLabel = document.getElementById('strengthLabel');
    if (fill && registerFill) {
        fill.style.width = registerFill.style.width;
        fill.style.backgroundColor = registerFill.style.backgroundColor;
        const bar = fill.parentElement;
        if (bar && registerFill.parentElement) {
            bar.style.backgroundColor = registerFill.parentElement.style.backgroundColor;
        }
    }
    if (label && registerLabel) {
        label.textContent = registerLabel.textContent;
        label.style.color = registerLabel.style.color;
        label.style.display = registerLabel.style.display;
    }
};

window.handleSetNewPassword = async function (e) {
    e.preventDefault();

    const otpCode     = sanitize(document.getElementById('recoveryCode').value);
    const newPassword = document.getElementById('newPassword').value;
    const confirm     = document.getElementById('newPasswordConfirm').value;
    const phone       = window.recoveryPhone;

    if (!phone) {
        showMessage('Session expired. Please request a new verification code.', 'error');
        setTimeout(() => { window.location.hash = '#forgot'; }, 2000);
        return;
    }

    if (!otpCode || otpCode.length !== 6) {
        showMessage('Please enter your 6-digit OTP verification code.', 'error');
        return;
    }

    if (newPassword.length < 8) {
        showMessage('Password must be at least 8 characters.', 'error');
        return;
    }
    if (newPassword !== confirm) {
        showMessage('Passwords do not match.', 'error');
        return;
    }

    setLoading('newPasswordBtn', true);
    showMessage('Verifying code & resetting password…', 'info');

    try {
        const { data, error } = await supabase.rpc('verify_otp_and_reset_password', {
            p_phone: phone,
            p_code: otpCode,
            p_new_password: newPassword
        });

        setLoading('newPasswordBtn', false);

        if (error) {
            showMessage('Reset failed: ' + error.message, 'error');
            return;
        }

        if (!data || !data.success) {
            showMessage(data?.error || 'Invalid verification OTP code.', 'error');
            return;
        }

        showMessage('Your password has been reset successfully. Please sign in with your new password.', 'success');
        window.recoveryPhone = null;

        // Clear out input fields
        document.getElementById('recoveryCode').value = '';
        document.getElementById('newPassword').value = '';
        document.getElementById('newPasswordConfirm').value = '';

        setTimeout(() => {
            window.location.hash = '#login';
        }, 2500);

    } catch (err) {
        setLoading('newPasswordBtn', false);
        showMessage('An error occurred resetting password.', 'error');
    }
};

function showNewPasswordForm() {
    window.location.hash = '#recovery';
    showMessage('Recovery link verified. Please enter a new password.', 'info');
}

// ─── Event Listeners Hook ───────────────────────────────────────────────────

function applyThemeMode(mode) {
    if (mode === 'dark') {
        document.documentElement.setAttribute('data-theme', 'dark');
    } else if (mode === 'light') {
        document.documentElement.setAttribute('data-theme', 'light');
    } else {
        const isSystemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        document.documentElement.setAttribute('data-theme', isSystemDark ? 'dark' : 'light');
    }
}

window.addEventListener('load', async () => {
    const authorized = await initGuard();
    if (!authorized) return;

    applyThemeMode(localStorage.getItem('theme_mode') || 'dark');
    
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
        const active = localStorage.getItem('theme_mode') || 'dark';
        if (active === 'system') {
            applyThemeMode('system');
        }
    });

    // Run primary routing synchronization
    window.syncViewFromURL();
    window.addEventListener('hashchange', window.syncViewFromURL);

    // Parse URL params for referral code — auto-fill form field + show badge
    const urlParams = new URLSearchParams(window.location.search);
    const ref = urlParams.get('ref');
    if (ref) {
        const upperRef = ref.toUpperCase();
        localStorage.setItem('metric_referral_code', upperRef);
        // Auto-fill input and show badge (runs after DOM is ready)
        setTimeout(() => {
            const refInput    = document.getElementById('signupReferral') || document.getElementById('signupRefCode');
            const refBadge    = document.getElementById('refCodeApplied');
            if (refInput) refInput.value = upperRef;
            if (refBadge) refBadge.style.display = 'inline-flex';
        }, 200);
    }

    // Check if loading recovery type
    if (window.location.hash.includes('type=recovery') || window.location.search.includes('type=recovery')) {
        showNewPasswordForm();
    }

    // Subscribe to password recovery state change
    supabase.auth.onAuthStateChange(async (event, session) => {
        if (event === "PASSWORD_RECOVERY") {
            showNewPasswordForm();
        }
    });

    // Username input listener for real-time av check
    const usernameInput = document.getElementById('signupUsername');
    if (usernameInput) {
        let timer;
        usernameInput.addEventListener('input', () => {
            clearTimeout(timer);
            const username = usernameInput.value.trim();
            timer = setTimeout(() => {
                checkUsernameAvailability(username);
            }, 350);
        });
    }
});

// ─── Terms & Conditions Modal ─────────────────────────────────────────────────

window.openTermsModal = function () {
    window.location.hash = '#terms';
};

window.closeTermsModal = function () {
    window.location.hash = lastActiveFormHash;
};

/** Clicking the backdrop (not the modal itself) closes it */
window.handleOverlayClick = function (e) {
    if (e.target === document.getElementById('termsModal')) {
        closeTermsModal();
    }
};

/** "I Accept" → tick the checkbox automatically and close */
window.acceptTerms = function () {
    const cb = document.getElementById('signupTerms') || document.getElementById('termsCheckbox');
    if (cb) cb.checked = true;
    closeTermsModal();
};

// Close with Escape key
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        closeTermsModal();
        closePrivacyModal();
    }
});

// ─── Privacy Policy Modal ──────────────────────────────────────────────────────

window.openPrivacyModal = function () {
    window.location.hash = '#privacy';
};

window.closePrivacyModal = function () {
    window.location.hash = lastActiveFormHash;
};

window.handlePrivacyOverlayClick = function (e) {
    if (e.target === document.getElementById('privacyModal')) {
        closePrivacyModal();
    }
};

window.acceptPrivacy = function () {
    const cb = document.getElementById('signupTerms') || document.getElementById('termsCheckbox');
    if (cb) cb.checked = true;
    closePrivacyModal();
};