/**
 * backend/api/_admin/actions.js
 *
 * Privileged Admin Actions: Freeze, Unfreeze, Assign Role, Adjust Balance, Override Crash Point.
 * Pure PostgreSQL via _lib/db.js. Zero Supabase.
 */

import { verifyPermission, logAdminAction } from '../_lib/auth.js';
import { query } from '../_lib/db.js';
import { clearSportsCache } from '../sports.js';

export default async function actionsHandler(req, res) {
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

    try {
        const access = await verifyPermission(req, 'manage_users');
        if (!access.success) return res.status(access.status).json({ error: access.error });

        const { action, targetUserId, roleName } = req.body || {};

        switch (action) {
            case 'freeze_user': {
                await query('UPDATE profiles SET is_frozen = true, updated_at = NOW() WHERE id = $1', [targetUserId]);
                await logAdminAction(access.user.id, 'FREEZE_USER', targetUserId, {});
                return res.status(200).json({ success: true });
            }

            case 'unfreeze_user': {
                await query('UPDATE profiles SET is_frozen = false, updated_at = NOW() WHERE id = $1', [targetUserId]);
                await logAdminAction(access.user.id, 'UNFREEZE_USER', targetUserId, {});
                return res.status(200).json({ success: true });
            }

            case 'assign_role': {
                const superCheck = await verifyPermission(req, 'manage_admins');
                if (!superCheck.success) return res.status(403).json({ error: 'Permission denied: Super Admin required' });

                const { rows: roles } = await query('SELECT id FROM roles WHERE name = $1', [roleName]);
                if (roles.length === 0) throw new Error('Role not found');

                const roleId = roles[0].id;
                await query('DELETE FROM user_roles WHERE user_id = $1', [targetUserId]);
                await query(
                    'INSERT INTO user_roles (user_id, role_id, assigned_by) VALUES ($1, $2, $3)',
                    [targetUserId, roleId, access.user.id]
                );

                await logAdminAction(access.user.id, 'ASSIGN_ROLE', targetUserId, { role: roleName });
                return res.status(200).json({ success: true });
            }

            case 'adjust_balance': {
                const balCheck = await verifyPermission(req, 'manage_admins');
                if (!balCheck.success) return res.status(403).json({ error: 'Permission denied: Super Admin required' });

                const { delta } = req.body;
                if (!targetUserId || typeof delta !== 'number' || !Number.isFinite(delta)) {
                    return res.status(400).json({ error: 'Missing targetUserId or invalid delta' });
                }

                if (Math.abs(delta) > 500000) {
                    return res.status(400).json({ error: 'Balance adjustment exceeds allowed range (max ±500,000 KES)' });
                }

                await query(
                    'UPDATE profiles SET balance = GREATEST(0, balance + $1), updated_at = NOW() WHERE id = $2',
                    [delta, targetUserId]
                );

                await query(
                    `INSERT INTO transactions (user_id, type, amount, status, metadata)
                     VALUES ($1, 'adjustment', $2, 'completed', $3)`,
                    [targetUserId, delta, JSON.stringify({ admin_id: access.user.id })]
                );

                await logAdminAction(access.user.id, 'ADJUST_BALANCE', targetUserId, { delta });
                return res.status(200).json({ success: true });
            }

            case 'override_crash_point': {
                const { multiplier } = req.body;
                if (multiplier === null || multiplier === 0 || multiplier === '' || multiplier === 'clear') {
                    await query('UPDATE active_game_state SET next_crash_point = NULL WHERE id = 1');
                    await logAdminAction(access.user.id, 'CLEAR_CRASH_OVERRIDE', '1', {});
                    return res.status(200).json({ success: true, message: 'Crash override cleared. Natural RNG restored.' });
                }

                const num = parseFloat(multiplier);
                if (isNaN(num) || num < 1.01 || num > 200) {
                    return res.status(400).json({ error: 'Invalid multiplier value. Must be between 1.01 and 200.' });
                }

                await query(
                    'UPDATE active_game_state SET next_crash_point = $1 WHERE id = 1',
                    [num]
                );

                await logAdminAction(access.user.id, 'OVERRIDE_CRASH_POINT', '1', { next_crash_point: num });
                return res.status(200).json({ success: true, message: `Crash multiplier armed at ${num.toFixed(2)}x for next round.` });
            }

            case 'settle_sports_bet': {
                const { betId, status: newStatus, customPayout, reason } = req.body;
                if (!betId || !['won', 'lost', 'cancelled'].includes(newStatus)) {
                    return res.status(400).json({ error: 'Valid betId and target status (won, lost, cancelled) are required.' });
                }

                await query('BEGIN');
                try {
                    const { rows: betRows } = await query('SELECT * FROM sports_bets WHERE id = $1 FOR UPDATE', [betId]);
                    if (betRows.length === 0) {
                        await query('ROLLBACK');
                        return res.status(404).json({ error: 'Bet not found' });
                    }

                    const bet = betRows[0];
                    const oldStatus = bet.status;
                    const userId = bet.user_id;
                    const stake = parseFloat(bet.stake || 0);
                    const defaultPayout = parseFloat(bet.potential_payout || 0);
                    const payout = customPayout !== undefined && customPayout !== null && !isNaN(parseFloat(customPayout))
                        ? parseFloat(customPayout)
                        : defaultPayout;

                    let balanceDelta = 0;
                    let txType = null;
                    let txAmount = 0;

                    if (newStatus === 'won') {
                        if (oldStatus === 'won') {
                            balanceDelta = 0;
                        } else if (oldStatus === 'cancelled') {
                            balanceDelta = payout - stake;
                            txType = 'sports_payout';
                            txAmount = payout;
                        } else {
                            balanceDelta = payout;
                            txType = 'sports_payout';
                            txAmount = payout;
                        }
                    } else if (newStatus === 'lost') {
                        if (oldStatus === 'won') {
                            balanceDelta = -defaultPayout;
                        } else if (oldStatus === 'cancelled') {
                            balanceDelta = -stake;
                        }
                    } else if (newStatus === 'cancelled') {
                        if (oldStatus === 'won') {
                            balanceDelta = stake - defaultPayout;
                            txType = 'sports_refund';
                            txAmount = stake;
                        } else if (oldStatus === 'pending' || oldStatus === 'lost') {
                            balanceDelta = stake;
                            txType = 'sports_refund';
                            txAmount = stake;
                        }
                    }

                    if (balanceDelta !== 0) {
                        await query(
                            'UPDATE profiles SET balance = GREATEST(0, balance + $1), updated_at = NOW() WHERE id = $2',
                            [balanceDelta, userId]
                        );
                    }

                    await query(
                        'UPDATE sports_bets SET status = $1, settled_at = NOW() WHERE id = $2',
                        [newStatus, betId]
                    );

                    if (txType && txAmount > 0) {
                        await query(
                            `INSERT INTO transactions (user_id, type, amount, status, metadata)
                             VALUES ($1, $2, $3, 'completed', $4)`,
                            [userId, txType, txAmount, JSON.stringify({
                                bet_id: betId,
                                admin_id: access.user.id,
                                admin_action: 'settle_sports_bet',
                                old_status: oldStatus,
                                new_status: newStatus,
                                reason: reason || 'Super Admin manual settlement'
                            })]
                        );
                    }

                    const { rows: profRows } = await query('SELECT balance FROM profiles WHERE id = $1', [userId]);
                    const newBalance = profRows[0]?.balance;

                    await query('COMMIT');

                    await logAdminAction(access.user.id, 'SETTLE_SPORTS_BET', betId, {
                        user_id: userId,
                        old_status: oldStatus,
                        new_status: newStatus,
                        balance_delta: balanceDelta,
                        payout_amount: payout,
                        reason
                    });

                    return res.status(200).json({
                        success: true,
                        betId,
                        oldStatus,
                        newStatus,
                        balanceDelta,
                        newBalance,
                        message: `Bet #${betId.slice(0, 8)} successfully settled as ${newStatus.toUpperCase()}.`
                    });
                } catch (txErr) {
                    await query('ROLLBACK');
                    throw txErr;
                }
            }

            case 'cashout_sports_bet': {
                const { betId, cashoutAmount, reason } = req.body;
                const numAmount = parseFloat(cashoutAmount);
                if (!betId || isNaN(numAmount) || numAmount <= 0) {
                    return res.status(400).json({ error: 'Valid betId and positive cashoutAmount are required.' });
                }

                await query('BEGIN');
                try {
                    const { rows: betRows } = await query('SELECT * FROM sports_bets WHERE id = $1 FOR UPDATE', [betId]);
                    if (betRows.length === 0) {
                        await query('ROLLBACK');
                        return res.status(404).json({ error: 'Bet not found' });
                    }
                    const bet = betRows[0];
                    const userId = bet.user_id;

                    await query(
                        'UPDATE profiles SET balance = balance + $1, updated_at = NOW() WHERE id = $2',
                        [numAmount, userId]
                    );

                    await query(
                        'UPDATE sports_bets SET status = $1, settled_at = NOW() WHERE id = $2',
                        ['cashed_out', betId]
                    );

                    await query(
                        `INSERT INTO transactions (user_id, type, amount, status, metadata)
                         VALUES ($1, 'sports_cashout', $2, 'completed', $3)`,
                        [userId, numAmount, JSON.stringify({
                            bet_id: betId,
                            original_stake: bet.stake,
                            admin_id: access.user.id,
                            admin_forced: true,
                            reason: reason || 'Super Admin forced cashout'
                        })]
                    );

                    const { rows: profRows } = await query('SELECT balance FROM profiles WHERE id = $1', [userId]);
                    const newBalance = profRows[0]?.balance;

                    await query('COMMIT');

                    await logAdminAction(access.user.id, 'ADMIN_CASHOUT_SPORTS_BET', betId, {
                        user_id: userId,
                        cashout_amount: numAmount,
                        reason
                    });

                    return res.status(200).json({
                        success: true,
                        betId,
                        cashoutAmount: numAmount,
                        newBalance,
                        message: `Bet cashed out successfully for KES ${numAmount.toLocaleString()}.`
                    });
                } catch (txErr) {
                    await query('ROLLBACK');
                    throw txErr;
                }
            }

            case 'resolve_sports_fixture': {
                const { matchName, eventId, winningPick } = req.body;
                if ((!matchName && !eventId) || !winningPick) {
                    return res.status(400).json({ error: 'matchName (or eventId) and winningPick are required.' });
                }

                const { rows: pendingBets } = await query(
                    "SELECT * FROM sports_bets WHERE status = 'pending' FOR UPDATE"
                );

                let evaluated = 0;
                let wonCount = 0;
                let lostCount = 0;
                let totalPayout = 0;

                for (const bet of pendingBets) {
                    const selections = Array.isArray(bet.selections) ? bet.selections : [];
                    const matchSelection = selections.find(s => {
                        const matchesName = matchName && s.match && s.match.toLowerCase().trim() === matchName.toLowerCase().trim();
                        const matchesId = eventId && s.eventId && String(s.eventId) === String(eventId);
                        return matchesName || matchesId;
                    });

                    if (!matchSelection) continue;

                    evaluated++;
                    const pickMatches = matchSelection.pick && matchSelection.pick.toLowerCase().trim() === winningPick.toLowerCase().trim();

                    if (bet.bet_type === 'single') {
                        if (pickMatches) {
                            const payout = parseFloat(bet.potential_payout);
                            await query('UPDATE profiles SET balance = balance + $1, updated_at = NOW() WHERE id = $2', [payout, bet.user_id]);
                            await query("UPDATE sports_bets SET status = 'won', settled_at = NOW() WHERE id = $1", [bet.id]);
                            await query(
                                `INSERT INTO transactions (user_id, type, amount, status, metadata)
                                 VALUES ($1, 'sports_payout', $2, 'completed', $3)`,
                                [bet.user_id, payout, JSON.stringify({ bet_id: bet.id, game: 'sportsbook', resolved_fixture: matchName || eventId })]
                            );
                            wonCount++;
                            totalPayout += payout;
                        } else {
                            await query("UPDATE sports_bets SET status = 'lost', settled_at = NOW() WHERE id = $1", [bet.id]);
                            lostCount++;
                        }
                    } else if (bet.bet_type === 'accumulator') {
                        if (!pickMatches) {
                            await query("UPDATE sports_bets SET status = 'lost', settled_at = NOW() WHERE id = $1", [bet.id]);
                            lostCount++;
                        } else {
                            const updatedSelections = selections.map(s => {
                                if ((matchName && s.match?.toLowerCase().trim() === matchName.toLowerCase().trim()) || (eventId && String(s.eventId) === String(eventId))) {
                                    return { ...s, legStatus: 'won' };
                                }
                                return s;
                            });
                            const allWon = updatedSelections.every(s => s.legStatus === 'won');
                            if (allWon) {
                                const payout = parseFloat(bet.potential_payout);
                                await query('UPDATE profiles SET balance = balance + $1, updated_at = NOW() WHERE id = $2', [payout, bet.user_id]);
                                await query("UPDATE sports_bets SET status = 'won', selections = $1, settled_at = NOW() WHERE id = $2", [JSON.stringify(updatedSelections), bet.id]);
                                await query(
                                    `INSERT INTO transactions (user_id, type, amount, status, metadata)
                                     VALUES ($1, 'sports_payout', $2, 'completed', $3)`,
                                    [bet.user_id, payout, JSON.stringify({ bet_id: bet.id, game: 'sportsbook', resolved_fixture: matchName || eventId })]
                                );
                                wonCount++;
                                totalPayout += payout;
                            } else {
                                await query("UPDATE sports_bets SET selections = $1 WHERE id = $2", [JSON.stringify(updatedSelections), bet.id]);
                            }
                        }
                    }
                }

                await logAdminAction(access.user.id, 'RESOLVE_SPORTS_FIXTURE', 'sportsbook', {
                    matchName,
                    eventId,
                    winningPick,
                    evaluated,
                    wonCount,
                    lostCount,
                    totalPayout
                });

                return res.status(200).json({
                    success: true,
                    evaluated,
                    wonCount,
                    lostCount,
                    totalPayout,
                    message: `Evaluated ${evaluated} pending bets: ${wonCount} won (KES ${totalPayout.toLocaleString()} paid), ${lostCount} lost.`
                });
            }

            case 'refresh_sports_cache': {
                clearSportsCache();
                await logAdminAction(access.user.id, 'REFRESH_SPORTS_CACHE', 'sharp_api', {});
                return res.status(200).json({ success: true, message: 'SharpAPI odds cache flushed successfully.' });
            }

            case 'update_sports_config': {
                const config = req.body.config || req.body;
                await query(
                    `INSERT INTO system_settings (key, value, updated_at)
                     VALUES ('sportsbook_config', $1, NOW())
                     ON CONFLICT (key) DO UPDATE
                     SET value = EXCLUDED.value, updated_at = NOW()`,
                    [JSON.stringify(config)]
                );
                await logAdminAction(access.user.id, 'UPDATE_SPORTSBOOK_CONFIG', 'sportsbook', config);
                return res.status(200).json({ success: true, message: 'Sportsbook configuration saved.' });
            }

            case 'approve_withdrawal': {
                const { transactionId } = req.body;
                if (!transactionId) {
                    return res.status(400).json({ error: 'Missing transactionId' });
                }

                const { rows } = await query(
                    `SELECT * FROM transactions WHERE (id::text = $1 OR reference = $1) AND type IN ('withdrawal', 'withdraw') LIMIT 1`,
                    [transactionId]
                );
                const tx = rows[0];
                if (!tx) {
                    return res.status(404).json({ error: 'Withdrawal transaction not found' });
                }
                if (tx.status !== 'pending') {
                    return res.status(400).json({ error: `Withdrawal is already ${tx.status}` });
                }

                const PALPLUSS_API_KEY = process.env.PALPLUSS_API_KEY;
                const CALLBACK_URL = process.env.PALPLUSS_WITHDRAW_CALLBACK_URL || process.env.PALPLUSS_CALLBACK_URL;
                let payoutRef = null;

                if (PALPLUSS_API_KEY) {
                    try {
                        const authHeader = 'Basic ' + Buffer.from(PALPLUSS_API_KEY + ':').toString('base64');
                        let phoneStr = String(tx.phone || '').replace(/[\s\-()]/g, '').replace(/^\+/, '');
                        if (phoneStr.startsWith('0')) phoneStr = '254' + phoneStr.slice(1);
                        else if (!phoneStr.startsWith('254')) phoneStr = '254' + phoneStr;

                        const payoutRes = await fetch('https://api.palpluss.com/v1/b2c/payouts', {
                            method: 'POST',
                            headers: {
                                'Authorization': authHeader,
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                phone: phoneStr,
                                amount: Math.floor(parseFloat(tx.amount)),
                                accountReference: `MW-W-${tx.user_id.slice(0, 8)}`,
                                remarks: 'MetroWins Approved Payout',
                                callbackUrl: CALLBACK_URL,
                                ...(process.env.PALPLUSS_CHANNEL_ID ? { channelId: process.env.PALPLUSS_CHANNEL_ID } : {})
                            })
                        });

                        const payoutData = await payoutRes.json().catch(() => ({}));
                        const nested = payoutData?.data;
                        payoutRef = nested?.transactionId || nested?.id || payoutData?.transactionId || payoutData?.id;

                        if (!payoutRes.ok && payoutData?.success !== true && !payoutRef) {
                            const errMsg = payoutData?.error?.message || payoutData?.message || nested?.message || 'Palpluss B2C payout call failed';
                            console.error('[Admin Approve Withdrawal Payout Failed]:', payoutRes.status, payoutData);
                            return res.status(400).json({ error: `M-Pesa B2C Gateway error: ${errMsg}` });
                        }
                    } catch (netErr) {
                        console.error('[Admin Approve Withdrawal Network Error]:', netErr.message);
                        return res.status(500).json({ error: `Gateway network error: ${netErr.message}` });
                    }
                } else {
                    console.warn('[Admin Approve Withdrawal] PALPLUSS_API_KEY not configured. Marking approved.');
                }

                await query(
                    `UPDATE transactions
                     SET status = 'completed',
                         reference = COALESCE($1, reference),
                         metadata = jsonb_set(
                             COALESCE(metadata::jsonb, '{}'::jsonb),
                             '{approved_by}',
                             jsonb_build_object('admin_id', $2::text, 'approved_at', NOW())::jsonb
                         )
                     WHERE id = $3`,
                    [payoutRef, access.user.id, tx.id]
                );

                await logAdminAction(access.user.id, 'APPROVE_WITHDRAWAL', tx.id, {
                    amount: tx.amount,
                    user_id: tx.user_id,
                    reference: payoutRef || tx.reference
                });

                return res.status(200).json({
                    success: true,
                    message: `Withdrawal of KES ${parseFloat(tx.amount).toLocaleString()} approved and released!`
                });
            }

            case 'reject_withdrawal': {
                const { transactionId, reason } = req.body;
                if (!transactionId) {
                    return res.status(400).json({ error: 'Missing transactionId' });
                }

                const { rows } = await query(
                    `SELECT * FROM transactions WHERE (id::text = $1 OR reference = $1) AND type IN ('withdrawal', 'withdraw') LIMIT 1`,
                    [transactionId]
                );
                const tx = rows[0];
                if (!tx) {
                    return res.status(404).json({ error: 'Withdrawal transaction not found' });
                }
                if (tx.status !== 'pending') {
                    return res.status(400).json({ error: `Withdrawal is already ${tx.status}` });
                }

                const refundAmt = parseFloat(tx.amount);

                // Refund balance to user profile
                await query(
                    `UPDATE profiles SET balance = balance + $1, updated_at = NOW() WHERE id = $2`,
                    [refundAmt, tx.user_id]
                );

                // Mark transaction as rejected
                await query(
                    `UPDATE transactions
                     SET status = 'rejected',
                         metadata = jsonb_set(
                             COALESCE(metadata::jsonb, '{}'::jsonb),
                             '{rejected_by}',
                             jsonb_build_object('admin_id', $1::text, 'reason', $2::text, 'rejected_at', NOW())::jsonb
                         )
                     WHERE id = $3`,
                    [access.user.id, reason || 'Rejected by administrator', tx.id]
                );

                await logAdminAction(access.user.id, 'REJECT_WITHDRAWAL', tx.id, {
                    amount: tx.amount,
                    user_id: tx.user_id,
                    reason: reason || 'Rejected by administrator'
                });

                return res.status(200).json({
                    success: true,
                    message: `Withdrawal rejected. KES ${refundAmt.toLocaleString()} refunded to player account.`
                });
            }

            default:
                return res.status(400).json({ error: 'Invalid action' });
        }
    } catch (err) {
        console.error('[Admin Actions Error]:', err);
        return res.status(500).json({ error: err.message });
    }
}
