-- ==============================================================================
-- SPORTSBOOK MIGRATION: Table, Indexes, and Stored Procedures
-- ==============================================================================

-- 1. Sports Bets Table
CREATE TABLE IF NOT EXISTS sports_bets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
    bet_type VARCHAR(20) DEFAULT 'single', -- 'single', 'accumulator'
    stake NUMERIC(12, 2) NOT NULL CHECK (stake >= 1),
    total_odds NUMERIC(10, 2) NOT NULL CHECK (total_odds >= 1.0),
    potential_payout NUMERIC(12, 2) NOT NULL CHECK (potential_payout >= stake),
    status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'won', 'lost', 'cashed_out', 'cancelled'
    selections JSONB NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    settled_at TIMESTAMPTZ DEFAULT NULL
);

CREATE INDEX IF NOT EXISTS idx_sports_bets_user ON sports_bets(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_sports_bets_status ON sports_bets(status);

-- 2. Place Sports Bet Stored Procedure
CREATE OR REPLACE FUNCTION place_sports_bet(
    p_user_id UUID,
    p_stake NUMERIC,
    p_total_odds NUMERIC,
    p_potential_payout NUMERIC,
    p_bet_type VARCHAR,
    p_selections JSONB
)
RETURNS JSON AS $$
DECLARE
    v_balance NUMERIC;
    v_is_frozen BOOLEAN;
    v_bet_id UUID;
BEGIN
    -- Check user balance and lock row
    SELECT balance, is_frozen INTO v_balance, v_is_frozen
    FROM profiles WHERE id = p_user_id FOR UPDATE;

    IF v_is_frozen THEN
        RETURN json_build_object('success', false, 'error', 'Account is frozen. Please contact support.');
    END IF;

    IF v_balance < p_stake THEN
        RETURN json_build_object('success', false, 'error', 'Insufficient balance. Please deposit funds.');
    END IF;

    -- Deduct balance
    UPDATE profiles
    SET balance = balance - p_stake, updated_at = NOW()
    WHERE id = p_user_id;

    -- Insert sports bet record
    INSERT INTO sports_bets (user_id, stake, total_odds, potential_payout, bet_type, selections, status)
    VALUES (p_user_id, p_stake, p_total_odds, p_potential_payout, p_bet_type, p_selections, 'pending')
    RETURNING id INTO v_bet_id;

    -- Record transaction
    INSERT INTO transactions (user_id, type, amount, status, metadata)
    VALUES (
        p_user_id,
        'sports_bet',
        p_stake,
        'completed',
        json_build_object(
            'bet_id', v_bet_id,
            'bet_type', p_bet_type,
            'total_odds', p_total_odds,
            'potential_payout', p_potential_payout
        )
    );

    RETURN json_build_object(
        'success', true,
        'betId', v_bet_id,
        'newBalance', v_balance - p_stake,
        'stake', p_stake,
        'totalOdds', p_total_odds,
        'potentialPayout', p_potential_payout
    );
END;
$$ LANGUAGE plpgsql;

-- 3. Settle Sports Bet Procedure
CREATE OR REPLACE FUNCTION settle_sports_bet(
    p_bet_id UUID,
    p_status VARCHAR -- 'won', 'lost', 'cancelled'
)
RETURNS JSON AS $$
DECLARE
    v_bet RECORD;
BEGIN
    SELECT * INTO v_bet FROM sports_bets WHERE id = p_bet_id FOR UPDATE;
    IF v_bet IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Bet not found.');
    END IF;

    IF v_bet.status != 'pending' THEN
        RETURN json_build_object('success', false, 'error', 'Bet is already settled.');
    END IF;

    IF p_status = 'won' THEN
        UPDATE profiles
        SET balance = balance + v_bet.potential_payout, updated_at = NOW()
        WHERE id = v_bet.user_id;

        UPDATE sports_bets
        SET status = 'won', settled_at = NOW()
        WHERE id = p_bet_id;

        INSERT INTO transactions (user_id, type, amount, status, metadata)
        VALUES (
            v_bet.user_id,
            'sports_payout',
            v_bet.potential_payout,
            'completed',
            json_build_object('bet_id', p_bet_id, 'game', 'sportsbook')
        );
    ELSIF p_status = 'cancelled' THEN
        UPDATE profiles
        SET balance = balance + v_bet.stake, updated_at = NOW()
        WHERE id = v_bet.user_id;

        UPDATE sports_bets
        SET status = 'cancelled', settled_at = NOW()
        WHERE id = p_bet_id;

        INSERT INTO transactions (user_id, type, amount, status, metadata)
        VALUES (
            v_bet.user_id,
            'sports_refund',
            v_bet.stake,
            'completed',
            json_build_object('bet_id', p_bet_id, 'reason', 'cancelled')
        );
    ELSE
        UPDATE sports_bets
        SET status = 'lost', settled_at = NOW()
        WHERE id = p_bet_id;
    END IF;

    RETURN json_build_object('success', true, 'betId', p_bet_id, 'status', p_status);
END;
$$ LANGUAGE plpgsql;

-- 4. Cash Out Sports Bet Procedure
CREATE OR REPLACE FUNCTION cash_out_sports_bet(
    p_user_id UUID,
    p_bet_id UUID,
    p_cashout_amount NUMERIC
)
RETURNS JSON AS $$
DECLARE
    v_bet RECORD;
BEGIN
    SELECT * INTO v_bet FROM sports_bets WHERE id = p_bet_id AND user_id = p_user_id FOR UPDATE;
    IF v_bet IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Bet not found.');
    END IF;

    IF v_bet.status != 'pending' THEN
        RETURN json_build_object('success', false, 'error', 'Bet cannot be cashed out.');
    END IF;

    IF p_cashout_amount <= 0 OR p_cashout_amount > v_bet.potential_payout THEN
        RETURN json_build_object('success', false, 'error', 'Invalid cashout amount.');
    END IF;

    UPDATE profiles
    SET balance = balance + p_cashout_amount, updated_at = NOW()
    WHERE id = p_user_id;

    UPDATE sports_bets
    SET status = 'cashed_out', settled_at = NOW()
    WHERE id = p_bet_id;

    INSERT INTO transactions (user_id, type, amount, status, metadata)
    VALUES (
        p_user_id,
        'sports_cashout',
        p_cashout_amount,
        'completed',
        json_build_object('bet_id', p_bet_id, 'original_stake', v_bet.stake)
    );

    RETURN json_build_object('success', true, 'betId', p_bet_id, 'cashoutAmount', p_cashout_amount);
END;
$$ LANGUAGE plpgsql;
