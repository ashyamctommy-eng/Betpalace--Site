-- ══════════════════════════════════════════════
-- MIGRATION 008: Secure Cancel Bet RPC
-- ══════════════════════════════════════════════

CREATE OR REPLACE FUNCTION public.cancel_bet(p_bet_id UUID)
RETURNS JSON AS $$
DECLARE
    v_user_id UUID;
    v_amount DECIMAL;
    v_status TEXT;
    v_balance DECIMAL;
BEGIN
    v_user_id := auth.uid();
    IF v_user_id IS NULL THEN
        RETURN json_build_object('error', 'Unauthorized');
    END IF;

    -- Get bet status and amount
    SELECT amount, status INTO v_amount, v_status 
    FROM public.bets WHERE id = p_bet_id AND user_id = v_user_id;

    IF v_amount IS NULL THEN
        RETURN json_build_object('error', 'Bet not found');
    END IF;

    IF v_status != 'playing' THEN
        RETURN json_build_object('error', 'Bet cannot be cancelled at this stage');
    END IF;

    -- Delete or update status to cancelled
    DELETE FROM public.bets WHERE id = p_bet_id;

    -- Return stake back
    UPDATE public.profiles SET balance = balance + v_amount WHERE id = v_user_id;
    
    -- Get updated balance
    SELECT balance INTO v_balance FROM public.profiles WHERE id = v_user_id;

    RETURN json_build_object('success', true, 'new_balance', v_balance);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execution permissions
GRANT EXECUTE ON FUNCTION public.cancel_bet(UUID) TO public;
GRANT EXECUTE ON FUNCTION public.cancel_bet(UUID) TO anon;
GRANT EXECUTE ON FUNCTION public.cancel_bet(UUID) TO authenticated;
