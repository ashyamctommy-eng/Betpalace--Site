/**
 * gameContext.js
 *
 * Shared mutable game state context.
 *
 * WHY THIS FILE EXISTS:
 *   main.js is a 4,782-line monolith where every function directly reads/writes
 *   module-level variables like `balance`, `gameState`, `serverRoundId`, etc.
 *   These cannot be trivially moved to separate files without first establishing
 *   a shared state contract.
 *
 *   This module provides that contract as a single exported object. Sub-modules
 *   (serverSync, betManager, walletManager, uiRenderer) import `ctx` from here
 *   and read/write via `ctx.balance`, `ctx.gameState`, etc. instead of
 *   referencing closure variables in main.js.
 *
 * USAGE:
 *   In new sub-modules:
 *     import { ctx } from '../state/gameContext.js';
 *     ctx.balance = data.new_balance;
 *     console.log(ctx.gameState);
 *
 *   In main.js during migration, bridge the existing vars:
 *     import { ctx } from './state/gameContext.js';
 *     // At the top of main.js, after the let declarations:
 *     ctx.balance = balance;
 *     // Or simply alias: const ctx = gameCtx; and update all reads/writes.
 *
 * NOTE: This is a plain object (not a Proxy/reactive store) to avoid overhead.
 * All writes are direct property assignments — callers are responsible for
 * triggering UI updates after writing, as main.js already does today.
 */

export const ctx = {
    // ── Auth ─────────────────────────────────────────────────────────────
    /** @type {object | null} */
    currentUser: null,

    /** @type {number} User's KES balance, authoritative from server. */
    balance: 0,

    // ── Game state ────────────────────────────────────────────────────────
    /** @type {'waiting' | 'playing' | 'crashed'} */
    gameState: 'waiting',

    /** @type {number} Live multiplier, updated every animation frame. */
    currentMultiplier: 1.0,

    // ── Server sync ───────────────────────────────────────────────────────
    /** @type {number} EWMA-smoothed offset (ms) between server clock and client clock. */
    serverTimeOffset: 0,

    /** @type {number} Epoch-ms when the current round started (server-reported). */
    serverRoundStartTime: 0,

    /** @type {number} Server-authoritative crash multiplier for the current round. */
    serverCrashPoint: 0,

    /** @type {number} Current round identifier from the server. */
    serverRoundId: 0,

    /** @type {'waiting' | 'playing' | 'crashed'} Last status string from the server. */
    serverGameStatus: 'waiting',

    /**
     * Stable local timestamp (epoch-ms) capturing the moment the FLYING phase began.
     * Set once in launchRound(); NEVER overwritten by poll updates.
     * gameTick() reads this so the 1500ms poll cannot reset elapsed time mid-flight.
     * @type {number}
     */
    localFlyStartMs: 0,

    /**
     * Deduplication key for server events.
     * Format: "roundId:status". Prevents double-transitions from realtime + poll.
     * @type {string}
     */
    lastEventKey: '',

    // ── History ───────────────────────────────────────────────────────────
    /** @type {number[]} Last 20 crash multipliers, newest first. */
    crashHistory: [],

    // ── Simulation ────────────────────────────────────────────────────────
    /** @type {any[]} Current round's simulated bot bets. */
    allBets: [],

    /** @type {any[]} Recent cashout events for the winners tab. */
    recentWinners: [],

    /** @type {number} Displayed active player count badge. */
    currentLobbyCount: 0,

    // ── Flags ─────────────────────────────────────────────────────────────
    /** @type {boolean} True when running in demo mode (no real money). */
    isDemoMode: false,
};
