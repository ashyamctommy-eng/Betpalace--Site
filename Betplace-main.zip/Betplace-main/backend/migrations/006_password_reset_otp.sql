-- ══════════════════════════════════════════════
-- MIGRATION 006: Phone OTP Password Reset System
-- ══════════════════════════════════════════════

-- 1. Enable pgcrypto safely for password hashing (bcrypt)
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- 2. Re-create the public.otps table
CREATE TABLE IF NOT EXISTS public.otps (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    phone TEXT NOT NULL,
    code TEXT NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    verified BOOLEAN DEFAULT FALSE
);

-- 3. Enable RLS on otps
ALTER TABLE public.otps ENABLE ROW LEVEL SECURITY;

-- No public policies needed as all operations run through security definer RPC functions.

-- 4. RPC to generate and store password reset OTP
CREATE OR REPLACE FUNCTION public.generate_and_send_reset_otp(p_phone TEXT)
RETURNS JSON AS $$
DECLARE
    v_profile_exists BOOLEAN;
    v_otp_code TEXT;
    v_expires_at TIMESTAMPTZ;
    v_search_phone TEXT;
BEGIN
    -- Strip any non-digits from input for matching raw values
    v_search_phone := regexp_replace(p_phone, '\D', '', 'g');

    -- Check if phone exists (try standard form, lead zero form, or bare E.164 matches)
    SELECT EXISTS(
        SELECT 1 FROM public.profiles 
        WHERE regexp_replace(phone, '\D', '', 'g') = v_search_phone
    ) INTO v_profile_exists;

    IF NOT v_profile_exists THEN
        RETURN json_build_object('success', false, 'error', 'Phone number not registered.');
    END IF;

    -- Generate a clean 6-digit random code
    v_otp_code := lpad(floor(random() * 1000000)::text, 6, '0');
    v_expires_at := now() + interval '5 minutes';

    -- Insert into otps table
    INSERT INTO public.otps (phone, code, expires_at)
    VALUES (p_phone, v_otp_code, v_expires_at);

    -- For demo/simulation, we return the generated code so the client-side can display it
    RETURN json_build_object('success', true, 'code', v_otp_code);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 5. RPC to verify OTP and update auth.users password
CREATE OR REPLACE FUNCTION public.verify_otp_and_reset_password(
    p_phone TEXT,
    p_code TEXT,
    p_new_password TEXT
)
RETURNS JSON AS $$
DECLARE
    v_profile_id UUID;
    v_otp_id UUID;
    v_search_phone TEXT;
BEGIN
    v_search_phone := regexp_replace(p_phone, '\D', '', 'g');

    -- Check if OTP exists and is valid (not expired, not verified)
    SELECT id INTO v_otp_id
    FROM public.otps
    WHERE regexp_replace(phone, '\D', '', 'g') = v_search_phone 
    AND code = p_code 
    AND expires_at > now() 
    AND verified = false
    ORDER BY created_at DESC
    LIMIT 1;

    IF v_otp_id IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Invalid or expired OTP code.');
    END IF;

    -- Get corresponding profile ID
    SELECT id INTO v_profile_id
    FROM public.profiles
    WHERE regexp_replace(phone, '\D', '', 'g') = v_search_phone
    LIMIT 1;

    IF v_profile_id IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Profile not found.');
    END IF;

    -- Update password in auth.users using crypt utility
    UPDATE auth.users
    SET encrypted_password = crypt(p_new_password, gen_salt('bf', 10)),
        updated_at = now()
    WHERE id = v_profile_id;

    -- Mark OTP as verified
    UPDATE public.otps
    SET verified = true
    WHERE id = v_otp_id;

    RETURN json_build_object('success', true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
