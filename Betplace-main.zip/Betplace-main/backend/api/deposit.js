/**
 * backend/api/deposit.js
 *
 * STK Push via Palpluss API (M-Pesa).
 * Uses direct PostgreSQL queries via _lib/db.js. Zero Supabase.
 */

import { verifyAuthToken } from './_lib/auth.js';
import { setCorsHeaders } from './_lib/cors.js';
import { query } from './_lib/db.js';
import { getFinancialLimits } from './_lib/limits.js';

export default async function depositHandler(req, res) {
    setCorsHeaders(req, res, 'POST, OPTIONS');

    if (req.method === 'OPTIONS') return res.status(200).end();
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

    // 1. Authenticate the caller via JWT
    const auth = await verifyAuthToken(req);
    if (!auth.success) {
        return res.status(auth.status).json({ success: false, message: auth.error });
    }
    const userId = auth.user.id;

    // 2. Validate inputs
    const body = typeof req.body === 'string' ? JSON.parse(req.body) : (req.body || {});
    const { phone, amount } = body;
    const depositAmt = Number(amount);
    const limits = await getFinancialLimits();
    const minDep = limits.minDeposit || 99;
    const maxDep = limits.maxDeposit || 300000;

    if (!phone || !amount || isNaN(depositAmt) || depositAmt < minDep || depositAmt > maxDep) {
        return res.status(400).json({
            success: false,
            message: `Invalid deposit amount. Minimum deposit is KES ${minDep}, maximum is KES ${maxDep.toLocaleString()}.`
        });
    }

    const phoneStr = String(phone).replace(/[\s\-()]/g, '');
    if (!/^(\+?254|0)[17]\d{8}$/.test(phoneStr)) {
        return res.status(400).json({ success: false, message: 'Invalid phone number format.' });
    }

    // 3. Check account is not frozen
    const { rows: profileRows } = await query('SELECT is_frozen FROM profiles WHERE id = $1', [userId]);
    if (profileRows[0]?.is_frozen) {
        return res.status(403).json({ success: false, message: 'Your account is frozen. Contact support.' });
    }

    // 4. Rate limiting: max 3 deposits per minute per user
    const oneMinAgo = new Date(Date.now() - 60 * 1000).toISOString();
    const { rows: countRows } = await query(
        `SELECT COUNT(*) AS count FROM transactions
         WHERE user_id = $1 AND type = 'deposit' AND created_at >= $2`,
        [userId, oneMinAgo]
    );

    if (parseInt(countRows[0]?.count, 10) >= 3) {
        return res.status(429).json({ success: false, message: 'Too many deposit requests. Please wait a minute.' });
    }

    const PALPLUSS_API_KEY    = process.env.PALPLUSS_API_KEY;
    const PALPLUSS_CHANNEL_ID = process.env.PALPLUSS_CHANNEL_ID;
    const CALLBACK_URL        = process.env.PALPLUSS_CALLBACK_URL;

    let normalizedPhone = phoneStr.replace(/^\+/, '');
    if (normalizedPhone.startsWith('0')) normalizedPhone = '254' + normalizedPhone.slice(1);

    if (!PALPLUSS_API_KEY) {
        return res.status(503).json({ success: false, message: 'Payment gateway not configured.' });
    }

    const idempotencyKey = `DEP-${userId.slice(0, 8)}-${Date.now()}`;

    // Insert initiated transaction
    const { rows: txRows } = await query(
        `INSERT INTO transactions (user_id, type, amount, status, phone, reference)
         VALUES ($1, 'deposit', $2, 'initiated', $3, $4)
         RETURNING id`,
        [userId, Math.ceil(depositAmt), normalizedPhone, idempotencyKey]
    );

    const pendingTxId = txRows[0]?.id;

    const payload = {
        phone:            normalizedPhone,
        amount:           Math.ceil(depositAmt),
        accountReference: `MW-${userId.slice(0, 8)}`,
        transactionDesc:  'MetroWins Dep',
        callbackUrl:      CALLBACK_URL,
        ...(PALPLUSS_CHANNEL_ID ? { channelId: PALPLUSS_CHANNEL_ID } : {})
    };

    try {
        const authHeader = 'Basic ' + Buffer.from(PALPLUSS_API_KEY + ':').toString('base64');
        const stkRes = await fetch('https://api.palpluss.com/v1/payments/stk', {
            method:  'POST',
            headers: {
                'Authorization': authHeader,
                'Content-Type':  'application/json'
            },
            body: JSON.stringify(payload)
        });

        const stkData = await stkRes.json();
        const nestedData = stkData?.data;
        const ref = nestedData?.transactionId || nestedData?.id || stkData?.transactionId || stkData?.id;
        const status = nestedData?.status || stkData?.status;
        const isSuccess = stkData?.success === true || nestedData?.success === true;

        if (stkRes.ok && (status === 'PENDING' || isSuccess || ref)) {
            await query(
                `UPDATE transactions SET status = 'pending', reference = $1 WHERE id = $2`,
                [ref || idempotencyKey, pendingTxId]
            );

            return res.status(200).json({
                success:       true,
                transactionId: ref,
                message:       'STK Push sent. Check your phone and enter your M-Pesa PIN.'
            });
        } else {
            await query(
                `UPDATE transactions SET status = 'failed' WHERE id = $1`,
                [pendingTxId]
            );

            const errorMsg = stkData?.error?.message || stkData?.message || nestedData?.message || 'STK Push failed';
            return res.status(400).json({ success: false, message: errorMsg });
        }
    } catch (err) {
        console.error('Palpluss deposit error:', err.message);
        await query(
            `UPDATE transactions SET status = 'failed' WHERE id = $1`,
            [pendingTxId]
        ).catch(() => {});
        return res.status(500).json({ success: false, message: 'Payment gateway error. Please try again.' });
    }
}
