-- ═══════════════════════════════════════════════════════════════
-- MIGRATION 021: Standardize Aviator Unpredictability
-- ═══════════════════════════════════════════════════════════════

-- 1. Updates standard config in system settings to have real Aviator house edge
UPDATE public.system_settings
SET value = '{"instant_crash_rate": 0.03, "dynamic_mode": true, "high_bet_limit": 15000.00, "extreme_bet_limit": 50000.00}'::jsonb
WHERE key = 'aviator_config';

-- If it doesn't exist, insert it
INSERT INTO public.system_settings (key, value)
VALUES (
    'aviator_config',
    '{"instant_crash_rate": 0.03, "dynamic_mode": true, "high_bet_limit": 15000.00, "extreme_bet_limit": 50000.00}'::jsonb
)
ON CONFLICT (key) DO NOTHING;

-- 2. Modify game state loop function to use a realistic Aviator multiplier curve
CREATE OR REPLACE FUNCTION public.sync_and_get_game_state()
RETURNS JSON AS $$
DECLARE
    v_state RECORD;
    v_now TIMESTAMPTZ;
    v_elapsed INT;
    v_needs_update BOOLEAN := false;
    v_status TEXT;
    v_round_id BIGINT;
    v_crash_point DECIMAL;
    v_start_time TIMESTAMPTZ;
    v_waiting_ms INT := 5000;
    v_max_flight_ms INT := 300000;
    v_post_crash_ms INT := 3000;
    v_elapsed_sec DECIMAL;
    v_calc_mult DECIMAL;
    v_random DECIMAL;
    v_new_crash_point DECIMAL;
    
    -- Config & dynamics
    v_config JSONB;
    v_instant_crash_rate DECIMAL := 0.03; -- default 3% instant crash rate
    v_dynamic_mode BOOLEAN := true;
    v_high_bet_limit DECIMAL := 15000.00;
    v_extreme_bet_limit DECIMAL := 50000.00;
    v_total_bets DECIMAL := 0.00;
BEGIN
    v_now := now();
    
    -- Read config
    SELECT value INTO v_config FROM public.system_settings WHERE key = 'aviator_config' LIMIT 1;
    IF v_config IS NOT NULL THEN
        v_instant_crash_rate := COALESCE((v_config->>'instant_crash_rate')::DECIMAL, 0.03);
        v_dynamic_mode       := COALESCE((v_config->>'dynamic_mode')::BOOLEAN, true);
        v_high_bet_limit     := COALESCE((v_config->>'high_bet_limit')::DECIMAL, 15000.00);
        v_extreme_bet_limit  := COALESCE((v_config->>'extreme_bet_limit')::DECIMAL, 50000.00);
    END IF;

    -- Get current state
    SELECT * INTO v_state FROM public.active_game_state WHERE id = 1 LIMIT 1;
    
    -- If no row exists, initialize it
    IF v_state IS NULL THEN
        INSERT INTO public.active_game_state (id, round_id, start_time, crash_point, status, server_time)
        VALUES (1, 1, v_now, 1.50, 'waiting', v_now)
        RETURNING * INTO v_state;
    END IF;

    v_status := v_state.status;
    v_round_id := v_state.round_id;
    v_crash_point := v_state.crash_point;
    v_start_time := v_state.start_time;

    -- Calculate elapsed milliseconds since last phase transition
    v_elapsed := EXTRACT(EPOCH FROM (v_now - v_start_time)) * 1000;

    -- Phase advance logic
    IF v_status = 'waiting' THEN
        IF v_elapsed >= v_waiting_ms THEN
            v_status := 'playing';
            v_start_time := v_now;
            v_elapsed := 0;
            v_needs_update := true;
            
            -- Dynamic bet-based capping (prevent excessive exposure on rare humongous table volume)
            IF v_dynamic_mode THEN
                SELECT COALESCE(SUM(amount), 0) INTO v_total_bets 
                FROM public.bets 
                WHERE round_id = v_round_id;
                
                IF v_total_bets >= v_extreme_bet_limit THEN
                    -- Extreme stakes: Force crash under 1.20 to protect liquidity
                    IF random() < 0.85 THEN
                        v_crash_point := round(1.00 + (random() * 0.19), 2);
                    ELSE
                        v_crash_point := 1.00;
                    END IF;
                ELSIF v_total_bets >= v_high_bet_limit THEN
                    -- High stakes: Cap crash under 1.80
                    IF random() < 0.70 THEN
                        v_crash_point := round(1.01 + (random() * 0.79), 2);
                    END IF;
                END IF;
            END IF;
        END IF;
    ELSIF v_status = 'playing' THEN
        -- Multiplier growth mapping: 1.06^seconds
        v_elapsed_sec := v_elapsed::DECIMAL / 1000.0;
        v_calc_mult := power(1.06, v_elapsed_sec);
        
        IF v_calc_mult >= v_crash_point OR v_elapsed >= v_max_flight_ms THEN
            v_status := 'crashed';
            v_start_time := v_now;
            v_elapsed := 0;
            v_needs_update := true;
        END IF;
    ELSIF v_status = 'crashed' THEN
        IF v_elapsed >= v_post_crash_ms + 2000 THEN -- Add 2s flight buffer
            v_status := 'waiting';
            v_round_id := v_round_id + 1;
            v_start_time := v_now;
            v_elapsed := 0;
            -- Generate unpredictable, standard casino-like crash point
            IF v_state.next_crash_point IS NOT NULL THEN
                v_new_crash_point := v_state.next_crash_point;
            ELSE
                v_random := random();
                -- Dynamic bet-based checks can also override values if needed, otherwise fallback:
                IF v_random < v_instant_crash_rate THEN
                    -- Standard ~3% instant crash house edge
                    v_new_crash_point := 1.00;
                ELSIF v_random < 0.40 THEN
                    -- 37% chance: Low multipliers (1.01 to 1.80)
                    v_new_crash_point := 1.01 + (random() * 0.79);
                ELSIF v_random < 0.80 THEN
                    -- 40% chance: Moderate multipliers (1.80 to 7.00)
                    v_new_crash_point := 1.80 + (random() * 5.20);
                ELSIF v_random < 0.95 THEN
                    -- 15% chance: High multipliers (7.00 to 25.00)
                    v_new_crash_point := 7.00 + (random() * 18.00);
                ELSE
                    -- 5% chance: Sky-high multipliers (25.00 to 200.00)
                    v_new_crash_point := 25.00 + (random() * 175.00);
                END IF;
            END IF;
            v_crash_point := round(v_new_crash_point, 2);
            
            v_needs_update := true;
        END IF;
    END IF;

    -- Save changes if state transitioned
    IF v_needs_update THEN
        UPDATE public.active_game_state
        SET status = v_status,
            round_id = v_round_id,
            crash_point = v_crash_point,
            start_time = v_start_time,
            server_time = v_now,
            next_crash_point = CASE WHEN v_status = 'waiting' THEN NULL ELSE next_crash_point END
        WHERE id = 1;
        
        -- If transitioned to crashed, insert into game history
        IF v_status = 'crashed' THEN
            INSERT INTO public.game_history (multiplier)
            VALUES (v_crash_point);
        END IF;
    END IF;

    RETURN json_build_object(
        'roundId', v_round_id,
        'roundStartTime', EXTRACT(EPOCH FROM v_start_time) * 1000,
        'crashPoint', v_crash_point,
        'gameStatus', v_status,
        'serverTime', EXTRACT(EPOCH FROM v_now) * 1000,
        'elapsedMs', v_elapsed
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
