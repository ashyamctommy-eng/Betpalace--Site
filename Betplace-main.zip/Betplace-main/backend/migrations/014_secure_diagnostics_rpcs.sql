-- MIGRATION 014: Secure Diagnostics and Repair RPC functions
-- By shifting auth.users listing logic to SECURITY DEFINER database functions,
-- Vercel endpoints do not require the SUPABASE_SERVICE_ROLE_KEY to perform user diagnostics/repair.

-- 1. DIAGNOSE USERS RPC FUNCTION
CREATE OR REPLACE FUNCTION public.diagnose_users_rpc()
RETURNS JSON
SECURITY DEFINER
AS $$
DECLARE
    auth_count INT;
    profile_count INT;
    missing_users JSON;
BEGIN
    -- Security Check: Limit access to Super Admin or Admin roles
    IF NOT EXISTS (
        SELECT 1 FROM public.user_roles ur
        JOIN public.roles r ON ur.role_id = r.id
        WHERE ur.user_id = auth.uid() AND r.name IN ('Super Admin', 'Admin')
    ) THEN
        RAISE EXCEPTION 'Unauthorized: Diagnostics are restricted to administrative roles.';
    END IF;

    SELECT count(*) INTO auth_count FROM auth.users;
    SELECT count(*) INTO profile_count FROM public.profiles;

    SELECT json_agg(json_build_object(
        'id', u.id,
        'email', u.email,
        'phone', u.phone,
        'created_at', u.created_at
    )) INTO missing_users
    FROM auth.users u
    LEFT JOIN public.profiles p ON u.id = p.id
    WHERE p.id IS NULL;

    RETURN json_build_object(
        'auth_count', auth_count,
        'profile_count', profile_count,
        'missing', COALESCE(missing_users, '[]'::json)
    );
END;
$$ LANGUAGE plpgsql;

-- 2. REPAIR USERS RPC FUNCTION
CREATE OR REPLACE FUNCTION public.repair_users_rpc()
RETURNS JSON
SECURITY DEFINER
AS $$
DECLARE
    missing_count INT;
    repaired_list JSON;
BEGIN
    -- Security Check: Limit access to Super Admin or Admin roles
    IF NOT EXISTS (
        SELECT 1 FROM public.user_roles ur
        JOIN public.roles r ON ur.role_id = r.id
        WHERE ur.user_id = auth.uid() AND r.name IN ('Super Admin', 'Admin')
    ) THEN
        RAISE EXCEPTION 'Unauthorized: User repairing is restricted to administrative roles.';
    END IF;

    -- Capture the list of missing users that will be repaired
    SELECT json_agg(json_build_object(
        'id', u.id,
        'username', COALESCE(u.raw_user_meta_data->>'username', 'player_' || substring(u.id::text from 1 for 8)),
        'phone', COALESCE(u.phone, u.raw_user_meta_data->>'phone', 'dummy_' || replace(u.id::text, '-', ''))
    )) INTO repaired_list
    FROM auth.users u
    LEFT JOIN public.profiles p ON u.id = p.id
    WHERE p.id IS NULL;

    SELECT count(*) INTO missing_count
    FROM auth.users u
    LEFT JOIN public.profiles p ON u.id = p.id
    WHERE p.id IS NULL;

    -- Rebuild missing Profiles in public.profiles using their auth metadata
    INSERT INTO public.profiles (id, phone, username, email, balance, is_admin, is_frozen)
    SELECT 
        u.id,
        COALESCE(u.phone, u.raw_user_meta_data->>'phone', 'dummy_' || replace(u.id::text, '-', '')),
        COALESCE(u.raw_user_meta_data->>'username', 'player_' || substring(u.id::text from 1 for 8)),
        COALESCE(u.email, u.phone || '@metricwin.app', u.id::text || '@metricwin.app'),
        0.00,
        false,
        false
    FROM auth.users u
    LEFT JOIN public.profiles p ON u.id = p.id
    WHERE p.id IS NULL
    ON CONFLICT (id) DO NOTHING;

    RETURN json_build_object(
        'success', true,
        'attempted', missing_count,
        'repaired', COALESCE(repaired_list, '[]'::json)
    );
END;
$$ LANGUAGE plpgsql;

-- Grant execution permissions
GRANT EXECUTE ON FUNCTION public.diagnose_users_rpc() TO authenticated;
GRANT EXECUTE ON FUNCTION public.repair_users_rpc() TO authenticated;
