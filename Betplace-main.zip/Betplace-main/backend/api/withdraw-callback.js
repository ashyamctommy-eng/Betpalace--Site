/**
 * backend/api/withdraw-callback.js
 *
 * Webhook receiver for Palpluss M-Pesa B2C withdrawal confirmations & failure refunds.
 * Zero Supabase dependency. Uses pure PostgreSQL transactions.
 */

import { createHmac, timingSafeEqual } from 'crypto';
import { getClient } from './_lib/db.js';

function verifyWebhookSignature(req, rawBody) {
    const secret = process.env.PALPLUSS_WEBHOOK_SECRET;
    if (!secret) return true;

    const sigHeader = req.headers['x-palpluss-signature'] ||
                      req.headers['x-webhook-signature'] ||
                      req.headers['x-signature'];
    if (!sigHeader) return false;

    try {
        const expected = createHmac('sha256', secret).update(rawBody).digest('hex');
        const received = sigHeader.replace('sha256=', '');
        return timingSafeEqual(Buffer.from(expected, 'hex'), Buffer.from(received, 'hex'));
    } catch {
        return false;
    }
}

export default async function withdrawCallbackHandler(req, res) {
    if (req.method !== 'POST') return res.status(405).end();

    const rawBody = req.rawBody || (typeof req.body === 'string' ? req.body : JSON.stringify(req.body));
    if (!verifyWebhookSignature(req, rawBody)) {
        console.error('B2C callback signature verification FAILED.');
        return res.status(401).json({ error: 'Invalid webhook signature.' });
    }

    let body = req.body;
    if (typeof body === 'string') {
        try { body = JSON.parse(body); } catch {}
    }

    const transaction = body?.transaction || {};
    const status      = (transaction?.status || body?.status || '').toUpperCase();
    const amount      = parseFloat(transaction?.amount || body?.amount || 0);
    const mpesaRef    = transaction?.id || body?.transactionId || body?.reference;
    const externalRef = transaction?.external_reference || body?.external_reference;

    if (!mpesaRef && !externalRef) {
        return res.status(200).json({ received: true });
    }

    const client = await getClient();

    try {
        await client.query('BEGIN');

        // Find transaction
        const { rows } = await client.query(
            `SELECT * FROM transactions
             WHERE reference = $1 OR reference = $2
             LIMIT 1 FOR UPDATE`,
            [mpesaRef, externalRef]
        );

        const tx = rows[0];
        if (!tx) {
            console.warn(`[Withdrawal Webhook] Transaction not found for ref: ${mpesaRef || externalRef}`);
            await client.query('COMMIT');
            return res.status(200).json({ received: true });
        }

        if (tx.status === 'completed' || tx.status === 'refunded') {
            await client.query('COMMIT');
            return res.status(200).json({ received: true, message: 'Already processed.' });
        }

        const isSuccess = status === 'SUCCESS' || status === 'COMPLETED' || status === 'PAID';

        if (isSuccess) {
            await client.query(
                "UPDATE transactions SET status = 'completed', metadata = $1 WHERE id = $2",
                [JSON.stringify(body), tx.id]
            );
            console.log(`[Withdrawal Webhook] Payout confirmed for tx ${tx.id}.`);
        } else {
            // Refund user balance
            await client.query(
                'UPDATE profiles SET balance = balance + $1, updated_at = NOW() WHERE id = $2',
                [tx.amount, tx.user_id]
            );

            await client.query(
                "UPDATE transactions SET status = 'refunded', metadata = $1 WHERE id = $2",
                [JSON.stringify(body), tx.id]
            );
            console.log(`[Withdrawal Webhook] Payout failed. Refunded KES ${tx.amount} to user ${tx.user_id}.`);
        }

        await client.query('COMMIT');
        return res.status(200).json({ received: true });
    } catch (err) {
        await client.query('ROLLBACK');
        console.error('[Withdrawal Callback Error]:', err);
        return res.status(500).json({ error: err.message });
    } finally {
        client.release();
    }
}
