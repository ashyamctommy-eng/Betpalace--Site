-- ══════════════════════════════════════════════
-- MIGRATION 007: Serverless Authoritative Game Loop RPC
-- ══════════════════════════════════════════════

-- Create RPC to safely sync and advance the game state
CREATE OR REPLACE FUNCTION public.sync_and_get_game_state()
RETURNS JSON AS $$
DECLARE
    v_state RECORD;
    v_now TIMESTAMPTZ;
    v_elapsed INT;
    v_needs_update BOOLEAN := false;
    v_status TEXT;
    v_round_id BIGINT;
    v_crash_point DECIMAL;
    v_start_time TIMESTAMPTZ;
    v_waiting_ms INT := 5000;
    v_max_flight_ms INT := 300000; -- Allow up to 5 minutes of flight duration to support high multipliers
    v_post_crash_ms INT := 3000;
    v_elapsed_sec DECIMAL;
    v_calc_mult DECIMAL;
    v_random DECIMAL;
    v_new_crash_point DECIMAL;
BEGIN
    v_now := now();
    
    -- Get current state
    SELECT * INTO v_state FROM public.active_game_state WHERE id = 1 LIMIT 1;
    
    -- If no row exists, initialize it
    IF v_state IS NULL THEN
        INSERT INTO public.active_game_state (id, round_id, start_time, crash_point, status, server_time)
        VALUES (1, 1, v_now, 2.50, 'waiting', v_now)
        RETURNING * INTO v_state;
    END IF;

    v_status := v_state.status;
    v_round_id := v_state.round_id;
    v_crash_point := v_state.crash_point;
    v_start_time := v_state.start_time;

    -- Calculate elapsed milliseconds since last phase transition
    v_elapsed := EXTRACT(EPOCH FROM (v_now - v_start_time)) * 1000;

    -- Phase advance logic
    IF v_status = 'waiting' THEN
        IF v_elapsed >= v_waiting_ms THEN
            v_status := 'playing';
            v_start_time := v_now;
            v_elapsed := 0;
            v_needs_update := true;
        END IF;
    ELSIF v_status = 'playing' THEN
        -- Multiplier growth mapping: 1.06^seconds
        v_elapsed_sec := v_elapsed::DECIMAL / 1000.0;
        v_calc_mult := power(1.06, v_elapsed_sec);
        
        IF v_calc_mult >= v_crash_point OR v_elapsed >= v_max_flight_ms THEN
            v_status := 'crashed';
            v_start_time := v_now;
            v_elapsed := 0;
            v_needs_update := true;
        END IF;
    ELSIF v_status = 'crashed' THEN
        IF v_elapsed >= v_post_crash_ms + 2000 THEN -- Add 2s flight buffer
            v_status := 'waiting';
            v_round_id := v_round_id + 1;
            v_start_time := v_now;
            v_elapsed := 0;
            
            -- Generate balanced, fair, and unpredictable crash point
            v_random := random();
            IF v_random < 0.03 THEN
                -- 3% instant crash house edge
                v_new_crash_point := 1.00;
            ELSIF v_random < 0.45 THEN
                -- 42% chance: Low-to-moderate multipliers (1.01 to 2.50)
                v_new_crash_point := 1.01 + (random() * 1.49);
            ELSIF v_random < 0.80 THEN
                -- 35% chance: Moderate multipliers (2.50 to 7.50)
                v_new_crash_point := 2.50 + (random() * 5.00);
            ELSIF v_random < 0.95 THEN
                -- 15% chance: High multipliers (7.50 to 25.00)
                v_new_crash_point := 7.50 + (random() * 17.50);
            ELSE
                -- 5% chance: Rare sky-high multipliers (25.00 to 150.00)
                v_new_crash_point := 25.00 + (random() * 125.00);
            END IF;
            v_crash_point := round(v_new_crash_point, 2);
            
            v_needs_update := true;
        END IF;
    END IF;

    -- Save changes if state transitioned
    IF v_needs_update THEN
        UPDATE public.active_game_state
        SET status = v_status,
            round_id = v_round_id,
            crash_point = v_crash_point,
            start_time = v_start_time,
            server_time = v_now
        WHERE id = 1;
        
        -- If transitioned to crashed, insert into game history
        IF v_status = 'crashed' THEN
            INSERT INTO public.game_history (multiplier)
            VALUES (v_crash_point);
        END IF;
    END IF;

    RETURN json_build_object(
        'roundId', v_round_id,
        'roundStartTime', EXTRACT(EPOCH FROM v_start_time) * 1000,
        'crashPoint', v_crash_point,
        'gameStatus', v_status,
        'serverTime', EXTRACT(EPOCH FROM v_now) * 1000,
        'elapsedMs', v_elapsed
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execution to public anon / authenticated roles
GRANT EXECUTE ON FUNCTION public.sync_and_get_game_state() TO public;
GRANT EXECUTE ON FUNCTION public.sync_and_get_game_state() TO anon;
GRANT EXECUTE ON FUNCTION public.sync_and_get_game_state() TO authenticated;
