/**
 * backend/scripts/migrate.js
 *
 * PostgreSQL Migration Runner for MetroWins (Zero Supabase).
 * Applies backend/schema.sql to any standard PostgreSQL database.
 *
 * Usage:
 *   node scripts/migrate.js
 *   or: npm run db:migrate
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import pg from 'pg';
import dotenv from 'dotenv';

dotenv.config();

const { Client } = pg;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const SCHEMA_FILE = path.resolve(__dirname, '../schema.sql');

const connectionString = process.env.DATABASE_URL;

if (!connectionString) {
    console.error('\x1b[31m[Database Error]\x1b[0m DATABASE_URL environment variable is required.');
    console.error('Example: postgresql://postgres:password@localhost:5432/metrowins');
    process.exit(1);
}

const isLocal = connectionString.includes('localhost') || connectionString.includes('127.0.0.1');

const client = new Client({
    connectionString,
    ssl: isLocal ? false : { rejectUnauthorized: false }
});

async function runMigration() {
    try {
        console.log('\x1b[36m[MetroWins Database]\x1b[0m Connecting to PostgreSQL...');
        await client.connect();
        console.log('\x1b[32m[Connected]\x1b[0m Connection established successfully.');

        console.log('\x1b[33m[Applying Schema]\x1b[0m Executing schema.sql...');
        const sql = fs.readFileSync(SCHEMA_FILE, 'utf8');

        await client.query(sql);

        console.log('\x1b[32m[Success]\x1b[0m Schema applied successfully! All tables, indexes, and stored functions are ready.');
    } catch (err) {
        console.error('\x1b[31m[Migration Failed]\x1b[0m', err.message);
        process.exit(1);
    } finally {
        await client.end();
    }
}

runMigration();
