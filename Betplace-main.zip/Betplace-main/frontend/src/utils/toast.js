/**
 * Universal Toast Notification System
 */

export function showToast(msg, type = 'info') {
    const parent = document.getElementById('app') || document.body;
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.style.position = 'fixed';
        container.style.bottom = '20px';
        container.style.right = '20px';
        container.style.zIndex = '9999';
        container.style.display = 'flex';
        container.style.flexDirection = 'column';
        container.style.gap = '8px';
        container.style.maxWidth = '340px';
        parent.appendChild(container);
    }
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.style.background = type === 'error' ? 'rgba(24, 16, 22, 0.96)' : type === 'success' ? 'rgba(14, 24, 20, 0.96)' : 'rgba(14, 20, 31, 0.95)';
    toast.style.backdropFilter = 'blur(12px)';
    toast.style.webkitBackdropFilter = 'blur(12px)';
    toast.style.color = type === 'error' ? '#FDA4AF' : type === 'success' ? '#BBF7D0' : '#E2E8F0';
    toast.style.border = type === 'error' ? '1px solid rgba(244, 63, 94, 0.28)' : type === 'success' ? '1px solid rgba(34, 197, 94, 0.25)' : '1px solid rgba(255, 255, 255, 0.08)';
    toast.style.borderRadius = '8px';
    toast.style.padding = '8px 14px';
    toast.style.fontSize = '0.8125rem';
    toast.style.fontWeight = '500';
    toast.style.letterSpacing = '-0.1px';
    toast.style.boxShadow = '0 4px 16px rgba(0, 0, 0, 0.35)';
    toast.style.display = 'flex';
    toast.style.alignItems = 'center';
    toast.style.gap = '8px';
    toast.style.transition = 'opacity 0.2s ease, transform 0.25s cubic-bezier(0.16, 1, 0.3, 1)';
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(8px)';

    const iconSvg = type === 'error'
        ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#F87171" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>'
        : type === 'success'
        ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#4ADE80" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="9 11 12 14 22 4"></polyline></svg>'
        : '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>';

    toast.innerHTML = `<span style="display:inline-flex;align-items:center;flex-shrink:0;">${iconSvg}</span><span style="flex:1;">${msg}</span>`;
    
    container.appendChild(toast);
    
    requestAnimationFrame(() => {
        toast.style.opacity = '1';
        toast.style.transform = 'translateY(0)';
    });

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(-6px)';
        setTimeout(() => toast.remove(), 250);
    }, 2800);
}

if (typeof window !== 'undefined') {
    window.showToast = showToast;
}
