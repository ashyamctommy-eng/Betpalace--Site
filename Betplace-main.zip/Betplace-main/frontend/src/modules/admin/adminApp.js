import { supabase } from '../../config/supabase.js';
import { injectVercelAnalytics } from '../../utils/analytics.js';
import { showToast } from '../../utils/toast.js';

export function initAdminApp() {
    injectVercelAnalytics();
}
