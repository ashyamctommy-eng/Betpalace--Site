/**
 * serverSync.js
 *
 * Server state polling and Supabase Realtime subscription.
 *
 * Extracted from main.js (lines ~405–797) to make server sync testable in isolation.
 *
 * Depends on: gameContext.ctx for shared state reads/writes.
 * Calls back into main.js via the `handlers` object passed to `initServerSync()`.
 * This avoids circular imports while keeping the extraction clean.
 */

import { supabase } from '../../config/supabase.js';
import { ctx } from '../../state/gameContext.js';

// ── State rank map (mirrors main.js) ─────────────────────────────────────────
const STATE_RANK = { waiting: 0, playing: 1, crashed: 2 };

/**
 * @typedef {Object} ServerSyncHandlers
 * @property {(status: string) => void} onStatusChange - Called when server status changes
 * @property {() => void} onHistoryUpdate - Called when crash history is refreshed
 * @property {() => Promise<void>} onBetsRecovery - Called to reconcile FSM with server
 */

/**
 * Fetches and processes the authoritative game state from the server.
 * Applies RTT-compensated EWMA clock correction.
 *
 * @param {ServerSyncHandlers} handlers
 * @returns {Promise<object|null>}
 */
export async function fetchServerState(handlers) {
    try {
        const pollSentAt = Date.now();

        // Primary: Supabase RPC game loop
        const { data: rpcData, error: rpcErr } = await supabase.rpc('sync_and_get_game_state');
        let data = rpcData;

        if (rpcErr || !data || data.error) {
            // Fallback: REST API via /api/game (Cloudflare Worker → API backend)
            const url = import.meta.env.VITE_GAME_STATE_URL || '/api/game';
            const headers = {};
            try {
                const { data: { session } } = await supabase.auth.getSession();
                if (session?.access_token) {
                    headers['Authorization'] = `Bearer ${session.access_token}`;
                }
            } catch (_) {}

            const res = await fetch(url, { headers });
            data = await res.json();

            // Fallback: deterministic round calculation when API also fails
            if (!data || data.error || (typeof data.roundId === 'undefined' && typeof data.round_id === 'undefined')) {
                const ROUND_DURATION = 60000;
                const now = Date.now();
                const windowStart = Math.floor(now / ROUND_DURATION);
                const roundId = windowStart;

                let seed = (roundId * 9301 + 49297) % 233280;
                let rnd = seed / 233280;

                let fallbackCrashPoint;
                if (rnd < 0.10) {
                    fallbackCrashPoint = 1.00;
                } else if (rnd < 0.40) {
                    fallbackCrashPoint = parseFloat((1.01 + ((rnd * 10) % 1) * 0.79).toFixed(2));
                } else if (rnd < 0.80) {
                    fallbackCrashPoint = parseFloat((1.80 + ((rnd * 100) % 1) * 5.20).toFixed(2));
                } else if (rnd < 0.95) {
                    fallbackCrashPoint = parseFloat((7.00 + ((rnd * 1000) % 1) * 18.00).toFixed(2));
                } else {
                    fallbackCrashPoint = parseFloat((25.00 + ((rnd * 10000) % 1) * 175.00).toFixed(2));
                }

                data = {
                    roundId,
                    roundStartTime: windowStart * ROUND_DURATION,
                    crashPoint: fallbackCrashPoint,
                    gameStatus: (now - (windowStart * ROUND_DURATION) < 5000) ? 'waiting' : 'playing',
                    serverTime: now
                };
            }
        }

        if (typeof data === 'string') {
            try { data = JSON.parse(data); } catch (_) {}
        }
        if (!data || typeof data !== 'object') return null;

        const pollReceivedAt = Date.now();

        // ── RTT-compensated clock correction ─────────────────────────────
        const rawSTime = data.serverTime ?? data.server_time ?? 0;
        let sTime = typeof rawSTime === 'string' ? new Date(rawSTime).getTime() : Number(rawSTime);
        if (!sTime || isNaN(sTime)) sTime = pollReceivedAt;

        const rtt = Math.max(0, pollReceivedAt - pollSentAt);
        const measuredOffset = sTime - pollReceivedAt + Math.round(rtt / 2);
        ctx.serverTimeOffset = Math.round(ctx.serverTimeOffset * 0.80 + measuredOffset * 0.20);

        // Update shared state (history only outside active rounds to avoid spoiling)
        ctx.serverRoundStartTime = Number(data.roundStartTime ?? data.round_start_time ?? data.start_time) || pollReceivedAt;
        ctx.serverCrashPoint     = Number(data.crashPoint ?? data.crash_point) || 1.00;
        ctx.serverGameStatus     = String(data.gameStatus ?? data.status ?? 'waiting');

        if (ctx.gameState !== 'playing') {
            const rawHistory = data.history;
            if (Array.isArray(rawHistory) && rawHistory.length > 0) {
                ctx.crashHistory = rawHistory.slice(0, 20).map(v => parseFloat(v));
                if (handlers?.onHistoryUpdate) handlers.onHistoryUpdate();
            }
        }

        processServerEvent(data, handlers);
        return data;
    } catch (e) {
        console.error('[ServerSync] Poll error:', e);
        return null;
    }
}

/**
 * Processes a raw server event (poll or realtime) through the deduplication layer.
 * Prevents double-transitions when poll and realtime fire simultaneously.
 *
 * @param {object} raw
 * @param {ServerSyncHandlers} handlers
 */
export function processServerEvent(raw, handlers) {
    if (!raw || typeof raw !== 'object') return;

    const rawStatus = String(raw.status ?? raw.gameStatus ?? '').toLowerCase();
    const roundId   = Number(raw.round_id ?? raw.roundId ?? ctx.serverRoundId);

    const rawSTime  = raw.server_time ?? raw.serverTime ?? 0;
    const sTime     = typeof rawSTime === 'string' ? new Date(rawSTime).getTime() : Number(rawSTime);

    const cPoint    = Number(raw.crash_point ?? raw.crashPoint ?? ctx.serverCrashPoint);
    const rStart    = raw.start_time
        ? new Date(raw.start_time).getTime()
        : Number(raw.roundStartTime ?? raw.round_start_time ?? ctx.serverRoundStartTime);

    if (!rawStatus) return;

    // ── Save previousRoundId BEFORE updating ────────────────────────────
    const previousRoundId = ctx.serverRoundId;

    if (roundId > 0) ctx.serverRoundId = roundId;
    ctx.serverCrashPoint = cPoint;
    if (rStart > 0) ctx.serverRoundStartTime = rStart;

    // ── Crash history update from realtime payload ───────────────────────
    const rawHistory = raw.history;
    if (rawHistory) {
        let hist = rawHistory;
        if (typeof hist === 'string') { try { hist = JSON.parse(hist); } catch (_) {} }
        if (Array.isArray(hist) && hist.length > 0) {
            const freshHistory = hist.slice(0, 20).map(v => parseFloat(v));
            if (ctx.gameState !== 'playing') {
                if (freshHistory.length >= ctx.crashHistory.length || rawStatus === 'waiting') {
                    ctx.crashHistory = freshHistory;
                    if (handlers?.onHistoryUpdate) handlers.onHistoryUpdate();
                }
            }
        }
    }

    // ── Out-of-order guard: discard stale events from previous rounds ────
    if (roundId < previousRoundId) {
        console.warn(`[ServerSync] Discarding stale event for round #${roundId} (current #${previousRoundId})`);
        return;
    }

    // ── Same-round demotion guard ────────────────────────────────────────
    if (roundId === previousRoundId) {
        const currentRank  = STATE_RANK[ctx.gameState] ?? -1;
        const incomingRank = STATE_RANK[rawStatus] ?? -1;
        if (incomingRank < currentRank) {
            console.warn(`[ServerSync] Discarding same-round demotion ${rawStatus} (client at ${ctx.gameState}, round #${roundId})`);
            return;
        }
    }

    // ── Deduplication: ignore events already processed this round ────────
    const key = `${roundId}:${rawStatus}`;
    if (key === ctx.lastEventKey) return;
    ctx.lastEventKey = key;

    console.log(`[ServerSync] → ${key}`);
    if (handlers?.onStatusChange) handlers.onStatusChange(rawStatus);
}

/**
 * Starts the server sync loop: initial fetch + 1500ms polling + Realtime channel.
 *
 * @param {ServerSyncHandlers} handlers
 * @param {(data: object) => void} onInitialReconcile - Called once after first fetch
 */
export async function startServerSyncLoop(handlers, onInitialReconcile) {
    const data = await fetchServerState(handlers);
    if (onInitialReconcile) onInitialReconcile(data);
    if (handlers?.onBetsRecovery) await handlers.onBetsRecovery();

    // ── 1500ms polling fallback ──────────────────────────────────────────
    setInterval(async () => {
        await fetchServerState(handlers);
    }, 1500);

    // ── Supabase Realtime channel ────────────────────────────────────────
    const channel = supabase
        .channel('game_state_changes')
        .on(
            'postgres_changes',
            { event: 'UPDATE', schema: 'public', table: 'active_game_state', filter: 'id=eq.1' },
            (payload) => {
                processServerEvent(payload.new, handlers);
            }
        )
        .on('system', {}, (status) => {
            console.log(`[ServerSync] Channel status: ${status}`);
        })
        .subscribe((status) => {
            console.log(`[ServerSync] Subscription: ${status}`);
            if (status === 'SUBSCRIBED' && handlers?.onBetsRecovery) {
                handlers.onBetsRecovery();
            }
        });

    return channel;
}
