/**
 * backend/api/deposit-callback.js
 *
 * Webhook receiver for Palpluss M-Pesa STK push confirmations.
 * Cryptographically verifies HMAC signatures and credits balance via PostgreSQL transactions.
 * Zero Supabase dependency.
 */

import { createHmac, timingSafeEqual } from 'crypto';
import { query, getClient } from './_lib/db.js';

function verifyWebhookSignature(req, rawBody) {
    const secret = process.env.PALPLUSS_WEBHOOK_SECRET;
    if (!secret) {
        console.warn('PALPLUSS_WEBHOOK_SECRET is not configured — skipping signature verification for local testing.');
        return true;
    }
    const sigHeader = req.headers['x-palpluss-signature'] ||
                      req.headers['x-webhook-signature'] ||
                      req.headers['x-signature'];
    if (!sigHeader) {
        console.error('Webhook received without signature header.');
        return false;
    }
    try {
        const expected = createHmac('sha256', secret).update(rawBody).digest('hex');
        const received = sigHeader.replace('sha256=', '');
        return timingSafeEqual(Buffer.from(expected, 'hex'), Buffer.from(received, 'hex'));
    } catch {
        return false;
    }
}

export default async function depositCallbackHandler(req, res) {
    if (req.method !== 'POST') return res.status(405).end();

    const rawBody = req.rawBody || (typeof req.body === 'string' ? req.body : JSON.stringify(req.body));
    if (!verifyWebhookSignature(req, rawBody)) {
        console.error('Webhook signature verification FAILED.');
        return res.status(401).json({ error: 'Invalid webhook signature.' });
    }

    let body = req.body;
    if (typeof body === 'string') {
        try { body = JSON.parse(body); } catch {}
    }

    const transaction = body?.transaction || {};
    const status      = (transaction?.status || body?.status || '').toUpperCase();
    const amount      = parseFloat(transaction?.amount || body?.amount || 0);
    const phone       = String(transaction?.phone_number || transaction?.phone || body?.phone || body?.phoneNumber || '');
    const mpesaRef    = transaction?.id || body?.transactionId || body?.reference || body?.mpesaReceiptNumber;
    const externalRef = transaction?.external_reference || body?.external_reference || body?.accountReference;

    const logRef = mpesaRef || externalRef || 'unknown';
    console.log(`[Palpluss Deposit Webhook] status=${status} ref=${logRef} amount=${amount}`);

    const client = await getClient();

    try {
        await client.query('BEGIN');

        // 1. Idempotency Guard: Find existing transaction
        let tx = null;
        if (mpesaRef || externalRef) {
            const { rows } = await client.query(
                `SELECT id, status, user_id FROM transactions
                 WHERE reference = $1 OR reference = $2
                 LIMIT 1 FOR UPDATE`,
                [mpesaRef, externalRef]
            );
            tx = rows[0];
        }

        if (tx && (tx.status === 'completed' || tx.status === 'failed')) {
            console.log(`[Webhook Idempotency] Transaction ${tx.id} already settled as ${tx.status}.`);
            await client.query('COMMIT');
            return res.status(200).json({ success: true, message: 'Already processed.' });
        }

        // 2. Determine user ID
        let userId = tx?.user_id;
        if (!userId) {
            let normalizedPhone = phone.replace(/^\+/, '').replace(/^254/, '0');
            if (normalizedPhone && !normalizedPhone.startsWith('0')) normalizedPhone = '0' + normalizedPhone;

            const { rows: userRows } = await client.query(
                'SELECT id FROM profiles WHERE phone LIKE $1 LIMIT 1',
                [`%${normalizedPhone.slice(-9)}`]
            );
            userId = userRows[0]?.id;
        }

        if (!userId) {
            console.warn(`[Webhook Warning] Could not associate deposit with any user. Phone: ${phone}`);
            await client.query('COMMIT');
            return res.status(200).json({ success: true, message: 'Unmatched deposit logged.' });
        }

        // 3. Process Success vs Failure
        const isSuccess = status === 'SUCCESS' || status === 'COMPLETED' || status === 'PAID';

        if (isSuccess && amount > 0) {
            // Credit user balance
            await client.query(
                'UPDATE profiles SET balance = balance + $1, updated_at = NOW() WHERE id = $2',
                [amount, userId]
            );

            // Update or insert transaction record
            if (tx) {
                await client.query(
                    `UPDATE transactions
                     SET status = 'completed', amount = $1, reference = $2, metadata = $3
                     WHERE id = $4`,
                    [amount, mpesaRef || externalRef, JSON.stringify(body), tx.id]
                );
            } else {
                await client.query(
                    `INSERT INTO transactions (user_id, type, amount, status, reference, phone, metadata)
                     VALUES ($1, 'deposit', $2, 'completed', $3, $4, $5)`,
                    [userId, amount, mpesaRef || externalRef, phone, JSON.stringify(body)]
                );
            }

            console.log(`[Deposit Credited] User ${userId} credited with KES ${amount}.`);
        } else {
            // Mark failed
            if (tx) {
                await client.query(
                    "UPDATE transactions SET status = 'failed', metadata = $1 WHERE id = $2",
                    [JSON.stringify(body), tx.id]
                );
            }
            console.log(`[Deposit Failed] Transaction marked as failed. Status: ${status}`);
        }

        await client.query('COMMIT');
        return res.status(200).json({ success: true });
    } catch (err) {
        await client.query('ROLLBACK');
        console.error('[Deposit Webhook Error]:', err);
        return res.status(500).json({ success: false, error: err.message });
    } finally {
        client.release();
    }
}
