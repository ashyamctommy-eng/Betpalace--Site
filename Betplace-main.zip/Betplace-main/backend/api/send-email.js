/**
 * api/send-email.js
 *
 * Secure backend endpoint to send transactional emails via Brevo.
 * Keeps the Brevo API key hidden from the frontend.
 *
 * SECURITY HARDENED:
 *  - Requires valid Bearer JWT (verified via Supabase auth.getUser)
 *  - Validates required fields before calling Brevo
 *  - CORS restricted to known origins
 */

import { verifyAuthToken } from './_lib/auth.js';
import { setCorsHeaders } from './_lib/cors.js';

/** Simple HTML sanitiser — strips tags to prevent HTML-injection via subject/body */
function stripTags(str) {
    return String(str || '').replace(/<[^>]*>/g, '').trim();
}

export default async function handler(req, res) {
    setCorsHeaders(req, res, 'POST, OPTIONS');

    if (req.method === 'OPTIONS') return res.status(200).end();
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

    // ── 1. Authenticate the caller ─────────────────────────────────────────────
    // Only authenticated users (e.g. support widget, in-app feedback) may send email.
    // This prevents the endpoint from being abused as an open relay.
    const auth = await verifyAuthToken(req);
    if (!auth.success) {
        return res.status(auth.status).json({ error: auth.error });
    }

    // ── 2. Validate inputs ─────────────────────────────────────────────────────
    const { to, subject, htmlContent } = req.body;

    if (!to || typeof to !== 'string' || !to.includes('@')) {
        return res.status(400).json({ error: 'Invalid or missing "to" email address.' });
    }
    if (!subject || typeof subject !== 'string' || subject.trim().length === 0) {
        return res.status(400).json({ error: 'Missing email subject.' });
    }
    if (!htmlContent || typeof htmlContent !== 'string' || htmlContent.trim().length === 0) {
        return res.status(400).json({ error: 'Missing email body content.' });
    }

    const apiKey = process.env.BREVO_API_KEY;
    if (!apiKey) return res.status(500).json({ error: 'Email service not configured.' });

    try {
        const response = await fetch('https://api.brevo.com/v3/smtp/email', {
            method: 'POST',
            headers: {
                'accept': 'application/json',
                'api-key': apiKey,
                'content-type': 'application/json'
            },
            body: JSON.stringify({
                sender: { name: 'Metricwin Support', email: 'support@metricwin.app' },
                to: [{ email: to }],
                subject: stripTags(subject),
                htmlContent: htmlContent
            })
        });

        const result = await response.json();
        if (!response.ok) {
            console.error('Brevo API error:', result);
            return res.status(502).json({ error: 'Email delivery failed. Please try again.' });
        }
        return res.status(200).json({ success: true });
    } catch (error) {
        console.error('send-email handler error:', error.message);
        return res.status(500).json({ error: 'Email service error. Please try again.' });
    }
}
