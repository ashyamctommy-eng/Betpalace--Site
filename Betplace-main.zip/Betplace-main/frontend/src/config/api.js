/**
 * src/config/api.js
 *
 * Centralized API URL resolver.
 * Supports:
 *  - Direct backend URL via VITE_API_URL (e.g., https://your-backend.onrender.com)
 *  - Relative URL fallback (/api/...) when using Vercel rewrites or Nginx reverse proxy
 */

const rawApiBase = import.meta.env.VITE_API_URL || '';
export const API_BASE = rawApiBase.replace(/\/+$/, '');

/**
 * Resolves an API path (e.g. '/api/deposit') to a full URL or relative path.
 * @param {string} path - API endpoint path starting with '/'
 * @returns {string} Fully qualified or relative URL
 */
export function apiUrl(path) {
    const cleanPath = path.startsWith('/') ? path : `/${path}`;
    return API_BASE ? `${API_BASE}${cleanPath}` : cleanPath;
}
