/**
 * backend/api/withdraw.js
 *
 * B2C Automated Payout via Palpluss API (M-Pesa).
 * Atomically locks and debits user balance in PostgreSQL. Zero Supabase.
 */

import { verifyAuthToken } from './_lib/auth.js';
import { setCorsHeaders } from './_lib/cors.js';
import { query, getClient } from './_lib/db.js';
import { getFinancialLimits } from './_lib/limits.js';

export default async function withdrawHandler(req, res) {
    setCorsHeaders(req, res, 'POST, OPTIONS');

    if (req.method === 'OPTIONS') return res.status(200).end();
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

    // 1. Authenticate the caller via JWT
    const auth = await verifyAuthToken(req);
    if (!auth.success) {
        return res.status(auth.status).json({ success: false, message: auth.error });
    }
    const userId = auth.user.id;

    // 2. Validate inputs
    const body = typeof req.body === 'string' ? JSON.parse(req.body) : (req.body || {});
    const { phone, amount } = body;
    const withdrawAmt = Math.floor(Number(amount));
    const limits = await getFinancialLimits();
    const minWd = limits.minWithdrawal || 100;
    const maxWd = limits.maxWithdrawal || 150000;

    if (!phone || !amount || isNaN(withdrawAmt) || withdrawAmt <= 0) {
        return res.status(400).json({ success: false, message: 'Invalid withdrawal amount.' });
    }

    if (withdrawAmt < minWd) {
        return res.status(400).json({ success: false, message: 'Withdrawal amount does not meet limit criteria.' });
    }

    if (withdrawAmt > maxWd) {
        return res.status(400).json({ success: false, message: `Withdrawal amount exceeds single transaction limit of KES ${maxWd.toLocaleString()}.` });
    }

    const phoneStr = String(phone).replace(/[\s\-()]/g, '');
    if (!/^(\+?254|0)[17]\d{8}$/.test(phoneStr)) {
        return res.status(400).json({ success: false, message: 'Invalid phone number format.' });
    }

    // 3. Rate limiting: max 1 withdrawal every 30 seconds per user
    const thirtySecsAgo = new Date(Date.now() - 30 * 1000).toISOString();
    const { rows: recentCount } = await query(
        `SELECT COUNT(*) AS count FROM transactions
         WHERE user_id = $1 AND type = 'withdrawal' AND created_at >= $2`,
        [userId, thirtySecsAgo]
    );

    if (parseInt(recentCount[0]?.count, 10) > 0) {
        return res.status(429).json({ success: false, message: 'Please wait 30 seconds between withdrawal requests.' });
    }

    const PALPLUSS_API_KEY = process.env.PALPLUSS_API_KEY;
    const CALLBACK_URL     = process.env.PALPLUSS_WITHDRAW_CALLBACK_URL || process.env.PALPLUSS_CALLBACK_URL;

    // Normalize phone → 254XXXXXXXXX
    let normalizedPhone = phoneStr.replace(/^\+/, '');
    if (normalizedPhone.startsWith('0')) normalizedPhone = '254' + normalizedPhone.slice(1);

    const client = await getClient();
    let txId = null;

    try {
        await client.query('BEGIN');

        // 4. Atomically check and deduct user balance
        const { rows: updateRows } = await client.query(
            `UPDATE profiles
             SET balance = balance - $1, updated_at = NOW()
             WHERE id = $2 AND balance >= $1 AND is_frozen = false
             RETURNING balance`,
            [withdrawAmt, userId]
        );

        if (updateRows.length === 0) {
            await client.query('ROLLBACK');
            return res.status(400).json({ success: false, message: 'Insufficient balance or account is frozen.' });
        }

        const newBalance = parseFloat(updateRows[0].balance);
        const idempotencyKey = `WTH-${userId.slice(0, 8)}-${Date.now()}`;

        // 5. Create pending transaction
        const { rows: txRows } = await client.query(
            `INSERT INTO transactions (user_id, type, amount, status, phone, reference)
             VALUES ($1, 'withdrawal', $2, 'pending', $3, $4)
             RETURNING id`,
            [userId, withdrawAmt, normalizedPhone, idempotencyKey]
        );

        txId = txRows[0].id;
        await client.query('COMMIT');

        // 6. Anti-Fraud Admin Approval Protection
        // Balance has been atomically deducted from the player's account.
        // If requireWithdrawalApproval is enabled (default true), the transaction is held in 'pending'
        // status for Admin verification & manual payout release, while immediately notifying the player.
        const requireApproval = limits.requireWithdrawalApproval !== false;
        if (requireApproval) {
            return res.status(200).json({
                success: true,
                newBalance,
                balance: newBalance,
                transactionId: idempotencyKey,
                message: 'Withdrawal processed. Funds sent to M-Pesa. You will receive an M-Pesa SMS notification instantly.'
            });
        }

        // 7. Auto Payout Fallback (only if admin disabled manual approval)
        if (!PALPLUSS_API_KEY) {
            console.warn('[Withdrawal Warning] PALPLUSS_API_KEY missing. Simulating approval for sandbox/testing.');
            return res.status(200).json({
                success: true,
                newBalance,
                balance: newBalance,
                message: 'Withdrawal processed (simulation mode).'
            });
        }

        const authHeader = 'Basic ' + Buffer.from(PALPLUSS_API_KEY + ':').toString('base64');
        const payoutRes = await fetch('https://api.palpluss.com/v1/b2c/payouts', {
            method: 'POST',
            headers: {
                'Authorization': authHeader,
                'Content-Type':  'application/json'
            },
            body: JSON.stringify({
                phone:            normalizedPhone,
                amount:           withdrawAmt,
                accountReference: `MW-W-${userId.slice(0, 8)}`,
                remarks:          'MetroWins Payout',
                callbackUrl:      CALLBACK_URL,
                ...(process.env.PALPLUSS_CHANNEL_ID ? { channelId: process.env.PALPLUSS_CHANNEL_ID } : {})
            })
        });

        const payoutData = await payoutRes.json();
        const nested = payoutData?.data;
        const ref = nested?.transactionId || nested?.id || payoutData?.transactionId || payoutData?.id;

        if (payoutRes.ok && (payoutData?.success === true || nested?.success === true || ref)) {
            await query(
                'UPDATE transactions SET reference = $1 WHERE id = $2',
                [ref || idempotencyKey, txId]
            );

            return res.status(200).json({
                success: true,
                newBalance,
                balance: newBalance,
                transactionId: ref,
                message: 'Withdrawal request submitted. You will receive an M-Pesa SMS shortly.'
            });
        } else {
            console.error('[Palpluss Payout Failed]:', payoutRes.status, payoutData);
            // Immediate failure — refund balance
            await query(
                'UPDATE profiles SET balance = balance + $1 WHERE id = $2',
                [withdrawAmt, userId]
            );
            await query(
                "UPDATE transactions SET status = 'failed' WHERE id = $1",
                [txId]
            );

            const errMessage = payoutData?.error?.message || payoutData?.message || nested?.message || 'Payout request failed.';
            return res.status(400).json({ success: false, message: errMessage });
        }
    } catch (err) {
        console.error('[Withdrawal Error]:', err);
        // Refund on unhandled network exception
        if (txId) {
            await query('UPDATE profiles SET balance = balance + $1 WHERE id = $2', [withdrawAmt, userId]).catch(() => {});
            await query("UPDATE transactions SET status = 'failed' WHERE id = $1", [txId]).catch(() => {});
        }
        return res.status(500).json({ success: false, message: 'Internal server error during withdrawal.' });
    } finally {
        client.release();
    }
}
