/**
 * backend/api/_lib/auth.js
 *
 * Standalone Authentication and RBAC System for MetroWins.
 * Zero Supabase Auth dependency. Uses JWT and bcryptjs.
 */

import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { query } from './db.js';

const JWT_SECRET = process.env.JWT_SECRET || 'metrowins_secret_jwt_key_2026_change_in_production';

/**
 * Hash a plain text password
 */
export async function hashPassword(plain) {
    return await bcrypt.hash(plain, 10);
}

/**
 * Compare plain password against stored hash
 */
export async function comparePassword(plain, hash) {
    return await bcrypt.compare(plain, hash);
}

/**
 * Generate a signed JWT
 */
export function generateToken(payload) {
    return jwt.sign(payload, JWT_SECRET, { expiresIn: '30d' });
}

/**
 * Verify a JWT string
 */
export function verifyToken(token) {
    try {
        return jwt.verify(token, JWT_SECRET);
    } catch {
        return null;
    }
}

/**
 * Extracts Bearer token from Express request
 */
export function extractToken(req) {
    const authHeader = req.headers.authorization || req.headers.Authorization;
    if (!authHeader || typeof authHeader !== 'string') return null;
    if (authHeader.startsWith('Bearer ')) {
        return authHeader.slice(7).trim();
    }
    return authHeader.trim();
}

/**
 * Authenticates request via JWT and fetches fresh user profile from DB
 * Drop-in replacement for old Supabase verifyAuthToken()
 */
export async function verifyAuthToken(req) {
    const token = extractToken(req);
    if (!token) {
        return { success: false, status: 401, error: 'Authentication required. Missing token.' };
    }

    const decoded = verifyToken(token);
    if (!decoded || !decoded.id) {
        return { success: false, status: 401, error: 'Invalid or expired session token.' };
    }

    try {
        const { rows } = await query(
            `SELECT p.id, p.phone, p.email, p.username, p.balance, p.is_frozen,
                    COALESCE(r.name, 'User') AS role
             FROM profiles p
             LEFT JOIN user_roles ur ON p.id = ur.user_id
             LEFT JOIN roles r ON ur.role_id = r.id
             WHERE p.id = $1`,
            [decoded.id]
        );

        if (rows.length === 0) {
            return { success: false, status: 401, error: 'User account not found.' };
        }

        const user = rows[0];
        if (user.is_frozen) {
            return { success: false, status: 403, error: 'Account is frozen. Contact support.' };
        }

        req.user = user;
        return { success: true, user };
    } catch (err) {
        console.error('[Auth Error]:', err.message);
        return { success: false, status: 500, error: 'Database authentication lookup failed.' };
    }
}

/**
 * Verifies that the authenticated user holds a specific permission
 * Drop-in replacement for old Supabase verifyPermission()
 */
export async function verifyPermission(req, requiredPermission) {
    const auth = await verifyAuthToken(req);
    if (!auth.success) return auth;

    const user = auth.user;

    // Super Admin has all permissions automatically
    if (user.role === 'Super Admin') {
        return { success: true, user };
    }

    try {
        const { rows } = await query(
            `SELECT has_permission($1, $2) AS allowed`,
            [user.id, requiredPermission]
        );

        const allowed = rows[0]?.allowed === true;
        if (!allowed) {
            return {
                success: false,
                status: 403,
                error: `Permission denied: Requires "${requiredPermission}".`
            };
        }

        return { success: true, user };
    } catch (err) {
        console.error('[Permission Check Error]:', err.message);
        return { success: false, status: 500, error: 'Permission verification failed.' };
    }
}

/**
 * Logs an administrative action to audit_logs
 */
export async function logAdminAction(adminId, action, targetId, details = {}) {
    try {
        const isUuid = typeof targetId === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(targetId);
        const uuidTarget = isUuid ? targetId : null;
        const finalDetails = isUuid ? details : { ...details, target_id_raw: targetId };

        await query(
            `INSERT INTO audit_logs (admin_id, action, target_id, details)
             VALUES ($1, $2, $3, $4)`,
            [adminId, action, uuidTarget, JSON.stringify(finalDetails)]
        );
    } catch (err) {
        console.warn('[Audit Log Error]: Failed to write audit log:', err.message);
    }
}

/**
 * Normalizes phone numbers to standard format and variants (+254..., 254..., 07...)
 */
export function getPhoneVariants(phone) {
    if (!phone) return [];
    const clean = String(phone).replace(/[\s\-()]/g, '');
    const set = new Set([clean]);
    if (clean.startsWith('+254')) {
        set.add(clean.slice(1)); // 254...
        set.add('0' + clean.slice(4)); // 07...
    } else if (clean.startsWith('254')) {
        set.add('+' + clean); // +254...
        set.add('0' + clean.slice(3)); // 07...
    } else if (clean.startsWith('0')) {
        set.add('254' + clean.slice(1)); // 2547...
        set.add('+254' + clean.slice(1)); // +2547...
    }
    return Array.from(set);
}

/**
 * Ensures Super Admin credentials specified in environment variables are provisioned in DB
 */
export async function ensureSuperAdmin() {
    const envPhone = process.env.SUPER_ADMIN_PHONE;
    const envPassword = process.env.SUPER_ADMIN_PASSWORD;

    if (!envPhone || !envPassword) {
        return null;
    }

    try {
        const phoneVariants = getPhoneVariants(envPhone);
        const cleanPhone = phoneVariants[0] || String(envPhone).replace(/[\s\-()]/g, '');
        const adminEmail = 'superadmin@betplace.app';
        const adminUsername = 'superadmin';

        // 1. Ensure 'Super Admin' role exists
        let superAdminRoleId;
        const { rows: roleRows } = await query("SELECT id FROM roles WHERE name = 'Super Admin'");
        if (roleRows.length > 0) {
            superAdminRoleId = roleRows[0].id;
        } else {
            const { rows: newRole } = await query(
                "INSERT INTO roles (name, description) VALUES ('Super Admin', 'Full unrestricted platform access') RETURNING id"
            );
            superAdminRoleId = newRole[0].id;
        }

        // 2. Check if user already exists by any phone variant, or email, or username
        const { rows: existingUsers } = await query(
            `SELECT p.id, p.phone, p.email, p.username, p.password_hash, p.balance, p.is_frozen,
                    COALESCE(r.name, 'User') AS role
             FROM profiles p
             LEFT JOIN user_roles ur ON p.id = ur.user_id
             LEFT JOIN roles r ON ur.role_id = r.id
             WHERE p.phone = ANY($1::text[]) OR p.email = $2 OR p.username = $3
             LIMIT 1`,
            [phoneVariants, adminEmail, adminUsername]
        );

        let user;
        const passwordHash = await hashPassword(envPassword);

        if (existingUsers.length > 0) {
            user = existingUsers[0];
            // Ensure phone and password match environment variables
            const matches = await comparePassword(envPassword, user.password_hash);
            const needsPhoneUpdate = user.phone !== cleanPhone;
            if (!matches || needsPhoneUpdate) {
                await query('UPDATE profiles SET phone = $1, password_hash = $2, updated_at = NOW() WHERE id = $3', [cleanPhone, passwordHash, user.id]);
                user.phone = cleanPhone;
                console.log('[Auth] Synced Super Admin phone and password with environment variables.');
            }
            // Ensure role is Super Admin
            await query(
                `INSERT INTO user_roles (user_id, role_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`,
                [user.id, superAdminRoleId]
            );
            user.role = 'Super Admin';
        } else {
            // Create Super Admin profile
            const { rows: newProfiles } = await query(
                `INSERT INTO profiles (phone, email, username, password_hash, balance)
                 VALUES ($1, $2, $3, $4, 10000.00)
                 RETURNING id, phone, email, username, balance`,
                [cleanPhone, adminEmail, adminUsername, passwordHash]
            );
            user = newProfiles[0];
            await query(
                `INSERT INTO user_roles (user_id, role_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`,
                [user.id, superAdminRoleId]
            );
            user.role = 'Super Admin';
            console.log(`[Auth] Provisioned initial Super Admin account for ${cleanPhone}.`);
        }

        return user;
    } catch (err) {
        console.error('[ensureSuperAdmin Error]:', err.message);
        return null;
    }
}

/**
 * Ensures Staff Admin credentials specified in environment variables are provisioned in DB
 */
export async function ensureAdmin() {
    const envPhone = process.env.ADMIN_PHONE;
    const envPassword = process.env.ADMIN_PASSWORD;

    if (!envPhone || !envPassword) {
        return null;
    }

    try {
        const phoneVariants = getPhoneVariants(envPhone);
        const cleanPhone = phoneVariants[0] || String(envPhone).replace(/[\s\-()]/g, '');
        const adminEmail = 'admin@betplace.app';
        const adminUsername = 'admin';

        // 1. Ensure 'Admin' role exists
        let adminRoleId;
        const { rows: roleRows } = await query("SELECT id FROM roles WHERE name = 'Admin'");
        if (roleRows.length > 0) {
            adminRoleId = roleRows[0].id;
        } else {
            const { rows: newRole } = await query(
                "INSERT INTO roles (name, description) VALUES ('Admin', 'Staff administrative access') RETURNING id"
            );
            adminRoleId = newRole[0].id;
        }

        // 2. Check if user already exists
        const { rows: existingUsers } = await query(
            `SELECT p.id, p.phone, p.email, p.username, p.password_hash, p.balance, p.is_frozen,
                    COALESCE(r.name, 'User') AS role
             FROM profiles p
             LEFT JOIN user_roles ur ON p.id = ur.user_id
             LEFT JOIN roles r ON ur.role_id = r.id
             WHERE p.phone = ANY($1::text[]) OR p.email = $2 OR p.username = $3
             LIMIT 1`,
            [phoneVariants, adminEmail, adminUsername]
        );

        let user;
        const passwordHash = await hashPassword(envPassword);

        if (existingUsers.length > 0) {
            user = existingUsers[0];
            const matches = await comparePassword(envPassword, user.password_hash);
            const needsPhoneUpdate = user.phone !== cleanPhone;
            if (!matches || needsPhoneUpdate) {
                await query('UPDATE profiles SET phone = $1, password_hash = $2, updated_at = NOW() WHERE id = $3', [cleanPhone, passwordHash, user.id]);
                user.phone = cleanPhone;
                console.log('[Auth] Synced Admin phone and password with environment variables.');
            }
            await query(
                `INSERT INTO user_roles (user_id, role_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`,
                [user.id, adminRoleId]
            );
            user.role = 'Admin';
        } else {
            const { rows: newProfiles } = await query(
                `INSERT INTO profiles (phone, email, username, password_hash, balance)
                 VALUES ($1, $2, $3, $4, 5000.00)
                 RETURNING id, phone, email, username, balance`,
                [cleanPhone, adminEmail, adminUsername, passwordHash]
            );
            user = newProfiles[0];
            await query(
                `INSERT INTO user_roles (user_id, role_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`,
                [user.id, adminRoleId]
            );
            user.role = 'Admin';
            console.log(`[Auth] Provisioned initial Admin account for ${cleanPhone}.`);
        }

        return user;
    } catch (err) {
        console.error('[ensureAdmin Error]:', err.message);
        return null;
    }
}

export default {
    hashPassword,
    comparePassword,
    generateToken,
    verifyToken,
    extractToken,
    verifyAuthToken,
    verifyPermission,
    logAdminAction,
    getPhoneVariants,
    ensureSuperAdmin,
    ensureAdmin
};
