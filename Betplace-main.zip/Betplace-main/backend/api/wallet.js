/**
 * backend/api/wallet.js
 *
 * User Wallet & Ledger Router.
 * Returns balance and transaction history without Supabase client.
 */

import { query } from './_lib/db.js';
import { verifyAuthToken } from './_lib/auth.js';
import { getFinancialLimits } from './_lib/limits.js';
import depositHandler from './deposit.js';
import withdrawHandler from './withdraw.js';

export default async function walletHandler(req, res) {
    const url = req.url || '';
    const pathPart = url.split('?')[0] || '';

    // Public / semi-public financial config endpoint (only reveals deposit limits)
    if (pathPart.endsWith('/config') || pathPart.endsWith('/limits')) {
        const limits = await getFinancialLimits();
        return res.status(200).json({
            success: true,
            minDeposit: limits.minDeposit,
            maxDeposit: limits.maxDeposit,
            minBetAviator: limits.minBetAviator,
            maxBetAviator: limits.maxBetAviator
            // Intentionally omitting minWithdrawal and maxWithdrawal to preserve confidentiality
        });
    }

    const queryParams = req.query || {};

    // Proxy deposit and withdrawal routes to avoid path mismatches
    if (pathPart.includes('/deposit') || queryParams.action === 'deposit') {
        return depositHandler(req, res);
    }
    if (pathPart.includes('/withdraw') || queryParams.action === 'withdraw') {
        return withdrawHandler(req, res);
    }

    const auth = await verifyAuthToken(req);
    if (!auth.success) {
        return res.status(auth.status).json({ success: false, message: auth.error });
    }

    if (pathPart.endsWith('/transactions')) {
        try {
            const { rows } = await query(
                'SELECT * FROM transactions WHERE user_id = $1 ORDER BY created_at DESC LIMIT 100',
                [auth.user.id]
            );
            return res.status(200).json(rows);
        } catch (err) {
            console.error('[Transactions Error]:', err.message);
            return res.status(500).json({ error: 'Failed to fetch transaction history.' });
        }
    }

    if (pathPart.endsWith('/status') || queryParams.reference || queryParams.action === 'status') {
        const reference = queryParams.reference || queryParams.id;
        try {
            const isPrivileged = auth.user.role === 'Super Admin' || auth.user.role === 'Admin';
            const { rows } = await query(
                `SELECT id, status, amount, reference, phone, created_at
                 FROM transactions
                 WHERE ($1::boolean = true OR user_id = $2) AND (reference = $3 OR id::text = $3)
                 ORDER BY created_at DESC LIMIT 1`,
                [isPrivileged, auth.user.id, reference]
            );
            if (rows.length === 0) {
                return res.status(200).json({ success: false, status: 'pending' });
            }
            return res.status(200).json({
                success: true,
                status: rows[0].status,
                transaction: rows[0]
            });
        } catch (err) {
            console.error('[Status Error]:', err.message);
            return res.status(500).json({ error: 'Failed to fetch transaction status.' });
        }
    }

    // Default: GET /api/wallet/balance
    try {
        const { rows } = await query(
            'SELECT balance, is_frozen FROM profiles WHERE id = $1',
            [auth.user.id]
        );
        if (rows.length === 0) {
            return res.status(404).json({ error: 'User not found.' });
        }
        return res.status(200).json({
            success: true,
            balance: parseFloat(rows[0].balance),
            isFrozen: rows[0].is_frozen
        });
    } catch (err) {
        console.error('[Balance Error]:', err.message);
        return res.status(500).json({ error: 'Failed to fetch user balance.' });
    }
}
