-- Migration: 017_promo_codes.sql
-- Create promo codes management table and claim validation logic

CREATE TABLE IF NOT EXISTS public.promo_codes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code TEXT UNIQUE NOT NULL,
    amount DECIMAL NOT NULL DEFAULT 0,
    max_uses INT NOT NULL DEFAULT 1,
    current_uses INT NOT NULL DEFAULT 0,
    require_deposit BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT now()
);
ALTER TABLE public.promo_codes ADD COLUMN IF NOT EXISTS require_deposit BOOLEAN NOT NULL DEFAULT FALSE;

CREATE TABLE IF NOT EXISTS public.promo_code_claims (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    promo_code_id UUID REFERENCES public.promo_codes(id) ON DELETE CASCADE,
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    claimed_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE (promo_code_id, user_id)
);

-- Enable Row Level Security (RLS)
ALTER TABLE public.promo_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.promo_code_claims ENABLE ROW LEVEL SECURITY;

-- Recreate policies safety block
DROP POLICY IF EXISTS "Admins can manage promo codes" ON public.promo_codes;
CREATE POLICY "Admins can manage promo codes" ON public.promo_codes
    FOR ALL
    USING (
        EXISTS (
            SELECT 1 FROM public.user_roles ur
            JOIN public.roles r ON ur.role_id = r.id
            WHERE ur.user_id = auth.uid()
              AND r.name IN ('Admin', 'Super Admin')
        )
    );

DROP POLICY IF EXISTS "Admins can view claims" ON public.promo_code_claims;
CREATE POLICY "Admins can view claims" ON public.promo_code_claims
    FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM public.user_roles ur
            JOIN public.roles r ON ur.role_id = r.id
            WHERE ur.user_id = auth.uid()
              AND r.name IN ('Admin', 'Super Admin')
        )
    );

-- Secure transaction logic RPC
CREATE OR REPLACE FUNCTION public.claim_promo_code(p_user_id UUID, p_code TEXT)
RETURNS JSON AS $$
DECLARE
    v_promo_id UUID;
    v_amount DECIMAL;
    v_max_uses INT;
    v_current_uses INT;
    v_already_claimed INT;
    v_require_deposit BOOLEAN;
BEGIN
    -- Check if user exists
    IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = p_user_id) THEN
        RETURN json_build_object('success', false, 'error', 'User profile not found');
    END IF;

    -- Check if promo code exists (case insensitive lookup)
    SELECT id, amount, max_uses, current_uses, require_deposit
    INTO v_promo_id, v_amount, v_max_uses, v_current_uses, v_require_deposit
    FROM public.promo_codes
    WHERE UPPER(code) = UPPER(p_code);

    IF v_promo_id IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Invalid promo code');
    END IF;

    -- Guard: deposit requirement
    IF v_require_deposit IS TRUE THEN
        IF NOT EXISTS (
            SELECT 1 FROM public.transactions 
            WHERE user_id = p_user_id 
              AND type = 'deposit' 
              AND status = 'completed'
              AND reference NOT LIKE 'PROMO-%'
              AND reference NOT LIKE 'SIGNUP-%'
              AND reference NOT LIKE 'REFERRAL-%'
        ) THEN
            RETURN json_build_object('success', false, 'error', 'You must have made at least one deposit to claim this promo code');
        END IF;
    END IF;

    -- Verify limit on number of users
    IF v_current_uses >= v_max_uses THEN
        RETURN json_build_object('success', false, 'error', 'This promo code has reached its usage limit');
    END IF;

    -- Check if this user has already claimed the code
    SELECT COUNT(*) INTO v_already_claimed
    FROM public.promo_code_claims
    WHERE promo_code_id = v_promo_id AND user_id = p_user_id;

    IF v_already_claimed > 0 THEN
        RETURN json_build_object('success', false, 'error', 'You have already claimed this promo code');
    END IF;

    -- Atomically increase uses
    UPDATE public.promo_codes
    SET current_uses = current_uses + 1
    WHERE id = v_promo_id AND current_uses < max_uses;

    -- Check if the update succeeded (to handle race conditions under high concurrency)
    IF NOT FOUND THEN
        RETURN json_build_object('success', false, 'error', 'Promo code limit exceeded by another user. Try another.');
    END IF;

    -- Insert claim record
    INSERT INTO public.promo_code_claims (promo_code_id, user_id)
    VALUES (v_promo_id, p_user_id);

    -- Increment user's profile balance
    UPDATE public.profiles
    SET balance = balance + v_amount
    WHERE id = p_user_id;

    -- Log transaction for auditing ledger
    INSERT INTO public.transactions (user_id, type, amount, status, reference)
    VALUES (
        p_user_id, 
        'deposit', 
        v_amount, 
        'completed', 
        'PROMO-' || UPPER(p_code) || '-' || substring(md5(random()::text), 1, 8)
    );

    RETURN json_build_object('success', true, 'amount', v_amount);
EXCEPTION
    WHEN OTHERS THEN
        RETURN json_build_object('success', false, 'error', SQLERRM);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
