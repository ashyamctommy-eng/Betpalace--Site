-- ═══════════════════════════════════════════════════════════════════
-- MIGRATION 035: Ensure missing transaction columns exist
-- ═══════════════════════════════════════════════════════════════════

SET lock_timeout = '10s';

-- Ensure description, reference, phone, and rejection_reason exist on transactions table
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS description TEXT;
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS reference TEXT;
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS phone TEXT;
ALTER TABLE public.transactions ADD COLUMN IF NOT EXISTS rejection_reason TEXT;

-- Create index on reference for fast webhook lookup
CREATE INDEX IF NOT EXISTS idx_transactions_reference ON public.transactions(reference);

NOTIFY pgrst, 'reload schema';
