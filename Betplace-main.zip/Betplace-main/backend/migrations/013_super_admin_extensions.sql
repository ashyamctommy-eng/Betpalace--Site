-- MIGRATION 013: Super Admin Extensions for Settings, Promotions, and Notifications

-- 1. SYSTEM SETTINGS (For support, telegram, whatsapp channel links)
CREATE TABLE IF NOT EXISTS public.system_settings (
    key TEXT PRIMARY KEY,
    value JSONB NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Seed default support and community configuration
INSERT INTO public.system_settings (key, value)
VALUES 
('support', '{"whatsapp": "+254700000000", "telegram_username": "metricwin_support"}'),
('community', '{"telegram_channel": "https://t.me/metricwin", "whatsapp_channel": "https://whatsapp.com/channel/0029"}')
ON CONFLICT (key) DO NOTHING;

-- 2. PROMOTIONS TABLE
CREATE TABLE IF NOT EXISTS public.promotions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    description TEXT,
    image_url TEXT,
    action_type TEXT NOT NULL DEFAULT 'play', -- 'play', 'deposit', 'refer', 'external'
    action_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Seed a default Metricwin anniversary style promotion
INSERT INTO public.promotions (title, description, image_url, action_type, action_url)
VALUES (
    'METRICWIN ANNIVERSARY DAILY FREE BETS/SPINS PROMOTION!',
    'As Metricwin celebrates years of greatness, get ready for nonstop surprises and rewards! Players stand a chance to enjoy daily free bets and spins across Sports and Games, with over KES 5 Million up for grabs!',
    'https://raw.githubusercontent.com/billgatesmalel/Metricwin/main/dist/assets/metricwin-promo.png',
    'play',
    '/'
)
ON CONFLICT DO NOTHING;

-- 3. NOTIFICATIONS TABLE
CREATE TABLE IF NOT EXISTS public.notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE, -- NULL refers to a system-wide announcement notification
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- RLS policies: select is public, update/insert requires admin permissions
ALTER TABLE public.system_settings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public system settings read access" ON public.system_settings;
CREATE POLICY "Public system settings read access" ON public.system_settings FOR SELECT USING (true);
DROP POLICY IF EXISTS "Admin write access for system settings" ON public.system_settings;
CREATE POLICY "Admin write access for system settings" ON public.system_settings FOR ALL USING (
    EXISTS (
        SELECT 1 FROM public.user_roles ur
        JOIN public.roles r ON ur.role_id = r.id
        WHERE ur.user_id = auth.uid() AND r.name IN ('Super Admin', 'Admin')
    )
);

ALTER TABLE public.promotions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public promotions read access" ON public.promotions;
CREATE POLICY "Public promotions read access" ON public.promotions FOR SELECT USING (true);
DROP POLICY IF EXISTS "Admin write access for promotions" ON public.promotions;
CREATE POLICY "Admin write access for promotions" ON public.promotions FOR ALL USING (
    EXISTS (
        SELECT 1 FROM public.user_roles ur
        JOIN public.roles r ON ur.role_id = r.id
        WHERE ur.user_id = auth.uid() AND r.name IN ('Super Admin', 'Admin')
    )
);

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Users can read own notification" ON public.notifications;
CREATE POLICY "Users can read own notification" ON public.notifications FOR SELECT USING (
    user_id IS NULL OR user_id = auth.uid()
);
DROP POLICY IF EXISTS "Admin write access for notifications" ON public.notifications;
CREATE POLICY "Admin write access for notifications" ON public.notifications FOR ALL USING (
    EXISTS (
        SELECT 1 FROM public.user_roles ur
        JOIN public.roles r ON ur.role_id = r.id
        WHERE ur.user_id = auth.uid() AND r.name IN ('Super Admin', 'Admin')
    )
);

-- Enable realtime support update subscriptions
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_publication_tables 
        WHERE pubname = 'supabase_realtime' 
        AND schemaname = 'public' 
        AND tablename = 'system_settings'
    ) THEN
        ALTER PUBLICATION supabase_realtime ADD TABLE public.system_settings;
    END IF;
    
    IF NOT EXISTS (
        SELECT 1 FROM pg_publication_tables 
        WHERE pubname = 'supabase_realtime' 
        AND schemaname = 'public' 
        AND tablename = 'promotions'
    ) THEN
        ALTER PUBLICATION supabase_realtime ADD TABLE public.promotions;
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_publication_tables 
        WHERE pubname = 'supabase_realtime' 
        AND schemaname = 'public' 
        AND tablename = 'notifications'
    ) THEN
        ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;
    END IF;
END $$;

-- 4. Map default permissions to the base Admin role
DO $$
DECLARE
    admin_role_id UUID;
    perm_id UUID;
BEGIN
    SELECT id INTO admin_role_id FROM public.roles WHERE name = 'Admin';
    IF admin_role_id IS NOT NULL THEN
        -- Map manage_users
        SELECT id INTO perm_id FROM public.permissions WHERE name = 'manage_users';
        IF perm_id IS NOT NULL THEN
            INSERT INTO public.role_permissions (role_id, permission_id)
            VALUES (admin_role_id, perm_id) ON CONFLICT DO NOTHING;
        END IF;

        -- Map manage_settings
        SELECT id INTO perm_id FROM public.permissions WHERE name = 'manage_settings';
        IF perm_id IS NOT NULL THEN
            INSERT INTO public.role_permissions (role_id, permission_id)
            VALUES (admin_role_id, perm_id) ON CONFLICT DO NOTHING;
        END IF;

        -- Map manage_finances
        SELECT id INTO perm_id FROM public.permissions WHERE name = 'manage_finances';
        IF perm_id IS NOT NULL THEN
            INSERT INTO public.role_permissions (role_id, permission_id)
            VALUES (admin_role_id, perm_id) ON CONFLICT DO NOTHING;
        END IF;
    END IF;
END $$;

