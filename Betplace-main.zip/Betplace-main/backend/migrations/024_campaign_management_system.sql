-- Migration: 024_campaign_management_system.sql
-- Extension to public.promotions table to support complete campaign settings,
-- customizable redemption messages, eligibility rules, advanced controls, and statistics.

ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS success_message TEXT DEFAULT 'Reward credited successfully!';
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS invalid_code_message TEXT DEFAULT 'The promo code entered is invalid.';
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS not_eligible_message TEXT DEFAULT 'You are not eligible for this promotion.';
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS already_claimed_message TEXT DEFAULT 'You have already claimed this promotion.';
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS promotion_expired_message TEXT DEFAULT 'This promotion has expired.';
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS promotion_not_started_message TEXT DEFAULT 'This promotion has not started yet.';
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS reward_limit_message TEXT DEFAULT 'This promotion has reached its maximum claim limit.';
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS account_suspended_message TEXT DEFAULT 'Your account is suspended.';
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS fraud_message TEXT DEFAULT 'Suspicious activity detected. Action blocked.';
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS system_error_message TEXT DEFAULT 'A system error occurred. Please try again later.';

ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS active_players_only BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS new_users_only BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS existing_users_only BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS minimum_games INT NOT NULL DEFAULT 0;
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS minimum_total_bets DECIMAL(12, 2) NOT NULL DEFAULT 0.00;
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS minimum_account_age INT NOT NULL DEFAULT 0; -- in days
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS phone_verification_required BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS email_verification_required BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS account_must_be_active BOOLEAN NOT NULL DEFAULT TRUE;

ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS max_claims_per_user INT NOT NULL DEFAULT 1;
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS max_daily_claims INT NOT NULL DEFAULT 0; -- 0 is unlimited

ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'active'; -- 'Draft', 'Scheduled', 'Active', 'Paused', 'Expired'
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS start_date TIMESTAMPTZ;
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS end_date TIMESTAMPTZ;
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS max_winners INT; -- usage limit
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS reward_per_winner DECIMAL(12, 2); -- reward amount
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS remaining_rewards INT;
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS featured BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS priority INT NOT NULL DEFAULT 0;
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS promo_code TEXT;

-- Advanced controls
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS auto_disable_winner_limit BOOLEAN NOT NULL DEFAULT TRUE;
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS auto_disable_end_date BOOLEAN NOT NULL DEFAULT TRUE;

-- Live Statistics column cache (to record real-time counts)
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS stats_successful_claims INT NOT NULL DEFAULT 0;
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS stats_incorrect_codes INT NOT NULL DEFAULT 0;
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS stats_already_claimed INT NOT NULL DEFAULT 0;
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS stats_expired_attempts INT NOT NULL DEFAULT 0;
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS stats_not_eligible_attempts INT NOT NULL DEFAULT 0;
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS stats_fraud_attempts INT NOT NULL DEFAULT 0;
ALTER TABLE public.promotions ADD COLUMN IF NOT EXISTS stats_wallet_distributed DECIMAL(12, 2) NOT NULL DEFAULT 0.00;

-- RPC increment_promo_stat
CREATE OR REPLACE FUNCTION public.increment_promo_stat(
    p_promo_id UUID, 
    p_stat_col TEXT, 
    p_amount DECIMAL DEFAULT 1
)
RETURNS VOID AS $$
BEGIN
    EXECUTE format('UPDATE public.promotions SET %I = %I + %L WHERE id = %L', p_stat_col, p_stat_col, p_amount, p_promo_id);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- RPC reserve_campaign_slot
CREATE OR REPLACE FUNCTION public.reserve_campaign_slot(
    p_promo_id UUID,
    p_max_winners INT,
    p_amount DECIMAL
)
RETURNS BOOLEAN AS $$
DECLARE
    v_updated BOOLEAN := FALSE;
BEGIN
    UPDATE public.promotions
    SET stats_successful_claims = stats_successful_claims + 1,
        stats_wallet_distributed = stats_wallet_distributed + p_amount
    WHERE id = p_promo_id 
      AND (p_max_winners IS NULL OR stats_successful_claims < p_max_winners);
      
    IF FOUND THEN
        v_updated := TRUE;
    END IF;
    
    RETURN v_updated;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

