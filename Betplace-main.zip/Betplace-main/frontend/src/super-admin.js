/**
 * src/super-admin.js
 * 
 * Expanded Super Admin Dashboard Logic
 * Provides full control over User Sovereignty, Admin Hierarchy, Financial Ledger, and Global settings.
 */

import { supabase } from './config/supabase.js';
import { injectVercelAnalytics } from './utils/analytics.js';
import { showNotFound } from './utils/notFound.js';
import { initGuard } from './utils/routeGuard.js';

const IS_SUPERADMIN_SUBDOMAIN = window.location.hostname.startsWith('superadmin.') || window.location.hostname.startsWith('super-admin.');

injectVercelAnalytics();

let currentUser = null;
let allUsers = [];
let allAuditLogs = [];
let allTransactions = [];
let activeTab = 'overview';

// ── PAGINATION SYSTEM CONFIGURATION ───────────────────────────
const PAGE_SIZE = 15;
const OVERVIEW_PAGE_SIZE = 10;

let userPage = 1;
let currentUsersList = [];

let ledgerPage = 1;
let currentLedgerList = [];

let auditPage = 1;
let currentAuditList = [];

let overviewAuditPage = 1;
let currentOverviewAuditList = [];

/** Non-blocking toast notification */
function showToast(message, isError = false) {
    const existing = document.getElementById('__adminToast');
    if (existing) existing.remove();
    const toast = document.createElement('div');
    toast.id = '__adminToast';
    toast.textContent = message;
    toast.style.cssText = `
        position:fixed; top:18px; right:18px; z-index:99999;
        background:${isError ? '#FEF2F2' : '#F0FDF4'};
        color:${isError ? '#991B1B' : '#166534'};
        padding:8px 14px; border-radius:8px; font-weight:500;
        font-size:0.8125rem; letter-spacing:-0.1px;
        box-shadow:0 4px 16px rgba(0,0,0,0.06);
        border:1px solid ${isError ? '#FECACA' : '#BBF7D0'};
        max-width:320px; word-break:break-word;
        transition:opacity 0.25s ease, transform 0.25s cubic-bezier(0.16, 1, 0.3, 1);
        backdrop-filter:blur(8px); -webkit-backdrop-filter:blur(8px);
    `;
    document.body.appendChild(toast);
    setTimeout(() => { toast.style.opacity = '0'; setTimeout(() => toast.remove(), 250); }, 3000);
}

function buildPaginationMarkup(totalItems, currentPage, pageSize, onPageChangeName) {
    const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
    let html = `
        <div class="pagination-controls">
            <div style="font-size:0.75rem; color:var(--sa-text-muted); font-weight:500;">
                Showing ${totalItems === 0 ? 0 : (currentPage - 1) * pageSize + 1} - ${Math.min(currentPage * pageSize, totalItems)} of ${totalItems} entries
            </div>
            <div style="display:flex; gap:6px; align-items:center;">
                <button class="quick-btn" style="padding:4px 10px; width:auto; font-weight:500;" 
                    ${currentPage === 1 ? 'disabled style="opacity:0.4; cursor:not-allowed;"' : `onclick="${onPageChangeName}(${currentPage - 1})"`}>
                    Prev
                </button>
    `;
    
    const startPage = Math.max(1, currentPage - 2);
    const endPage = Math.min(totalPages, startPage + 4);
    
    for (let i = startPage; i <= endPage; i++) {
        const isActive = i === currentPage;
        html += `
            <button class="quick-btn" 
                style="padding:4px 10px; width:auto; font-weight:600; border-radius:6px; cursor:pointer; ${isActive ? 'background:#0F172A; color:#FFFFFF; border:1px solid #0F172A;' : 'background:#FFFFFF; border:1px solid var(--sa-border); color:var(--sa-text-secondary);'}" 
                onclick="${onPageChangeName}(${i})">
                ${i}
            </button>
        `;
    }
    
    html += `
                <button class="quick-btn" style="padding:4px 10px; width:auto; font-weight:500;" 
                    ${currentPage === totalPages ? 'disabled style="opacity:0.4; cursor:not-allowed;"' : `onclick="${onPageChangeName}(${currentPage + 1})"`}>
                    Next
                </button>
            </div>
        </div>
    `;
    return html;
}


window.addEventListener('load', async () => {
    const authorized = await initGuard();
    if (!authorized) return;

    document.title = 'Super Admin Portal | Betplace';

    const { data: { session } } = await supabase.auth.getSession();
    currentUser = session?.user || JSON.parse(localStorage.getItem('metrowins_auth_user') || '{}');

    const topUserEl = document.getElementById('saTopUsername');
    if (topUserEl && currentUser) {
        topUserEl.textContent = currentUser.username || currentUser.phone || 'Super Admin';
    }

    window.handleAdminLogout = () => {
        localStorage.removeItem('metrowins_auth_token');
        localStorage.removeItem('metrowins_auth_user');
        document.cookie = 'metrowins_auth_token=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT';
        window.location.replace('/super-admin/login');
    };
    
    // Subscribe to game state realtime changes
    subscribeToGameState();

    // Bind Tab Click Handlers
    const buttons = document.querySelectorAll('.tool-btn[data-tab]');
    const tabs = ['overview', 'predictor', 'sportsbook', 'users', 'hierarchy', 'ledger', 'audit', 'promotions', 'promocodes', 'notifications', 'support', 'community', 'referral', 'settings'];

    buttons.forEach((btn) => {
        btn.addEventListener('click', () => {
            const targetTab = btn.getAttribute('data-tab');
            if (targetTab) {
                window.location.hash = '#' + targetTab;
            }
        });
    });

    window.addEventListener('hashchange', () => {
        const hashTab = window.location.hash.replace('#/', '').replace('#', '') || 'overview';
        if (tabs.includes(hashTab)) {
            buttons.forEach((b) => {
                b.classList.toggle('active', b.getAttribute('data-tab') === hashTab);
            });
            switchTab(hashTab);
        }
    });

    // Load initial screen based on hash routing
    const startTab = window.location.hash.replace('#/', '').replace('#', '') || 'overview';
    if (tabs.includes(startTab)) {
        buttons.forEach((b) => {
            b.classList.toggle('active', b.getAttribute('data-tab') === startTab);
        });
        switchTab(startTab);
    } else {
        switchTab('overview');
    }
});

function subscribeToGameState() {
    supabase
        .channel('active_game_state_admin')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'active_game_state' }, payload => {
            const newState = payload.new;
            if (!newState) return;
            
            const liveValEl = document.getElementById('liveCrashPointDisplay');
            if (liveValEl) {
                liveValEl.textContent = `${parseFloat(newState.crash_point).toFixed(2)}x`;
            }
            const liveStateEl = document.getElementById('liveGameStateDisplay');
            if (liveStateEl) {
                liveStateEl.textContent = String(newState.status).toUpperCase();
                liveStateEl.className = `status-pill ${newState.status === 'playing' ? 'status-approved' : (newState.status === 'waiting' ? 'status-pending' : 'status-rejected')}`;
            }
            const liveRoundEl = document.getElementById('liveRoundDisplay');
            if (liveRoundEl) {
                liveRoundEl.textContent = `#${newState.round_id}`;
            }
            // Trigger predictor update if current tab is predictor
            if (activeTab === 'predictor') {
                fetchPredictorData();
            }
        })
        .subscribe();
}

let predictorPollInterval = null;
let predictorHistoryLog = [];

function stopPredictorPolling() {
    if (predictorPollInterval) {
        clearInterval(predictorPollInterval);
        predictorPollInterval = null;
    }
}

async function switchTab(tab) {
    if (activeTab === 'predictor' && tab !== 'predictor') {
        stopPredictorPolling();
    }
    if (activeTab === 'sportsbook' && tab !== 'sportsbook') {
        stopSportsbookPolling();
    }
    activeTab = tab;
    const contentEl = document.getElementById('adminContent');
    if (!contentEl) return;

    // Show loading state
    contentEl.innerHTML = `
        <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; padding:100px 0; gap:16px;">
            <div class="airplane-spinner" style="font-size: 2rem; animation: spin 1.5s linear infinite;">✈</div>
            <div style="color:var(--sa-text-muted); font-size:0.8rem;">Loading administration interface...</div>
        </div>
    `;

    try {
        const { data: { session } } = await supabase.auth.getSession();
        const token = session?.access_token || localStorage.getItem('metrowins_auth_token');
        const headers = { 'Authorization': `Bearer ${token}` };

        if (tab === 'overview') {
            const statsRes = await fetch('/api/admin/system?action=stats', { headers });
            const stats = await statsRes.json();
            if (stats.error) throw new Error(stats.error);
            
            const logsRes = await fetch('/api/admin/system?action=audit_logs', { headers });
            allAuditLogs = await logsRes.json();
            if (allAuditLogs.error) throw new Error(allAuditLogs.error);

            renderOverview(stats, allAuditLogs);
        }
        else if (tab === 'predictor') {
            await renderAviatorPredictor();
        }
        else if (tab === 'sportsbook') {
            await renderSportsbookManagement();
        }
        else if (tab === 'users') {
            const res = await fetch('/api/admin/system?action=users', { headers });
            allUsers = await res.json();
            if (allUsers.error) throw new Error(allUsers.error);
            if (!Array.isArray(allUsers)) throw new Error('Expected array of users, received ' + typeof allUsers);
            renderUserSovereignty();
        }
        else if (tab === 'hierarchy') {
            const res = await fetch('/api/admin/system?action=users', { headers });
            allUsers = await res.json();
            if (allUsers.error) throw new Error(allUsers.error);
            if (!Array.isArray(allUsers)) throw new Error('Expected array of users, received ' + typeof allUsers);
            renderAdminHierarchy();
        }
        else if (tab === 'ledger') {
            const res = await fetch('/api/admin/system?action=transactions', { headers });
            allTransactions = await res.json();
            if (allTransactions.error) throw new Error(allTransactions.error);
            if (!Array.isArray(allTransactions)) throw new Error('Expected array of transactions, received ' + typeof allTransactions);
            renderFinancialLedger();
        }
        else if (tab === 'audit') {
            const res = await fetch('/api/admin/system?action=audit_logs', { headers });
            allAuditLogs = await res.json();
            if (allAuditLogs.error) throw new Error(allAuditLogs.error);
            if (!Array.isArray(allAuditLogs)) throw new Error('Expected array of audit logs, received ' + typeof allAuditLogs);
            renderAuditRecords();
        }
        else if (tab === 'promotions') {
            const res = await fetch('/api/admin/content?action=promotions', { headers });
            const data = await res.json();
            if (data.error) throw new Error(data.error);
            renderPromotions(Array.isArray(data) ? data : []);
        }
        else if (tab === 'promocodes') {
            const res = await fetch('/api/admin/promocodes?action=list', { headers });
            const data = await res.json();
            if (data.error) throw new Error(data.error);
            renderPromocodes(Array.isArray(data) ? data : []);
        }
        else if (tab === 'notifications') {
            renderNotifications();
        }
        else if (tab === 'support') {
            const res = await fetch('/api/admin/content?action=settings', { headers });
            const settings = await res.json();
            renderSupport(settings);
        }
        else if (tab === 'community') {
            const res = await fetch('/api/admin/content?action=settings', { headers });
            const settings = await res.json();
            renderCommunity(settings);
        }
        else if (tab === 'referral') {
            const res = await fetch('/api/admin/content?action=settings', { headers });
            const settings = await res.json();
            renderReferralSettings(settings);
        }
        else if (tab === 'settings') {
            renderGlobalSettings();
        }

        if (window.lucide) lucide.createIcons();
    } catch (e) {
        contentEl.innerHTML = `
            <div style="padding: 24px; text-align: center; color: var(--sa-accent-red);">
                <h3>Failed to load system workspace</h3>
                <p style="font-size:0.75rem; color:var(--sa-text-muted); margin-top:8px;">${e.message}</p>
                <button class="danger-btn" style="width:auto; margin:16px auto 0; padding:8px 20px;" onclick="switchTab('${tab}')">TRY AGAIN</button>
            </div>
        `;
    }
}

window.switchTab = switchTab;

// ── AVIATOR PREDICTOR & ENGINE TELEMETRY ─────────────────────────────────────

async function renderAviatorPredictor() {
    stopPredictorPolling();
    const contentEl = document.getElementById('adminContent');
    if (!contentEl) return;

    contentEl.innerHTML = `
        <div class="pane-header">
            <div class="pane-header-titles">
                <h1>Aviator AI Telemetry & Predictor Portal</h1>
                <p>Real-time neural regression telemetry, flight stream forecasting, and crash multiplier override controls</p>
            </div>
            <div style="display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
                <button class="sa-topbar-btn" onclick="fetchPredictorData(true)">
                    <i data-lucide="refresh-cw" style="width:14px; height:14px;"></i>
                    <span>Sync Engine</span>
                </button>
                <a href="/aviator" target="_blank" class="sa-topbar-btn game-btn">
                    <i data-lucide="external-link" style="width:14px; height:14px;"></i>
                    <span>Open Live Flight Game</span>
                </a>
            </div>
        </div>

        <!-- Predictor Top Metrics Strip -->
        <div class="metrics-grid">
            <div class="metric-card">
                <div class="metric-label">Server Round</div>
                <div class="metric-value purple" id="predRoundDisplay">#-----</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">Flight State</div>
                <div class="metric-value" id="predStatusDisplay">--</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">Predicted Crash Multiplier</div>
                <div class="metric-value stable" id="predMultTopDisplay">--.--x</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">Next Round Override</div>
                <div class="metric-value" id="predOverrideDisplay" style="font-size:1.35rem;">NATURAL RNG</div>
            </div>
        </div>

        <!-- Predictor Main Grid -->
        <div class="pred-portal-grid">
            <!-- Left Column: Circular Radar & Safety Recommendation -->
            <div class="pred-radar-card">
                <div class="pred-radar-header">
                    <div class="pred-ai-tag">
                        <i data-lucide="cpu" style="width:13px; height:13px;"></i>
                        <span>Neural Model v4.2</span>
                    </div>
                    <span class="pred-round-badge" id="predRoundIdBadge">ROUND #-----</span>
                </div>

                <h2 style="font-size:1.15rem; font-weight:700; color:var(--sa-text-primary); margin-bottom:4px;">Live Round Predictor</h2>
                <p style="font-size:0.75rem; color:var(--sa-text-muted);">Real-time telemetry stream synchronized with server game loop</p>

                <!-- Circular Radar Gauge -->
                <div class="pred-gauge-wrapper">
                    <div class="pred-gauge-outer"></div>
                    <div class="pred-gauge-inner"></div>
                    <div class="pred-gauge-sweep"></div>
                    <div class="pred-gauge-center">
                        <span id="predRadarVal" class="pred-multiplier-val">--.--x</span>
                        <span id="predRadarStatus" class="pred-status-pill">CONNECTING...</span>
                    </div>
                </div>

                <!-- Cashout Recommendation Banner -->
                <div class="pred-cashout-banner">
                    <i data-lucide="target"></i>
                    <div class="pred-cashout-meta">
                        <span class="pred-cashout-label">Target Cashout Recommendation</span>
                        <strong id="predCashoutTarget" class="pred-cashout-val">AUTO ANALYZING...</strong>
                    </div>
                </div>

                <!-- Live AI Confidence Grid -->
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-top:16px;">
                    <div style="background:var(--sa-bg-body); border:1px solid var(--sa-border); padding:10px; border-radius:6px; text-align:left;">
                        <span style="font-size:0.65rem; color:var(--sa-text-muted); font-weight:600; text-transform:uppercase;">AI Accuracy</span>
                        <div style="font-size:1.05rem; font-weight:700; color:#16A34A; margin-top:2px;">99.2% <span style="font-size:0.65rem; color:#15803D; font-weight:600;">Verified</span></div>
                    </div>
                    <div style="background:var(--sa-bg-body); border:1px solid var(--sa-border); padding:10px; border-radius:6px; text-align:left;">
                        <span style="font-size:0.65rem; color:var(--sa-text-muted); font-weight:600; text-transform:uppercase;">Confidence</span>
                        <div style="font-size:1.05rem; font-weight:700; color:var(--sa-text-primary); margin-top:2px;">MAXIMUM</div>
                    </div>
                    <div style="background:var(--sa-bg-body); border:1px solid var(--sa-border); padding:10px; border-radius:6px; text-align:left;">
                        <span style="font-size:0.65rem; color:var(--sa-text-muted); font-weight:600; text-transform:uppercase;">Latency Sync</span>
                        <div style="font-size:1.05rem; font-weight:700; color:var(--sa-text-primary); margin-top:2px;">&lt; 4ms</div>
                    </div>
                    <div style="background:var(--sa-bg-body); border:1px solid var(--sa-border); padding:10px; border-radius:6px; text-align:left;">
                        <span style="font-size:0.65rem; color:var(--sa-text-muted); font-weight:600; text-transform:uppercase;">Risk Index</span>
                        <div style="font-size:1.05rem; font-weight:700; color:#16A34A; margin-top:2px;">LOW (Optimal)</div>
                    </div>
                </div>
            </div>

            <!-- Right Column: Flight Override Controller & Live Stream Feed -->
            <div class="pred-controls-column">
                <!-- Flight Multiplier Override Console -->
                <div class="pred-controller-card">
                    <div class="pred-controller-header">
                        <div class="pred-controller-title">
                            <i data-lucide="sliders" style="width:18px; height:18px; color:var(--sa-text-secondary);"></i>
                            <span>Flight Multiplier Controller</span>
                        </div>
                        <span id="overrideStatusBadge" class="override-status-indicator natural">
                            NATURAL RNG ACTIVE
                        </span>
                    </div>

                    <p style="font-size:0.82rem; color:var(--sa-text-secondary); margin-bottom:16px; line-height:1.4;">
                        Arm the exact crash multiplier for the upcoming flight round. When set, the flight engine enforces this exact target point when transitioning from waiting to flight.
                    </p>

                    <!-- Quick Preset Buttons -->
                    <div style="font-size:0.68rem; font-weight:600; color:var(--sa-text-muted); text-transform:uppercase; letter-spacing:0.04em; margin-bottom:8px;">
                        Quick Multiplier Presets
                    </div>
                    <div class="preset-buttons-grid">
                        <button class="preset-btn" onclick="setPresetMultiplier(1.50)">1.50x Safe</button>
                        <button class="preset-btn" onclick="setPresetMultiplier(2.20)">2.20x Balanced</button>
                        <button class="preset-btn" onclick="setPresetMultiplier(3.50)">3.50x Medium</button>
                        <button class="preset-btn" onclick="setPresetMultiplier(5.00)">5.00x High</button>
                        <button class="preset-btn" onclick="setPresetMultiplier(10.00)">10.00x Super</button>
                        <button class="preset-btn" onclick="setPresetMultiplier(50.00)">50.00x Mega</button>
                    </div>

                    <!-- Custom Multiplier Arm Form -->
                    <div class="override-form-row">
                        <input type="number" step="0.01" min="1.01" max="200" id="customMultiplierInput" class="override-input" placeholder="Custom Multiplier (e.g. 3.25x)">
                        <button class="arm-btn" id="armMultiplierBtn" onclick="handleArmMultiplier()">
                            <i data-lucide="lock" style="width:14px; height:14px;"></i>
                            <span>ARM NEXT ROUND</span>
                        </button>
                        <button class="clear-btn" id="clearMultiplierBtn" onclick="handleClearOverride()">
                            <i data-lucide="rotate-ccw" style="width:14px; height:14px;"></i>
                            <span>Reset RNG</span>
                        </button>
                    </div>
                </div>

                <!-- Live Prediction Stream Feed Card -->
                <div class="pred-controller-card">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px;">
                        <div style="font-size:0.95rem; font-weight:600; color:var(--sa-text-primary); display:flex; align-items:center; gap:8px;">
                            <i data-lucide="trending-up" style="width:16px; height:16px; color:#16A34A;"></i>
                            <span>Live Prediction Stream Feed</span>
                        </div>
                        <span style="font-size:0.6875rem; color:#166534; font-weight:600; background:#F0FDF4; border:1px solid #BBF7D0; padding:2px 8px; border-radius:4px;">
                            Realtime Telemetry
                        </span>
                    </div>

                    <!-- Upcoming Predictions Section -->
                    <div style="margin-bottom:16px;">
                        <div style="font-size:0.6875rem; font-weight:600; color:var(--sa-text-muted); text-transform:uppercase; letter-spacing:0.04em; margin-bottom:8px; display:flex; justify-content:space-between; align-items:center;">
                            <span>Next 3 AI Forecasts &amp; Immediate Arming</span>
                            <span style="font-size:0.625rem; color:var(--sa-text-muted); font-weight:500;">Click "ARM THIS" to enforce</span>
                        </div>
                        <div class="pred-upcoming-grid" id="predUpcomingForecasts">
                            <div style="grid-column:1/-1; padding:12px; text-align:center; font-size:0.75rem; color:var(--sa-text-muted); background:var(--sa-bg-body); border-radius:6px; border:1px solid var(--sa-border);">
                                Synchronizing neural forecast stream...
                            </div>
                        </div>
                    </div>

                    <!-- Historical Verified Rounds Feed -->
                    <div>
                        <div style="font-size:0.6875rem; font-weight:600; color:var(--sa-text-muted); text-transform:uppercase; letter-spacing:0.04em; margin-bottom:6px;">
                            Recent Verified Telemetry Log
                        </div>
                        <div class="pred-history-pills" id="predLiveHistoryFeed">
                            <div class="pred-pill-item">
                                <span style="color:var(--sa-text-muted);">#INIT</span>
                                <strong style="color:var(--sa-text-primary);">--.--x</strong>
                                <span style="color:#16A34A;">✓</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;

    if (window.lucide) lucide.createIcons();

    // Fetch initial data immediately and start polling
    await fetchPredictorData();
    predictorPollInterval = setInterval(fetchPredictorData, 1500);
}

async function fetchPredictorData(isManual = false) {
    if (activeTab !== 'predictor') return;

    try {
        const { data: { session } } = await supabase.auth.getSession();
        const token = session?.access_token || localStorage.getItem('metrowins_auth_token');
        const headers = { 'Authorization': `Bearer ${token}` };

        // Fetch live signal
        const sigRes = await fetch('/api/signal', { headers });
        let sigData = null;
        if (sigRes.ok) {
            sigData = await sigRes.json();
        }

        // Fetch engine state for override
        const stateRes = await fetch('/api/admin/system?action=game_state', { headers });
        let stateData = null;
        if (stateRes.ok) {
            stateData = await stateRes.json();
        }

        updatePredictorUI(sigData, stateData);
        if (isManual) {
            showToast('Predictor telemetry synchronized with flight engine.');
        }
    } catch (err) {
        console.warn('[Predictor Fetch Warning]:', err.message);
    }
}

function updatePredictorUI(sigData, stateData) {
    if (!sigData) return;

    const roundId = sigData.roundId || stateData?.round_id || 0;
    const status = (sigData.status || stateData?.status || 'waiting').toLowerCase();
    const crashPoint = parseFloat(sigData.crashPoint || stateData?.crash_point || 2.00);

    // Update Round displays
    const roundEl = document.getElementById('predRoundDisplay');
    const roundBadge = document.getElementById('predRoundIdBadge');
    if (roundEl) roundEl.textContent = `#${roundId}`;
    if (roundBadge) roundBadge.textContent = `ROUND #${roundId}`;

    // Update Status display
    const statusEl = document.getElementById('predStatusDisplay');
    if (statusEl) {
        if (status === 'playing') {
            statusEl.textContent = 'IN FLIGHT';
            statusEl.style.color = '#10b981';
        } else if (status === 'crashed') {
            statusEl.textContent = 'CRASHED';
            statusEl.style.color = '#ef4444';
        } else {
            statusEl.textContent = 'WAITING';
            statusEl.style.color = '#f59e0b';
        }
    }

    // Update Radar Multiplier & Status
    const radarVal = document.getElementById('predRadarVal');
    const radarStatus = document.getElementById('predRadarStatus');
    const cashoutTarget = document.getElementById('predCashoutTarget');
    const multTopDisplay = document.getElementById('predMultTopDisplay');

    if (status === 'crashed') {
        if (radarStatus) radarStatus.textContent = 'COMPILING NEXT FLIGHT...';
        if (radarVal) {
            radarVal.textContent = '--.--x';
            radarVal.style.color = '#94A3B8';
            radarVal.style.textShadow = 'none';
        }
        if (cashoutTarget) cashoutTarget.textContent = 'PREPARING TAKEOFF';
        if (multTopDisplay) multTopDisplay.textContent = '--.--x';
    } else {
        const valFormatted = `${crashPoint.toFixed(2)}x`;
        const safeTarget = Math.max(1.01, crashPoint * 0.88).toFixed(2);

        if (radarStatus) radarStatus.textContent = 'SIGNAL SECURED & ENCRYPTED';
        if (cashoutTarget) cashoutTarget.textContent = `${safeTarget}x (SAFETY MARGIN)`;
        if (multTopDisplay) multTopDisplay.textContent = valFormatted;

        if (radarVal) {
            radarVal.textContent = valFormatted;
            radarVal.style.textShadow = 'none';
            if (crashPoint >= 10.0) {
                radarVal.style.color = '#7C3AED';
            } else if (crashPoint >= 3.0) {
                radarVal.style.color = '#16A34A';
            } else if (crashPoint >= 2.0) {
                radarVal.style.color = '#2563EB';
            } else {
                radarVal.style.color = '#0F172A';
            }
        }

        // History feed
        if (!predictorHistoryLog.some(h => h.roundId === roundId)) {
            predictorHistoryLog.unshift({
                roundId,
                multiplier: crashPoint.toFixed(2)
            });
            if (predictorHistoryLog.length > 15) predictorHistoryLog.pop();

            const feedEl = document.getElementById('predLiveHistoryFeed');
            if (feedEl) {
                feedEl.innerHTML = predictorHistoryLog.map(h => `
                    <div class="pred-pill-item">
                        <span style="color:var(--sa-text-muted);">#${h.roundId}</span>
                        <strong style="color:var(--sa-text-primary);">${h.multiplier}x</strong>
                        <span style="color:#16A34A;">✓</span>
                    </div>
                `).join('');
            }
        }
    }

    // Update Upcoming Predictions (Next 3 Rounds)
    const upcomingContainer = document.getElementById('predUpcomingForecasts');
    if (upcomingContainer && roundId) {
        let forecasts = sigData.nextPredictions;
        const armedPoint = stateData?.next_crash_point ? parseFloat(stateData.next_crash_point) : null;
        const isArmedActive = armedPoint !== null && !isNaN(armedPoint);

        if (!forecasts || !Array.isArray(forecasts) || forecasts.length === 0) {
            forecasts = [1, 2, 3].map(offset => {
                const targetRoundId = roundId + offset;
                const isNextAndArmed = offset === 1 && isArmedActive;
                let multiplier;
                if (isNextAndArmed) {
                    multiplier = armedPoint;
                } else {
                    const x = Math.sin(targetRoundId * 9301 + 49297) * 233280;
                    const r = x - Math.floor(x);
                    if (r < 0.45) multiplier = 1.15 + (r / 0.45) * 1.10;
                    else if (r < 0.75) multiplier = 2.25 + ((r - 0.45) / 0.30) * 2.50;
                    else if (r < 0.92) multiplier = 4.80 + ((r - 0.75) / 0.17) * 6.50;
                    else multiplier = 12.00 + ((r - 0.92) / 0.08) * 25.00;
                    multiplier = parseFloat(multiplier.toFixed(2));
                }
                return {
                    roundId: targetRoundId,
                    offset,
                    multiplier,
                    isArmed: !!isNextAndArmed,
                    confidence: isNextAndArmed ? 99.9 : parseFloat((94.5 + ((Math.cos(targetRoundId * 1337) + 1) / 2) * 5.0).toFixed(1))
                };
            });
        }

        upcomingContainer.innerHTML = forecasts.map(f => {
            const multVal = parseFloat(f.multiplier).toFixed(2);
            const isThisArmed = f.offset === 1 && isArmedActive && Math.abs(parseFloat(f.multiplier) - armedPoint) < 0.01;
            return `
                <div class="pred-forecast-card ${isThisArmed ? 'armed' : ''}">
                    <div class="pred-forecast-top">
                        <span class="pred-forecast-round">
                            #${f.roundId}
                            <span class="pred-forecast-tag">${f.offset === 1 ? 'Next Round' : `+${f.offset} Rounds`}</span>
                        </span>
                        <span class="pred-forecast-conf">${f.confidence}% Conf</span>
                    </div>
                    <div class="pred-forecast-body">
                        <div class="pred-forecast-mult">${multVal}x</div>
                        <button class="pred-arm-btn ${isThisArmed ? 'armed' : ''}" onclick="window.armSpecificMultiplier(${multVal})" title="Arm ${multVal}x for round #${f.roundId}">
                            <i data-lucide="${isThisArmed ? 'check-circle' : 'zap'}" style="width:12px; height:12px;"></i>
                            <span>${isThisArmed ? 'ARMED' : 'ARM THIS'}</span>
                        </button>
                    </div>
                </div>
            `;
        }).join('');
    }

    // Update Override status
    const overrideStatusBadge = document.getElementById('overrideStatusBadge');
    const predOverrideDisplay = document.getElementById('predOverrideDisplay');
    const nextCrashPoint = stateData?.next_crash_point;

    if (nextCrashPoint && !isNaN(parseFloat(nextCrashPoint))) {
        const armedVal = parseFloat(nextCrashPoint).toFixed(2);
        if (overrideStatusBadge) {
            overrideStatusBadge.className = 'override-status-indicator armed';
            overrideStatusBadge.textContent = `ARMED: ${armedVal}x`;
        }
        if (predOverrideDisplay) {
            predOverrideDisplay.textContent = `${armedVal}x ARMED`;
            predOverrideDisplay.style.color = '#ef4444';
        }
    } else {
        if (overrideStatusBadge) {
            overrideStatusBadge.className = 'override-status-indicator natural';
            overrideStatusBadge.textContent = 'NATURAL RNG ACTIVE';
        }
        if (predOverrideDisplay) {
            predOverrideDisplay.textContent = 'NATURAL RNG';
            predOverrideDisplay.style.color = '#10b981';
        }
    }

    if (window.lucide) lucide.createIcons();
}

window.armSpecificMultiplier = async (val) => {
    const mult = parseFloat(val);
    if (isNaN(mult) || mult < 1.01 || mult > 200) {
        showToast('Please specify a valid multiplier between 1.01x and 200.00x.', true);
        return;
    }

    const input = document.getElementById('customMultiplierInput');
    if (input) input.value = mult.toFixed(2);

    try {
        const { data: { session } } = await supabase.auth.getSession();
        const token = session?.access_token || localStorage.getItem('metrowins_auth_token');

        const res = await fetch('/api/admin/actions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                action: 'override_crash_point',
                multiplier: mult
            })
        });

        const data = await res.json();
        if (!res.ok || data.error) {
            throw new Error(data.error || 'Failed to arm multiplier.');
        }

        showToast(data.message || `Next crash point armed at ${mult.toFixed(2)}x!`);
        await fetchPredictorData();
    } catch (err) {
        showToast(err.message || 'Error communicating with flight engine.', true);
    }
};

window.setPresetMultiplier = (val) => {
    const input = document.getElementById('customMultiplierInput');
    if (input) {
        input.value = val;
        input.focus();
    }
};

window.handleArmMultiplier = async () => {
    const input = document.getElementById('customMultiplierInput');
    const mult = parseFloat(input?.value);

    if (isNaN(mult) || mult < 1.01 || mult > 200) {
        showToast('Please specify a valid multiplier between 1.01x and 200.00x.', true);
        return;
    }

    const btn = document.getElementById('armMultiplierBtn');
    if (btn) btn.disabled = true;

    try {
        const { data: { session } } = await supabase.auth.getSession();
        const token = session?.access_token || localStorage.getItem('metrowins_auth_token');

        const res = await fetch('/api/admin/actions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                action: 'override_crash_point',
                multiplier: mult
            })
        });

        const data = await res.json();
        if (!res.ok || data.error) {
            throw new Error(data.error || 'Failed to arm multiplier.');
        }

        showToast(data.message || `Next crash point armed at ${mult.toFixed(2)}x!`);
        await fetchPredictorData();
    } catch (err) {
        showToast(err.message || 'Error communicating with flight engine.', true);
    } finally {
        if (btn) btn.disabled = false;
    }
};

window.handleClearOverride = async () => {
    const btn = document.getElementById('clearMultiplierBtn');
    if (btn) btn.disabled = true;

    try {
        const { data: { session } } = await supabase.auth.getSession();
        const token = session?.access_token || localStorage.getItem('metrowins_auth_token');

        const res = await fetch('/api/admin/actions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                action: 'override_crash_point',
                multiplier: 'clear'
            })
        });

        const data = await res.json();
        if (!res.ok || data.error) {
            throw new Error(data.error || 'Failed to clear override.');
        }

        const input = document.getElementById('customMultiplierInput');
        if (input) input.value = '';

        showToast(data.message || 'Crash override cleared. Natural RNG active.');
        await fetchPredictorData();
    } catch (err) {
        showToast(err.message || 'Error clearing flight override.', true);
    } finally {
        if (btn) btn.disabled = false;
    }
};

// ── SPORTSBOOK & BETTORS MANAGEMENT CONSOLE ──────────────────────────────────

let sportsbookPollInterval = null;
let sportsbookAutoRefresh = true;
let currentSportsSubTab = 'bets'; // 'bets' | 'fixtures' | 'risk'
let currentSportsStatusFilter = 'all'; // 'all' | 'pending' | 'won' | 'lost' | 'cashed_out' | 'cancelled'
let currentSportsTypeFilter = 'all'; // 'all' | 'single' | 'accumulator'
let currentSportsSearch = '';
let currentSportsSort = 'newest';
let currentSportsPage = 0;
let sportsbookStatsData = null;
let sportsbookBetsData = [];
let sportsbookFixturesData = [];
let sportsbookTotalBets = 0;
let sportsSearchDebounceTimer = null;

function stopSportsbookPolling() {
    if (sportsbookPollInterval) {
        clearInterval(sportsbookPollInterval);
        sportsbookPollInterval = null;
    }
}

function formatSportsTime(isoStr) {
    if (!isoStr) return '—';
    try {
        const d = new Date(isoStr);
        const diffMs = Date.now() - d.getTime();
        const diffSec = Math.floor(diffMs / 1000);
        if (diffSec < 60) return 'Just now';
        const diffMin = Math.floor(diffSec / 60);
        if (diffMin < 60) return `${diffMin}m ago`;
        const diffHr = Math.floor(diffMin / 60);
        if (diffHr < 24) return `${diffHr}h ago`;
        return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    } catch (_) {
        return isoStr;
    }
}

async function renderSportsbookManagement() {
    stopSportsbookPolling();
    const contentEl = document.getElementById('adminContent');
    if (!contentEl) return;

    contentEl.innerHTML = `
        <div class="pane-header">
            <div class="pane-header-titles">
                <h1>Sportsbook & Bettors Management Console</h1>
                <p>Real-time wager monitoring, live bet slips, manual settlement overrides, and bookmaker risk controls</p>
            </div>
            <div style="display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
                <button class="sa-topbar-btn" id="sbAutoRefreshBtn" onclick="toggleSportsAutoRefresh()">
                    <i data-lucide="activity" style="width:14px; height:14px; color:${sportsbookAutoRefresh ? '#10B981' : '#64748B'};"></i>
                    <span>Auto-Sync: ${sportsbookAutoRefresh ? 'ON (5s)' : 'PAUSED'}</span>
                </button>
                <button class="sa-topbar-btn" onclick="fetchSportsbookData(false)">
                    <i data-lucide="refresh-cw" style="width:14px; height:14px;"></i>
                    <span>Sync Telemetry</span>
                </button>
                <a href="/sports" target="_blank" class="sa-topbar-btn game-btn">
                    <i data-lucide="external-link" style="width:14px; height:14px;"></i>
                    <span>Launch Sportsbook</span>
                </a>
            </div>
        </div>

        <!-- Sportsbook Top Metrics Strip -->
        <div class="metrics-grid">
            <div class="metric-card">
                <div class="metric-label">
                    <i data-lucide="coins" style="width:14px; height:14px; color:var(--sa-text-muted);"></i>
                    <span>Total Sports Turnover</span>
                </div>
                <div class="metric-value" id="sbMetricVolume">KES 0.00</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">
                    <i data-lucide="arrow-up-right" style="width:14px; height:14px; color:var(--sa-text-muted);"></i>
                    <span>Total Paid Out</span>
                </div>
                <div class="metric-value" id="sbMetricPayout">KES 0.00</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">
                    <i data-lucide="trending-up" style="width:14px; height:14px; color:var(--sa-text-muted);"></i>
                    <span>Net Sports GGR (Hold)</span>
                </div>
                <div class="metric-value stable" id="sbMetricGGR">KES 0.00 (0%)</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">
                    <i data-lucide="clock" style="width:14px; height:14px; color:var(--sa-text-muted);"></i>
                    <span>Pending Wagers & Liability</span>
                </div>
                <div class="metric-value" id="sbMetricPending" style="font-size:1.15rem;">0 Slips (KES 0.00)</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">
                    <i data-lucide="users" style="width:14px; height:14px; color:var(--sa-text-muted);"></i>
                    <span>Active Bettors / Win Ratio</span>
                </div>
                <div class="metric-value" id="sbMetricWinRate" style="font-size:1.15rem;">0 Bettors (0W / 0L)</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">
                    <i data-lucide="cpu" style="width:14px; height:14px; color:var(--sa-text-muted);"></i>
                    <span>SharpAPI Engine Status</span>
                </div>
                <div class="metric-value" id="sbMetricQuota" style="font-size:1.15rem;">ONLINE • Best Price</div>
            </div>
        </div>

        <!-- Sub-navigation Tabs -->
        <div class="sports-subnav">
            <button class="sports-subnav-btn ${currentSportsSubTab === 'bets' ? 'active' : ''}" onclick="switchSportsSubTab('bets')">
                <i data-lucide="receipt" style="width:15px; height:15px;"></i>
                <span>Live Bets & Bettors Ledger</span>
                <span class="pill-badge" id="sbPendingBadge">0 PENDING</span>
            </button>
            <button class="sports-subnav-btn ${currentSportsSubTab === 'fixtures' ? 'active' : ''}" onclick="switchSportsSubTab('fixtures')">
                <i data-lucide="trophy" style="width:15px; height:15px;"></i>
                <span>Match Result & Settle Controller</span>
            </button>
            <button class="sports-subnav-btn ${currentSportsSubTab === 'risk' ? 'active' : ''}" onclick="switchSportsSubTab('risk')">
                <i data-lucide="sliders" style="width:15px; height:15px;"></i>
                <span>Risk & Bookmaker Limits</span>
            </button>
        </div>

        <!-- Dynamic Subtab View Container -->
        <div id="sportsSubViewContainer">
            <!-- Rendered by switchSportsSubTab -->
        </div>

        <!-- Inspection Modal Container -->
        <div id="sportsModalContainer"></div>
    `;

    if (window.lucide) lucide.createIcons();

    // Render active subtab
    await renderActiveSportsSubView();

    // Initial fetch
    await fetchSportsbookData(true);

    // Setup polling
    if (sportsbookAutoRefresh) {
        sportsbookPollInterval = setInterval(() => fetchSportsbookData(true), 5000);
    }
}

function toggleSportsAutoRefresh() {
    sportsbookAutoRefresh = !sportsbookAutoRefresh;
    const btn = document.getElementById('sbAutoRefreshBtn');
    if (btn) {
        btn.innerHTML = `
            <i data-lucide="activity" style="width:14px; height:14px; color:${sportsbookAutoRefresh ? '#10B981' : '#64748B'};"></i>
            <span>Auto-Sync: ${sportsbookAutoRefresh ? 'ON (5s)' : 'PAUSED'}</span>
        `;
        if (window.lucide) lucide.createIcons();
    }
    stopSportsbookPolling();
    if (sportsbookAutoRefresh) {
        sportsbookPollInterval = setInterval(() => fetchSportsbookData(true), 5000);
        showToast('Real-time sports wager synchronization resumed.');
    } else {
        showToast('Real-time synchronization paused.');
    }
}

async function switchSportsSubTab(subTab) {
    currentSportsSubTab = subTab;
    document.querySelectorAll('.sports-subnav-btn').forEach((btn, idx) => {
        const matches = (idx === 0 && subTab === 'bets') || (idx === 1 && subTab === 'fixtures') || (idx === 2 && subTab === 'risk');
        btn.classList.toggle('active', matches);
    });
    await renderActiveSportsSubView();
    await fetchSportsbookData(true);
}

async function renderActiveSportsSubView() {
    const container = document.getElementById('sportsSubViewContainer');
    if (!container) return;

    if (currentSportsSubTab === 'bets') {
        container.innerHTML = `
            <!-- Filter & Search Controls -->
            <div class="sa-filter-bar" style="margin-bottom:16px;">
                <div class="sa-filter-chips">
                    <button class="sa-chip ${currentSportsStatusFilter === 'all' ? 'active' : ''}" onclick="filterSportsByStatus('all', this)">All Bets</button>
                    <button class="sa-chip ${currentSportsStatusFilter === 'pending' ? 'active' : ''}" onclick="filterSportsByStatus('pending', this)" style="border-color:rgba(245,158,11,0.3); color:#FBBF24;">Pending</button>
                    <button class="sa-chip ${currentSportsStatusFilter === 'won' ? 'active' : ''}" onclick="filterSportsByStatus('won', this)" style="border-color:rgba(16,185,129,0.3); color:#34D399;">Won</button>
                    <button class="sa-chip ${currentSportsStatusFilter === 'lost' ? 'active' : ''}" onclick="filterSportsByStatus('lost', this)" style="border-color:rgba(239,68,68,0.3); color:#F87171;">Lost</button>
                    <button class="sa-chip ${currentSportsStatusFilter === 'cashed_out' ? 'active' : ''}" onclick="filterSportsByStatus('cashed_out', this)" style="border-color:rgba(168,85,247,0.3); color:#D8B4FE;">Cashed Out</button>
                    <button class="sa-chip ${currentSportsStatusFilter === 'cancelled' ? 'active' : ''}" onclick="filterSportsByStatus('cancelled', this)">Void / Refunded</button>
                </div>

                <div class="sa-filter-chips" style="margin-left:auto;">
                    <button class="sa-chip ${currentSportsTypeFilter === 'all' ? 'active' : ''}" onclick="filterSportsByType('all', this)">All Types</button>
                    <button class="sa-chip ${currentSportsTypeFilter === 'single' ? 'active' : ''}" onclick="filterSportsByType('single', this)">Singles</button>
                    <button class="sa-chip ${currentSportsTypeFilter === 'accumulator' ? 'active' : ''}" onclick="filterSportsByType('accumulator', this)">Accumulators</button>
                </div>

                <div class="sa-search-input-wrap" style="width:100%; max-width:320px;">
                    <i data-lucide="search" style="width:14px; height:14px;"></i>
                    <input type="text" id="sportsSearchInput" placeholder="Search bettor, phone, ticket ID, team..." value="${currentSportsSearch}" oninput="handleSportsSearch(this.value)">
                </div>
            </div>

            <!-- Bets Table Wrapper -->
            <div class="audit-table-wrap">
                <table class="audit-table">
                    <thead>
                        <tr>
                            <th>Bettor Account</th>
                            <th>Ticket ID & Date</th>
                            <th>Stake (KES)</th>
                            <th>Combined Odds</th>
                            <th>Potential Return</th>
                            <th>Selections Breakdown</th>
                            <th>Status</th>
                            <th style="text-align:right;">Super Admin Controls</th>
                        </tr>
                    </thead>
                    <tbody id="sportsBetsTableBody">
                        <tr>
                            <td colspan="8" style="text-align:center; padding:40px; color:var(--sa-text-muted);">
                                Loading sports bets ledger...
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Pagination Bar -->
            <div class="pagination-controls" style="display:flex; justify-content:space-between; align-items:center; margin-top:16px;">
                <div style="font-size:0.75rem; color:var(--sa-text-muted);" id="sbPaginationInfo">
                    Showing 0 bets
                </div>
                <div style="display:flex; gap:8px;">
                    <button class="sa-topbar-btn" id="sbPrevPageBtn" onclick="changeSportsPage(-1)" disabled>
                        <i data-lucide="chevron-left" style="width:14px; height:14px;"></i>
                        <span>Previous</span>
                    </button>
                    <button class="sa-topbar-btn" id="sbNextPageBtn" onclick="changeSportsPage(1)" disabled>
                        <span>Next</span>
                        <i data-lucide="chevron-right" style="width:14px; height:14px;"></i>
                    </button>
                </div>
            </div>
        `;
    } else if (currentSportsSubTab === 'fixtures') {
        container.innerHTML = `
            <div style="background:var(--sa-bg-card); border:1px solid var(--sa-border); border-radius:var(--radius-lg); padding:20px; margin-bottom:20px; box-shadow:0 1px 2px 0 rgba(0,0,0,0.03);">
                <div style="display:flex; align-items:center; gap:10px; margin-bottom:8px;">
                    <i data-lucide="target" style="width:18px; height:18px; color:var(--sa-text-muted);"></i>
                    <h2 style="font-size:1.05rem; font-weight:700; color:var(--sa-text-primary);">Live Match Result & Settlement Controller</h2>
                </div>
                <p style="font-size:0.78rem; color:var(--sa-text-secondary); line-height:1.5;">
                    Adjudicate active fixtures to resolve all outstanding player slips in bulk. Selecting a winning outcome automatically settles all matching single bets as WON (crediting user wallets) and non-matching as LOST. In accumulator slips, the fixture leg is evaluated.
                </p>
            </div>

            <!-- Active Fixtures Grid -->
            <div class="section-title" style="margin-bottom:12px;">
                <i data-lucide="clock" style="width:16px; height:16px; color:var(--sa-text-muted);"></i>
                <span>Active Matches with Pending Wagers</span>
            </div>
            <div class="fixtures-grid" id="sportsFixturesContainer">
                <div style="color:var(--sa-text-muted); font-size:0.8rem; padding:30px; text-align:center; grid-column:1/-1;">
                    Scanning pending bets for active fixtures...
                </div>
            </div>

            <!-- Custom Manual Fixture Resolution Form -->
            <div style="background:var(--sa-bg-card); border:1px solid var(--sa-border); border-radius:var(--radius-lg); padding:20px; margin-top:28px; box-shadow:0 1px 2px 0 rgba(0,0,0,0.03);">
                <div style="display:flex; align-items:center; gap:10px; margin-bottom:12px;">
                    <i data-lucide="sliders" style="width:16px; height:16px; color:var(--sa-text-muted);"></i>
                    <h3 style="font-size:0.95rem; font-weight:700; color:var(--sa-text-primary);">Manual Outcome Resolution Override</h3>
                </div>
                <p style="font-size:0.75rem; color:var(--sa-text-muted); margin-bottom:16px;">
                    Enter an exact match name or event identifier and winning pick to adjudicate tickets manually.
                </p>
                <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(200px, 1fr)) auto; gap:10px; align-items:end;">
                    <div>
                        <label style="font-size:0.65rem; color:var(--sa-text-muted); font-weight:700; text-transform:uppercase; display:block; margin-bottom:4px;">Match Name / Event</label>
                        <input type="text" id="manualMatchNameInput" class="sa-input" placeholder="e.g. Arsenal vs Chelsea" style="width:100%;">
                    </div>
                    <div>
                        <label style="font-size:0.65rem; color:var(--sa-text-muted); font-weight:700; text-transform:uppercase; display:block; margin-bottom:4px;">Winning Outcome / Pick</label>
                        <input type="text" id="manualWinningPickInput" class="sa-input" placeholder="e.g. Arsenal or Over 2.5" style="width:100%;">
                    </div>
                    <button class="arm-btn" onclick="handleManualFixtureResolution()" style="height:38px; padding:0 20px;">
                        <i data-lucide="check-circle" style="width:14px; height:14px;"></i>
                        <span>Auto-Settle Fixture Bets</span>
                    </button>
                </div>
            </div>
        `;
    } else if (currentSportsSubTab === 'risk') {
        container.innerHTML = `
            <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(320px, 1fr)); gap:20px;">
                <!-- Card 1: Sportsbook Risk Limits -->
                <div style="background:var(--sa-bg-card); border:1px solid var(--sa-border); border-radius:var(--radius-lg); padding:20px; box-shadow:0 1px 2px 0 rgba(0,0,0,0.03);">
                    <div style="display:flex; align-items:center; gap:10px; margin-bottom:14px;">
                        <i data-lucide="shield" style="width:18px; height:18px; color:var(--sa-text-muted);"></i>
                        <h2 style="font-size:1.05rem; font-weight:700; color:var(--sa-text-primary);">Operational & Risk Limits</h2>
                    </div>
                    <p style="font-size:0.75rem; color:var(--sa-text-secondary); margin-bottom:18px;">
                        Authoritative betting constraints enforced across the platform for singles and multi-leg accumulators.
                    </p>

                    <div style="display:flex; flex-direction:column; gap:14px;">
                        <div>
                            <label style="font-size:0.68rem; color:var(--sa-text-muted); font-weight:700; text-transform:uppercase; display:block; margin-bottom:4px;">Sportsbook Status</label>
                            <select id="riskSportsStatus" class="sa-select" style="width:100%;">
                                <option value="true">ACTIVE • Normal Betting Enabled</option>
                                <option value="false">SUSPENDED • Maintenance Kill-Switch</option>
                            </select>
                        </div>
                        <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
                            <div>
                                <label style="font-size:0.68rem; color:var(--sa-text-muted); font-weight:700; text-transform:uppercase; display:block; margin-bottom:4px;">Minimum Stake (KES)</label>
                                <input type="number" id="riskMinStake" class="sa-input" value="10" min="1" max="1000" style="width:100%;">
                            </div>
                            <div>
                                <label style="font-size:0.68rem; color:var(--sa-text-muted); font-weight:700; text-transform:uppercase; display:block; margin-bottom:4px;">Maximum Stake (KES)</label>
                                <input type="number" id="riskMaxStake" class="sa-input" value="50000" min="100" max="500000" style="width:100%;">
                            </div>
                        </div>
                        <div>
                            <label style="font-size:0.68rem; color:var(--sa-text-muted); font-weight:700; text-transform:uppercase; display:block; margin-bottom:4px;">Maximum Potential Payout per Ticket (KES)</label>
                            <input type="number" id="riskMaxPayout" class="sa-input" value="1000000" min="1000" max="10000000" style="width:100%;">
                        </div>
                        <button class="arm-btn" onclick="handleSaveSportsConfig()" style="margin-top:8px; justify-content:center;">
                            <i data-lucide="save" style="width:14px; height:14px;"></i>
                            <span>Save Risk Limits</span>
                        </button>
                    </div>
                </div>

                <!-- Card 2: SharpAPI Telemetry & Cache Management -->
                <div style="background:var(--sa-bg-card); border:1px solid var(--sa-border); border-radius:var(--radius-lg); padding:20px; box-shadow:0 1px 2px 0 rgba(0,0,0,0.03);">
                    <div style="display:flex; align-items:center; gap:10px; margin-bottom:14px;">
                        <i data-lucide="zap" style="width:18px; height:18px; color:var(--sa-text-muted);"></i>
                        <h2 style="font-size:1.05rem; font-weight:700; color:var(--sa-text-primary);">SharpAPI Feed & Telemetry</h2>
                    </div>
                    <p style="font-size:0.75rem; color:var(--sa-text-secondary); margin-bottom:18px;">
                        Real-time SharpAPI quota consumption, in-memory caching efficiency, and odds synchronization.
                    </p>

                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:16px;">
                        <div style="background:var(--sa-bg-body); border:1px solid var(--sa-border); padding:10px; border-radius:8px;">
                            <span style="font-size:0.62rem; color:var(--sa-text-muted); font-weight:700; text-transform:uppercase;">Rate Limit Remaining</span>
                            <div style="font-size:1.15rem; font-weight:700; color:#16A34A; margin-top:2px;" id="sbQuotaRemaining">
                                ${sportsbookStatsData?.telemetry?.quota?.remaining ?? 'OK'}
                            </div>
                        </div>
                        <div style="background:var(--sa-bg-body); border:1px solid var(--sa-border); padding:10px; border-radius:8px;">
                            <span style="font-size:0.62rem; color:var(--sa-text-muted); font-weight:700; text-transform:uppercase;">Cached Markets</span>
                            <div style="font-size:1.15rem; font-weight:700; color:var(--sa-text-primary); margin-top:2px;" id="sbCachedMarkets">
                                ${sportsbookStatsData?.telemetry?.cachedOddsCount || 'Active'}
                            </div>
                        </div>
                        <div style="background:var(--sa-bg-body); border:1px solid var(--sa-border); padding:10px; border-radius:8px;">
                            <span style="font-size:0.62rem; color:var(--sa-text-muted); font-weight:700; text-transform:uppercase;">Live Matches In Play</span>
                            <div style="font-size:1.15rem; font-weight:700; color:var(--sa-text-primary); margin-top:2px;" id="sbCachedLive">
                                ${sportsbookStatsData?.telemetry?.cachedLiveCount || '0'}
                            </div>
                        </div>
                        <div style="background:var(--sa-bg-body); border:1px solid var(--sa-border); padding:10px; border-radius:8px;">
                            <span style="font-size:0.62rem; color:var(--sa-text-muted); font-weight:700; text-transform:uppercase;">Data Feed Tier</span>
                            <div style="font-size:1.15rem; font-weight:700; color:var(--sa-text-primary); margin-top:2px;">
                                SharpAPI v1
                            </div>
                        </div>
                    </div>

                    <div style="background:#F8FAFC; border:1px solid var(--sa-border); border-radius:8px; padding:12px; margin-bottom:16px;">
                        <div style="font-size:0.75rem; font-weight:600; color:var(--sa-text-primary); margin-bottom:4px;">Force Flush Odds Cache</div>
                        <div style="font-size:0.70rem; color:var(--sa-text-muted); line-height:1.4;">
                            Flushes all stored in-memory league odds and consensus prices. The immediate next player or visitor request will pull fresh live market odds from SharpAPI.
                        </div>
                    </div>

                    <button class="clear-btn" onclick="handleFlushSportsCache()" style="width:100%; justify-content:center;">
                        <i data-lucide="rotate-ccw" style="width:14px; height:14px;"></i>
                        <span>Flush & Force Refresh Odds Cache</span>
                    </button>
                </div>
            </div>
        `;

        // Load existing settings if available
        try {
            const { data: { session } } = await supabase.auth.getSession();
            const token = session?.access_token || localStorage.getItem('metrowins_auth_token');
            const res = await fetch('/api/admin/content?action=settings', { headers: { 'Authorization': `Bearer ${token}` } });
            if (res.ok) {
                const settings = await res.json();
                const cfg = settings.sportsbook_config;
                if (cfg) {
                    const parsed = typeof cfg === 'string' ? JSON.parse(cfg) : cfg;
                    if (document.getElementById('riskSportsStatus')) document.getElementById('riskSportsStatus').value = String(parsed.enabled !== false);
                    if (document.getElementById('riskMinStake')) document.getElementById('riskMinStake').value = parsed.minStake || 10;
                    if (document.getElementById('riskMaxStake')) document.getElementById('riskMaxStake').value = parsed.maxStake || 50000;
                    if (document.getElementById('riskMaxPayout')) document.getElementById('riskMaxPayout').value = parsed.maxPayout || 1000000;
                }
            }
        } catch (_) {}
    }

    if (window.lucide) lucide.createIcons();
}

async function fetchSportsbookData(silent = false) {
    if (activeTab !== 'sportsbook') return;
    try {
        const { data: { session } } = await supabase.auth.getSession();
        const token = session?.access_token || localStorage.getItem('metrowins_auth_token');
        const headers = { 'Authorization': `Bearer ${token}` };

        // 1. Fetch Stats
        const statsRes = await fetch('/api/admin/system?action=sports_stats', { headers });
        if (statsRes.ok) {
            sportsbookStatsData = await statsRes.json();
            updateSportsbookTopMetrics(sportsbookStatsData);
        }

        // 2. Fetch Bets if on 'bets' subtab
        if (currentSportsSubTab === 'bets') {
            const queryParams = new URLSearchParams({
                action: 'sports_bets',
                status: currentSportsStatusFilter,
                type: currentSportsTypeFilter,
                search: currentSportsSearch,
                sort: currentSportsSort,
                page: String(currentSportsPage),
                limit: '50'
            });
            const betsRes = await fetch(`/api/admin/system?${queryParams.toString()}`, { headers });
            if (betsRes.ok) {
                const betsJson = await betsRes.json();
                sportsbookBetsData = betsJson.bets || [];
                sportsbookTotalBets = betsJson.total || 0;
                renderSportsBetsTable(sportsbookBetsData);
            }
        }

        // 3. Fetch Fixtures if on 'fixtures' subtab
        if (currentSportsSubTab === 'fixtures') {
            const fixRes = await fetch('/api/admin/system?action=sports_fixtures', { headers });
            if (fixRes.ok) {
                const fixJson = await fixRes.json();
                sportsbookFixturesData = fixJson.fixtures || [];
                renderSportsFixturesList(sportsbookFixturesData);
            }
        }

        if (!silent) {
            showToast('Sportsbook ledger and telemetry synchronized.');
        }
    } catch (err) {
        console.warn('[Sportsbook Fetch Error]:', err.message);
        if (!silent) showToast(`Failed to sync sportsbook data: ${err.message}`, true);
    }
}

function updateSportsbookTopMetrics(stats) {
    if (!stats) return;

    const volEl = document.getElementById('sbMetricVolume');
    if (volEl) volEl.textContent = `KES ${Number(stats.totalVolume || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}`;

    const payEl = document.getElementById('sbMetricPayout');
    if (payEl) payEl.textContent = `KES ${Number(stats.totalPayout || 0).toLocaleString(undefined, {minimumFractionDigits: 2})}`;

    const ggrEl = document.getElementById('sbMetricGGR');
    if (ggrEl) {
        const ggr = Number(stats.ggr || 0);
        ggrEl.textContent = `KES ${ggr.toLocaleString(undefined, {minimumFractionDigits: 2})} (${stats.holdPercentage || 0}%)`;
        ggrEl.className = `metric-value ${ggr >= 0 ? 'stable' : 'error'}`;
    }

    const pendEl = document.getElementById('sbMetricPending');
    if (pendEl) {
        pendEl.textContent = `${stats.pendingCount || 0} Slips (KES ${Number(stats.pendingExposure || 0).toLocaleString()})`;
    }

    const winEl = document.getElementById('sbMetricWinRate');
    if (winEl) {
        winEl.textContent = `${stats.uniqueBettors || 0} Bettors (${stats.wonCount || 0}W / ${stats.lostCount || 0}L)`;
    }

    const quotaEl = document.getElementById('sbMetricQuota');
    if (quotaEl) {
        const rem = stats.telemetry?.quota?.remaining;
        quotaEl.textContent = rem !== null && rem !== undefined ? `${rem} req rem • SharpAPI` : 'SharpAPI v1 • Best Price';
    }

    const badgeEl = document.getElementById('sbPendingBadge');
    if (badgeEl) {
        badgeEl.textContent = `${stats.pendingCount || 0} PENDING`;
    }
}

function renderSportsBetsTable(bets) {
    const tbody = document.getElementById('sportsBetsTableBody');
    if (!tbody) return;

    if (!bets || bets.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="8" style="text-align:center; padding:50px 20px; color:var(--sa-text-muted);">
                    <i data-lucide="inbox" style="width:32px; height:32px; margin:0 auto 10px; display:block; opacity:0.4;"></i>
                    <div style="font-weight:700; font-size:0.9rem; color:var(--sa-text-primary);">No Sports Bets Found</div>
                    <div style="font-size:0.75rem; margin-top:4px;">No player tickets matched the active filters or search parameters.</div>
                </td>
            </tr>
        `;
        if (window.lucide) lucide.createIcons();
        updateSportsPaginationInfo();
        return;
    }

    tbody.innerHTML = bets.map(bet => {
        const username = bet.username || 'Anonymous User';
        const phone = bet.phone || 'No Phone';
        const initials = username.slice(0, 2).toUpperCase();
        const stake = parseFloat(bet.stake || 0);
        const odds = parseFloat(bet.total_odds || 0);
        const payout = parseFloat(bet.potential_payout || 0);
        const isPending = bet.status === 'pending';
        const selections = Array.isArray(bet.selections) ? bet.selections : [];
        const isMulti = bet.bet_type === 'accumulator' || selections.length > 1;

        let statusClass = 'sb-status-pending';
        let statusLabel = 'Pending';
        if (bet.status === 'won') { statusClass = 'sb-status-won'; statusLabel = 'Won'; }
        else if (bet.status === 'lost') { statusClass = 'sb-status-lost'; statusLabel = 'Lost'; }
        else if (bet.status === 'cashed_out') { statusClass = 'sb-status-cashed'; statusLabel = 'Cashed Out'; }
        else if (bet.status === 'cancelled') { statusClass = 'sb-status-cancelled'; statusLabel = 'Void / Refund'; }

        // Selections preview summary
        const legsPreview = selections.slice(0, 2).map(s => `
            <div class="sb-leg-item" title="${s.match || ''} - ${s.market || ''}">
                <span>${s.match || 'Match'}</span>
                <span class="sb-leg-pick">${s.pick || ''}</span>
                <span class="sb-leg-odds">@${parseFloat(s.odds || 1).toFixed(2)}</span>
            </div>
        `).join('');
        const moreLegsTag = selections.length > 2 ? `<span style="font-size:0.65rem; color:var(--sa-text-muted); font-weight:600;">+${selections.length - 2} more legs</span>` : '';

        return `
            <tr id="bet-row-${bet.id}">
                <td>
                    <div class="bettor-meta-cell">
                        <div class="bettor-avatar">${initials}</div>
                        <div class="bettor-info">
                            <span class="bettor-username">${username}</span>
                            <span class="bettor-sub">${phone}</span>
                            <span style="font-size:0.62rem; color:#16A34A; font-family:var(--font-mono); font-weight:600;">
                                Bal: KES ${Number(bet.user_balance || 0).toLocaleString()}
                            </span>
                        </div>
                    </div>
                </td>
                <td>
                    <div style="display:flex; flex-direction:column; gap:2px;">
                        <span style="font-family:var(--font-mono); font-size:0.75rem; font-weight:700; color:var(--sa-text-primary); cursor:pointer;" onclick="navigator.clipboard.writeText('${bet.id}'); showToast('Ticket ID copied to clipboard!')" title="Click to copy full UUID">
                            #${bet.id.slice(0, 8)}
                        </span>
                        <span style="font-size:0.65rem; color:var(--sa-text-muted);">${formatSportsTime(bet.created_at)}</span>
                        <span class="pill-badge" style="margin-left:0; margin-top:2px;">
                            ${isMulti ? `Acca (${selections.length} Legs)` : 'Single'}
                        </span>
                    </div>
                </td>
                <td>
                    <strong style="font-family:var(--font-mono); font-size:0.85rem; color:var(--sa-text-primary);">KES ${stake.toLocaleString()}</strong>
                </td>
                <td>
                    <span style="font-family:var(--font-mono); font-size:0.82rem; font-weight:600; color:var(--sa-text-primary);">${odds.toFixed(2)}x</span>
                </td>
                <td>
                    <strong style="font-family:var(--font-mono); font-size:0.85rem; color:#16A34A;">KES ${payout.toLocaleString()}</strong>
                </td>
                <td>
                    <div class="sb-legs-preview">
                        ${legsPreview}
                        ${moreLegsTag}
                    </div>
                </td>
                <td>
                    <span class="sb-status-badge ${statusClass}">
                        <span class="pulse-dot" style="width:5px; height:5px; ${!isPending ? 'animation:none;' : ''}"></span>
                        ${statusLabel}
                    </span>
                    ${bet.settled_at ? `<div style="font-size:0.60rem; color:var(--sa-text-muted); margin-top:2px;">${formatSportsTime(bet.settled_at)}</div>` : ''}
                </td>
                <td style="text-align:right;">
                    <div class="sb-actions-group" style="justify-content:flex-end;">
                        ${isPending ? `
                            <button class="sb-btn-action sb-btn-won" onclick="handleSettleSportsBet('${bet.id}', 'won')" title="Force Settle as WON and Credit Wallet">
                                <i data-lucide="check" style="width:12px; height:12px;"></i>
                                <span>WON</span>
                            </button>
                            <button class="sb-btn-action sb-btn-lost" onclick="handleSettleSportsBet('${bet.id}', 'lost')" title="Force Settle as LOST">
                                <i data-lucide="x" style="width:12px; height:12px;"></i>
                                <span>LOST</span>
                            </button>
                            <button class="sb-btn-action sb-btn-refund" onclick="handleSettleSportsBet('${bet.id}', 'cancelled')" title="Void Ticket & Full Stake Refund">
                                <i data-lucide="rotate-ccw" style="width:12px; height:12px;"></i>
                                <span>VOID</span>
                            </button>
                            <button class="sb-btn-action sb-btn-cashout" onclick="handleCashoutSportsBet('${bet.id}')" title="Emergency / Forced Cashout">
                                <i data-lucide="dollar-sign" style="width:12px; height:12px;"></i>
                                <span>CASH OUT</span>
                            </button>
                        ` : `
                            <button class="sb-btn-action sb-btn-refund" onclick="handleSettleSportsBet('${bet.id}', 'override')" title="Super Admin Override Settlement">
                                <i data-lucide="edit-3" style="width:12px; height:12px;"></i>
                                <span>OVERRIDE</span>
                            </button>
                        `}
                        <button class="sb-btn-action sb-btn-inspect" onclick="inspectSportsBet('${bet.id}')" title="View Full Bet Slip Dossier">
                            <i data-lucide="eye" style="width:12px; height:12px;"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }).join('');

    if (window.lucide) lucide.createIcons();
    updateSportsPaginationInfo();
}

function updateSportsPaginationInfo() {
    const infoEl = document.getElementById('sbPaginationInfo');
    const prevBtn = document.getElementById('sbPrevPageBtn');
    const nextBtn = document.getElementById('sbNextPageBtn');

    const start = currentSportsPage * 50 + 1;
    const end = Math.min((currentSportsPage + 1) * 50, sportsbookTotalBets);

    if (infoEl) {
        infoEl.textContent = sportsbookTotalBets > 0
            ? `Showing ${start}–${end} of ${sportsbookTotalBets} sports bets`
            : `Showing 0 bets`;
    }

    if (prevBtn) prevBtn.disabled = currentSportsPage === 0;
    if (nextBtn) nextBtn.disabled = end >= sportsbookTotalBets;
}

function changeSportsPage(delta) {
    currentSportsPage = Math.max(0, currentSportsPage + delta);
    fetchSportsbookData(true);
}

function filterSportsByStatus(status, btn) {
    currentSportsStatusFilter = status;
    currentSportsPage = 0;
    document.querySelectorAll('.sa-filter-chips button').forEach(b => {
        if (['All Bets', 'Pending', 'Won', 'Lost', 'Cashed Out', 'Void / Refunded'].includes(b.textContent.trim())) {
            b.classList.toggle('active', b === btn);
        }
    });
    fetchSportsbookData(true);
}

function filterSportsByType(type, btn) {
    currentSportsTypeFilter = type;
    currentSportsPage = 0;
    document.querySelectorAll('.sa-filter-chips button').forEach(b => {
        if (['All Types', 'Singles', 'Accumulators'].includes(b.textContent.trim())) {
            b.classList.toggle('active', b === btn);
        }
    });
    fetchSportsbookData(true);
}

function handleSportsSearch(val) {
    currentSportsSearch = val.trim();
    currentSportsPage = 0;
    clearTimeout(sportsSearchDebounceTimer);
    sportsSearchDebounceTimer = setTimeout(() => {
        fetchSportsbookData(true);
    }, 300);
}

function renderSportsFixturesList(fixtures) {
    const container = document.getElementById('sportsFixturesContainer');
    if (!container) return;

    if (!fixtures || fixtures.length === 0) {
        container.innerHTML = `
            <div style="background:var(--sa-bg-card); border:1px solid var(--sa-border); border-radius:var(--radius-lg); padding:40px 20px; text-align:center; color:var(--sa-text-muted); grid-column:1/-1; box-shadow:0 1px 2px 0 rgba(0,0,0,0.03);">
                <i data-lucide="check-circle-2" style="width:32px; height:32px; margin:0 auto 10px; display:block; color:#16A34A; opacity:0.9;"></i>
                <div style="font-weight:700; font-size:0.95rem; color:var(--sa-text-primary);">All Pending Match Wagers Settled!</div>
                <div style="font-size:0.75rem; margin-top:4px;">No outstanding active player slips require fixture settlement at this time.</div>
            </div>
        `;
        if (window.lucide) lucide.createIcons();
        return;
    }

    container.innerHTML = fixtures.map(f => {
        const matchName = f.match_name || 'Match Fixture';
        const pendingCount = f.pending_bets_count || 0;
        const stakeKes = parseFloat(f.total_stake_kes || 0);
        const exposureKes = parseFloat(f.total_exposure_kes || 0);
        const picks = Array.isArray(f.picks) ? f.picks : [];

        // Parse teams
        const teams = matchName.split(/ vs | v /i);
        const homeTeam = teams[0] ? teams[0].trim() : 'Home';
        const awayTeam = teams[1] ? teams[1].trim() : 'Away';

        return `
            <div class="fixture-card">
                <div class="fixture-header">
                    <div>
                        <div class="fixture-title">⚽ ${matchName}</div>
                        <div class="fixture-league">${f.market || 'Match Winner (1X2)'} • ${f.sport || 'SharpAPI'}</div>
                    </div>
                    <span class="pill-badge">${pendingCount} ${pendingCount === 1 ? 'Slip' : 'Slips'}</span>
                </div>

                <div class="fixture-metrics">
                    <div class="fixture-metric-item">
                        <span class="fixture-metric-label">Total Stakes</span>
                        <span class="fixture-metric-val">KES ${stakeKes.toLocaleString()}</span>
                    </div>
                    <div class="fixture-metric-item">
                        <span class="fixture-metric-label">Max Exposure</span>
                        <span class="fixture-metric-val">KES ${exposureKes.toLocaleString()}</span>
                    </div>
                </div>

                <div>
                    <div style="font-size:0.65rem; color:var(--sa-text-muted); font-weight:700; text-transform:uppercase; margin-bottom:6px;">
                        Player Picks on this Match:
                    </div>
                    <div style="display:flex; flex-wrap:wrap; gap:5px;">
                        ${picks.map(p => `<span style="background:#F1F5F9; border:1px solid #E2E8F0; color:var(--sa-text-primary); font-size:0.68rem; font-weight:600; padding:2px 7px; border-radius:4px;">${p}</span>`).join('')}
                    </div>
                </div>

                <div style="margin-top:auto; padding-top:10px; border-top:1px solid var(--sa-border);">
                    <div style="font-size:0.65rem; color:var(--sa-text-muted); font-weight:700; text-transform:uppercase; margin-bottom:6px;">
                        One-Click Settle Winning Outcome:
                    </div>
                    <div class="fixture-actions-row">
                        <button class="fixture-outcome-btn" onclick="handleResolveSportsFixture('${matchName}', '${homeTeam}')" title="Settle ${homeTeam} as Winner">
                            ${homeTeam} (1)
                        </button>
                        <button class="fixture-outcome-btn" onclick="handleResolveSportsFixture('${matchName}', 'Draw')" title="Settle Draw as Winner">
                            Draw (X)
                        </button>
                        <button class="fixture-outcome-btn" onclick="handleResolveSportsFixture('${matchName}', '${awayTeam}')" title="Settle ${awayTeam} as Winner">
                            ${awayTeam} (2)
                        </button>
                    </div>
                </div>
            </div>
        `;
    }).join('');

    if (window.lucide) lucide.createIcons();
}

async function handleManualFixtureResolution() {
    const matchInput = document.getElementById('manualMatchNameInput');
    const pickInput = document.getElementById('manualWinningPickInput');

    const matchName = matchInput?.value.trim();
    const winningPick = pickInput?.value.trim();

    if (!matchName || !winningPick) {
        showToast('Please enter both match name and winning outcome.', true);
        return;
    }

    await handleResolveSportsFixture(matchName, winningPick);
    if (matchInput) matchInput.value = '';
    if (pickInput) pickInput.value = '';
}

// ── SPORTS ACTIONS (SETTLE, CASHOUT, RESOLVE, LIMITS) ─────────────────────────

async function handleSettleSportsBet(betId, status) {
    let targetStatus = status;
    let customPayout = null;

    if (status === 'override') {
        const choice = prompt(`OVERRIDE SETTLEMENT for Bet #${betId.slice(0, 8)}\nEnter target status:\n1 = WON\n2 = LOST\n3 = VOID / REFUND`, '1');
        if (!choice) return;
        if (choice === '1' || choice.toLowerCase() === 'won') targetStatus = 'won';
        else if (choice === '2' || choice.toLowerCase() === 'lost') targetStatus = 'lost';
        else if (choice === '3' || choice.toLowerCase() === 'void' || choice.toLowerCase() === 'cancelled') targetStatus = 'cancelled';
        else {
            showToast('Invalid override status chosen.', true);
            return;
        }

        if (targetStatus === 'won') {
            const payoutInput = prompt('Enter custom payout amount in KES (leave blank for default potential payout):', '');
            if (payoutInput && !isNaN(parseFloat(payoutInput))) {
                customPayout = parseFloat(payoutInput);
            }
        }
    } else {
        const actionLabel = targetStatus === 'won' ? 'WON (Credit Payout to Bettor)' : (targetStatus === 'lost' ? 'LOST (Close Slip)' : 'VOID (100% Refund Stake)');
        const confirmed = confirm(`Are you sure you want to mark Bet #${betId.slice(0, 8)} as ${actionLabel}?`);
        if (!confirmed) return;
    }

    try {
        const { data: { session } } = await supabase.auth.getSession();
        const token = session?.access_token || localStorage.getItem('metrowins_auth_token');

        const res = await fetch('/api/admin/actions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                action: 'settle_sports_bet',
                betId,
                status: targetStatus,
                customPayout
            })
        });

        const data = await res.json();
        if (!res.ok || data.error) {
            throw new Error(data.error || 'Failed to settle sports bet.');
        }

        showToast(data.message || `Bet #${betId.slice(0, 8)} settled as ${targetStatus.toUpperCase()}!`);
        closeSportsModal();
        await fetchSportsbookData(true);
    } catch (err) {
        showToast(err.message || 'Error settling bet.', true);
    }
}

async function handleCashoutSportsBet(betId) {
    const bet = sportsbookBetsData.find(b => b.id === betId);
    const defaultAmt = bet ? (parseFloat(bet.stake) * 0.85).toFixed(0) : '100';

    const amtStr = prompt(`FORCE CASHOUT for Bet #${betId.slice(0, 8)}\nEnter cashout amount to award player (KES):`, defaultAmt);
    if (!amtStr) return;

    const numAmount = parseFloat(amtStr);
    if (isNaN(numAmount) || numAmount <= 0) {
        showToast('Please enter a valid cashout amount.', true);
        return;
    }

    try {
        const { data: { session } } = await supabase.auth.getSession();
        const token = session?.access_token || localStorage.getItem('metrowins_auth_token');

        const res = await fetch('/api/admin/actions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                action: 'cashout_sports_bet',
                betId,
                cashoutAmount: numAmount,
                reason: 'Super Admin manual cashout'
            })
        });

        const data = await res.json();
        if (!res.ok || data.error) {
            throw new Error(data.error || 'Failed to cash out bet.');
        }

        showToast(data.message || `Bet cashed out for KES ${numAmount.toLocaleString()}!`);
        closeSportsModal();
        await fetchSportsbookData(true);
    } catch (err) {
        showToast(err.message || 'Error executing cashout.', true);
    }
}

async function handleResolveSportsFixture(matchName, winningPick) {
    const confirmed = confirm(`Bulk Settle Fixture:\n\nMatch: ${matchName}\nWinning Outcome: "${winningPick}"\n\nAll pending tickets containing this pick will be awarded WON (with wallet payouts). Non-matching tickets will be closed as LOST. Proceed?`);
    if (!confirmed) return;

    try {
        const { data: { session } } = await supabase.auth.getSession();
        const token = session?.access_token || localStorage.getItem('metrowins_auth_token');

        const res = await fetch('/api/admin/actions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                action: 'resolve_sports_fixture',
                matchName,
                winningPick
            })
        });

        const data = await res.json();
        if (!res.ok || data.error) {
            throw new Error(data.error || 'Failed to resolve fixture.');
        }

        showToast(data.message || `Fixture resolved! ${data.wonCount} won, ${data.lostCount} lost.`);
        await fetchSportsbookData(true);
    } catch (err) {
        showToast(err.message || 'Error resolving fixture.', true);
    }
}

async function handleFlushSportsCache() {
    try {
        const { data: { session } } = await supabase.auth.getSession();
        const token = session?.access_token || localStorage.getItem('metrowins_auth_token');

        const res = await fetch('/api/admin/actions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                action: 'refresh_sports_cache'
            })
        });

        const data = await res.json();
        if (!res.ok || data.error) {
            throw new Error(data.error || 'Failed to flush cache.');
        }

        showToast(data.message || 'SharpAPI odds cache flushed!');
        await fetchSportsbookData(true);
    } catch (err) {
        showToast(err.message || 'Error flushing cache.', true);
    }
}

async function handleSaveSportsConfig() {
    try {
        const enabled = document.getElementById('riskSportsStatus')?.value === 'true';
        const minStake = parseFloat(document.getElementById('riskMinStake')?.value || 10);
        const maxStake = parseFloat(document.getElementById('riskMaxStake')?.value || 50000);
        const maxPayout = parseFloat(document.getElementById('riskMaxPayout')?.value || 1000000);

        const { data: { session } } = await supabase.auth.getSession();
        const token = session?.access_token || localStorage.getItem('metrowins_auth_token');

        const res = await fetch('/api/admin/actions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                action: 'update_sports_config',
                config: { enabled, minStake, maxStake, maxPayout }
            })
        });

        const data = await res.json();
        if (!res.ok || data.error) {
            throw new Error(data.error || 'Failed to save sportsbook config.');
        }

        showToast('Sportsbook risk limits and operational status updated.');
    } catch (err) {
        showToast(err.message || 'Error saving risk configuration.', true);
    }
}

// ── DETAILED BET SLIP INSPECTION MODAL ───────────────────────────────────────

function inspectSportsBet(betId) {
    const bet = sportsbookBetsData.find(b => b.id === betId);
    if (!bet) return;
    activeInspectedBet = bet;

    const modalContainer = document.getElementById('sportsModalContainer');
    if (!modalContainer) return;

    const selections = Array.isArray(bet.selections) ? bet.selections : [];
    const isPending = bet.status === 'pending';

    modalContainer.innerHTML = `
        <div class="sb-modal-backdrop" onclick="if(event.target===this) closeSportsModal()">
            <div class="sb-modal-card">
                <div class="sb-modal-header">
                    <div style="display:flex; align-items:center; gap:8px;">
                        <i data-lucide="receipt" style="width:18px; height:18px; color:var(--sa-text-muted);"></i>
                        <span style="font-weight:700; font-size:0.95rem; color:var(--sa-text-primary);">Bet Slip Dossier #${bet.id.slice(0, 8)}</span>
                    </div>
                    <button class="sa-topbar-btn" onclick="closeSportsModal()" style="padding:4px 8px;">
                        <i data-lucide="x" style="width:14px; height:14px;"></i>
                    </button>
                </div>

                <div class="sb-modal-body">
                    <!-- Bettor Dossier -->
                    <div style="background:#F8FAFC; border:1px solid var(--sa-border); border-radius:var(--radius-md); padding:14px;">
                        <div style="font-size:0.65rem; color:var(--sa-text-muted); font-weight:700; text-transform:uppercase; margin-bottom:8px;">
                            Bettor Identity Card
                        </div>
                        <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
                            <div>
                                <span style="font-size:0.65rem; color:var(--sa-text-muted);">Username</span>
                                <div style="font-size:0.85rem; font-weight:700; color:var(--sa-text-primary);">${bet.username || 'Anonymous'}</div>
                            </div>
                            <div>
                                <span style="font-size:0.65rem; color:var(--sa-text-muted);">Phone Number</span>
                                <div style="font-size:0.85rem; font-weight:700; color:var(--sa-text-primary); font-family:var(--font-mono);">${bet.phone || 'No Phone'}</div>
                            </div>
                            <div>
                                <span style="font-size:0.65rem; color:var(--sa-text-muted);">Current Wallet Balance</span>
                                <div style="font-size:0.85rem; font-weight:700; color:#16A34A; font-family:var(--font-mono);">KES ${Number(bet.user_balance || 0).toLocaleString()}</div>
                            </div>
                            <div>
                                <span style="font-size:0.65rem; color:var(--sa-text-muted);">Account Security Status</span>
                                <div style="font-size:0.85rem; font-weight:700; color:${bet.is_frozen ? '#DC2626' : '#16A34A'};">
                                    ${bet.is_frozen ? 'FROZEN' : 'ACTIVE & VERIFIED'}
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Ticket Financials -->
                    <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:10px;">
                        <div style="background:#F8FAFC; border:1px solid var(--sa-border); padding:10px; border-radius:8px;">
                            <span style="font-size:0.62rem; color:var(--sa-text-muted); font-weight:700; text-transform:uppercase;">Stake</span>
                            <div style="font-size:1.05rem; font-weight:700; color:var(--sa-text-primary); font-family:var(--font-mono);">KES ${parseFloat(bet.stake).toLocaleString()}</div>
                        </div>
                        <div style="background:#F8FAFC; border:1px solid var(--sa-border); padding:10px; border-radius:8px;">
                            <span style="font-size:0.62rem; color:var(--sa-text-muted); font-weight:700; text-transform:uppercase;">Total Odds</span>
                            <div style="font-size:1.05rem; font-weight:700; color:var(--sa-text-primary); font-family:var(--font-mono);">${parseFloat(bet.total_odds).toFixed(2)}x</div>
                        </div>
                        <div style="background:#F8FAFC; border:1px solid var(--sa-border); padding:10px; border-radius:8px;">
                            <span style="font-size:0.62rem; color:var(--sa-text-muted); font-weight:700; text-transform:uppercase;">Potential Return</span>
                            <div style="font-size:1.05rem; font-weight:700; color:#16A34A; font-family:var(--font-mono);">KES ${parseFloat(bet.potential_payout).toLocaleString()}</div>
                        </div>
                    </div>

                    <!-- Selections Table -->
                    <div>
                        <div style="font-size:0.75rem; font-weight:700; color:var(--sa-text-primary); margin-bottom:8px;">
                            Selections Breakdown (${selections.length} ${selections.length === 1 ? 'Leg' : 'Legs'})
                        </div>
                        <div style="display:flex; flex-direction:column; gap:8px;">
                            ${selections.map((s, idx) => `
                                <div style="background:#F8FAFC; border:1px solid var(--sa-border); border-radius:8px; padding:10px 12px; display:flex; align-items:center; justify-content:space-between; gap:10px;">
                                    <div>
                                        <div style="font-size:0.82rem; font-weight:600; color:var(--sa-text-primary);">
                                            ${idx + 1}. ${s.match || 'Match'}
                                        </div>
                                        <div style="font-size:0.68rem; color:var(--sa-text-muted); margin-top:2px;">
                                            ${s.market || '1X2'} • Event: ${s.eventId || '—'}
                                        </div>
                                    </div>
                                    <div style="text-align:right;">
                                        <div style="font-size:0.82rem; font-weight:700; color:var(--sa-text-primary);">
                                            ${s.pick || '—'}
                                        </div>
                                        <div style="font-size:0.72rem; color:#2563EB; font-family:var(--font-mono); font-weight:600;">
                                            @${parseFloat(s.odds || 1).toFixed(2)}
                                        </div>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>

                    <!-- Meta Details -->
                    <div style="font-size:0.68rem; color:var(--sa-text-muted); display:flex; flex-direction:column; gap:3px;">
                        <div>Placed At: <strong>${bet.created_at ? new Date(bet.created_at).toUTCString() : '—'}</strong></div>
                        <div>Settled At: <strong>${bet.settled_at ? new Date(bet.settled_at).toUTCString() : 'Pending Active Slip'}</strong></div>
                        <div>Ticket UUID: <code style="color:#94A3B8;">${bet.id}</code></div>
                    </div>
                </div>

                <div class="sb-modal-footer">
                    ${isPending ? `
                        <button class="sb-btn-action sb-btn-won" onclick="handleSettleSportsBet('${bet.id}', 'won')" style="padding:6px 14px; font-size:0.75rem;">
                            <i data-lucide="check" style="width:13px; height:13px;"></i>
                            <span>Settle WON</span>
                        </button>
                        <button class="sb-btn-action sb-btn-lost" onclick="handleSettleSportsBet('${bet.id}', 'lost')" style="padding:6px 14px; font-size:0.75rem;">
                            <i data-lucide="x" style="width:13px; height:13px;"></i>
                            <span>Settle LOST</span>
                        </button>
                        <button class="sb-btn-action sb-btn-refund" onclick="handleSettleSportsBet('${bet.id}', 'cancelled')" style="padding:6px 14px; font-size:0.75rem;">
                            <i data-lucide="rotate-ccw" style="width:13px; height:13px;"></i>
                            <span>Void & Refund</span>
                        </button>
                        <button class="sb-btn-action sb-btn-cashout" onclick="handleCashoutSportsBet('${bet.id}')" style="padding:6px 14px; font-size:0.75rem;">
                            <i data-lucide="dollar-sign" style="width:13px; height:13px;"></i>
                            <span>Force Cashout</span>
                        </button>
                    ` : `
                        <button class="sb-btn-action sb-btn-refund" onclick="handleSettleSportsBet('${bet.id}', 'override')" style="padding:6px 14px; font-size:0.75rem;">
                            <i data-lucide="edit-3" style="width:13px; height:13px;"></i>
                            <span>Override Settlement</span>
                        </button>
                    `}
                    <button class="sa-topbar-btn" onclick="closeSportsModal()" style="padding:6px 14px;">
                        <span>Close</span>
                    </button>
                </div>
            </div>
        </div>
    `;

    if (window.lucide) lucide.createIcons();
}

function closeSportsModal() {
    const modalContainer = document.getElementById('sportsModalContainer');
    if (modalContainer) modalContainer.innerHTML = '';
    activeInspectedBet = null;
}

// Window bindings for inline HTML handlers
window.renderSportsbookManagement = renderSportsbookManagement;
window.fetchSportsbookData = fetchSportsbookData;
window.toggleSportsAutoRefresh = toggleSportsAutoRefresh;
window.switchSportsSubTab = switchSportsSubTab;
window.filterSportsByStatus = filterSportsByStatus;
window.filterSportsByType = filterSportsByType;
window.handleSportsSearch = handleSportsSearch;
window.changeSportsPage = changeSportsPage;
window.handleSettleSportsBet = handleSettleSportsBet;
window.handleCashoutSportsBet = handleCashoutSportsBet;
window.handleResolveSportsFixture = handleResolveSportsFixture;
window.handleManualFixtureResolution = handleManualFixtureResolution;
window.handleFlushSportsCache = handleFlushSportsCache;
window.handleSaveSportsConfig = handleSaveSportsConfig;
window.inspectSportsBet = inspectSportsBet;
window.closeSportsModal = closeSportsModal;

// ── TAB RENDERING ─────────────────────────────────────────────────────────────

function renderOverview(stats, logs) {
    const contentEl = document.getElementById('adminContent');
    contentEl.innerHTML = `
        <div class="pane-header">
            <div class="pane-header-titles">
                <h1>Platform Overview</h1>
                <p>Real-time platform health, wagers, and operations metrics</p>
            </div>
            <div style="display:flex; gap:10px; align-items:center;">
                <button class="sa-topbar-btn" onclick="switchTab('overview')">
                    <i data-lucide="refresh-cw" style="width:14px; height:14px;"></i>
                    <span>Refresh</span>
                </button>
            </div>
        </div>

        <div class="metrics-grid">
            <div class="metric-card">
                <div class="metric-label">
                    <i data-lucide="users" style="width:14px; height:14px; color:var(--sa-text-muted);"></i>
                    <span>Active Sessions</span>
                </div>
                <div class="metric-value" id="activeSessions">${stats.users || '0'}</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">
                    <i data-lucide="activity" style="width:14px; height:14px; color:var(--sa-text-muted);"></i>
                    <span>System Health</span>
                </div>
                <div class="metric-value stable">
                    <span style="display:inline-flex; align-items:center; gap:8px;">
                        <span class="pulse-dot"></span> STABLE
                    </span>
                </div>
            </div>
            <div class="metric-card">
                <div class="metric-label">
                    <i data-lucide="coins" style="width:14px; height:14px; color:var(--sa-text-muted);"></i>
                    <span>Total Platform GGR</span>
                </div>
                <div class="metric-value" id="totalGGR">KES ${stats.ggr?.toLocaleString(undefined, {minimumFractionDigits:2}) || '0.00'}</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">
                    <i data-lucide="shield-check" style="width:14px; height:14px; color:var(--sa-text-muted);"></i>
                    <span>Aviator Engine</span>
                </div>
                <div class="metric-value" style="font-size:1.15rem; display:flex; align-items:center; gap:6px;">
                    ONLINE • 97% RTP
                </div>
            </div>
        </div>

        <!-- Quick Launch Command Deck -->
        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(200px, 1fr)); gap:12px; margin-bottom:28px;">
            <button onclick="window.location.hash='#sportsbook'" style="background:#FFFFFF; border:1px solid var(--sa-border); border-radius:8px; padding:16px; display:flex; align-items:center; gap:12px; cursor:pointer; text-align:left; transition:all 0.15s ease; box-shadow:0 1px 2px 0 rgba(0,0,0,0.03);">
                <div style="width:36px; height:36px; border-radius:6px; background:#F1F5F9; display:flex; align-items:center; justify-content:center; color:#0F172A; flex-shrink:0;">
                    <i data-lucide="trophy" style="width:18px; height:18px;"></i>
                </div>
                <div>
                    <div style="font-size:0.8125rem; font-weight:600; color:var(--sa-text-primary);">Sportsbook Controls</div>
                    <div style="font-size:0.6875rem; color:var(--sa-text-muted);">Bets ledger & match settlement</div>
                </div>
            </button>

            <button onclick="window.location.hash='#predictor'" style="background:#FFFFFF; border:1px solid var(--sa-border); border-radius:8px; padding:16px; display:flex; align-items:center; gap:12px; cursor:pointer; text-align:left; transition:all 0.15s ease; box-shadow:0 1px 2px 0 rgba(0,0,0,0.03);">
                <div style="width:36px; height:36px; border-radius:6px; background:#F1F5F9; display:flex; align-items:center; justify-content:center; color:#0F172A; flex-shrink:0;">
                    <i data-lucide="zap" style="width:18px; height:18px;"></i>
                </div>
                <div>
                    <div style="font-size:0.8125rem; font-weight:600; color:var(--sa-text-primary);">Aviator Predictor</div>
                    <div style="font-size:0.6875rem; color:var(--sa-text-muted);">Flight forecast & override</div>
                </div>
            </button>

            <button onclick="window.location.hash='#users'" style="background:#FFFFFF; border:1px solid var(--sa-border); border-radius:8px; padding:16px; display:flex; align-items:center; gap:12px; cursor:pointer; text-align:left; transition:all 0.15s ease; box-shadow:0 1px 2px 0 rgba(0,0,0,0.03);">
                <div style="width:36px; height:36px; border-radius:6px; background:#F1F5F9; display:flex; align-items:center; justify-content:center; color:#0F172A; flex-shrink:0;">
                    <i data-lucide="users" style="width:18px; height:18px;"></i>
                </div>
                <div>
                    <div style="font-size:0.8125rem; font-weight:600; color:var(--sa-text-primary);">User Accounts</div>
                    <div style="font-size:0.6875rem; color:var(--sa-text-muted);">Balances & account controls</div>
                </div>
            </button>

            <button onclick="window.location.hash='#ledger'" style="background:#FFFFFF; border:1px solid var(--sa-border); border-radius:8px; padding:16px; display:flex; align-items:center; gap:12px; cursor:pointer; text-align:left; transition:all 0.15s ease; box-shadow:0 1px 2px 0 rgba(0,0,0,0.03);">
                <div style="width:36px; height:36px; border-radius:6px; background:#F1F5F9; display:flex; align-items:center; justify-content:center; color:#0F172A; flex-shrink:0;">
                    <i data-lucide="wallet" style="width:18px; height:18px;"></i>
                </div>
                <div>
                    <div style="font-size:0.8125rem; font-weight:600; color:var(--sa-text-primary);">Financial Ledger</div>
                    <div style="font-size:0.6875rem; color:var(--sa-text-muted);">Deposits & payouts log</div>
                </div>
            </button>

            <button onclick="window.location.hash='#settings'" style="background:#FFFFFF; border:1px solid var(--sa-border); border-radius:8px; padding:16px; display:flex; align-items:center; gap:12px; cursor:pointer; text-align:left; transition:all 0.15s ease; box-shadow:0 1px 2px 0 rgba(0,0,0,0.03);">
                <div style="width:36px; height:36px; border-radius:6px; background:#F1F5F9; display:flex; align-items:center; justify-content:center; color:#0F172A; flex-shrink:0;">
                    <i data-lucide="sliders" style="width:18px; height:18px;"></i>
                </div>
                <div>
                    <div style="font-size:0.8125rem; font-weight:600; color:var(--sa-text-primary);">Global Settings</div>
                    <div style="font-size:0.6875rem; color:var(--sa-text-muted);">Platform configuration</div>
                </div>
            </button>
        </div>

        <div class="section-title">
            <i data-lucide="activity" style="width: 16px; height: 16px; color: var(--sa-text-muted);"></i>
            <span>Recent Audit Trail</span>
        </div>
        <div class="audit-table-wrap" style="margin-bottom:0; border-bottom:none; border-bottom-left-radius:0; border-bottom-right-radius:0;">
            <table class="audit-table">
                <thead>
                    <tr>
                        <th>Timestamp</th>
                        <th>User</th>
                        <th>Action</th>
                        <th>Target Reference</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody id="auditTrail">
                </tbody>
            </table>
        </div>
        <div id="overviewAuditPagination"></div>
    `;

    currentOverviewAuditList = logs || [];
    overviewAuditPage = 1;
    renderOverviewAuditPage();
    if (window.lucide) lucide.createIcons();
}

window.changeOverviewAuditPage = (page) => {
    overviewAuditPage = page;
    renderOverviewAuditPage();
};

function renderOverviewAuditPage() {
    const startIdx = (overviewAuditPage - 1) * OVERVIEW_PAGE_SIZE;
    const paginatedLogs = currentOverviewAuditList.slice(startIdx, startIdx + OVERVIEW_PAGE_SIZE);
    
    const tbody = document.getElementById('auditTrail');
    if (tbody) {
        tbody.innerHTML = renderAuditRows(paginatedLogs);
    }
    
    const paginationContainer = document.getElementById('overviewAuditPagination');
    if (paginationContainer) {
        paginationContainer.innerHTML = buildPaginationMarkup(currentOverviewAuditList.length, overviewAuditPage, OVERVIEW_PAGE_SIZE, 'changeOverviewAuditPage');
    }
}

function renderAuditRows(logs) {
    if (!logs || logs.length === 0) {
        return `
            <tr>
                <td colspan="5" style="text-align: center; padding: 48px; color: var(--text-muted);">
                    <div style="font-size: 1.5rem; margin-bottom: 6px;">📋</div>
                    <div style="font-weight: 600; color: var(--text-primary);">Audit Trail Empty</div>
                    <div style="font-size: 0.72rem;">No system actions recorded.</div>
                </td>
            </tr>
        `;
    }
    return logs.map(log => {
        const timeStr = new Date(log.created_at).toLocaleString();
        const subject = log.profiles ? (log.profiles.username ? `@${log.profiles.username}` : log.profiles.phone) : 'SYSTEM';
        const detailsText = log.details ? (typeof log.details === 'object' ? JSON.stringify(log.details) : log.details) : '—';
        return `
            <tr>
                <td style="color: var(--text-muted); font-size:0.75rem;">${timeStr}</td>
                <td style="font-weight: 600; color: var(--sa-text-primary);">${subject}</td>
                <td class="action-tag">${log.action}</td>
                <td style="color: var(--text-secondary); font-family: monospace;">${log.target_id || '—'}</td>
                <td style="font-size: 0.73rem; color: var(--text-secondary); font-family: monospace; max-width: 250px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${detailsText.replace(/"/g, '&quot;')}">${detailsText}</td>
            </tr>
        `;
    }).join('');
}

function renderUserSovereignty() {
    const contentEl = document.getElementById('adminContent');
    contentEl.innerHTML = `
        <div class="pane-header">
            <div class="pane-header-titles">
                <h1>User Accounts & Management</h1>
                <p>Search players, credit/debit balances, freeze accounts, and adjust roles of registered users</p>
            </div>
            <div style="display:flex; gap:10px; align-items:center;">
                <button class="sa-topbar-btn" onclick="switchTab('users')">
                    <i data-lucide="refresh-cw" style="width:14px; height:14px;"></i>
                    <span>Refresh</span>
                </button>
            </div>
        </div>

        <div class="sa-search-bar">
            <div class="sa-search-input-wrap">
                <i data-lucide="search" style="width: 18px; height: 18px;"></i>
                <input type="text" id="userSearch" placeholder="Search user by email, phone, or username...">
            </div>
            <div class="sa-filter-chips" id="userFilterChips">
                <button class="sa-chip active" onclick="window.filterUsersByStatus('all', this)">All Players</button>
                <button class="sa-chip" onclick="window.filterUsersByStatus('active', this)">Active</button>
                <button class="sa-chip" onclick="window.filterUsersByStatus('frozen', this)">Frozen</button>
                <button class="sa-chip" onclick="window.filterUsersByStatus('admins', this)">Admins</button>
            </div>
        </div>

        <div class="audit-table-wrap" style="margin-bottom:0; border-bottom:none; border-bottom-left-radius:0; border-bottom-right-radius:0;">
            <table class="audit-table">
                <thead>
                    <tr>
                        <th>Username / Phone</th>
                        <th>Email / Reg Date</th>
                        <th>Balance (KES)</th>
                        <th>Status</th>
                        <th>Wallet Modification</th>
                        <th>Account Operations</th>
                    </tr>
                </thead>
                <tbody id="userRows">
                </tbody>
            </table>
        </div>
        <div id="userPagination"></div>
    `;

    window.filterUsersByStatus = (statusFilter, btn) => {
        if (btn) {
            document.querySelectorAll('#userFilterChips .sa-chip').forEach(c => c.classList.remove('active'));
            btn.classList.add('active');
        }
        const query = (document.getElementById('userSearch')?.value || '').toLowerCase();
        currentUsersList = allUsers.filter(u => {
            const matchesQuery = !query || 
                (u.phone && u.phone.toLowerCase().includes(query)) ||
                (u.email && u.email.toLowerCase().includes(query)) ||
                (u.username && u.username.toLowerCase().includes(query));
            if (!matchesQuery) return false;
            if (statusFilter === 'active') return !u.is_frozen;
            if (statusFilter === 'frozen') return !!u.is_frozen;
            if (statusFilter === 'admins') {
                const role = u.user_roles?.[0]?.roles?.name || (u.is_admin ? 'Admin' : 'User');
                return role === 'Admin' || role === 'Super Admin';
            }
            return true;
        });
        userPage = 1;
        renderUserPage();
    };

    document.getElementById('userSearch').addEventListener('input', (e) => {
        const activeChip = document.querySelector('#userFilterChips .sa-chip.active');
        const statusFilter = activeChip?.textContent.toLowerCase().includes('frozen') ? 'frozen' :
                             activeChip?.textContent.toLowerCase().includes('active') ? 'active' :
                             activeChip?.textContent.toLowerCase().includes('admin') ? 'admins' : 'all';
        window.filterUsersByStatus(statusFilter);
    });

    currentUsersList = allUsers || [];
    userPage = 1;
    renderUserPage();
    if (window.lucide) lucide.createIcons();
}

window.changeUserPage = (page) => {
    userPage = page;
    renderUserPage();
};

function renderUserPage() {
    const startIdx = (userPage - 1) * PAGE_SIZE;
    const paginatedUsers = currentUsersList.slice(startIdx, startIdx + PAGE_SIZE);
    
    const tbody = document.getElementById('userRows');
    if (tbody) {
        tbody.innerHTML = getUserRowsMarkup(paginatedUsers);
    }
    
    const paginationContainer = document.getElementById('userPagination');
    if (paginationContainer) {
        paginationContainer.innerHTML = buildPaginationMarkup(currentUsersList.length, userPage, PAGE_SIZE, 'changeUserPage');
    }
}

function getUserRowsMarkup(users) {
    if (!users || users.length === 0) {
        return `<tr><td colspan="6" style="text-align:center; padding:32px; color:var(--text-muted);">No matching profiles found</td></tr>`;
    }

    return users.map(u => {
        const uLabel = u.username ? `@${u.username}` : (u.phone || 'Guest User');
        const role = u.user_roles?.[0]?.roles?.name || (u.is_admin ? 'Admin' : 'User');
        const isFrozen = u.is_frozen === true;
        const joinedDate = new Date(u.created_at).toLocaleDateString();

        return `
            <tr data-user-id="${u.id}">
                <td>
                    <div style="font-weight:700; color:var(--text-primary);">${uLabel}</div>
                    <div style="font-size:0.68rem; color:var(--text-muted); margin-top:2px;">Role: ${role}</div>
                </td>
                <td>
                    <div style="font-size:0.75rem; color:var(--text-secondary);">${u.email || '—'}</div>
                    <div style="font-size:0.65rem; color:var(--text-muted); margin-top:2px;">Reg: ${joinedDate}</div>
                </td>
                <td style="font-weight:700; color:var(--success); font-size:0.85rem;">
                    KES ${parseFloat(u.balance || 0).toLocaleString(undefined, {minimumFractionDigits:2})}
                </td>
                <td>
                    <span class="status-pill ${isFrozen ? 'status-pending' : 'status-approved'}" style="padding: 2px 8px; border-radius:4px; font-size:0.65rem;">
                        ${isFrozen ? 'FROZEN' : 'ACTIVE'}
                    </span>
                </td>
                <td>
                    <div style="display:flex; align-items:center; gap:6px;">
                        <input type="number" class="amount-input" id="adjVal_${u.id}" style="width:80px; padding:4px 6px; font-size:0.75rem;" placeholder="KES">
                        <button class="quick-btn" style="padding:4px 8px; font-weight:700;" onclick="submitBalanceAdjustment('${u.id}', 1)">+</button>
                        <button class="quick-btn" style="padding:4px 8px; font-weight:700;" onclick="submitBalanceAdjustment('${u.id}', -1)">−</button>
                    </div>
                </td>
                <td>
                    <div style="display:flex; gap:6px;">
                        <button class="quick-btn" onclick="submitToggleFreeze('${u.id}', ${isFrozen})">
                            ${isFrozen ? 'Unfreeze' : 'Freeze'}
                        </button>
                        <select onchange="submitSetRole('${u.id}', this.value)" style="background:var(--bg-elevated); border:1px solid var(--border); color:var(--text-primary); font-size:0.72rem; border-radius:4px; padding:3px 6px;">
                            <option value="">Set Role...</option>
                            <option value="User" ${role === 'User' ? 'selected' : ''}>User</option>
                            <option value="Predictor" ${role === 'Predictor' ? 'selected' : ''}>Predictor</option>
                            <option value="Admin" ${role === 'Admin' ? 'selected' : ''}>Admin</option>
                            <option value="Super Admin" ${role === 'Super Admin' ? 'selected' : ''}>Super Admin</option>
                        </select>
                    </div>
                </td>
            </tr>
        `;
    }).join('');
}

function renderAdminHierarchy() {
    const contentEl = document.getElementById('adminContent');
    const admins = allUsers.filter(u => {
        const role = u.user_roles?.[0]?.roles?.name || (u.is_admin ? 'Admin' : 'User');
        return role === 'Admin' || role === 'Super Admin';
    });

    contentEl.innerHTML = `
        <div class="pane-header">
            <div class="pane-header-titles">
                <h1>Staff & Admin Roles</h1>
                <p>Promote operators, demote staff, and view root access permissions across the system</p>
            </div>
            <div style="display:flex; gap:10px; align-items:center;">
                <button class="sa-topbar-btn" onclick="switchTab('hierarchy')">
                    <i data-lucide="refresh-cw" style="width:14px; height:14px;"></i>
                    <span>Refresh</span>
                </button>
            </div>
        </div>

        <div class="audit-table-wrap">
            <table class="audit-table">
                <thead>
                    <tr>
                        <th>Operator</th>
                        <th>Identity Email</th>
                        <th>Assigned Privileges</th>
                        <th>Role Operations</th>
                    </tr>
                </thead>
                <tbody>
                    ${admins.map(a => {
                        const label = a.username ? `@${a.username}` : (a.phone || 'Anonymous Admin');
                        const role = a.user_roles?.[0]?.roles?.name || (a.is_admin ? 'Admin' : 'User');
                        const isSuper = role === 'Super Admin';
                        return `
                            <tr>
                                <td style="font-weight:600; color:var(--sa-text-primary); display:flex; align-items:center; gap:8px;">
                                    <div style="width:28px; height:28px; border-radius:50%; background:${isSuper ? '#0F172A' : '#F1F5F9'}; border:1px solid ${isSuper ? '#0F172A' : '#E2E8F0'}; display:flex; align-items:center; justify-content:center; font-size:0.6875rem; font-weight:600; color:${isSuper ? '#FFFFFF' : '#475569'};">
                                        ${label.substring(1, 3).toUpperCase()}
                                    </div>
                                    <span>${label}</span>
                                </td>
                                <td style="color:var(--sa-text-secondary);">${a.email || '—'}</td>
                                <td>
                                    <span class="status-pill" style="background:${isSuper ? '#0F172A' : '#F1F5F9'}; color:${isSuper ? '#FFFFFF' : '#334155'}; border:1px solid ${isSuper ? '#0F172A' : '#CBD5E1'}; padding:3px 8px; border-radius:4px; font-size:0.6875rem; font-weight:600; letter-spacing:0.02em;">
                                        ${isSuper ? 'ROOT L5 • SUPER ADMIN' : 'STAFF L3 • ADMIN'}
                                    </span>
                                </td>
                                <td>
                                    <button class="danger-btn" style="width:auto; padding:5px 12px;" onclick="submitSetRole('${a.id}', 'User')">
                                        <i data-lucide="user-minus" style="width:12px; height:12px;"></i>
                                        <span>DEMOTE TO PLAYER</span>
                                    </button>
                                </td>
                            </tr>
                        `;
                    }).join('')}
                </tbody>
            </table>
        </div>
    `;
    if (window.lucide) lucide.createIcons();
}

function getLedgerRowsMarkup(transactions) {
    if (!transactions || transactions.length === 0) {
        return `<tr><td colspan="7" style="text-align:center; padding:32px; color:var(--text-muted);">No transaction records found</td></tr>`;
    }
    return transactions.map(t => {
        const timeStr = new Date(t.created_at).toLocaleString();
        const userLabel = t.profiles ? (t.profiles.username ? `@${t.profiles.username}` : t.profiles.phone) : (t.user_id || 'Unknown');
        const typeLabel = String(t.type).toUpperCase();
        const isSuccess = t.status === 'success' || t.status === 'approved' || t.status === 'completed';
        const isPendingWithdrawal = (t.type === 'withdrawal' || t.type === 'withdraw') && t.status === 'pending';

        let actionsMarkup = `<span style="color:var(--text-muted); font-size:0.75rem;">—</span>`;
        if (isPendingWithdrawal) {
            actionsMarkup = `
                <div style="display:flex; gap:6px; align-items:center;">
                    <button class="approve-btn" onclick="window.approveWithdrawal('${t.id}')" title="Approve & Release M-Pesa Payout">
                        <i data-lucide="check" style="width:12px; height:12px;"></i>
                        <span>Release</span>
                    </button>
                    <button class="danger-btn" style="width:auto; padding:5px 10px; font-size:0.72rem; font-weight:700;" onclick="window.rejectWithdrawal('${t.id}')" title="Reject & Refund to User">
                        <i data-lucide="x" style="width:12px; height:12px;"></i>
                        <span>Reject</span>
                    </button>
                </div>
            `;
        } else if (t.metadata?.approved_by) {
            actionsMarkup = `<span style="color:var(--success); font-size:0.72rem; font-weight:600; display:inline-flex; align-items:center; gap:4px;"><i data-lucide="check-check" style="width:12px; height:12px;"></i> Approved</span>`;
        } else if (t.status === 'rejected') {
            const reason = t.metadata?.rejection_reason || 'Rejected';
            actionsMarkup = `<span style="color:var(--danger); font-size:0.72rem;" title="${reason}">✕ ${reason.length > 20 ? reason.slice(0, 18) + '...' : reason}</span>`;
        }
        
        return `
            <tr>
                <td style="color:var(--text-muted);">${timeStr}</td>
                <td style="font-weight:600; color:var(--text-primary);">${userLabel}</td>
                <td>
                    <span style="font-weight:700; color:${typeLabel === 'DEPOSIT' ? 'var(--success)' : (typeLabel.includes('WITHDRAW') ? 'var(--warning)' : 'var(--text-primary)')};">
                        ${typeLabel}
                    </span>
                </td>
                <td style="font-weight:700;">KES ${parseFloat(t.amount || 0).toLocaleString(undefined, {minimumFractionDigits:2})}</td>
                <td>
                    <span class="status-pill ${isSuccess ? 'status-approved' : (t.status === 'pending' ? 'status-pending' : 'status-rejected')}" style="padding:2px 8px; border-radius:4px; font-size:0.65rem;">
                        ${String(t.status).toUpperCase()}
                    </span>
                </td>
                <td style="font-family:monospace; font-size:0.72rem; color:var(--text-secondary);">${t.reference || '—'}</td>
                <td>${actionsMarkup}</td>
            </tr>
        `;
    }).join('');
}

function renderFinancialLedger() {
    const contentEl = document.getElementById('adminContent');
    contentEl.innerHTML = `
        <div class="pane-header">
            <div class="pane-header-titles">
                <h1>Financial Ledger Audit</h1>
                <p>Monitor all transaction ledger statements, deposit clearances, and payout actions.</p>
            </div>
            <div style="display:flex; gap:10px; align-items:center;">
                <button class="sa-topbar-btn" onclick="switchTab('ledger')">
                    <i data-lucide="refresh-cw" style="width:14px; height:14px;"></i>
                    <span>Refresh</span>
                </button>
            </div>
        </div>

        <div class="sa-search-bar">
            <div class="sa-search-input-wrap">
                <i data-lucide="search" style="width: 18px; height: 18px;"></i>
                <input type="text" id="ledgerSearch" placeholder="Search transaction by account, reference, or type...">
            </div>
            <div class="sa-filter-chips" id="ledgerFilterChips">
                <button class="sa-chip active" onclick="window.filterLedgerByType('all', this)">All Records</button>
                <button class="sa-chip" onclick="window.filterLedgerByType('pending_withdrawal', this)">Pending Withdrawals</button>
                <button class="sa-chip" onclick="window.filterLedgerByType('deposit', this)">Deposits</button>
                <button class="sa-chip" onclick="window.filterLedgerByType('withdrawal', this)">Withdrawals</button>
                <button class="sa-chip" onclick="window.filterLedgerByType('bet', this)">Bets</button>
            </div>
        </div>

        <div class="audit-table-wrap" style="margin-bottom:0; border-bottom:none; border-bottom-left-radius:0; border-bottom-right-radius:0;">
            <table class="audit-table">
                <thead>
                    <tr>
                        <th>Timestamp</th>
                        <th>User Account</th>
                        <th>Transaction Type</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Tracking Reference</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="ledgerRows">
                </tbody>
            </table>
        </div>
        <div id="ledgerPagination"></div>
    `;

    window.filterLedgerByType = (typeFilter, btn) => {
        if (btn) {
            document.querySelectorAll('#ledgerFilterChips .sa-chip').forEach(c => c.classList.remove('active'));
            btn.classList.add('active');
        }
        const query = (document.getElementById('ledgerSearch')?.value || '').toLowerCase();
        currentLedgerList = allTransactions.filter(t => {
            const username = t.profiles?.username || '';
            const phone = t.profiles?.phone || '';
            const uid = t.user_id || '';
            const type = t.type || '';
            const ref = t.reference || '';
            const status = (t.status || '').toLowerCase();
            const matchesQuery = !query ||
                   username.toLowerCase().includes(query) ||
                   phone.toLowerCase().includes(query) ||
                   uid.toLowerCase().includes(query) ||
                   type.toLowerCase().includes(query) ||
                   ref.toLowerCase().includes(query);
            if (!matchesQuery) return false;
            if (typeFilter === 'pending_withdrawal') {
                return (type.toLowerCase() === 'withdrawal' || type.toLowerCase() === 'withdraw') && status === 'pending';
            }
            if (typeFilter !== 'all') {
                return type.toLowerCase() === typeFilter;
            }
            return true;
        });
        ledgerPage = 1;
        renderLedgerPage();
    };

    document.getElementById('ledgerSearch').addEventListener('input', (e) => {
        const activeChip = document.querySelector('#ledgerFilterChips .sa-chip.active');
        let typeFilter = 'all';
        if (activeChip) {
            const text = activeChip.textContent.toLowerCase();
            if (text.includes('pending')) typeFilter = 'pending_withdrawal';
            else if (text.includes('deposit')) typeFilter = 'deposit';
            else if (text.includes('withdrawal')) typeFilter = 'withdrawal';
            else if (text.includes('bet')) typeFilter = 'bet';
        }
        window.filterLedgerByType(typeFilter);
    });

    currentLedgerList = allTransactions || [];
    ledgerPage = 1;
    renderLedgerPage();
    if (window.lucide) lucide.createIcons();
}

window.changeLedgerPage = (page) => {
    ledgerPage = page;
    renderLedgerPage();
};

function renderLedgerPage() {
    const startIdx = (ledgerPage - 1) * PAGE_SIZE;
    const paginatedTransactions = currentLedgerList.slice(startIdx, startIdx + PAGE_SIZE);

    const tbody = document.getElementById('ledgerRows');
    if (tbody) {
        tbody.innerHTML = getLedgerRowsMarkup(paginatedTransactions);
        if (window.lucide) lucide.createIcons();
    }

    const paginationContainer = document.getElementById('ledgerPagination');
    if (paginationContainer) {
        paginationContainer.innerHTML = buildPaginationMarkup(currentLedgerList.length, ledgerPage, PAGE_SIZE, 'changeLedgerPage');
    }
}

function renderAuditRecords() {
    const contentEl = document.getElementById('adminContent');
    contentEl.innerHTML = `
        <div class="pane-header">
            <h1>Platform Audit Records</h1>
            <p>Raw ledger trails recording administrative executions, safety locks, and system adjustments.</p>
        </div>

        <div style="margin-bottom: 20px; display:flex; gap:12px;">
            <input type="text" id="auditSearch" class="amount-input" style="flex-grow:1; max-width:400px; text-transform:none;" placeholder="Search audit logs by actor, action, target...">
        </div>

        <div class="audit-table-wrap" style="margin-bottom:0; border-bottom:none; border-bottom-left-radius:0; border-bottom-right-radius:0;">
            <table class="audit-table">
                <thead>
                    <tr>
                        <th>Timestamp</th>
                        <th>Actor</th>
                        <th>Action</th>
                        <th>Target Entity</th>
                        <th>Metadata Details</th>
                    </tr>
                </thead>
                <tbody id="auditRows">
                </tbody>
            </table>
        </div>
        <div id="auditPagination"></div>
    `;

    document.getElementById('auditSearch').addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase();
        currentAuditList = allAuditLogs.filter(log => {
            const username = log.profiles?.username || '';
            const phone = log.profiles?.phone || '';
            const action = log.action || '';
            const target = log.target_id || '';
            const details = typeof log.details === 'object' ? JSON.stringify(log.details) : (log.details || '');
            return username.toLowerCase().includes(query) ||
                   phone.toLowerCase().includes(query) ||
                   action.toLowerCase().includes(query) ||
                   target.toLowerCase().includes(query) ||
                   details.toLowerCase().includes(query);
        });
        auditPage = 1;
        renderAuditPage();
    });

    currentAuditList = allAuditLogs || [];
    auditPage = 1;
    renderAuditPage();
}

window.changeAuditPage = (page) => {
    auditPage = page;
    renderAuditPage();
};

function renderAuditPage() {
    const startIdx = (auditPage - 1) * PAGE_SIZE;
    const paginatedAuditLogs = currentAuditList.slice(startIdx, startIdx + PAGE_SIZE);

    const tbody = document.getElementById('auditRows');
    if (tbody) {
        tbody.innerHTML = renderAuditRows(paginatedAuditLogs);
    }

    const paginationContainer = document.getElementById('auditPagination');
    if (paginationContainer) {
        paginationContainer.innerHTML = buildPaginationMarkup(currentAuditList.length, auditPage, PAGE_SIZE, 'changeAuditPage');
    }
}

async function renderGlobalSettings() {
    const contentEl = document.getElementById('adminContent');

    // ── 1. Render skeleton instantly (no DB wait) ──────────────────
    contentEl.innerHTML = `
        <div class="pane-header">
            <h1>Global Platform Settings</h1>
            <p>Configure parameters, force outcomes, and manage game signals.</p>
        </div>

        <div style="background: var(--bg-surface); border: 1px solid var(--border); padding: 24px; border-radius: var(--radius-md); max-width:600px; display:flex; flex-direction:column; gap:20px;">

            <!-- Real-time Game Sync Monitor Card -->
            <div style="background: var(--bg-elevated); border: 1px solid var(--border); padding: 16px; border-radius: var(--radius-sm); display:flex; justify-content:space-between; align-items:center; margin-bottom: 8px;">
                <div>
                    <div style="font-size:0.6rem; color:var(--text-muted); text-transform:uppercase; letter-spacing:1px; font-weight:700;">Active Round ID</div>
                    <div id="liveRoundDisplay" style="font-size:1.1rem; font-weight:800; color:var(--text-primary); margin-top:2px;">…</div>
                </div>
                <div>
                    <div style="font-size:0.6rem; color:var(--text-muted); text-transform:uppercase; letter-spacing:1px; font-weight:700;">Game Room Status</div>
                    <span id="liveGameStateDisplay" class="status-pill status-pending" style="padding:4px 10px; font-size:0.7rem; border-radius:4px; font-weight:700; display:inline-block; margin-top:4px;">…</span>
                </div>
                <div>
                    <div style="font-size:0.6rem; color:var(--text-muted); text-transform:uppercase; letter-spacing:1px; font-weight:700;">Active Outcome Signal</div>
                    <div id="liveCrashPointDisplay" style="font-size:1.1rem; font-weight:950; color:var(--accent); margin-top:2px; font-family:monospace;">…</div>
                </div>
            </div>

            <h3 style="margin-bottom:4px; font-size:0.92rem; font-weight:800;">🛰 Target Next Crash Point Signal</h3>
            <p style="color:var(--text-muted); font-size:0.75rem;">Force a specific crash multiplier for the incoming round. E.g. placing 100.00 will allow players to ride up to 100x before crash.</p>

            <div style="display:flex; flex-direction:column; gap:8px;">
                <label style="font-size:0.68rem; font-weight:700; color:var(--text-secondary); text-transform:uppercase;">Next Crash Point (Multiplier)</label>
                <div style="display:flex; gap:12px;">
                    <input type="number" id="nextCrashOverride" class="amount-input" style="width:140px; text-align:left;" value="1.80" min="1.01" step="0.05">
                    <button class="big-bet-btn" onclick="submitCrashPointOverride()" style="margin:0; height:38px; width:auto; padding:0 24px; border-radius:var(--radius-sm);">
                        APPLY OUTCOME SIGNAL
                    </button>
                </div>
            </div>

            <hr style="border:none; border-bottom: 1px solid var(--border); margin: 8px 0;">

            <h3 style="margin-bottom:4px; font-size:0.92rem; font-weight:800; color:var(--error);">🚨 Platform Maintenance Lockdown</h3>
            <p style="color:var(--text-muted); font-size:0.75rem;">Toggle the maintenance system mode. This restricts access for all non-privileged players system-wide.</p>

            <div>
                <button class="danger-btn" style="width:auto; padding:8px 24px;" onclick="toggleMaintenance()">
                    ⚠ ACTIVATE EMERGENCY MAINTENANCE
                </button>
            </div>

            <hr style="border:none; border-bottom: 1px solid var(--border); margin: 8px 0;">

            <h3 style="margin-bottom:4px; font-size:0.92rem; font-weight:800; color:var(--blue);">🔍 Profiles Registry Sync Diagnostics</h3>
            <p style="color:var(--text-muted); font-size:0.75rem;">Identify and repair newly created signups that failed to sync with the public profiles table.</p>

            <div style="display:flex; gap:12px;">
                <button class="quick-btn" style="width:auto; padding:8px 16px; border-radius:var(--radius-sm);" onclick="runUserDiagnostics()">
                    RUN DIAGNOSTICS
                </button>
                <button class="big-bet-btn" style="width:auto; padding:8px 16px; border-radius:var(--radius-sm); margin:0;" onclick="runUserRepair()">
                    AUTO-REPAIR PROFILES
                </button>
            </div>

            <div id="diagnosticResults" style="font-size:0.72rem; font-family:monospace; background:var(--bg-elevated); padding:10px; border-radius:4px; border:1px solid var(--border); display:none; max-height: 150px; overflow-y: auto;">
            </div>

            <hr style="border:none; border-bottom: 1px solid var(--border); margin: 8px 0;">

            <!-- Financial Limits Management Card -->
            <div>
                <h3 style="margin:0 0 4px; font-size:0.95rem; font-weight:800; color:var(--text-primary); display:flex; align-items:center; gap:8px;">
                    <span>💳 Financial & Transaction Limits</span>
                </h3>
                <p style="color:var(--text-muted); font-size:0.75rem; margin:0 0 14px;">
                    Configure deposit and withdrawal constraints. Deposit minimums are displayed to users on payment prompts. Withdrawal minimums are strictly enforced on backend but hidden from the user end.
                </p>

                <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:14px;">
                    <div style="display:flex; flex-direction:column; gap:4px;">
                        <label style="font-size:0.68rem; font-weight:700; color:var(--text-secondary); text-transform:uppercase;">
                            Min Deposit (KES) <span style="color:var(--success); font-size:0.62rem;">• Shown to User</span>
                        </label>
                        <input type="number" id="saMinDeposit" class="amount-input" style="width:100%; text-align:left;" value="99" min="1" step="1">
                    </div>
                    <div style="display:flex; flex-direction:column; gap:4px;">
                        <label style="font-size:0.68rem; font-weight:700; color:var(--text-secondary); text-transform:uppercase;">
                            Max Deposit (KES)
                        </label>
                        <input type="number" id="saMaxDeposit" class="amount-input" style="width:100%; text-align:left;" value="300000" min="10" step="1000">
                    </div>

                    <div style="display:flex; flex-direction:column; gap:4px;">
                        <label style="font-size:0.68rem; font-weight:700; color:var(--text-secondary); text-transform:uppercase;">
                            Min Withdrawal (KES) <span style="color:var(--sa-accent-amber, #f59e0b); font-size:0.62rem;">• Hidden from User</span>
                        </label>
                        <input type="number" id="saMinWithdrawal" class="amount-input" style="width:100%; text-align:left;" value="100" min="1" step="1">
                    </div>
                    <div style="display:flex; flex-direction:column; gap:4px;">
                        <label style="font-size:0.68rem; font-weight:700; color:var(--text-secondary); text-transform:uppercase;">
                            Max Withdrawal (KES)
                        </label>
                        <input type="number" id="saMaxWithdrawal" class="amount-input" style="width:100%; text-align:left;" value="150000" min="10" step="1000">
                    </div>

                    <div style="display:flex; flex-direction:column; gap:4px;">
                        <label style="font-size:0.68rem; font-weight:700; color:var(--text-secondary); text-transform:uppercase;">
                            Min Bet Aviator (KES)
                        </label>
                        <input type="number" id="saMinBetAviator" class="amount-input" style="width:100%; text-align:left;" value="10" min="1" step="1">
                    </div>
                    <div style="display:flex; flex-direction:column; gap:4px;">
                        <label style="font-size:0.68rem; font-weight:700; color:var(--text-secondary); text-transform:uppercase;">
                            Max Bet Aviator (KES)
                        </label>
                        <input type="number" id="saMaxBetAviator" class="amount-input" style="width:100%; text-align:left;" value="50000" min="100" step="500">
                    </div>
                </div>

                <button id="btnSaveFinancialLimits" class="big-bet-btn" onclick="saveFinancialLimits()" style="width:100%; margin:0; padding:10px 20px; border-radius:var(--radius-sm); font-weight:600;">
                    💾 SAVE FINANCIAL LIMITS
                </button>
            </div>
        </div>
    `;

    // ── 2. Fast DB sync — only 3 columns needed ────────────────────
    const syncState = async () => {
        const roundEl = document.getElementById('liveRoundDisplay');
        if (!roundEl) return false; // panel is gone, stop polling
        
        try {
            await supabase.rpc('sync_and_get_game_state');
        } catch (e) {
            console.warn("Could not progress game state loop via settings syncSuper:", e);
        }

        const { data: s } = await supabase
            .from('active_game_state')
            .select('round_id, crash_point, status')
            .eq('id', 1)
            .single();
        if (!s) return true;
        const statusEl = document.getElementById('liveGameStateDisplay');
        const crashEl  = document.getElementById('liveCrashPointDisplay');
        const inputEl  = document.getElementById('nextCrashOverride');
        roundEl.textContent = `#${s.round_id}`;
        if (statusEl) {
            statusEl.textContent = String(s.status).toUpperCase();
            statusEl.className   = `status-pill ${s.status === 'playing' ? 'status-approved' : s.status === 'waiting' ? 'status-pending' : 'status-rejected'}`;
        }
        if (crashEl)  crashEl.textContent = `${parseFloat(s.crash_point).toFixed(2)}x`;
        if (inputEl && document.activeElement !== inputEl)
            inputEl.value = parseFloat(s.crash_point).toFixed(2);
        return true;
    };

    // Load current financial limits into form
    try {
        const { data: { session } } = await supabase.auth.getSession();
        const res = await fetch('/api/admin/content?action=settings', {
            headers: { 'Authorization': `Bearer ${session?.access_token || localStorage.getItem('metrowins_auth_token')}` }
        });
        const settings = await res.json();
        const fl = settings?.financial_limits || {};
        if (document.getElementById('saMinDeposit')) {
            if (fl.minDeposit !== undefined) document.getElementById('saMinDeposit').value = fl.minDeposit;
            if (fl.maxDeposit !== undefined) document.getElementById('saMaxDeposit').value = fl.maxDeposit;
            if (fl.minWithdrawal !== undefined) document.getElementById('saMinWithdrawal').value = fl.minWithdrawal;
            if (fl.maxWithdrawal !== undefined) document.getElementById('saMaxWithdrawal').value = fl.maxWithdrawal;
            if (fl.minBetAviator !== undefined) document.getElementById('saMinBetAviator').value = fl.minBetAviator;
            if (fl.maxBetAviator !== undefined) document.getElementById('saMaxBetAviator').value = fl.maxBetAviator;
        }
    } catch (_) {}

    await syncState(); // immediate first fetch

    // ── 3. Poll every 1.5 s — auto-clears when panel unmounts ─────
    const tid = setInterval(async () => {
        const alive = await syncState();
        if (!alive) clearInterval(tid);
    }, 1500);
}

window.saveFinancialLimits = async () => {
    const minDeposit = parseFloat(document.getElementById('saMinDeposit').value) || 99;
    const maxDeposit = parseFloat(document.getElementById('saMaxDeposit').value) || 300000;
    const minWithdrawal = parseFloat(document.getElementById('saMinWithdrawal').value) || 100;
    const maxWithdrawal = parseFloat(document.getElementById('saMaxWithdrawal').value) || 150000;
    const minBetAviator = parseFloat(document.getElementById('saMinBetAviator').value) || 10;
    const maxBetAviator = parseFloat(document.getElementById('saMaxBetAviator').value) || 50000;

    if (minDeposit < 1 || minWithdrawal < 1) {
        alert('Limits must be greater than zero.');
        return;
    }
    if (minDeposit > maxDeposit) {
        alert('Minimum deposit cannot exceed maximum deposit.');
        return;
    }
    if (minWithdrawal > maxWithdrawal) {
        alert('Minimum withdrawal cannot exceed maximum withdrawal.');
        return;
    }

    const payload = {
        minDeposit,
        maxDeposit,
        minWithdrawal,
        maxWithdrawal,
        minBetAviator,
        maxBetAviator
    };

    const btn = document.getElementById('btnSaveFinancialLimits');
    if (btn) { btn.disabled = true; btn.textContent = 'SAVING...'; }

    try {
        const { data: { session } } = await supabase.auth.getSession();
        const res = await fetch('/api/admin/content?action=update_settings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${session?.access_token || localStorage.getItem('metrowins_auth_token')}`
            },
            body: JSON.stringify({ key: 'financial_limits', value: payload })
        });
        const result = await res.json();
        if (result.success) {
            showToast(`✓ Financial limits updated! Min deposit: KES ${minDeposit}`);
        } else {
            alert('Error: ' + (result.error || 'Failed to update limits'));
        }
    } catch (e) {
        alert('Error: ' + e.message);
    } finally {
        if (btn) { btn.disabled = false; btn.textContent = '💾 SAVE FINANCIAL LIMITS'; }
    }
};

// ── ACTION EXECUTION MUTATORS ───────────────────────────────────────────────

window.submitCrashPointOverride = async () => {
    const inputVal = parseFloat(document.getElementById('nextCrashOverride').value);
    if (isNaN(inputVal) || inputVal < 1.01) {
        alert("Invalid crash point. Must be >= 1.01.");
        return;
    }

    try {
        const { data: { session } } = await supabase.auth.getSession();
        const res = await fetch('/api/admin/actions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${session.access_token}`
            },
            body: JSON.stringify({ action: 'override_crash_point', multiplier: inputVal })
        });
        const result = await res.json();
        
        if (result.success) {
            alert(`Signal set successfully! Next round crash point is locked to ${inputVal}x.`);
        } else {
            alert(`Override failed: ${result.error}`);
        }
    } catch(err) {
        alert(`Error: ${err.message}`);
    }
};

window.submitBalanceAdjustment = async (userId, direction) => {
    const input = document.getElementById(`adjVal_${userId}`);
    const amount = parseFloat(input ? input.value : 0);
    if (isNaN(amount) || amount <= 0) {
        alert("Enter a valid adjustment amount.");
        return;
    }

    const delta = amount * direction;

    try {
        const { data: { session } } = await supabase.auth.getSession();
        const res = await fetch('/api/admin/actions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${session.access_token}`
            },
            body: JSON.stringify({ action: 'adjust_balance', targetUserId: userId, delta })
        });
        const result = await res.json();
        
        if (result.success) {
            alert(`Wallet balance adjusted by KES ${delta.toLocaleString()}.`);
            switchTab(activeTab); // Reload statistics
        } else {
            alert(`Write failed: ${result.error}`);
        }
    } catch (err) {
        alert(`Error Adjusting: ${err.message}`);
    }
};

window.submitToggleFreeze = async (userId, currentFrozen) => {
    const newFrozenState = !currentFrozen;
    const actionName = newFrozenState ? 'freeze_user' : 'unfreeze_user';

    try {
        const { data: { session } } = await supabase.auth.getSession();
        const res = await fetch('/api/admin/actions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${session.access_token}`
            },
            body: JSON.stringify({ action: actionName, targetUserId: userId })
        });
        const result = await res.json();
        
        if (result.success) {
            alert(`User account frozen state successfully updated.`);
            switchTab(activeTab); // Reload
        } else {
            alert(`Operation failed: ${result.error}`);
        }
    } catch (err) {
        alert(`Error operating status: ${err.message}`);
    }
};

window.submitSetRole = async (userId, targetRole) => {
    if (!targetRole) return;
    const confirm = window.confirm(`Are you sure you want to change this operator's role privileges to: ${targetRole}?`);
    if (!confirm) return;

    try {
        const { data: { session } } = await supabase.auth.getSession();
        const res = await fetch('/api/admin/actions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${session.access_token}`
            },
            body: JSON.stringify({ action: 'assign_role', targetUserId: userId, roleName: targetRole })
        });
        const result = await res.json();
        
        if (result.success) {
            alert(`User role assigned successfully.`);
            switchTab(activeTab); // Reload
        } else {
            alert(`Role write failed: ${result.error}`);
        }
    } catch (err) {
        alert(`Network Error: ${err.message}`);
    }
};

window.approveWithdrawal = async (txId) => {
    if (!confirm('Are you sure you want to approve this withdrawal and dispatch funds via M-Pesa?')) return;
    try {
        const { data } = await supabase.auth.getSession();
        const token = data?.session?.access_token || localStorage.getItem('metrowins_auth_token');
        if (!token) {
            alert('Not authenticated. Please log in again.');
            return;
        }
        const res = await fetch('/api/admin/actions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ action: 'approve_withdrawal', transactionId: txId })
        });
        const result = await res.json();
        if (result.success) {
            alert(result.message || 'Withdrawal approved and released successfully!');
            switchTab('ledger');
        } else {
            alert(`Approval failed: ${result.error}`);
        }
    } catch (err) {
        alert(`Network Error: ${err.message}`);
    }
};

window.rejectWithdrawal = async (txId) => {
    const reason = prompt('Please enter the reason for rejecting this withdrawal (funds will be refunded to user):', 'Admin rejected request');
    if (reason === null) return;
    try {
        const { data } = await supabase.auth.getSession();
        const token = data?.session?.access_token || localStorage.getItem('metrowins_auth_token');
        if (!token) {
            alert('Not authenticated. Please log in again.');
            return;
        }
        const res = await fetch('/api/admin/actions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                action: 'reject_withdrawal',
                transactionId: txId,
                reason: reason.trim() || 'Admin rejected request'
            })
        });
        const result = await res.json();
        if (result.success) {
            alert(result.message || 'Withdrawal rejected and funds refunded to user.');
            switchTab('ledger');
        } else {
            alert(`Rejection failed: ${result.error}`);
        }
    } catch (err) {
        alert(`Network Error: ${err.message}`);
    }
};

window.toggleMaintenance = async () => {
    const confirm = prompt("DANGER: This will lock the platform for all standard users. Type 'CONFIRM' to proceed:");
    if (confirm !== 'CONFIRM') return;
    alert("Maintenance Mode Activated System-Wide.");
};

window.runUserDiagnostics = async () => {
    const resultsBox = document.getElementById('diagnosticResults');
    if (!resultsBox) return;
    resultsBox.style.display = 'block';
    resultsBox.innerHTML = 'Running analytical scans on database schemas...';
    try {
        const { data: { session } } = await supabase.auth.getSession();
        if (!session) { resultsBox.innerHTML = `<span style="color:var(--error)">ERROR: Not authenticated. Please refresh the page.</span>`; return; }
        const headers = { 'Authorization': `Bearer ${session.access_token}` };
        const res = await fetch('/api/admin/system?action=diagnose_users', { headers });
        const data = await res.json();
        if (data.error) { resultsBox.innerHTML = `<span style="color:var(--error)">ERROR: ${data.error}</span>`; return; }
        if (!data.missing || data.missing.length === 0) {
            resultsBox.innerHTML = `<span style="color:var(--success)">✓ INTEGRITY CHECK PASSED: Auth users (${data.auth_count}) match Public profiles (${data.profile_count}).</span>`;
        } else {
            resultsBox.innerHTML = `<span style="color:var(--warning)">⚠ ${data.missing.length} users missing profile entries.</span><br><br>` +
                data.missing.map(m => `• ${m.email || 'No Email'} (${m.phone || 'No Phone'}) | ID: ${m.id}`).join('<br>');
        }
    } catch (e) {
        resultsBox.innerHTML = `<span style="color:var(--error)">RUN FAILURE: ${e.message}</span>`;
    }
};

window.runUserRepair = async () => {
    const resultsBox = document.getElementById('diagnosticResults');
    if (!resultsBox) return;
    resultsBox.style.display = 'block';
    resultsBox.innerHTML = 'Executing registry healing procedures...';

    try {
        const { data: { session } } = await supabase.auth.getSession();
        if (!session) { resultsBox.innerHTML = `<span style="color:var(--error)">ERROR: Not authenticated. Please refresh the page.</span>`; return; }
        const headers = { 'Authorization': `Bearer ${session.access_token}` };
        
        const res = await fetch('/api/admin/system?action=repair_users', { headers });
        const data = await res.json();
        
        if (data.error) { resultsBox.innerHTML = `<span style="color:var(--error)">ERROR: ${data.error}</span>`; return; }
        
        resultsBox.innerHTML = `<span style="color:var(--success)">HEALING PROCESS COMPLETE. Successfully rebuilt/synced ${data.repaired?.length || 0} user profiles in DB.</span>`;
        if (data.repaired && data.repaired.length > 0) {
            resultsBox.innerHTML += `<br><br>` + data.repaired.map(r => `✓ Reconstructed: ${r.username} (${r.phone})`).join('<br>');
        }
    } catch (e) {
        resultsBox.innerHTML = `<span style="color:var(--error)">RUN FAILURE: ${e.message}</span>`;
    }
};

// ── PROMOTIONS TAB ────────────────────────────────────────────────────────────
const ACTION_TYPES = {
    play:    { label: 'Play Now',   url: '/' },
    deposit: { label: 'Deposit',    url: '/#deposit' },
    refer:   { label: 'Refer Now',  url: '/#referral' },
    external:{ label: 'Learn More', url: '' },
    claim:   { label: 'Claim Code', url: '' }
};

function renderPromotions(promos) {
    const el = document.getElementById('adminContent');
    el.innerHTML = `
        <div class="pane-header">
            <h1>Campaign Management System</h1>
            <p>Design visual promotions, configure wagers eligibility thresholds, track conversions, and preview player alerts.</p>
        </div>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(360px, 1fr)); gap: 24px; max-width: 1200px; margin-bottom: 28px; align-items: start;">
            <!-- Builder Card Form -->
            <div style="background:var(--bg-surface); border:1px solid var(--border); border-radius:var(--radius-md); padding:20px; display:flex; flex-direction:column; gap:14px;">
                <h3 style="font-size:0.95rem; font-weight:800; color:var(--text-primary); margin:0;">➕ Campaign Configurations</h3>
                
                <input id="promoTitle" class="amount-input" placeholder="Title (e.g. 200% DEPOSIT BONUS!)" style="width:100%; text-align:left;" oninput="updateLivePreview()">
                <textarea id="promoDesc" class="amount-input" placeholder="Terms & conditions wagers description..." rows="2" style="width:100%; text-align:left; resize:vertical;" oninput="updateLivePreview()"></textarea>
                <input id="promoImage" class="amount-input" placeholder="Banner Image URL" style="width:100%; text-align:left;" oninput="updateLivePreview()">
                
                <div style="display:flex; gap:10px; flex-wrap:wrap;">
                    <div style="flex:1; min-width:140px;">
                        <label style="font-size:0.6rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; display:block; margin-bottom:4px;">Action Button Type</label>
                        <select id="promoActionType" class="amount-input" style="width:100%; text-align:left; cursor:pointer;" onchange="toggleCustomUrl(this.value); updateLivePreview();">
                            <option value="play">▶ Play Now → Game Board</option>
                            <option value="deposit">💰 Deposit Now → Wallet</option>
                            <option value="refer">🤝 Refer Now → Referral Tab</option>
                            <option value="external">🔗 Custom External URL</option>
                            <option value="claim">🎁 Claim Promo Code</option>
                        </select>
                    </div>
                    <div id="customUrlWrap" style="flex:1; min-width:140px; display:none;">
                        <label id="promoUrlLabel" style="font-size:0.6rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; display:block; margin-bottom:4px;">External URL / Code</label>
                        <input id="promoActionUrl" class="amount-input" placeholder="e.g. SUPER500" style="width:100%; text-align:left;" oninput="updateLivePreview()">
                    </div>
                </div>

                <!-- General Campaign Configurations (Visible for all campaign types) -->
                <div style="display:flex; gap:10px; flex-wrap:wrap;">
                    <div style="flex:1; min-width:110px;">
                        <label style="font-size:0.6rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; display:block; margin-bottom:4px;">Campaign Status</label>
                        <select id="campaignStatus" class="amount-input" style="width:100%; text-align:left; cursor:pointer;">
                            <option value="active">🟢 Active</option>
                            <option value="Draft">🟡 Draft</option>
                            <option value="Scheduled">🔵 Scheduled</option>
                            <option value="Paused">⏸️ Paused</option>
                            <option value="Expired">🔴 Expired</option>
                        </select>
                    </div>
                    <div style="flex:1; min-width:110px;">
                        <label style="font-size:0.6rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; display:block; margin-bottom:4px;">Priority Display Weight</label>
                        <input type="number" id="campaignPriority" class="amount-input" value="0" style="width:100%; text-align:left;">
                    </div>
                </div>

                <div style="display:flex; align-items:center; gap:8px;">
                    <input type="checkbox" id="campaignFeatured" style="width:15px; height:15px; accent-color:var(--accent); cursor:pointer;">
                    <label for="campaignFeatured" style="font-size:0.75rem; color:var(--text-secondary); cursor:pointer; font-weight:600; user-select:none;">Feature Promotion banner</label>
                </div>

                <!-- Promo Code Specific Section (Visible ONLY for Claim Promo Code action type) -->
                <div id="promoCodeExtraConfigs" style="display:none; flex-direction:column; gap:14px; opacity:0; transition: opacity 0.25s ease;">
                    <div id="promoClaimSpecsWrap" style="display:none; gap:10px; flex-wrap:wrap;">
                        <div style="flex:1; min-width:110px;">
                            <label style="font-size:0.6rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; display:block; margin-bottom:4px;">Reward Val (KES)</label>
                            <input type="number" id="promoClaimAmount" class="amount-input" value="50" style="width:100%; text-align:left;" oninput="updateLivePreview()">
                        </div>
                        <div style="flex:1; min-width:110px;">
                            <label style="font-size:0.6rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; display:block; margin-bottom:4px;">Winners Limit (Uses)</label>
                            <input type="number" id="promoClaimMaxUses" class="amount-input" value="100" style="width:100%; text-align:left;" oninput="updateLivePreview()">
                        </div>
                    </div>

                    <!-- 1. Collapsible Section: Redemption Messages -->
                    <details style="border: 1px solid var(--sa-border); border-radius: var(--radius-sm); background: #F8FAFC;">
                        <summary style="font-size: 0.72rem; font-weight: 700; padding: 10px; cursor: pointer; user-select: none; color: var(--sa-text-secondary); text-transform: uppercase;">✉️ Redemption Messages</summary>
                        <div style="padding: 10px; display: flex; flex-direction: column; gap: 10px; border-top: 1px solid var(--sa-border);">
                            <div>
                                <label style="font-size:0.58rem; color:var(--text-muted); display:block; margin-bottom:3px;">Success Message</label>
                                <textarea id="msgSuccess" class="amount-input" rows="1" style="width:100%; text-align:left;" oninput="updateLivePreview()">✓ Correct code claimed! {amount} KES credited to wallet.</textarea>
                            </div>
                            <div>
                                <label style="font-size:0.58rem; color:var(--text-muted); display:block; margin-bottom:3px;">Wrong Code Message</label>
                                <textarea id="msgInvalid" class="amount-input" rows="1" style="width:100%; text-align:left;" oninput="updateLivePreview()">The promo code entered is invalid.</textarea>
                            </div>
                            <div>
                                <label style="font-size:0.58rem; color:var(--text-muted); display:block; margin-bottom:3px;">Not Eligible Message</label>
                                <textarea id="msgNotEligible" class="amount-input" rows="1" style="width:100%; text-align:left;" oninput="updateLivePreview()">You are not eligible for this promotion campaign.</textarea>
                            </div>
                            <div>
                                <label style="font-size:0.58rem; color:var(--text-muted); display:block; margin-bottom:3px;">Already Claimed Message</label>
                                <textarea id="msgAlreadyClaimed" class="amount-input" rows="1" style="width:100%; text-align:left;" oninput="updateLivePreview()">You have already claimed this promotion.</textarea>
                            </div>
                            <div>
                                <label style="font-size:0.58rem; color:var(--text-muted); display:block; margin-bottom:3px;">Expired Message</label>
                                <textarea id="msgExpired" class="amount-input" rows="1" style="width:100%; text-align:left;" oninput="updateLivePreview()">This campaign promotion has expired.</textarea>
                            </div>
                            <div>
                                <label style="font-size:0.58rem; color:var(--text-muted); display:block; margin-bottom:3px;">Not Started Message</label>
                                <textarea id="msgNotStarted" class="amount-input" rows="1" style="width:100%; text-align:left;" oninput="updateLivePreview()">This campaign has not started yet.</textarea>
                            </div>
                            <div>
                                <label style="font-size:0.58rem; color:var(--text-muted); display:block; margin-bottom:3px;">Limit Reached Message</label>
                                <textarea id="msgRewardLimit" class="amount-input" rows="1" style="width:100%; text-align:left;" oninput="updateLivePreview()">This promotion has reached its winner claim limit.</textarea>
                            </div>
                            <div>
                                <label style="font-size:0.58rem; color:var(--text-muted); display:block; margin-bottom:3px;">Suspended Message</label>
                                <textarea id="msgSuspended" class="amount-input" rows="1" style="width:100%; text-align:left;" oninput="updateLivePreview()">Your account is restricted from claiming wagers rewards.</textarea>
                            </div>
                            <div>
                                <label style="font-size:0.58rem; color:var(--text-muted); display:block; margin-bottom:3px;">Fraud Message</label>
                                <textarea id="msgFraud" class="amount-input" rows="1" style="width:100%; text-align:left;" oninput="updateLivePreview()">Suspicious behavior detected. Safety block activated.</textarea>
                            </div>
                            <div>
                                <label style="font-size:0.58rem; color:var(--text-muted); display:block; margin-bottom:3px;">System Error Message</label>
                                <textarea id="msgSysError" class="amount-input" rows="1" style="width:100%; text-align:left;" oninput="updateLivePreview()">Wager engine validation error. Try again.</textarea>
                            </div>
                        </div>
                    </details>

                    <!-- 2. Collapsible Section: Eligibility Rules -->
                    <details style="border: 1px solid var(--sa-border); border-radius: var(--radius-sm); background: #F8FAFC;">
                        <summary style="font-size: 0.72rem; font-weight: 700; padding: 10px; cursor: pointer; user-select: none; color: var(--sa-text-secondary); text-transform: uppercase;">🎯 Eligibility Criteria</summary>
                        <div style="padding: 10px; display: flex; flex-direction: column; gap: 8px; border-top: 1px solid var(--sa-border);">
                            <label style="display:flex; align-items:center; gap:8px; font-size:0.75rem; color:var(--text-secondary); cursor:pointer;">
                                <input type="checkbox" id="ruleActivePlayers" style="width:15px; height:15px; accent-color:var(--sa-text-primary);"> Active Aviator Players Only
                            </label>
                            <label style="display:flex; align-items:center; gap:8px; font-size:0.75rem; color:var(--text-secondary); cursor:pointer;">
                                <input type="checkbox" id="ruleNewUsers" style="width:15px; height:15px; accent-color:var(--sa-text-primary);"> New Signups Only
                            </label>
                            <label style="display:flex; align-items:center; gap:8px; font-size:0.75rem; color:var(--text-secondary); cursor:pointer;">
                                <input type="checkbox" id="ruleExistingUsers" style="width:15px; height:15px; accent-color:var(--sa-text-primary);"> Existing Users Only
                            </label>
                            <label style="display:flex; align-items:center; gap:8px; font-size:0.75rem; color:var(--text-secondary); cursor:pointer;">
                                <input type="checkbox" id="rulePhoneVerified" style="width:15px; height:15px; accent-color:var(--sa-text-primary);"> Safe/Verified Mobile Only
                            </label>
                            <label style="display:flex; align-items:center; gap:8px; font-size:0.75rem; color:var(--text-secondary); cursor:pointer;">
                                <input type="checkbox" id="ruleEmailVerified" style="width:15px; height:15px; accent-color:var(--sa-text-primary);"> Verified Email Required
                            </label>
                            <label style="display:flex; align-items:center; gap:8px; font-size:0.75rem; color:var(--text-secondary); cursor:pointer;">
                                <input type="checkbox" id="ruleAccountActive" checked style="width:15px; height:15px; accent-color:var(--sa-text-primary);"> Must Not Be Frozen
                            </label>
                            
                            <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-top:8px;">
                                <div>
                                    <label style="font-size:0.58rem; color:var(--text-muted); display:block; margin-bottom:3px;">Min Games Played</label>
                                    <input type="number" id="ruleMinGames" class="amount-input" value="0" min="0" style="width:100%; text-align:left;">
                                </div>
                                <div>
                                    <label style="font-size:0.58rem; color:var(--text-muted); display:block; margin-bottom:3px;">Min Total Bets (KES)</label>
                                    <input type="number" id="ruleMinBets" class="amount-input" value="0" min="0" style="width:100%; text-align:left;">
                                </div>
                            </div>
                            <div>
                                <label style="font-size:0.58rem; color:var(--text-muted); display:block; margin-bottom:3px;">Min Account Age (Days)</label>
                                <input type="number" id="ruleMinAge" class="amount-input" value="0" min="0" style="width:100%; text-align:left;">
                            </div>
                        </div>
                    </details>

                    <!-- 3. Collapsible Section: Claim Timing & Limits -->
                    <details style="border: 1px solid var(--sa-border); border-radius: var(--radius-sm); background: #F8FAFC;">
                        <summary style="font-size: 0.72rem; font-weight: 700; padding: 10px; cursor: pointer; user-select: none; color: var(--sa-text-secondary); text-transform: uppercase;">📅 Claim Timing & Limits</summary>
                        <div style="padding: 10px; display: flex; flex-direction: column; gap: 8px; border-top: 1px solid var(--sa-border);">
                            <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
                                <div>
                                    <label style="font-size:0.58rem; color:var(--text-muted); display:block; margin-bottom:3px;">Start Time</label>
                                    <input type="datetime-local" id="campaignStartDate" class="amount-input" style="width:100%; text-align:left;">
                                </div>
                                <div>
                                    <label style="font-size:0.58rem; color:var(--text-muted); display:block; margin-bottom:3px;">End Time</label>
                                    <input type="datetime-local" id="campaignEndDate" class="amount-input" style="width:100%; text-align:left;">
                                </div>
                            </div>
                            <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
                                <div>
                                    <label style="font-size:0.58rem; color:var(--text-muted); display:block; margin-bottom:3px;">Claims per User</label>
                                    <input type="number" id="campaignMaxUserClaims" class="amount-input" value="1" min="1" style="width:100%; text-align:left;">
                                </div>
                                <div>
                                    <label style="font-size:0.58rem; color:var(--text-muted); display:block; margin-bottom:3px;">Max Claims / Day</label>
                                    <input type="number" id="campaignMaxDailyClaims" class="amount-input" value="0" min="0" placeholder="0 = unlimited" style="width:100%; text-align:left;">
                                </div>
                            </div>
                        </div>
                    </details>

                    <!-- 4. Collapsible Section: Advanced Controls -->
                    <details style="border: 1px solid var(--sa-border); border-radius: var(--radius-sm); background: #F8FAFC;">
                        <summary style="font-size: 0.72rem; font-weight: 700; padding: 10px; cursor: pointer; user-select: none; color: var(--sa-text-secondary); text-transform: uppercase;">🛡️ Advanced Controls</summary>
                        <div style="padding: 10px; display: flex; flex-direction: column; gap: 8px; border-top: 1px solid var(--sa-border);">
                            <label style="display:flex; align-items:center; gap:8px; font-size:0.75rem; color:var(--text-secondary); cursor:pointer;">
                                <input type="checkbox" id="campaignAutoWinnerLimit" checked style="width:15px; height:15px; accent-color:var(--sa-text-primary);"> Auto-Disable on winner limit
                            </label>
                            <label style="display:flex; align-items:center; gap:8px; font-size:0.75rem; color:var(--text-secondary); cursor:pointer;">
                                <input type="checkbox" id="campaignAutoEndDate" checked style="width:15px; height:15px; accent-color:var(--sa-text-primary);"> Auto-Disable after End Date
                            </label>
                        </div>
                    </details>
                </div>

                <button class="big-bet-btn" onclick="openConfirmationModal()" style="width:100%; height:40px; margin:0; border-radius:var(--radius-sm);">
                    🛡️ PUBLISH CAMPAIGN PROMOTION
                </button>
            </div>

            <!-- Preview Card -->
            <div style="background:var(--bg-surface); border:1px solid var(--border); border-radius:var(--radius-md); padding:20px; display:flex; flex-direction:column; gap:14px; position:sticky; top:20px;">
                <h3 style="font-size:0.95rem; font-weight:800; color:var(--text-primary); margin:0; display:flex; align-items:center; justify-content:space-between;">
                    <span>👁️ Live User Preview</span>
                    <span style="font-size:0.65rem; background:#F0FDF4; color:#166534; border:1px solid #BBF7D0; padding:2px 8px; border-radius:4px; font-weight:600;">REAL-TIME</span>
                </h3>
                
                <div id="previewCard" style="border:1px solid var(--border); border-radius:var(--radius-sm); overflow:hidden; background:var(--bg-base);">
                    <div id="previewBannerWrap" style="width:100%; height:110px; background:#F1F5F9; display:flex; justify-content:center; align-items:center;">
                        <span id="previewNoImage" style="font-size:0.65rem; color:var(--text-muted);">No Banner URL Provided</span>
                        <img id="previewImageEl" src="" style="width:100%; height:110px; object-fit:cover; display:none;">
                    </div>
                    <div style="padding:12px; display:flex; flex-direction:column; gap:6px;">
                        <div id="previewTitle" style="font-weight:700; font-size:0.85rem; color:var(--text-primary);">Wager Bonus Campaign</div>
                        <div id="previewDesc" style="font-size:0.7rem; color:var(--text-muted); line-height:1.3;">Promotion terms info wagers wagers...</div>
                        <button id="previewCtaButton" style="width:100%; padding:8px; border-radius:var(--radius-xs); border:none; background:#0F172A; color:#FFFFFF; font-weight:600; font-size:0.72rem; cursor:not-allowed; text-transform:uppercase; margin-top:4px;">
                            Play Now
                        </button>
                    </div>
                </div>

                <div id="previewSimulatorWrap" style="display:none; flex-direction:column; gap:10px;">
                    <hr style="border:none; border-top:1px solid var(--border); margin:0;">

                    <div>
                        <label style="font-size:0.58rem; color:var(--text-muted); display:block; margin-bottom:4px;">⚠️ REDEMPTION ALERT SIMULATOR</label>
                        <select id="previewOutcomeSelect" class="amount-input" style="width:100%; cursor:pointer; text-align:left;" onchange="simulateRedemptionOutcome(this.value)">
                            <option value="success">✅ Success Message</option>
                            <option value="invalid">❌ Wrong Promo Code</option>
                            <option value="not_eligible">⚠️ Not Eligible</option>
                            <option value="already_claimed">🔄 Already Claimed</option>
                            <option value="expired">🕒 Campaign Expired</option>
                            <option value="not_started">🚫 Campaign Not Started</option>
                            <option value="reward_limit">⛔ Reward Limit Reached</option>
                            <option value="suspended">🔒 Account Suspended</option>
                            <option value="fraud">🚨 Fraud / VPN Lockout</option>
                            <option value="sys_error">🔌 System Error</option>
                        </select>
                    </div>

                    <div id="previewOutcomeAlertBox" style="padding:10px; border-radius:var(--radius-xs); font-size:0.72rem; line-height:1.3; border:1px solid; display:flex; align-items:center; gap:6px;">
                        <div id="previewAlertText">Outcome Alert message simulated here...</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- 5. Active Promotions statistics section -->
        <div class="section-title">Active Promotion Campaigns / Performance Analytics (${promos.length})</div>
        <div style="display:flex; flex-direction:column; gap:16px; max-width:1200px;">
            ${promos.length === 0
                ? `<div style="color:var(--text-muted); font-size:0.8rem; padding:24px; text-align:center; background:var(--bg-surface); border:1px solid var(--border); border-radius:var(--radius-md);">No active promotions. Add one above.</div>`
                : promos.map(p => {
                    const attempts = (p.stats_successful_claims || 0) + (p.stats_incorrect_codes || 0) + (p.stats_already_claimed || 0) + (p.stats_expired_attempts || 0) + (p.stats_not_eligible_attempts || 0) + (p.stats_fraud_attempts || 0);
                    const conversionRate = attempts > 0 ? ((p.stats_successful_claims || 0) / attempts * 100).toFixed(1) + '%' : '0.0%';
                    return `
                    <div style="background:var(--bg-surface); border:1px solid var(--border); border-radius:var(--radius-md); overflow:hidden;">
                        ${p.image_url ? `<img src="${p.image_url}" style="width:100%; height:130px; object-fit:cover; display:block;" onerror="this.style.display='none'">` : ''}
                        <div style="padding:16px;">
                            <div style="display:flex; justify-content:space-between; align-items:start; margin-bottom:6px; flex-wrap:wrap; gap:8px;">
                                <div style="font-weight:900; font-size:0.95rem; color:var(--text-primary);">${p.title}</div>
                                <span class="status-pill ${p.status === 'active' ? 'status-approved' : p.status === 'Draft' ? 'status-pending' : 'status-rejected'}" style="font-size:0.65rem; padding:2px 8px; text-transform:uppercase;">
                                    ${p.status || 'Active'}
                                </span>
                            </div>
                            <div style="font-size:0.75rem; color:var(--text-muted); margin-bottom:12px;">${p.description || ''}</div>
                            
                            <!-- Display Live Statistics grid -->
                            <div style="background:#F8FAFC; border:1px solid var(--sa-border); border-radius:6px; padding:12px; margin-bottom:14px;">
                                <div style="font-size:0.6rem; color:var(--text-muted); font-weight:800; text-transform:uppercase; margin-bottom:8px; display:flex; justify-content:space-between; align-items:center;">
                                    <span>📊 Campaign Marketing Insights</span>
                                    <span style="color:var(--text-secondary)">Total Interactions: ${attempts}</span>
                                </div>
                                <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(130px, 1fr)); gap:8px;">
                                    <div style="font-size:0.68rem; color:var(--text-secondary);">
                                        <div style="color:var(--text-muted); font-size:0.55rem; text-transform:uppercase;">Claims</div>
                                        <span style="color:var(--success); font-weight:bold;">${p.stats_successful_claims || 0}</span>
                                    </div>
                                    <div style="font-size:0.68rem; color:var(--text-secondary);">
                                        <div style="color:var(--text-muted); font-size:0.55rem; text-transform:uppercase;">Remaining</div>
                                        <span style="color:var(--blue); font-weight:bold;">${p.remaining_rewards !== null ? p.remaining_rewards : (p.max_winners || '∞')}</span>
                                    </div>
                                    <div style="font-size:0.68rem; color:var(--text-secondary);">
                                        <div style="color:var(--text-muted); font-size:0.55rem; text-transform:uppercase;">Incorrect Codes</div>
                                        <span style="color:var(--error); font-weight:bold;">${p.stats_incorrect_codes || 0}</span>
                                    </div>
                                    <div style="font-size:0.68rem; color:var(--text-secondary);">
                                        <div style="color:var(--text-muted); font-size:0.55rem; text-transform:uppercase;">Double claims</div>
                                        <span style="color:var(--text-muted); font-weight:bold;">${p.stats_already_claimed || 0}</span>
                                    </div>
                                    <div style="font-size:0.68rem; color:var(--text-secondary);">
                                        <div style="color:var(--text-muted); font-size:0.55rem; text-transform:uppercase;">Wagers failure</div>
                                        <span style="color:var(--warning); font-weight:bold;">${p.stats_not_eligible_attempts || 0}</span>
                                    </div>
                                    <div style="font-size:0.68rem; color:var(--text-secondary);">
                                        <div style="color:var(--text-muted); font-size:0.55rem; text-transform:uppercase;">Fraud (IP Block)</div>
                                        <span style="color:var(--error); font-weight:bold;">${p.stats_fraud_attempts || 0}</span>
                                    </div>
                                    <div style="font-size:0.68rem; color:var(--text-secondary);">
                                        <div style="color:var(--text-muted); font-size:0.55rem; text-transform:uppercase;">Distributed Cash</div>
                                        <span style="color:var(--success); font-weight:bold;">KES ${parseFloat(p.stats_wallet_distributed || 0).toLocaleString()}</span>
                                    </div>
                                    <div style="font-size:0.68rem; color:var(--text-secondary);">
                                        <div style="color:var(--text-muted); font-size:0.55rem; text-transform:uppercase;">Conversion rate</div>
                                        <span style="color:var(--sa-text-primary); font-weight:bold;">${conversionRate}</span>
                                    </div>
                                </div>
                            </div>
                            
                            <div style="display:flex; justify-content:space-between; align-items:center;">
                                <span class="status-pill status-approved" style="padding:4px 12px; font-size:0.7rem; font-weight:bold;">
                                    ${ACTION_TYPES[p.action_type]?.label || p.action_type || 'Play Now'} 
                                    ${p.promo_code ? `: ${p.promo_code}` : ''}
                                </span>
                                <div style="display:flex; gap:8px;">
                                    ${p.featured ? `<span style="font-size:0.6rem; border:1px solid rgba(88,86,214,0.3); color:#5856d6; background:rgba(88,86,214,0.1); padding:2px 8px; border-radius:3px; font-weight:bold; display:flex; align-items:center;">FEATURED</span>` : ''}
                                    <button onclick="deletePromotion('${p.id}')" class="danger-btn" style="width:auto; padding:5px 14px; font-size:0.7rem; margin:0;">🗑 DELETE</button>
                                </div>
                            </div>
                        </div>
                    </div>`;
                }).join('')}
        </div>

        <!-- 6. Confirmation Verification Modal -->
        <div id="confirmModalBackdrop" style="display:none; position:fixed; top:0; left:0; right:0; bottom:0; background:rgba(15, 23, 42, 0.45); z-index:1000; justify-content:center; align-items:center; padding:20px; backdrop-filter:blur(4px);">
            <div style="background:#FFFFFF; border:1px solid var(--sa-border); border-radius:var(--radius-md); padding:24px; max-width:550px; width:100%; display:flex; flex-direction:column; gap:16px; box-shadow:var(--shadow-xl);">
                <h2 style="font-size:1.1rem; font-weight:700; color:var(--text-primary); margin:0; border-bottom:1px solid var(--sa-border); padding-bottom:10px;">
                    🛡️ Verify Campaign parameters
                </h2>
                <p style="font-size:0.72rem; color:var(--text-muted); margin:0;">Please audit the promotion settings before publishing to the live server:</p>
                
                <div id="confirmDetailsContent" style="display:flex; flex-direction:column; gap:10px; max-height:280px; overflow-y:auto; font-size:0.72rem;">
                    <!-- Filled dynamically -->
                </div>

                <div style="display:flex; justify-content:flex-end; gap:10px; border-top:1px solid var(--sa-border); padding-top:14px; margin-top:4px;">
                    <button onclick="closeConfirmationModal()" class="sa-topbar-btn" style="padding:6px 14px;">
                        ← Cancel
                    </button>
                    <button onclick="confirmedSubmitPromotion()" class="big-bet-btn" style="width:auto; margin:0; padding:6px 18px;">
                        Publish Campaign ✓
                    </button>
                </div>
            </div>
        </div>
    `;

    // Initialize instant live layout updates
    setTimeout(() => {
        const selectEl = document.getElementById('promoActionType');
        if (selectEl) window.toggleCustomUrl(selectEl.value);
        window.updateLivePreview();
    }, 20);
}

window.toggleCustomUrl = (val) => {
    const wrap = document.getElementById('customUrlWrap');
    const label = document.getElementById('promoUrlLabel');
    const input = document.getElementById('promoActionUrl');
    const specs = document.getElementById('promoClaimSpecsWrap');
    const extraConfigs = document.getElementById('promoCodeExtraConfigs');
    const simWrap = document.getElementById('previewSimulatorWrap');
    
    if (val === 'external' || val === 'claim') {
        if (wrap) wrap.style.display = 'block';
        if (val === 'claim') {
            if (label) label.textContent = 'Promo Code Name';
            if (input) {
                input.placeholder = 'e.g. WELCOME100';
                input.style.textTransform = 'uppercase';
            }
            if (specs) specs.style.display = 'flex';
        } else {
            if (label) label.textContent = 'External URL Link';
            if (input) {
                input.placeholder = 'https://...';
                input.style.textTransform = 'none';
            }
            if (specs) specs.style.display = 'none';
        }
    } else {
        if (wrap) wrap.style.display = 'none';
        if (specs) specs.style.display = 'none';
    }

    if (val === 'claim') {
        if (extraConfigs) {
            extraConfigs.style.display = 'flex';
            setTimeout(() => { extraConfigs.style.opacity = '1'; }, 10);
        }
        if (simWrap) simWrap.style.display = 'flex';
    } else {
        if (extraConfigs) {
            extraConfigs.style.display = 'none';
            extraConfigs.style.opacity = '0';
        }
        if (simWrap) simWrap.style.display = 'none';
    }
};

window.updateLivePreview = () => {
    const titleVal = document.getElementById('promoTitle')?.value?.trim() || 'SAMPLE CAMPAIGN TITLE';
    const descVal = document.getElementById('promoDesc')?.value?.trim() || 'Promotional guidelines, wagering multiplier caps, and details go here.';
    const imgUrl = document.getElementById('promoImage')?.value?.trim();
    const actionType = document.getElementById('promoActionType')?.value;
    const actionUrl = document.getElementById('promoActionUrl')?.value?.trim();
    
    const titleEl = document.getElementById('previewTitle');
    const descEl = document.getElementById('previewDesc');
    const imgEl = document.getElementById('previewImageEl');
    const noImgEl = document.getElementById('previewNoImage');
    const ctaBtn = document.getElementById('previewCtaButton');

    if (titleEl) titleEl.textContent = titleVal;
    if (descEl) descEl.textContent = descVal;

    if (imgUrl) {
        if (imgEl) { imgEl.src = imgUrl; imgEl.style.display = 'block'; }
        if (noImgEl) noImgEl.style.display = 'none';
    } else {
        if (imgEl) imgEl.style.display = 'none';
        if (noImgEl) noImgEl.style.display = 'block';
    }

    if (ctaBtn) {
        if (actionType === 'play') ctaBtn.textContent = '▶ Play Now';
        else if (actionType === 'deposit') ctaBtn.textContent = '💰 Deposit Now';
        else if (actionType === 'refer') ctaBtn.textContent = '🤝 Refer Friends';
        else if (actionType === 'external') ctaBtn.textContent = '🔗 Learn More';
        else if (actionType === 'claim') {
            ctaBtn.textContent = `Claim: ${actionUrl || '...'}`;
        }
    }

    const select = document.getElementById('previewOutcomeSelect');
    if (select) window.simulateRedemptionOutcome(select.value);
};

window.simulateRedemptionOutcome = (outcome) => {
    const textEl = document.getElementById('previewAlertText');
    const alertBox = document.getElementById('previewOutcomeAlertBox');
    if (!textEl || !alertBox) return;

    let text = '';
    let bgColor = '';
    let borderColor = '';
    let color = '';

    const claimAmt = document.getElementById('promoClaimAmount')?.value || '50';

    switch (outcome) {
        case 'success':
            text = document.getElementById('msgSuccess')?.value?.trim() || 'Reward credited successfully!';
            bgColor = 'rgba(34, 197, 94, 0.08)';
            borderColor = 'rgba(34, 197, 94, 0.4)';
            color = 'var(--success)';
            break;
        case 'invalid':
            text = document.getElementById('msgInvalid')?.value?.trim() || 'The promo code entered is invalid.';
            bgColor = 'rgba(239, 68, 68, 0.08)';
            borderColor = 'rgba(239, 68, 68, 0.4)';
            color = 'var(--error)';
            break;
        case 'not_eligible':
            text = document.getElementById('msgNotEligible')?.value?.trim() || 'You are not eligible for this promotion.';
            bgColor = 'rgba(249, 115, 22, 0.08)';
            borderColor = 'rgba(249, 115, 22, 0.4)';
            color = '#f97316';
            break;
        case 'already_claimed':
            text = document.getElementById('msgAlreadyClaimed')?.value?.trim() || 'You have already claimed this promotion.';
            bgColor = 'rgba(234, 179, 8, 0.08)';
            borderColor = 'rgba(234, 179, 8, 0.4)';
            color = 'var(--warning)';
            break;
        case 'expired':
            text = document.getElementById('msgExpired')?.value?.trim() || 'This promotion has expired.';
            bgColor = 'rgba(234, 179, 8, 0.08)';
            borderColor = 'rgba(234, 179, 8, 0.4)';
            color = 'var(--warning)';
            break;
        case 'not_started':
            text = document.getElementById('msgNotStarted')?.value?.trim() || 'This promotion has not started yet.';
            bgColor = 'rgba(234, 179, 8, 0.08)';
            borderColor = 'rgba(234, 179, 8, 0.4)';
            color = 'var(--warning)';
            break;
        case 'reward_limit':
            text = document.getElementById('msgRewardLimit')?.value?.trim() || 'This promotion has reached its maximum claim limit.';
            bgColor = 'rgba(249, 115, 22, 0.08)';
            borderColor = 'rgba(249, 115, 22, 0.4)';
            color = '#f97316';
            break;
        case 'suspended':
            text = document.getElementById('msgSuspended')?.value?.trim() || 'Your account is suspended.';
            bgColor = 'rgba(239, 68, 68, 0.08)';
            borderColor = 'rgba(239, 68, 68, 0.4)';
            color = 'var(--error)';
            break;
        case 'fraud':
            text = document.getElementById('msgFraud')?.value?.trim() || 'Suspicious activity detected. Action blocked.';
            bgColor = 'rgba(239, 68, 68, 0.08)';
            borderColor = 'rgba(239, 68, 68, 0.4)';
            color = 'var(--error)';
            break;
        case 'sys_error':
            text = document.getElementById('msgSysError')?.value?.trim() || 'A system error occurred. Please try again later.';
            bgColor = 'rgba(239, 68, 68, 0.08)';
            borderColor = 'rgba(239, 68, 68, 0.4)';
            color = 'var(--error)';
            break;
    }

    textEl.innerHTML = text.replace('{amount}', claimAmt);
    alertBox.style.backgroundColor = bgColor;
    alertBox.style.borderColor = borderColor;
    alertBox.style.color = color;
};

window.openConfirmationModal = () => {
    const title = document.getElementById('promoTitle').value.trim();
    if (!title) { alert('Please enter a promotion title.'); return; }

    const action_type = document.getElementById('promoActionType').value;
    const action_url = document.getElementById('promoActionUrl')?.value?.trim();
    if (action_type === 'claim' && !action_url) {
        alert('Please enter a promo code.');
        return;
    }

    const ruleActivePlayers = document.getElementById('ruleActivePlayers').checked;
    const ruleNewUsers = document.getElementById('ruleNewUsers').checked;
    const ruleExistingUsers = document.getElementById('ruleExistingUsers').checked;
    const rulePhoneVerified = document.getElementById('rulePhoneVerified').checked;
    const ruleEmailVerified = document.getElementById('ruleEmailVerified').checked;
    const ruleAccountActive = document.getElementById('ruleAccountActive').checked;
    
    const ruleMinGames = parseInt(document.getElementById('ruleMinGames').value || 0, 10);
    const ruleMinBets = parseFloat(document.getElementById('ruleMinBets').value || 0);
    const ruleMinAge = parseInt(document.getElementById('ruleMinAge').value || 0, 10);

    const status = document.getElementById('campaignStatus').value;
    const amountVal = parseFloat(document.getElementById('promoClaimAmount').value || 0);
    const maxUsesVal = parseInt(document.getElementById('promoClaimMaxUses').value || 0, 10);

    const auditHtml = `
        <div style="background:var(--bg-elevated); padding:10px; border-radius:4px; border:1px solid var(--border); display:flex; flex-direction:column; gap:6px; margin-bottom:10px;">
            <div><strong>📌 Title:</strong> ${title}</div>
            <div><strong>📢 Action Profile:</strong> ${action_type.toUpperCase()} ${action_url ? `(${action_url})` : ''}</div>
            ${action_type === 'claim' ? `
                <div><strong>💰 Reward Multiplier:</strong> KES ${amountVal.toLocaleString()}</div>
                <div><strong>👥 Winner cap allocations:</strong> ${maxUsesVal > 0 ? maxUsesVal.toLocaleString() : 'Unlimited'}</div>
            ` : ''}
            <div><strong>🟢 Status:</strong> ${status.toUpperCase()}</div>
        </div>
        
        ${action_type === 'claim' ? `
        <div>
            <strong>🎯 Targets Constraint checks:</strong>
            <ul style="margin:4px 0 0 14px; padding:0; display:flex; flex-direction:column; gap:2px; list-style-type:square;">
                <li>Aviator Action: ${ruleActivePlayers ? 'Active Players Only' : 'All users eligible'}</li>
                <li>User Type: ${ruleNewUsers ? 'New Signups Only' : ruleExistingUsers ? 'Existing Active players' : 'All players'}</li>
                <li>Phone Verification: ${rulePhoneVerified ? 'Required' : 'No constraint Check'}</li>
                <li>Email Verification: ${ruleEmailVerified ? 'Required' : 'No constraint Check'}</li>
                <li>Must Not Be Frozen: ${ruleAccountActive ? 'Yes' : 'No'}</li>
                ${ruleMinGames > 0 ? `<li>Min Games: ${ruleMinGames} games played</li>` : ''}
                ${ruleMinBets > 0 ? `<li>Min Bets: KES ${ruleMinBets.toLocaleString()} wagers</li>` : ''}
                ${ruleMinAge > 0 ? `<li>Min Account Age: ${ruleMinAge} days</li>` : ''}
            </ul>
        </div>
        ` : ''}
    `;

    document.getElementById('confirmDetailsContent').innerHTML = auditHtml;
    document.getElementById('confirmModalBackdrop').style.display = 'flex';
};

window.closeConfirmationModal = () => {
    document.getElementById('confirmModalBackdrop').style.display = 'none';
};

window.confirmedSubmitPromotion = async () => {
    document.getElementById('confirmModalBackdrop').style.display = 'none';

    const title = document.getElementById('promoTitle').value.trim();
    const description = document.getElementById('promoDesc').value.trim();
    const image_url = document.getElementById('promoImage').value.trim();
    const action_type = document.getElementById('promoActionType').value;
    const customUrl = document.getElementById('promoActionUrl')?.value?.trim();
    
    let action_url = action_type === 'external' ? customUrl : (ACTION_TYPES[action_type]?.url || '/');
    let rewardVal = action_type === 'claim' ? parseFloat(document.getElementById('promoClaimAmount').value) : null;
    let maxWinnersVal = action_type === 'claim' ? parseInt(document.getElementById('promoClaimMaxUses').value) : null;

    if (action_type === 'claim') {
        action_url = customUrl;
    }

    const isClaim = action_type === 'claim';

    const payload = {
        title,
        description,
        image_url,
        action_type,
        action_url,
        promo_code: isClaim ? customUrl : null,
        reward_per_winner: isClaim ? rewardVal : null,
        max_winners: isClaim ? maxWinnersVal : null,
        
        success_message: isClaim ? document.getElementById('msgSuccess').value.trim() : null,
        invalid_code_message: isClaim ? document.getElementById('msgInvalid').value.trim() : null,
        not_eligible_message: isClaim ? document.getElementById('msgNotEligible').value.trim() : null,
        already_claimed_message: isClaim ? document.getElementById('msgAlreadyClaimed').value.trim() : null,
        promotion_expired_message: isClaim ? document.getElementById('msgExpired').value.trim() : null,
        promotion_not_started_message: isClaim ? document.getElementById('msgNotStarted').value.trim() : null,
        reward_limit_message: isClaim ? document.getElementById('msgRewardLimit').value.trim() : null,
        account_suspended_message: isClaim ? document.getElementById('msgSuspended').value.trim() : null,
        fraud_message: isClaim ? document.getElementById('msgFraud').value.trim() : null,
        system_error_message: isClaim ? document.getElementById('msgSysError').value.trim() : null,

        active_players_only: isClaim ? document.getElementById('ruleActivePlayers').checked : false,
        new_users_only: isClaim ? document.getElementById('ruleNewUsers').checked : false,
        existing_users_only: isClaim ? document.getElementById('ruleExistingUsers').checked : false,
        phone_verification_required: isClaim ? document.getElementById('rulePhoneVerified').checked : false,
        email_verification_required: isClaim ? document.getElementById('ruleEmailVerified').checked : false,
        account_must_be_active: isClaim ? document.getElementById('ruleAccountActive').checked : false,
        minimum_games: isClaim ? parseInt(document.getElementById('ruleMinGames').value || 0, 10) : 0,
        minimum_total_bets: isClaim ? parseFloat(document.getElementById('ruleMinBets').value || 0) : 0,
        minimum_account_age: isClaim ? parseInt(document.getElementById('ruleMinAge').value || 0, 10) : 0,

        status: document.getElementById('campaignStatus').value,
        start_date: isClaim ? (document.getElementById('campaignStartDate').value || null) : null,
        end_date: isClaim ? (document.getElementById('campaignEndDate').value || null) : null,
        max_claims_per_user: isClaim ? parseInt(document.getElementById('campaignMaxUserClaims').value || 1, 10) : 1,
        max_daily_claims: isClaim ? parseInt(document.getElementById('campaignMaxDailyClaims').value || 0, 10) : 0,

        featured: document.getElementById('campaignFeatured').checked,
        auto_disable_winner_limit: isClaim ? document.getElementById('campaignAutoWinnerLimit').checked : false,
        auto_disable_end_date: isClaim ? document.getElementById('campaignAutoEndDate').checked : false,
        priority: parseInt(document.getElementById('campaignPriority').value || 0, 10)
    };

    if (action_type === 'claim') {
        try {
            const { data: { session } } = await supabase.auth.getSession();
            const promoRes = await fetch('/api/admin/promocodes?action=create', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${session.access_token}` },
                body: JSON.stringify({ code: customUrl, amount: rewardVal, max_uses: maxWinnersVal })
            });
            const promoResult = await promoRes.json();
            if (!promoRes.ok && promoResult.error !== 'Promo code already exists. Please choose a unique code.') {
                console.warn(`Promo Sync Warn: ${promoResult.error}`);
            }
        } catch (e) {
            console.warn(`Promo Sync Net Warn: ${e.message}`);
        }
    }

    try {
        const { data: { session } } = await supabase.auth.getSession();
        const res = await fetch('/api/admin/content?action=create_promotion', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${session.access_token}` },
            body: JSON.stringify(payload)
        });
        const result = await res.json();
        if (result.success) {
            alert('✓ Campaign published successfully!');
            switchTab('promotions');
        } else {
            alert(`Error: ${result.error}`);
        }
    } catch (e) {
        alert(`Error: ${e.message}`);
    }
};

window.deletePromotion = async (id) => {
    if (!confirm('Are you sure you want to delete this campaign?')) return;
    try {
        const { data: { session } } = await supabase.auth.getSession();
        const res = await fetch('/api/admin/content?action=delete_promotion', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${session.access_token}` },
            body: JSON.stringify({ id })
        });
        const result = await res.json();
        if (result.success) switchTab('promotions');
        else alert(`Error deleting campaign: ${result.error}`);
    } catch (e) {
        alert(`Error: ${e.message}`);
    }
};

// ── PROMO CODES TAB ──────────────────────────────────────────────────────────
function renderPromocodes(promocodes) {
    const el = document.getElementById('adminContent');
    el.innerHTML = `
        <div class="pane-header">
            <h1>Promo Codes Manager</h1>
            <p>Generate secure promo codes that players can claim for direct balance credits.</p>
        </div>
        <div style="background:var(--bg-surface); border:1px solid var(--border); border-radius:var(--radius-md); padding:24px; max-width:680px; margin-bottom:28px;">
            <h3 style="font-size:0.9rem; font-weight:800; margin-bottom:16px;">➕ Generate New Promo Code</h3>
            <div style="display:flex; flex-direction:column; gap:12px;">
                <div>
                    <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:4px;">Unique Code</label>
                    <input id="promoCodeStr" class="amount-input" placeholder="e.g. WELCOME200" style="width:100%; text-align:left; text-transform: uppercase;">
                </div>
                <div style="display:flex; gap:12px; flex-wrap:wrap;">
                    <div style="flex:1; min-width:180px;">
                        <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:4px;">Credit Amount (KES)</label>
                        <input id="promoCodeAmount" type="number" class="amount-input" placeholder="e.g. 100" min="1" step="any" style="width:100%; text-align:left;">
                    </div>
                    <div style="flex:1; min-width:180px;">
                        <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:4px;">Max Allowed Claims</label>
                        <input id="promoCodeMaxUses" type="number" class="amount-input" placeholder="e.g. 50" min="1" style="width:100%; text-align:left;">
                    </div>
                </div>
                <div style="display:flex; align-items:center; gap:8px; margin:4px 0 8px 0;">
                    <input id="promoCodeRequireDeposit" type="checkbox" style="width:16px; height:16px; cursor:pointer; accent-color:var(--blue);">
                    <label for="promoCodeRequireDeposit" style="font-size:0.75rem; color:var(--text-primary); font-weight:600; cursor:pointer;">Require at least 1 deposit ever to claim this promo code</label>
                </div>
                <button class="big-bet-btn" onclick="submitPromoCode()" style="width:auto; align-self:flex-start; height:38px; padding:0 24px; margin:0; border-radius:var(--radius-sm);">
                    GENERATE PROMO CODE
                </button>
            </div>
        </div>
        
        <div class="section-title">Active Promo Codes (${promocodes.length})</div>
        <div class="audit-table-wrap" style="max-width:680px;">
            <table class="audit-table">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Amount</th>
                        <th>Claims / Limit</th>
                        <th>Created At</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    ${promocodes.length === 0 
                        ? `<tr><td colspan="5" style="text-align:center; padding:24px; color:var(--text-muted);">No promo codes active yet. Generate one above.</td></tr>` 
                        : promocodes.map(pc => `
                        <tr>
                            <td><span style="font-family:var(--font-mono, monospace); font-weight:600; color:var(--sa-text-primary); letter-spacing:0.5px;">${pc.code}</span></td>
                            <td>KES ${parseFloat(pc.amount).toFixed(2)}</td>
                            <td>
                                <span class="status-pill ${pc.current_uses >= pc.max_uses ? 'status-rejected' : 'status-pending'}" style="font-size:0.75rem; font-family:monospace; font-weight:bold; padding:2px 8px;">
                                    ${pc.current_uses} / ${pc.max_uses}
                                </span>
                                ${pc.require_deposit ? `<span class="status-pill" style="font-size:0.65rem; font-family:monospace; font-weight:600; padding:2px 6px; margin-left:6px; background:#F1F5F9; color:#475569; border:1px solid #CBD5E1;">DEP ONLY</span>` : ''}
                            </td>
                            <td><span class="time-tag">${new Date(pc.created_at).toLocaleString()}</span></td>
                            <td>
                                <button onclick="deletePromoCode('${pc.id}')" class="danger-btn" style="width:auto; padding:3px 10px; font-size:0.65rem; margin:0;">🗑 REVOKE</button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
}

window.submitPromoCode = async () => {
    const code = document.getElementById('promoCodeStr').value.trim().toUpperCase();
    const amountVal = document.getElementById('promoCodeAmount').value;
    const maxUsesVal = document.getElementById('promoCodeMaxUses').value;
    const require_deposit = document.getElementById('promoCodeRequireDeposit').checked;

    if (!code || !amountVal || !maxUsesVal) {
        alert('Please fill out all fields.');
        return;
    }

    const amount = parseFloat(amountVal);
    const max_uses = parseInt(maxUsesVal);

    if (isNaN(amount) || amount <= 0) {
        alert('Reward amount must be a positive number.');
        return;
    }
    if (isNaN(max_uses) || max_uses <= 0) {
        alert('Max uses must be a positive integer.');
        return;
    }

    try {
        const { data: { session } } = await supabase.auth.getSession();
        const res = await fetch('/api/admin/promocodes?action=create', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json', 
                'Authorization': `Bearer ${session.access_token}` 
            },
            body: JSON.stringify({ code, amount, max_uses, require_deposit })
        });
        const result = await res.json();
        if (result.success) {
            alert('Promo code created successfully!');
            switchTab('promocodes');
        } else {
            alert(`Error: ${result.error}`);
        }
    } catch (e) {
        alert(`Error: ${e.message}`);
    }
};

window.deletePromoCode = async (id) => {
    if (!confirm('Are you sure you want to delete/revoke this promo code? New claims will be blocked.')) return;
    try {
        const { data: { session } } = await supabase.auth.getSession();
        const res = await fetch('/api/admin/promocodes?action=delete', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json', 
                'Authorization': `Bearer ${session.access_token}` 
            },
            body: JSON.stringify({ id })
        });
        const result = await res.json();
        if (result.success) {
            switchTab('promocodes');
        } else {
            alert(`Error: ${result.error}`);
        }
    } catch (e) {
        alert(`Error: ${e.message}`);
    }
};

// ── NOTIFICATIONS TAB ─────────────────────────────────────────────────────────

function renderNotifications() {
    const el = document.getElementById('adminContent');
    el.innerHTML = `
        <div class="pane-header">
            <h1>Communications Center</h1>
            <p>Send system notifications to individual users or broadcast to all players.</p>
        </div>
        <div style="background:var(--bg-surface); border:1px solid var(--border); border-radius:var(--radius-md); padding:24px; max-width:600px; display:flex; flex-direction:column; gap:16px;">
            <div>
                <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:4px;">Notification Title</label>
                <input id="notifTitle" class="amount-input" placeholder="e.g. Platform Maintenance Scheduled" style="width:100%; text-align:left;">
            </div>
            <div>
                <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:4px;">Message Body</label>
                <textarea id="notifMessage" class="amount-input" placeholder="Enter full notification message..." rows="4" style="width:100%; text-align:left; resize:vertical;"></textarea>
            </div>
            <div>
                <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:4px;">Attach Call-To-Action Link (Optional)</label>
                <div style="display:flex; gap:12px; flex-wrap:wrap;">
                    <div style="flex:1; min-width:200px;">
                        <select id="notifLinkType" class="amount-input" style="width:100%; text-align:left; cursor:pointer;" onchange="window.toggleNotifCustomUrl(this.value)">
                            <option value="">🚫 No Link (Text Only)</option>
                            <option value="play">▶ Play Now → Game Board</option>
                            <option value="deposit">💰 Deposit Now → Wallet</option>
                            <option value="refer">🤝 Refer Now → Referral Tab</option>
                            <option value="external">🔗 Custom External URL</option>
                            <option value="claim">🎁 Claim Promo Code</option>
                        </select>
                    </div>
                    <div id="notifCustomUrlWrap" style="flex:1; min-width:200px; display:none;">
                        <label id="notifUrlLabel" style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:4px;">External URL</label>
                        <input id="notifActionUrl" class="amount-input" placeholder="https://..." style="width:100%; text-align:left;">
                    </div>
                </div>
                <div id="notifClaimSpecsWrap" style="display:none; gap:12px; flex-wrap:wrap; margin-top:8px;">
                    <div style="flex:1; min-width:140px;">
                        <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:4px;">Promo Amount (KES)</label>
                        <input type="number" id="notifClaimAmount" class="amount-input" placeholder="e.g. 50" style="width:100%; text-align:left;">
                    </div>
                    <div style="flex:1; min-width:140px;">
                        <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:4px;">No. of Users (Usage Limit)</label>
                        <input type="number" id="notifClaimMaxUses" class="amount-input" placeholder="e.g. 100" style="width:100%; text-align:left;">
                    </div>
                </div>
            </div>
            <div>
                <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:8px;">Target Audience</label>
                <div style="display:flex; gap:18px;">
                    <label style="display:flex; align-items:center; gap:6px; cursor:pointer; color:var(--text-secondary); font-size:0.8rem;">
                        <input type="radio" name="notifTarget" value="broadcast" checked onchange="document.getElementById('notifTargetUser').style.display='none'"> 📢 Broadcast to ALL Users
                    </label>
                    <label style="display:flex; align-items:center; gap:6px; cursor:pointer; color:var(--text-secondary); font-size:0.8rem;">
                        <input type="radio" name="notifTarget" value="targeted" onchange="document.getElementById('notifTargetUser').style.display='block'"> 🎯 Specific User
                    </label>
                </div>
            </div>
            <div id="notifTargetUser" style="display:none;">
                <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:4px;">Target User UUID</label>
                <input id="notifUserId" class="amount-input" placeholder="Paste user UUID here..." style="width:100%; text-align:left;">
            </div>
            <button class="big-bet-btn" onclick="sendNotification()" style="width:auto; align-self:flex-start; height:38px; padding:0 28px; margin:0; border-radius:var(--radius-sm);">
                📤 SEND NOTIFICATION
            </button>
        </div>
    `;
}

window.toggleNotifCustomUrl = (val) => {
    const wrap = document.getElementById('notifCustomUrlWrap');
    const label = document.getElementById('notifUrlLabel');
    const input = document.getElementById('notifActionUrl');
    const specs = document.getElementById('notifClaimSpecsWrap');

    if (val === 'external' || val === 'claim') {
        if (wrap) wrap.style.display = 'block';
        if (val === 'claim') {
            if (label) label.textContent = 'Promo Code to Claim';
            if (input) {
                input.placeholder = 'e.g. MEGA500';
                input.style.textTransform = 'uppercase';
            }
            if (specs) specs.style.display = 'flex';
        } else {
            if (label) label.textContent = 'External URL';
            if (input) {
                input.placeholder = 'https://...';
                input.style.textTransform = 'none';
            }
            if (specs) specs.style.display = 'none';
        }
    } else {
        if (wrap) wrap.style.display = 'none';
        if (specs) specs.style.display = 'none';
    }
};

window.sendNotification = async () => {
    const title = document.getElementById('notifTitle').value.trim();
    const message = document.getElementById('notifMessage').value.trim();
    const targetType = document.querySelector('input[name="notifTarget"]:checked')?.value;
    const user_id = targetType === 'targeted' ? document.getElementById('notifUserId')?.value?.trim() : null;
    const linkType = document.getElementById('notifLinkType').value;
    const customUrl = document.getElementById('notifActionUrl')?.value?.trim();

    if (!title || !message) { alert('Please enter both a title and message.'); return; }
    if (targetType === 'targeted' && !user_id) { alert('Please enter a target User ID.'); return; }
    if (linkType === 'external' && !customUrl) { alert('Please enter a custom destination URL.'); return; }

    let action_url = null;
    if (linkType === 'play') action_url = '/';
    else if (linkType === 'deposit') action_url = '/#deposit';
    else if (linkType === 'refer') action_url = '/#referral';
    else if (linkType === 'external') action_url = customUrl;
    else if (linkType === 'claim') {
        if (!customUrl) { alert('Please enter a promo code name.'); return; }
        const amountVal = parseFloat(document.getElementById('notifClaimAmount').value);
        const maxUsesVal = parseInt(document.getElementById('notifClaimMaxUses').value);
        if (isNaN(amountVal) || amountVal <= 0) { alert('Please enter a valid promo amount.'); return; }
        if (isNaN(maxUsesVal) || maxUsesVal <= 0) { alert('Please enter valid usage limit (number of users).'); return; }

        try {
            const { data: { session } } = await supabase.auth.getSession();
            const promoRes = await fetch('/api/admin/promocodes?action=create', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${session.access_token}` },
                body: JSON.stringify({ code: customUrl.toUpperCase(), amount: amountVal, max_uses: maxUsesVal })
            });
            const promoResult = await promoRes.json();
            if (!promoRes.ok && promoResult.error !== 'Promo code already exists. Please choose a unique code.') {
                alert(`Promo Code Creation Error: ${promoResult.error}`);
                return;
            }
        } catch (e) {
            alert(`Promo Code Creation Network Error: ${e.message}`);
            return;
        }

        action_url = 'claim:' + customUrl.toUpperCase();
    }

    const confirmed = targetType === 'broadcast'
        ? confirm('This will send a notification to ALL registered users. Continue?')
        : confirm(`Send this notification to user ${user_id}?`);
    if (!confirmed) return;
    try {
        const { data: { session } } = await supabase.auth.getSession();
        const res = await fetch('/api/admin/content?action=send_notification', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${session.access_token}` },
            body: JSON.stringify({ title, message, user_id, action_url })
        });
        const result = await res.json();
        if (result.success) alert(targetType === 'broadcast' ? '✓ Notification broadcast to all users!' : '✓ Notification sent!');
        else alert(`Error: ${result.error}`);
    } catch (e) { alert(`Error: ${e.message}`); }
};

// ── SUPPORT TAB ───────────────────────────────────────────────────────────────

function renderSupport(settings) {
    const support = settings?.support || {};
    const el = document.getElementById('adminContent');
    el.innerHTML = `
        <div class="pane-header">
            <h1>Support Contact Settings</h1>
            <p>Update the official support channels visible to users across the platform.</p>
        </div>
        <div style="background:var(--bg-surface); border:1px solid var(--border); border-radius:var(--radius-md); padding:24px; max-width:540px; display:flex; flex-direction:column; gap:18px;">
            <div>
                <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:6px;">📞 WhatsApp Support Number</label>
                <input id="supportWhatsapp" class="amount-input" placeholder="+254700000000" value="${support.whatsapp || ''}" style="width:100%; text-align:left;">
                <div style="font-size:0.65rem; color:var(--text-muted); margin-top:4px;">Full number with country code, e.g. +254712345678</div>
            </div>
            <div>
                <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:6px;">✈ Telegram Support Username</label>
                <input id="supportTelegram" class="amount-input" placeholder="metricwin_support" value="${support.telegram_username || ''}" style="width:100%; text-align:left;">
                <div style="font-size:0.65rem; color:var(--text-muted); margin-top:4px;">Without the @, e.g. metricwin_support</div>
            </div>
            <div>
                <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:6px;">✉ Email Support Address</label>
                <input id="supportEmail" class="amount-input" placeholder="support@metricwin.com" value="${support.email || ''}" style="width:100%; text-align:left;">
                <div style="font-size:0.65rem; color:var(--text-muted); margin-top:4px;">Official email support, e.g. support@metricwin.app</div>
            </div>
            <button class="big-bet-btn" onclick="saveSupportSettings()" style="width:auto; align-self:flex-start; height:38px; padding:0 28px; margin:0; border-radius:var(--radius-sm);">
                💾 SAVE SUPPORT CONTACTS
            </button>
        </div>
    `;
}

window.saveSupportSettings = async () => {
    const whatsapp = document.getElementById('supportWhatsapp').value.trim();
    const telegram_username = document.getElementById('supportTelegram').value.trim().replace('@', '');
    const email = document.getElementById('supportEmail').value.trim();
    const btn = document.querySelector('[onclick="saveSupportSettings()"]');
    if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }
    try {
        const { data: { session } } = await supabase.auth.getSession();
        const res = await fetch('/api/admin/content?action=update_settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${session.access_token}` },
            body: JSON.stringify({ key: 'support', value: { whatsapp, telegram_username, email } })
        });
        const result = await res.json();
        if (result.success) {
            const freshRes = await fetch('/api/admin/content?action=settings', { headers: { 'Authorization': `Bearer ${session.access_token}` } });
            const freshSettings = await freshRes.json();
            renderSupport(freshSettings);
            showToast('✓ Support contacts saved!');
        } else {
            alert(`Error: ${result.error}`);
            if (btn) { btn.disabled = false; btn.textContent = '💾 SAVE SUPPORT CONTACTS'; }
        }
    } catch (e) {
        alert(`Error: ${e.message}`);
        if (btn) { btn.disabled = false; btn.textContent = '💾 SAVE SUPPORT CONTACTS'; }
    }
};

// ── COMMUNITY TAB ─────────────────────────────────────────────────────────────

function renderCommunity(settings) {
    const community = settings?.community || {};
    const el = document.getElementById('adminContent');
    el.innerHTML = `
        <div class="pane-header">
            <h1>Community Channel Settings</h1>
            <p>Manage the official community channels visible to all platform users.</p>
        </div>
        <div style="background:var(--bg-surface); border:1px solid var(--border); border-radius:var(--radius-md); padding:24px; max-width:540px; display:flex; flex-direction:column; gap:18px;">
            <div>
                <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:6px;">✈ Telegram Channel URL</label>
                <input id="commTelegram" class="amount-input" placeholder="https://t.me/metricwin" value="${community.telegram_channel || ''}" style="width:100%; text-align:left;">
            </div>
            <div>
                <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:6px;">📞 WhatsApp Channel URL</label>
                <input id="commWhatsapp" class="amount-input" placeholder="https://whatsapp.com/channel/..." value="${community.whatsapp_channel || ''}" style="width:100%; text-align:left;">
            </div>
            <button class="big-bet-btn" onclick="saveCommunitySettings()" style="width:auto; align-self:flex-start; height:38px; padding:0 28px; margin:0; border-radius:var(--radius-sm);">
                💾 SAVE COMMUNITY LINKS
            </button>
        </div>
    `;
}

window.saveCommunitySettings = async () => {
    const telegram_channel = document.getElementById('commTelegram').value.trim();
    const whatsapp_channel = document.getElementById('commWhatsapp').value.trim();
    const btn = document.querySelector('[onclick="saveCommunitySettings()"]');
    if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }
    try {
        const { data: { session } } = await supabase.auth.getSession();
        const res = await fetch('/api/admin/content?action=update_settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${session.access_token}` },
            body: JSON.stringify({ key: 'community', value: { telegram_channel, whatsapp_channel } })
        });
        const result = await res.json();
        if (result.success) {
            const freshRes = await fetch('/api/admin/content?action=settings', { headers: { 'Authorization': `Bearer ${session.access_token}` } });
            const freshSettings = await freshRes.json();
            renderCommunity(freshSettings);
            showToast('✓ Community links saved!');
        } else {
            alert(`Error: ${result.error}`);
            if (btn) { btn.disabled = false; btn.textContent = '💾 SAVE COMMUNITY LINKS'; }
        }
    } catch (e) {
        alert(`Error: ${e.message}`);
        if (btn) { btn.disabled = false; btn.textContent = '💾 SAVE COMMUNITY LINKS'; }
    }
};

// ── REFERRAL REWARDS TAB ──────────────────────────────────────────────────────

function renderReferralSettings(settings) {
    const cfg = settings?.referral_rewards || {};
    const enabled          = cfg.enabled === true;
    const referrerBonus    = parseFloat(cfg.referrer_bonus_kes || 0);
    const refereeBonus     = parseFloat(cfg.referee_bonus_kes || 0);
    const requireDeposit   = cfg.require_first_deposit === true;
    const minDeposit       = parseFloat(cfg.min_deposit_kes || 100);

    // Signup bonus settings (separate system_settings key)
    const sbCfg            = settings?.signup_bonus || {};
    const sbEnabled        = sbCfg.enabled === true;
    const sbAmount         = parseFloat(sbCfg.amount_kes || 50);

    const el = document.getElementById('adminContent');
    el.innerHTML = `
        <div class="pane-header">
            <h1>Referral Rewards Configuration</h1>
            <p>Control the referral program rewards. Changes are applied to all users instantly upon save.</p>
        </div>

        <div style="background:var(--bg-surface); border:1px solid var(--border); border-radius:var(--radius-md); padding:24px; max-width:580px; display:flex; flex-direction:column; gap:20px;">

            <!-- Enable / Disable Toggle -->
            <div style="display:flex; align-items:center; justify-content:space-between; padding-bottom:16px; border-bottom:1px solid var(--border);">
                <div>
                    <div style="font-size:0.85rem; font-weight:800; color:var(--text-primary);">Referral Program Enabled</div>
                    <div style="font-size:0.7rem; color:var(--text-muted); margin-top:3px;">When ON, referral bonuses are automatically credited after a new user signs up via a referral link.</div>
                </div>
                <label style="position:relative; display:inline-flex; align-items:center; cursor:pointer; gap:8px; flex-shrink:0; margin-left:16px;">
                    <input type="checkbox" id="refEnabled" style="appearance:none; width:42px; height:24px; background:${enabled ? 'var(--success)' : 'var(--bg-elevated)'}; border-radius:100px; cursor:pointer; transition:background 0.3s; border:1px solid var(--border);" ${enabled ? 'checked' : ''} onchange="this.style.background = this.checked ? 'var(--success)' : 'var(--bg-elevated)'">
                    <span style="font-size:0.72rem; font-weight:700; color:${enabled ? 'var(--success)' : 'var(--text-muted)'}" id="refEnabledLabel">${enabled ? 'ON' : 'OFF'}</span>
                </label>
            </div>

            <!-- Referrer Bonus -->
            <div>
                <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:6px;">
                    💰 Referrer Bonus (KES) — Amount credited to the person who shared the link
                </label>
                <input id="refReferrerBonus" class="amount-input" type="number" min="0" step="10" value="${referrerBonus}" style="width:100%; text-align:left;" placeholder="e.g. 100">
                <div style="font-size:0.65rem; color:var(--text-muted); margin-top:4px;">Set to 0 to disable referrer reward.</div>
            </div>

            <!-- Referee Bonus (New User) -->
            <div>
                <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:6px;">
                    🎁 New User Bonus (KES) — Amount credited to the new user who signed up with a referral code
                </label>
                <input id="refRefereeBonus" class="amount-input" type="number" min="0" step="10" value="${refereeBonus}" style="width:100%; text-align:left;" placeholder="e.g. 50">
                <div style="font-size:0.65rem; color:var(--text-muted); margin-top:4px;">Set to 0 to not give any bonus to the new user.</div>
            </div>

            <!-- Require First Deposit -->
            <div style="display:flex; align-items:center; justify-content:space-between; padding-top:8px; border-top: 1px solid var(--border);">
                <div>
                    <div style="font-size:0.8rem; font-weight:700; color:var(--text-primary);">Require First Deposit</div>
                    <div style="font-size:0.7rem; color:var(--text-muted); margin-top:3px;">If enabled, the referral bonus is only credited after the new user makes their first deposit (not implemented in auto-credit — use deposit webhook instead).</div>
                </div>
                <label style="position:relative; display:inline-flex; align-items:center; cursor:pointer; gap:8px; flex-shrink:0; margin-left:16px;">
                    <input type="checkbox" id="refRequireDeposit" style="appearance:none; width:42px; height:24px; background:${requireDeposit ? 'var(--success)' : 'var(--bg-elevated)'}; border-radius:100px; cursor:pointer; transition:background 0.3s; border:1px solid var(--border);" ${requireDeposit ? 'checked' : ''} onchange="this.style.background = this.checked ? 'var(--success)' : 'var(--bg-elevated)'">
                </label>
            </div>

            <!-- Min Deposit Amount -->
            <div>
                <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:6px;">
                    Minimum Qualifying Deposit (KES)
                </label>
                <input id="refMinDeposit" class="amount-input" type="number" min="0" step="50" value="${minDeposit}" style="width:100%; text-align:left;" placeholder="e.g. 100">
            </div>

            <button class="big-bet-btn" onclick="saveReferralSettings()" style="width:auto; align-self:flex-start; height:40px; padding:0 32px; margin:0; border-radius:var(--radius-sm); font-size:0.8rem;">
                💾 SAVE REFERRAL SETTINGS
            </button>
        </div>

        <!-- ── SIGNUP BONUS SECTION ── -->
        <div style="background:var(--bg-surface); border:1px solid var(--border); border-radius:var(--radius-md); padding:24px; max-width:580px; display:flex; flex-direction:column; gap:20px; margin-top:20px;">

            <div style="font-size:1rem; font-weight:800; color:var(--text-primary); border-bottom:1px solid var(--border); padding-bottom:12px;">
                🎉 New User Signup Bonus
            </div>

            <!-- Enable toggle -->
            <div style="display:flex; align-items:center; justify-content:space-between;">
                <div>
                    <div style="font-size:0.82rem; font-weight:700; color:var(--text-primary);">Enable Signup Bonus</div>
                    <div style="font-size:0.7rem; color:var(--text-muted); margin-top:3px;">When ON, every new user who successfully registers receives the bonus amount automatically, regardless of referral code.</div>
                </div>
                <label style="position:relative; display:inline-flex; align-items:center; cursor:pointer; gap:8px; flex-shrink:0; margin-left:16px;">
                    <input type="checkbox" id="sbEnabled" style="appearance:none; width:42px; height:24px; background:${sbEnabled ? 'var(--success)' : 'var(--bg-elevated)'}; border-radius:100px; cursor:pointer; transition:background 0.3s; border:1px solid var(--border);" ${sbEnabled ? 'checked' : ''} onchange="this.style.background=this.checked?'var(--success)':'var(--bg-elevated)'; document.getElementById('sbEnabledLabel').textContent=this.checked?'ON':'OFF'; document.getElementById('sbEnabledLabel').style.color=this.checked?'var(--success)':'var(--text-muted)'">
                    <span style="font-size:0.72rem; font-weight:700; color:${sbEnabled ? 'var(--success)' : 'var(--text-muted)'}" id="sbEnabledLabel">${sbEnabled ? 'ON' : 'OFF'}</span>
                </label>
            </div>

            <!-- Signup bonus amount -->
            <div>
                <label style="font-size:0.65rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:1px; display:block; margin-bottom:6px;">
                    🎁 Bonus Amount (KES) — Credited instantly to every new registered user
                </label>
                <input id="sbAmountKes" class="amount-input" type="number" min="1" step="10" value="${sbAmount}" style="width:100%; text-align:left;" placeholder="e.g. 50">
                <div style="font-size:0.65rem; color:var(--text-muted); margin-top:4px;">This amount is credited as a <code>signup_bonus</code> transaction. It will only be given once per account (idempotent).</div>
            </div>

            <button class="big-bet-btn" onclick="saveSignupBonusSettings()" style="width:auto; align-self:flex-start; height:40px; padding:0 32px; margin:0; border-radius:var(--radius-sm); font-size:0.8rem;">
                💾 SAVE SIGNUP BONUS
            </button>
        </div>

        <div style="margin-top:20px; max-width:580px; background:var(--bg-surface); border:1px solid var(--border); border-radius:var(--radius-md); padding:18px;">
            <div style="font-size:0.75rem; font-weight:800; color:var(--text-primary); margin-bottom:10px;">ℹ️ How the Referral &amp; Signup Bonus System Works</div>
            <ol style="font-size:0.72rem; color:var(--text-muted); line-height:1.8; margin:0; padding-left:18px;">
                <li>Each user has a unique referral code visible in their profile under the "Referrals" tab.</li>
                <li>When someone clicks a referral link (<code>/auth?ref=REFXXXXXXX</code>), the code is saved and auto-filled in the signup form.</li>
                <li>After the new user successfully registers, the system automatically calls <code>credit_referral_reward()</code> (referrer + referee bonuses) AND <code>credit_signup_bonus()</code> (universal new user welcome bonus).</li>
                <li>All rewards are logged as <code>referral_bonus</code> or <code>signup_bonus</code> transactions in the financial ledger.</li>
                <li>The signup bonus is idempotent — even if called multiple times, each account only ever receives it once.</li>
            </ol>
        </div>
    `;

    // Update referral label dynamically on toggle
    document.getElementById('refEnabled').addEventListener('change', function () {
        document.getElementById('refEnabledLabel').textContent = this.checked ? 'ON' : 'OFF';
        document.getElementById('refEnabledLabel').style.color = this.checked ? 'var(--success)' : 'var(--text-muted)';
    });
}

window.saveReferralSettings = async () => {
    const enabled        = document.getElementById('refEnabled').checked;
    const referrerBonus  = parseFloat(document.getElementById('refReferrerBonus').value) || 0;
    const refereeBonus   = parseFloat(document.getElementById('refRefereeBonus').value) || 0;
    const requireDeposit = document.getElementById('refRequireDeposit').checked;
    const minDeposit     = parseFloat(document.getElementById('refMinDeposit').value) || 100;

    if (referrerBonus < 0 || refereeBonus < 0) {
        alert('Bonus amounts cannot be negative.'); return;
    }

    const payload = {
        enabled,
        referrer_bonus_kes: referrerBonus,
        referee_bonus_kes: refereeBonus,
        require_first_deposit: requireDeposit,
        min_deposit_kes: minDeposit
    };

    const btn = document.querySelector('[onclick="saveReferralSettings()"]');
    if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }

    try {
        const { data: { session } } = await supabase.auth.getSession();
        const res = await fetch('/api/admin/content?action=update_settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${session.access_token}` },
            body: JSON.stringify({ key: 'referral_rewards', value: payload })
        });
        const result = await res.json();
        if (result.success) {
            // Re-fetch and re-render with live values
            const freshRes = await fetch('/api/admin/content?action=settings', { headers: { 'Authorization': `Bearer ${session.access_token}` } });
            const freshSettings = await freshRes.json();
            renderReferralSettings(freshSettings);
            showToast(`✓ Referral settings saved! Program: ${enabled ? 'ACTIVE' : 'INACTIVE'}`);
        } else {
            alert(`Error: ${result.error}`);
            if (btn) { btn.disabled = false; btn.textContent = '💾 SAVE REFERRAL SETTINGS'; }
        }
    } catch (e) {
        alert(`Error: ${e.message}`);
        if (btn) { btn.disabled = false; btn.textContent = '💾 SAVE REFERRAL SETTINGS'; }
    }
};

window.saveSignupBonusSettings = async () => {
    const enabled = document.getElementById('sbEnabled').checked;
    const amount = parseFloat(document.getElementById('sbAmountKes').value) || 0;

    if (amount < 0) {
        alert('Bonus amount cannot be negative.'); return;
    }

    const payload = { enabled, amount_kes: amount };
    const btn = document.querySelector('[onclick="saveSignupBonusSettings()"]');
    if (btn) { btn.disabled = true; btn.textContent = 'Saving…'; }

    try {
        const { data: { session } } = await supabase.auth.getSession();
        const res = await fetch('/api/admin/content?action=update_settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${session.access_token}` },
            body: JSON.stringify({ key: 'signup_bonus', value: payload })
        });
        const result = await res.json();
        if (result.success) {
            const freshRes = await fetch('/api/admin/content?action=settings', { headers: { 'Authorization': `Bearer ${session.access_token}` } });
            const freshSettings = await freshRes.json();
            renderReferralSettings(freshSettings);
            showToast(`✓ Signup bonus saved! ${enabled ? `KES ${amount.toLocaleString()} per new user` : 'Disabled'}`);
        } else {
            alert(`Error: ${result.error}`);
            if (btn) { btn.disabled = false; btn.textContent = '💾 SAVE SIGNUP BONUS'; }
        }
    } catch (e) {
        alert(`Error: ${e.message}`);
        if (btn) { btn.disabled = false; btn.textContent = '💾 SAVE SIGNUP BONUS'; }
    }
};

