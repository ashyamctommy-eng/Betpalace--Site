/**
 * walletManager.js
 *
 * Wallet refresh and balance management.
 *
 * Extracted from main.js (refreshBalance function ~line 1474)
 * Uses gameContext.ctx.isDemoMode and ctx.currentUser so it works
 * both in real and demo mode without any main.js dependency.
 */

import { supabase } from '../../config/supabase.js';
import { ctx } from '../../state/gameContext.js';

/**
 * Refreshes the user's balance from the server and writes it into ctx.balance.
 * In demo mode, reads from localStorage instead.
 *
 * @returns {Promise<number>} The updated balance value
 */
export async function refreshBalance() {
    if (ctx.isDemoMode) {
        const stored = localStorage.getItem('demo_balance');
        ctx.balance = stored ? parseFloat(stored) : 1000.00;
        return ctx.balance;
    }
    if (!ctx.currentUser) return ctx.balance;

    try {
        const { data, error } = await supabase
            .from('profiles')
            .select('balance')
            .eq('id', ctx.currentUser.id)
            .single();

        if (data && !error) {
            ctx.balance = parseFloat(data.balance);
        }
    } catch (e) {
        console.warn('[WalletManager] Balance refresh failed:', e);
    }
    return ctx.balance;
}

/**
 * Sets the demo balance in localStorage and syncs ctx.balance.
 * @param {number} amount
 */
export function setDemoBalance(amount) {
    ctx.balance = parseFloat(amount.toFixed(2));
    localStorage.setItem('demo_balance', String(ctx.balance));
}
