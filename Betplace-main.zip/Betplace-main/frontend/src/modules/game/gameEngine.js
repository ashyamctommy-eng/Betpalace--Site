import { FlightScene } from './FlightScene.js';

let phaserGame = null;

export function initCanvas() {
    const parent = document.getElementById('gameBoard');
    if (!parent) return null;

    const oldCanvas = document.getElementById('gameCanvas');
    if (oldCanvas) oldCanvas.remove();

    const config = {
        type: Phaser.AUTO,
        width: parent.clientWidth,
        height: parent.clientHeight,
        parent: 'gameBoard',
        transparent: true,
        backgroundColor: 'rgba(0,0,0,0)',
        scene: FlightScene,
        scale: {
            mode: Phaser.Scale.ENVELOP,
            autoCenter: Phaser.Scale.CENTER_BOTH
        }
    };

    phaserGame = new Phaser.Game(config);

    window.addEventListener('resize', () => {
        if (phaserGame && phaserGame.scale && parent) {
            phaserGame.scale.resize(parent.clientWidth, parent.clientHeight);
        }
    });

    return phaserGame;
}

export function getPhaserGameInstance() {
    return phaserGame;
}
