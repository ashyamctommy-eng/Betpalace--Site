/**
 * backend/api/_admin/content.js
 *
 * Admin Content Management: Promotions, System Settings, Notifications.
 * Pure PostgreSQL via _lib/db.js. Zero Supabase.
 */

import { verifyPermission, logAdminAction } from '../_lib/auth.js';
import { setCorsHeaders } from '../_lib/cors.js';
import { query } from '../_lib/db.js';
import { clearFinancialLimitsCache } from '../_lib/limits.js';

export default async function contentHandler(req, res) {
    setCorsHeaders(req, res, 'GET, POST, DELETE, OPTIONS');
    if (req.method === 'OPTIONS') return res.status(200).end();

    const { action } = req.query;

    // ─── PUBLIC READ ACTIONS ───────────────────────────────────────────────
    if (req.method === 'GET' && action === 'promotions') {
        try {
            const { rows } = await query('SELECT * FROM promotions WHERE is_active = true ORDER BY created_at DESC');
            return res.status(200).json(rows);
        } catch (err) {
            return res.status(500).json({ error: err.message });
        }
    }

    if (req.method === 'GET' && action === 'settings') {
        try {
            const { rows } = await query('SELECT key, value FROM system_settings');
            const settings = {};
            rows.forEach(r => { settings[r.key] = r.value; });
            return res.status(200).json(settings);
        } catch (err) {
            return res.status(500).json({ error: err.message });
        }
    }

    // ─── PROTECTED WRITE ACTIONS ──────────────────────────────────────────
    try {
        const access = await verifyPermission(req, 'manage_users');
        if (!access.success) return res.status(access.status).json({ error: access.error });

        const body = req.method === 'POST' ? req.body : {};

        switch (action) {
            case 'create_promotion': {
                const { title, description, image_url, action_type, action_url, badge_text } = body;
                if (!title) return res.status(400).json({ error: 'title is required' });

                const { rows } = await query(
                    `INSERT INTO promotions (title, description, image_url, action_type, action_url, badge_text)
                     VALUES ($1, $2, $3, $4, $5, $6)
                     RETURNING *`,
                    [title, description || '', image_url || null, action_type || 'link', action_url || '', badge_text || null]
                );

                await logAdminAction(access.user.id, 'CREATE_PROMOTION', rows[0].id, { title });
                return res.status(200).json({ success: true, promotion: rows[0] });
            }

            case 'delete_promotion': {
                const { id } = body;
                if (!id) return res.status(400).json({ error: 'id is required' });

                await query('DELETE FROM promotions WHERE id = $1', [id]);
                await logAdminAction(access.user.id, 'DELETE_PROMOTION', id, {});
                return res.status(200).json({ success: true });
            }

            case 'update_settings': {
                const { key, value } = body;
                if (!key || !value) return res.status(400).json({ error: 'key and value are required' });

                await query(
                    `INSERT INTO system_settings (key, value, updated_at)
                     VALUES ($1, $2, NOW())
                     ON CONFLICT (key) DO UPDATE
                     SET value = EXCLUDED.value, updated_at = NOW()`,
                    [key, JSON.stringify(value)]
                );

                if (key === 'financial_limits' || key === 'game_limits') {
                    clearFinancialLimitsCache();
                }

                await logAdminAction(access.user.id, 'UPDATE_SYSTEM_SETTINGS', key, value);
                return res.status(200).json({ success: true });
            }

            default:
                return res.status(400).json({ error: `Unknown action: ${action}` });
        }
    } catch (err) {
        console.error('[Admin Content Error]:', err);
        return res.status(500).json({ error: err.message });
    }
}
