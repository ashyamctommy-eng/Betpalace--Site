/**
 * Crash History Ticker & Bet History Renderers
 */

export function renderHistoryTicker(crashHistory) {
    const el = document.getElementById('historyTicker');
    if (!el) return;
    el.innerHTML = crashHistory.map(m => {
        const val = typeof m === 'number' ? m : parseFloat(m) || 1.00;
        const cls = val < 2.0 ? 'low' : val < 10.0 ? 'mid' : val < 50.0 ? 'high' : 'ultra';
        return `<div class="hist-pill ${cls}" title="Click to verify round fairness">${val.toFixed(2)}x</div>`;
    }).join('');
}

export function updateCrashedMultiplierDisplay(multiplier) {
    const crashedVal = document.getElementById('crashedValue');
    if (crashedVal) crashedVal.textContent = `${multiplier.toFixed(2)}x`;
    
    const infoStatus = document.getElementById('infoRoundStatus');
    if (infoStatus) infoStatus.textContent = 'CRASHED';

    const lastCrash = document.getElementById('infoLastCrash');
    if (lastCrash) {
        lastCrash.textContent = `${multiplier.toFixed(2)}x`;
        lastCrash.style.color = multiplier < 2 ? 'var(--error)' : multiplier < 10 ? 'var(--warning)' : 'var(--blue)';
    }
}
