# MetroWins Backend — Render & VPS Deployment Guide (Zero Supabase)

This guide details how to deploy the **MetroWins Backend** to **[Render](https://render.com)** and a **Linux VPS** (Ubuntu/Debian via PM2 or Docker).

The backend is completely self-contained:
- **Runtime**: Node.js 22 LTS + Express
- **Real-Time Engine**: Built-in WebSockets (`/ws`) for sub-second game state broadcast
- **Database**: Pure PostgreSQL (Render PostgreSQL, VPS PostgreSQL, AWS RDS, Neon)
- **Authentication**: Native JWT with bcrypt password hashing
- **Zero Third-Party Vendor Dependencies** (No Supabase required)

---

## 1. Environment Variables Reference

| Variable | Required | Description | Example |
| :--- | :--- | :--- | :--- |
| `PORT` | Auto | Port to listen on (Render sets this automatically) | `3000` |
| `NODE_ENV` | Yes | Environment mode | `production` |
| `CORS_ORIGIN` | Yes | Allowed frontend origin(s), comma-separated | `https://metrowins.vercel.app,http://localhost:5173` |
| `DATABASE_URL` | Yes | PostgreSQL Connection String | `postgresql://user:pass@host:5432/metrowins` |
| `JWT_SECRET` | Yes | Strong secret for signing session tokens | `openssl rand -hex 32` |
| `PALPLUSS_API_KEY` | Yes | Palpluss merchant API key | `pal_live_...` |
| `PALPLUSS_CHANNEL_ID`| Yes | Palpluss channel ID | `12345` |
| `PALPLUSS_CALLBACK_URL`| Yes | Public STK push webhook callback URL | `https://your-backend/api/deposit-callback` |
| `PALPLUSS_WITHDRAW_CALLBACK_URL`| Yes | Public B2C payout webhook callback URL | `https://your-backend/api/withdraw-callback` |
| `PALPLUSS_WEBHOOK_SECRET` | Yes | Secret HMAC key for verifying webhook signatures | `whsec_...` |
| `BREVO_API_KEY` | Optional | Brevo API key for transactional emails | `xkeysib-...` |
| `MASTER_SETUP_KEY` | Yes | Secret one-time key for initial Super Admin setup | `your-secure-setup-key` |

---

## 2. Deployment to Render (Recommended PaaS)

### Step 1: Create a PostgreSQL Database on Render
1. In [dashboard.render.com](https://dashboard.render.com), click **New +** → **PostgreSQL**.
2. Name: `metrowins-db`.
3. Select your preferred region.
4. Click **Create Database**.
5. Once created, copy the **Internal Database URL** (if Web Service is on Render) or **External Database URL**.

### Step 2: Create the Backend Web Service
1. Click **New +** → **Web Service**.
2. Connect your Git repository (`kem6oi/MetroWins`).
3. Settings:
   - **Name**: `metrowins-backend`
   - **Root Directory**: `backend`
   - **Runtime**: `Node`
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
4. Expand **Advanced** and set **Health Check Path** to: `/health`

### Step 3: Add Environment Variables
Add the variables from Section 1 into Render's Environment Variables table, notably:
- `DATABASE_URL`: Your Render PostgreSQL connection string.
- `JWT_SECRET`: A secure random secret.
- `CORS_ORIGIN`: Your frontend URL (e.g. `https://metrowins.vercel.app`).

### Step 4: Initialize the Database Schema
In the Render Web Service dashboard, go to the **Shell** tab and run:
```bash
npm run db:setup
```
This runs `schema.sql` and initializes all tables, stored procedures, and initial roles!

---

## 3. Deployment to Linux VPS (Ubuntu 22.04 / 24.04)

### Step 1: Server Setup & PostgreSQL Installation
```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y git curl ufw nginx postgresql postgresql-contrib

# Configure Firewall
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx Full'
sudo ufw enable
```

### Step 2: Configure Local PostgreSQL Database
```bash
sudo -u postgres psql
```
Inside the PostgreSQL prompt:
```sql
CREATE DATABASE metrowins;
CREATE USER metrowins_user WITH ENCRYPTED PASSWORD 'StrongPassword123!';
GRANT ALL PRIVILEGES ON DATABASE metrowins TO metrowins_user;
\c metrowins
GRANT ALL ON SCHEMA public TO metrowins_user;
\q
```

### Step 3: Install Node.js 22 LTS & PM2
```bash
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs
sudo npm install -g pm2
```

### Step 4: Clone Repository & Setup
```bash
cd /var/www
sudo git clone https://github.com/kem6oi/MetroWins.git
sudo chown -R $USER:$USER /var/www/MetroWins

cd /var/www/MetroWins/backend
npm install

# Create environment file
cp .env.example .env
nano .env
```
Set `DATABASE_URL=postgresql://metrowins_user:StrongPassword123!@localhost:5432/metrowins` and your other credentials.

### Step 5: Initialize the Database Schema
```bash
npm run db:setup
```

### Step 6: Start with PM2
```bash
pm2 start ecosystem.config.cjs
pm2 save
pm2 startup
```

### Step 7: Nginx Reverse Proxy with WebSocket Support
Create `/etc/nginx/sites-available/metrowins-backend`:
```nginx
server {
    listen 80;
    server_name api.yourdomain.com;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;

        # WebSocket support
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";

        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        proxy_read_timeout 86400;
        proxy_connect_timeout 60s;
    }
}
```

Enable the configuration and reload Nginx:
```bash
sudo ln -s /etc/nginx/sites-available/metrowins-backend /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### Step 8: Free SSL with Certbot
```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d api.yourdomain.com
```

---

## 4. Verification & Initial Bootstrap

1. **Check Health**:
   ```bash
   curl https://api.yourdomain.com/health
   ```
   Should respond:
   ```json
   {"status":"ok","database":"connected","uptime":...,"environment":"production"}
   ```

2. **Bootstrap Super Admin**:
   ```bash
   curl -X POST https://api.yourdomain.com/api/setup-admin \
     -H "Content-Type: application/json" \
     -d '{
       "email": "admin@metrowins.app",
       "phone": "+254700000000",
       "password": "AdminPassword123!",
       "secretKey": "YOUR_MASTER_SETUP_KEY"
     }'
   ```
