-- Migration 027: Create increment_balance RPC + safety constraints
-- This RPC is needed for atomic balance rollbacks in withdraw.js
-- and for admin balance adjustments in actions.js

-- Drop existing signatures first to allow changing parameter names
DROP FUNCTION IF EXISTS public.increment_balance(UUID, NUMERIC);
DROP FUNCTION IF EXISTS public.increment_balance(UUID, DECIMAL);

-- Create public.increment_balance with standardized parameter names (user_id and amount)
CREATE OR REPLACE FUNCTION public.increment_balance(user_id UUID, amount DECIMAL)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
    UPDATE public.profiles
    SET balance = balance + amount
    WHERE id = user_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'User profile not found: %', user_id;
    END IF;
END;
$$;

GRANT EXECUTE ON FUNCTION public.increment_balance(UUID, DECIMAL) TO authenticated;
GRANT EXECUTE ON FUNCTION public.increment_balance(UUID, DECIMAL) TO service_role;

-- 3. Add CHECK constraint to prevent negative balances (if not exists)
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'profiles_balance_non_negative'
    ) THEN
        ALTER TABLE public.profiles
          ADD CONSTRAINT profiles_balance_non_negative CHECK (balance >= 0);
    END IF;
END $$;

-- 4. Add CHECK constraint on active_game_state for crash multiplier sanity (if not exists)
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'crash_point_sanity'
    ) THEN
        ALTER TABLE public.active_game_state
          ADD CONSTRAINT crash_point_sanity CHECK (crash_point >= 1.00 AND crash_point <= 500.00);
    END IF;
END $$;

-- Reload PostgREST schema cache
NOTIFY pgrst, 'reload schema';
