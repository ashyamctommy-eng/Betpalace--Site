-- ═══════════════════════════════════════════════════════════════════
-- MIGRATION 038: Streamline Aviator Betting and Financial Limits
-- ═══════════════════════════════════════════════════════════════════

-- 1. Initialize default financial limits in system_settings if not present
INSERT INTO public.system_settings (key, value, updated_at)
VALUES (
    'financial_limits',
    jsonb_build_object(
        'minDeposit', 99,
        'maxDeposit', 300000,
        'minWithdrawal', 100,
        'maxWithdrawal', 150000,
        'minBetAviator', 10,
        'maxBetAviator', 50000
    ),
    NOW()
)
ON CONFLICT (key) DO UPDATE
SET value = jsonb_build_object(
    'minDeposit', COALESCE((public.system_settings.value->>'minDeposit')::numeric, 99),
    'maxDeposit', COALESCE((public.system_settings.value->>'maxDeposit')::numeric, 300000),
    'minWithdrawal', COALESCE((public.system_settings.value->>'minWithdrawal')::numeric, 100),
    'maxWithdrawal', COALESCE((public.system_settings.value->>'maxWithdrawal')::numeric, 150000),
    'minBetAviator', COALESCE((public.system_settings.value->>'minBetAviator')::numeric, 10),
    'maxBetAviator', COALESCE((public.system_settings.value->>'maxBetAviator')::numeric, 50000)
),
updated_at = NOW();

-- 2. Streamlined place_bet RPC supporting mid-flight queueing and dynamic limits
CREATE OR REPLACE FUNCTION public.place_bet(
    p_user_id UUID,
    p_round_id BIGINT,
    p_amount NUMERIC,
    p_auto_cashout NUMERIC DEFAULT NULL
)
RETURNS JSON AS $$
DECLARE
    v_balance NUMERIC;
    v_is_frozen BOOLEAN;
    v_status VARCHAR;
    v_bet_id UUID;
    v_game_round BIGINT;
    v_target_round BIGINT;
    v_min_bet NUMERIC := 10;
    v_max_bet NUMERIC := 50000;
    v_config JSONB;
BEGIN
    -- Read financial / bet limits
    SELECT value INTO v_config FROM public.system_settings WHERE key = 'financial_limits' LIMIT 1;
    IF v_config IS NOT NULL THEN
        v_min_bet := COALESCE((v_config->>'minBetAviator')::numeric, (v_config->>'min_bet')::numeric, 10);
        v_max_bet := COALESCE((v_config->>'maxBetAviator')::numeric, (v_config->>'max_bet')::numeric, 50000);
    END IF;

    IF p_amount < v_min_bet THEN
        RETURN json_build_object('success', false, 'error', 'Minimum bet is KES ' || v_min_bet);
    END IF;
    IF p_amount > v_max_bet THEN
        RETURN json_build_object('success', false, 'error', 'Maximum bet is KES ' || v_max_bet);
    END IF;

    -- Check user balance and lock row
    SELECT balance, COALESCE(is_frozen, FALSE) INTO v_balance, v_is_frozen
    FROM public.profiles WHERE id = p_user_id FOR UPDATE;

    IF v_is_frozen THEN
        RETURN json_build_object('success', false, 'error', 'Account is frozen.');
    END IF;

    IF v_balance < p_amount THEN
        RETURN json_build_object('success', false, 'error', 'Insufficient balance.');
    END IF;

    -- Fetch active game state
    SELECT round_id, status INTO v_game_round, v_status FROM public.active_game_state WHERE id = 1;
    IF v_game_round IS NULL THEN
        v_game_round := 1;
        v_status := 'waiting';
    END IF;

    -- Auto-resolve target round:
    -- If waiting: target is current round
    -- If playing or crashed: auto-queue for upcoming round
    IF v_status = 'waiting' THEN
        v_target_round := v_game_round;
    ELSE
        v_target_round := v_game_round + 1;
    END IF;

    -- If client passed a specific future round_id >= v_target_round, respect it
    IF p_round_id IS NOT NULL AND p_round_id > v_target_round THEN
        v_target_round := p_round_id;
    END IF;

    -- Deduct balance
    UPDATE public.profiles SET balance = balance - p_amount, updated_at = NOW() WHERE id = p_user_id;

    -- Insert bet record
    INSERT INTO public.bets (user_id, round_id, amount, auto_cashout, status)
    VALUES (p_user_id, v_target_round, p_amount, p_auto_cashout, 'active')
    RETURNING id INTO v_bet_id;

    -- Record transaction
    INSERT INTO public.transactions (user_id, type, amount, status, metadata)
    VALUES (p_user_id, 'bet', p_amount, 'completed', json_build_object('bet_id', v_bet_id, 'round_id', v_target_round));

    RETURN json_build_object(
        'success', true,
        'betId', v_bet_id,
        'bet_id', v_bet_id,
        'roundId', v_target_round,
        'round_id', v_target_round,
        'newBalance', v_balance - p_amount,
        'new_balance', v_balance - p_amount
    );
END;
$$ LANGUAGE plpgsql;

-- 3. Robust cash_out RPC
CREATE OR REPLACE FUNCTION public.cash_out(
    p_user_id UUID,
    p_bet_id UUID,
    p_multiplier NUMERIC
)
RETURNS JSON AS $$
DECLARE
    v_bet RECORD;
    v_game RECORD;
    v_payout NUMERIC;
    v_new_balance NUMERIC;
BEGIN
    SELECT * INTO v_bet FROM public.bets WHERE id = p_bet_id AND user_id = p_user_id FOR UPDATE;
    IF v_bet IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Bet not found.');
    END IF;

    IF v_bet.status != 'active' THEN
        RETURN json_build_object('success', false, 'error', 'Bet is not active.');
    END IF;

    SELECT * INTO v_game FROM public.active_game_state WHERE id = 1;
    IF v_game.status != 'playing' THEN
        RETURN json_build_object('success', false, 'error', 'Round has already ended.');
    END IF;

    IF v_bet.round_id != v_game.round_id THEN
        RETURN json_build_object('success', false, 'error', 'Bet is not for the active round.');
    END IF;

    IF p_multiplier > v_game.crash_point THEN
        RETURN json_build_object('success', false, 'error', 'Plane already flew away.');
    END IF;

    v_payout := ROUND(v_bet.amount * p_multiplier, 2);

    UPDATE public.bets
    SET status = 'cashed_out',
        cashout_multiplier = p_multiplier,
        payout = v_payout,
        cashed_out_at = NOW()
    WHERE id = p_bet_id;

    UPDATE public.profiles
    SET balance = balance + v_payout,
        updated_at = NOW()
    WHERE id = p_user_id
    RETURNING balance INTO v_new_balance;

    INSERT INTO public.transactions (user_id, type, amount, status, metadata)
    VALUES (p_user_id, 'payout', v_payout, 'completed', json_build_object('bet_id', p_bet_id, 'multiplier', p_multiplier));

    RETURN json_build_object(
        'success', true,
        'payout', v_payout,
        'winnings', v_payout,
        'multiplier', p_multiplier,
        'newBalance', v_new_balance,
        'new_balance', v_new_balance
    );
END;
$$ LANGUAGE plpgsql;

-- 4. Cancel bet RPC allowing queued bets to be cancelled
CREATE OR REPLACE FUNCTION public.cancel_bet(
    p_user_id UUID,
    p_bet_id UUID
)
RETURNS JSON AS $$
DECLARE
    v_bet RECORD;
    v_game RECORD;
    v_new_balance NUMERIC;
BEGIN
    SELECT * INTO v_bet FROM public.bets WHERE id = p_bet_id AND user_id = p_user_id FOR UPDATE;
    IF v_bet IS NULL OR v_bet.status != 'active' THEN
        RETURN json_build_object('success', false, 'error', 'Active bet not found.');
    END IF;

    SELECT round_id, status INTO v_game FROM public.active_game_state WHERE id = 1;

    -- Bet can be cancelled if queued for next round OR if currently in waiting phase
    IF v_bet.round_id = v_game.round_id AND v_game.status != 'waiting' THEN
        RETURN json_build_object('success', false, 'error', 'Cannot cancel bet once the round begins.');
    END IF;

    IF v_bet.round_id < v_game.round_id THEN
        RETURN json_build_object('success', false, 'error', 'Cannot cancel a past round bet.');
    END IF;

    UPDATE public.bets SET status = 'cancelled' WHERE id = p_bet_id;

    UPDATE public.profiles
    SET balance = balance + v_bet.amount,
        updated_at = NOW()
    WHERE id = p_user_id
    RETURNING balance INTO v_new_balance;

    RETURN json_build_object(
        'success', true,
        'refunded', v_bet.amount,
        'newBalance', v_new_balance,
        'new_balance', v_new_balance
    );
END;
$$ LANGUAGE plpgsql;
