/**
 * Number, Currency, Date, and XSS Sanitization Utilities
 */

export function formatCurrency(amount, currency = 'KES') {
    const val = typeof amount === 'number' ? amount : parseFloat(amount) || 0;
    return `${currency} ${val.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function formatMultiplier(mult) {
    const val = typeof mult === 'number' ? mult : parseFloat(mult) || 1.00;
    return `${val.toFixed(2)}x`;
}

export function formatDate(dateString) {
    if (!dateString) return '--';
    const date = new Date(dateString);
    return date.toLocaleDateString(undefined, {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

/** Sanitizes untrusted user strings before injecting into DOM HTML */
export function escapeHTML(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}
