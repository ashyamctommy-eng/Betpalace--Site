/**
 * backend/api/_admin/system.js
 *
 * Super Admin System Management: Stats, Users, Audit Logs, Transactions.
 * Powered by pure PostgreSQL. Zero Supabase dependency.
 */

import { verifyPermission } from '../_lib/auth.js';
import { query } from '../_lib/db.js';
import { getSportsCacheTelemetry } from '../sports.js';

export default async function systemHandler(req, res) {
    try {
        const { action } = req.query;
        let requiredPermission = 'all_access';

        if (action === 'stats' || action === 'audit_logs' || action === 'users' || action === 'diagnose_users' || action === 'repair_users' || action === 'game_state' || action === 'sports_stats' || action === 'sports_bets' || action === 'sports_fixtures') {
            requiredPermission = 'manage_users';
        } else if (action === 'transactions') {
            requiredPermission = 'manage_finances';
        }

        const access = await verifyPermission(req, requiredPermission);
        if (!access.success) return res.status(access.status).json({ error: access.error });

        switch (action) {
            case 'game_state': {
                const { rows } = await query(
                    'SELECT round_id, status, crash_point, next_crash_point, server_time FROM active_game_state WHERE id = 1'
                );
                return res.status(200).json(rows[0] || {});
            }

            case 'stats': {
                const { rows: userCount } = await query('SELECT COUNT(*) AS count FROM profiles');
                const { rows: ggrRows } = await query('SELECT calculate_total_ggr() AS ggr');

                return res.status(200).json({
                    users: parseInt(userCount[0]?.count || '0', 10),
                    ggr: parseFloat(ggrRows[0]?.ggr || 0),
                    status: 'STABLE'
                });
            }

            case 'audit_logs': {
                const { rows } = await query(
                    `SELECT a.id, a.action, a.target_id, a.details, a.created_at,
                            json_build_object('username', p.username, 'phone', p.phone) AS profiles
                     FROM audit_logs a
                     LEFT JOIN profiles p ON a.admin_id = p.id
                     ORDER BY a.created_at DESC LIMIT 500`
                );
                return res.status(200).json(rows);
            }

            case 'users': {
                const { rows } = await query(
                    `SELECT p.id, p.phone, p.email, p.username, p.balance, p.is_frozen, p.created_at,
                            json_build_object('roles', json_build_object('name', COALESCE(r.name, 'User'))) AS user_roles
                     FROM profiles p
                     LEFT JOIN user_roles ur ON p.id = ur.user_id
                     LEFT JOIN roles r ON ur.role_id = r.id
                     ORDER BY p.created_at DESC LIMIT 500`
                );
                return res.status(200).json(rows);
            }

            case 'transactions': {
                const page   = Math.max(0, parseInt(req.query.page  || '0', 10));
                const limit  = Math.min(500, Math.max(1, parseInt(req.query.limit || '100', 10)));
                const offset = page * limit;

                const { rows } = await query(
                    `SELECT t.*, json_build_object('username', p.username, 'phone', p.phone) AS profiles
                     FROM transactions t
                     LEFT JOIN profiles p ON t.user_id = p.id
                     ORDER BY t.created_at DESC
                     LIMIT $1 OFFSET $2`,
                    [limit, offset]
                );
                return res.status(200).json(rows);
            }

            case 'diagnose_users': {
                const { rows: missingRoles } = await query(
                    `SELECT p.id, p.phone, p.username FROM profiles p
                     LEFT JOIN user_roles ur ON p.id = ur.user_id
                     WHERE ur.role_id IS NULL`
                );

                return res.status(200).json({
                    healthy: missingRoles.length === 0,
                    missingRoleCount: missingRoles.length,
                    usersWithoutRoles: missingRoles
                });
            }

            case 'repair_users': {
                const { rows: userRole } = await query("SELECT id FROM roles WHERE name = 'User'");
                if (userRole.length === 0) throw new Error('User role not found in database.');

                const defaultRoleId = userRole[0].id;

                const { rowCount } = await query(
                    `INSERT INTO user_roles (user_id, role_id)
                     SELECT p.id, $1 FROM profiles p
                     LEFT JOIN user_roles ur ON p.id = ur.user_id
                     WHERE ur.role_id IS NULL
                     ON CONFLICT DO NOTHING`,
                    [defaultRoleId]
                );

                return res.status(200).json({
                    success: true,
                    repairedUsers: rowCount,
                    message: `Assigned default User role to ${rowCount} users.`
                });
            }

            case 'sports_stats': {
                const { rows: statsRows } = await query(`
                    SELECT
                        COUNT(*) AS total_bets,
                        COALESCE(SUM(stake), 0) AS total_volume,
                        COALESCE(SUM(CASE WHEN status = 'won' THEN potential_payout ELSE 0 END), 0) AS total_won_payout,
                        COALESCE(SUM(CASE WHEN status = 'cashed_out' THEN potential_payout ELSE 0 END), 0) AS total_cashed_out_payout,
                        COALESCE(SUM(CASE WHEN status = 'pending' THEN potential_payout ELSE 0 END), 0) AS pending_exposure,
                        COALESCE(SUM(CASE WHEN status = 'pending' THEN stake ELSE 0 END), 0) AS pending_stake,
                        COUNT(*) FILTER (WHERE status = 'pending') AS pending_count,
                        COUNT(*) FILTER (WHERE status = 'won') AS won_count,
                        COUNT(*) FILTER (WHERE status = 'lost') AS lost_count,
                        COUNT(*) FILTER (WHERE status = 'cashed_out') AS cashed_out_count,
                        COUNT(*) FILTER (WHERE status = 'cancelled') AS cancelled_count,
                        COUNT(DISTINCT user_id) AS unique_bettors
                    FROM sports_bets
                `);

                const { rows: txRows } = await query(`
                    SELECT
                        COALESCE(SUM(CASE WHEN type = 'sports_payout' THEN amount ELSE 0 END), 0) AS actual_payout,
                        COALESCE(SUM(CASE WHEN type = 'sports_cashout' THEN amount ELSE 0 END), 0) AS actual_cashout,
                        COALESCE(SUM(CASE WHEN type = 'sports_refund' THEN amount ELSE 0 END), 0) AS actual_refund
                    FROM transactions
                    WHERE status = 'completed'
                `);

                const { rows: topBettors } = await query(`
                    SELECT
                        p.id, p.username, p.phone, p.balance,
                        COUNT(sb.id) AS bet_count,
                        COALESCE(SUM(sb.stake), 0) AS total_wagered,
                        COALESCE(SUM(CASE WHEN sb.status = 'won' THEN sb.potential_payout ELSE 0 END), 0) AS total_won
                    FROM sports_bets sb
                    LEFT JOIN profiles p ON sb.user_id = p.id
                    GROUP BY p.id, p.username, p.phone, p.balance
                    ORDER BY total_wagered DESC
                    LIMIT 8
                `);

                const stats = statsRows[0] || {};
                const tx = txRows[0] || {};

                const totalVolume = parseFloat(stats.total_volume || 0);
                const totalPayout = parseFloat(tx.actual_payout || stats.total_won_payout || 0) + parseFloat(tx.actual_cashout || 0);
                const ggr = totalVolume - totalPayout;
                const hold = totalVolume > 0 ? ((ggr / totalVolume) * 100).toFixed(1) : '0.0';

                return res.status(200).json({
                    totalBets: parseInt(stats.total_bets || 0, 10),
                    totalVolume,
                    totalPayout,
                    ggr,
                    holdPercentage: parseFloat(hold),
                    pendingCount: parseInt(stats.pending_count || 0, 10),
                    pendingExposure: parseFloat(stats.pending_exposure || 0),
                    pendingStake: parseFloat(stats.pending_stake || 0),
                    wonCount: parseInt(stats.won_count || 0, 10),
                    lostCount: parseInt(stats.lost_count || 0, 10),
                    cashedOutCount: parseInt(stats.cashed_out_count || 0, 10),
                    cancelledCount: parseInt(stats.cancelled_count || 0, 10),
                    uniqueBettors: parseInt(stats.unique_bettors || 0, 10),
                    topBettors,
                    telemetry: getSportsCacheTelemetry ? getSportsCacheTelemetry() : null
                });
            }

            case 'sports_bets': {
                const page   = Math.max(0, parseInt(req.query.page  || '0', 10));
                const limit  = Math.min(200, Math.max(1, parseInt(req.query.limit || '50', 10)));
                const offset = page * limit;
                const status = req.query.status;
                const type   = req.query.type;
                const search = (req.query.search || '').trim();
                const sort   = req.query.sort || 'newest';

                const conditions = [];
                const params = [];

                if (status && status !== 'all') {
                    params.push(status);
                    conditions.push(`sb.status = $${params.length}`);
                }

                if (type && type !== 'all') {
                    params.push(type);
                    conditions.push(`sb.bet_type = $${params.length}`);
                }

                if (search) {
                    params.push(`%${search}%`);
                    const idx = params.length;
                    conditions.push(`(
                        p.username ILIKE $${idx} OR
                        p.phone ILIKE $${idx} OR
                        p.email ILIKE $${idx} OR
                        sb.id::text ILIKE $${idx} OR
                        sb.selections::text ILIKE $${idx}
                    )`);
                }

                const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

                let orderClause = 'ORDER BY sb.created_at DESC';
                if (sort === 'oldest') orderClause = 'ORDER BY sb.created_at ASC';
                else if (sort === 'highest_stake') orderClause = 'ORDER BY sb.stake DESC';
                else if (sort === 'highest_payout') orderClause = 'ORDER BY sb.potential_payout DESC';
                else if (sort === 'highest_odds') orderClause = 'ORDER BY sb.total_odds DESC';

                const countSql = `
                    SELECT COUNT(*) AS total
                    FROM sports_bets sb
                    LEFT JOIN profiles p ON sb.user_id = p.id
                    ${whereClause}
                `;
                const { rows: countRows } = await query(countSql, params);
                const total = parseInt(countRows[0]?.total || 0, 10);

                params.push(limit);
                params.push(offset);
                const querySql = `
                    SELECT
                        sb.id, sb.user_id, sb.bet_type, sb.stake, sb.total_odds, sb.potential_payout,
                        sb.status, sb.selections, sb.created_at, sb.settled_at,
                        p.username, p.phone, p.email, p.balance AS user_balance, p.is_frozen
                    FROM sports_bets sb
                    LEFT JOIN profiles p ON sb.user_id = p.id
                    ${whereClause}
                    ${orderClause}
                    LIMIT $${params.length - 1} OFFSET $${params.length}
                `;

                const { rows } = await query(querySql, params);

                return res.status(200).json({
                    total,
                    page,
                    limit,
                    bets: rows
                });
            }

            case 'sports_fixtures': {
                const { rows: fixtures } = await query(`
                    SELECT
                        elem->>'match' AS match_name,
                        elem->>'sport' AS sport,
                        elem->>'market' AS market,
                        elem->>'eventId' AS event_id,
                        COUNT(DISTINCT sb.id) AS pending_bets_count,
                        COALESCE(SUM(sb.stake), 0) AS total_stake_kes,
                        COALESCE(SUM(sb.potential_payout), 0) AS total_exposure_kes,
                        json_agg(DISTINCT elem->>'pick') AS picks
                    FROM sports_bets sb,
                         jsonb_array_elements(sb.selections) elem
                    WHERE sb.status = 'pending'
                    GROUP BY elem->>'match', elem->>'sport', elem->>'market', elem->>'eventId'
                    ORDER BY total_stake_kes DESC
                `);

                return res.status(200).json({
                    success: true,
                    count: fixtures.length,
                    fixtures
                });
            }

            default:
                return res.status(400).json({ error: `Unknown system action: ${action}` });
        }
    } catch (err) {
        console.error('[Admin System Error]:', err);
        return res.status(500).json({ error: err.message });
    }
}
