import { defineConfig } from "vite";
import { resolve } from "path";

export default defineConfig({
  root: ".",
  plugins: [
    {
      name: 'html-rewrite',
      configureServer(server) {
        server.middlewares.use((req, res, next) => {
          const url = new URL(req.url || '', `http://${req.headers.host || 'localhost'}`);
          const pathname = url.pathname;
          
          // Rewrite clean URLs to their corresponding HTML file in development
          if (req.method === 'GET' && !pathname.includes('.')) {
            if (pathname === '/super-admin/login') {
              req.url = '/super-admin-login.html';
            } else if (pathname === '/admin/login') {
              req.url = '/admin-login.html';
            } else if (pathname === '/404') {
              req.url = '/404.html';
            } else if (pathname === '/auth' || pathname === '/login' || pathname === '/register') {
              req.url = '/auth.html';
            } else if (pathname === '/admin') {
              req.url = '/admin.html';
            } else if (pathname === '/super-admin') {
              req.url = '/super-admin.html';
            } else if (pathname === '/play' || pathname === '/aviator') {
              req.url = '/play.html';
            } else if (pathname === '/accounts' || pathname === '/account') {
              req.url = '/account.html';
            } else if (pathname === '/bets' || pathname === '/my-bets') {
              req.url = '/bets.html';
            } else if (pathname === '/' || pathname === '/sports') {
              req.url = '/sports.html';
            } else if (!pathname.startsWith('/api') && !pathname.startsWith('/webhooks')) {
              req.url = '/sports.html';
            }
          }
          next();
        });
      }
    }
  ],
  build: {
    outDir: "dist",
    emptyOutDir: true,
    rollupOptions: {
      input: {
        main: resolve(__dirname, "index.html"),
        sports: resolve(__dirname, "sports.html"),
        auth: resolve(__dirname, "auth.html"),
        admin: resolve(__dirname, "admin.html"),
        adminLogin: resolve(__dirname, "admin-login.html"),
        superAdmin: resolve(__dirname, "super-admin.html"),
        superAdminLogin: resolve(__dirname, "super-admin-login.html"),
        notFound: resolve(__dirname, "404.html"),
        play: resolve(__dirname, "play.html"),
        account: resolve(__dirname, "account.html"),
        bets: resolve(__dirname, "bets.html"),
      },
    },
  },
});
