import { supabase } from '../config/supabase.js';

/**
 * Retrieves a helper that returns the current session's Bearer token.
 * Returns null if the user is not authenticated.
 */
async function getAuthHeader() {
    try {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.access_token) {
            return { Authorization: `Bearer ${session.access_token}` };
        }
    } catch (_) {}
    return {};
}

export async function fetchUserBalance(userId) {
    if (!userId) return { balance: 0, error: new Error('User ID required') };
    try {
        const { data, error } = await supabase
            .from('profiles')
            .select('balance')
            .eq('id', userId)
            .single();
        if (error) return { balance: 0, error };
        return { balance: parseFloat(data.balance), error: null };
    } catch (err) {
        return { balance: 0, error: err };
    }
}

export async function requestDeposit(amount, phone) {
    try {
        const authHeaders = await getAuthHeader();
        const res = await fetch('/api/deposit', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                ...authHeaders
            },
            body: JSON.stringify({ amount, phone })
        });
        const data = await res.json();
        return data;
    } catch (err) {
        return { success: false, error: err.message || 'Deposit request failed' };
    }
}

export async function requestWithdrawal(amount, phone) {
    try {
        const authHeaders = await getAuthHeader();
        const res = await fetch('/api/withdraw', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                ...authHeaders
            },
            body: JSON.stringify({ amount, phone })
        });
        const data = await res.json();
        return data;
    } catch (err) {
        return { success: false, error: err.message || 'Withdrawal request failed' };
    }
}

export async function claimPromoCode(code) {
    try {
        const authHeaders = await getAuthHeader();
        const res = await fetch('/api/claim-promo', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                ...authHeaders
            },
            body: JSON.stringify({ code })
        });
        const data = await res.json();
        return data;
    } catch (err) {
        return { success: false, error: err.message || 'Claim promo code failed' };
    }
}
