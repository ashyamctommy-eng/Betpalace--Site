import { supabase } from '../config/supabase.js';

// Central route configurations and requirements
export const ROUTE_REGISTRY = {
  '/':                  { authRequired: false, allowedRoles: [] },
  '/sports':            { authRequired: false, allowedRoles: [] },
  '/accounts':          { authRequired: true,  allowedRoles: ['User', 'Admin', 'Super Admin'], redirectIfUnauth: '/auth#login' },
  '/account':           { authRequired: true,  allowedRoles: ['User', 'Admin', 'Super Admin'], redirectIfUnauth: '/auth#login' },
  '/bets':              { authRequired: true,  allowedRoles: ['User', 'Admin', 'Super Admin'], redirectIfUnauth: '/auth#login' },
  '/my-bets':           { authRequired: true,  allowedRoles: ['User', 'Admin', 'Super Admin'], redirectIfUnauth: '/auth#login' },
  '/auth':              { authRequired: false, allowedRoles: [], redirectIfAuth: '/sports' },
  '/auth.html':         { authRequired: false, allowedRoles: [], redirectIfAuth: '/sports' },
  '/login':             { authRequired: false, allowedRoles: [], redirectIfAuth: '/sports' },
  '/register':          { authRequired: false, allowedRoles: [], redirectIfAuth: '/sports' },
  '/aviator':           { authRequired: true,  allowedRoles: ['User', 'Admin', 'Super Admin'] },
  '/play':              { authRequired: true,  allowedRoles: ['User', 'Admin', 'Super Admin'] },
  '/super-admin/login': { authRequired: false, allowedRoles: [], redirectIfAuth: '/super-admin' },
  '/admin/login':       { authRequired: false, allowedRoles: [], redirectIfAuth: '/admin' },
  '/admin':             { authRequired: true,  allowedRoles: ['Admin', 'Super Admin'], unauthAction: '404' },
  '/admin.html':        { authRequired: true,  allowedRoles: ['Admin', 'Super Admin'], unauthAction: '404' },
  '/super-admin':       { authRequired: true,  allowedRoles: ['Super Admin'], unauthAction: '404' },
  '/super-admin.html':  { authRequired: true,  allowedRoles: ['Super Admin'], unauthAction: '404' }
};

const roleCache = new Map();

/**
 * Restores user session cryptographically or from native JWT storage.
 */
export async function restoreSession() {
  try {
    const { data: { session }, error } = await supabase.auth.getSession();
    if (error || !session) return null;

    // Cryptographically verify session validity on auth server
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      return null;
    }

    return session;
  } catch (err) {
    console.error('[Auth] Session restoration error:', err);
    return null;
  }
}

/**
 * Resolves user role (User, Admin, Super Admin) and caches in memory.
 */
export async function resolveRole(userId) {
  const cacheKey = `role_${userId}`;
  const cached = roleCache.get(cacheKey);
  if (cached && (Date.now() - cached.timestamp < 300000)) {
    return cached.role;
  }

  try {
    // 1. Check local session storage
    const rawUser = localStorage.getItem('metrowins_auth_user');
    if (rawUser) {
      const u = JSON.parse(rawUser);
      if (u && u.role) {
        const normalized = u.role === 'Player' ? 'User' : u.role;
        roleCache.set(cacheKey, { role: normalized, timestamp: Date.now() });
        return normalized;
      }
    }

    // 2. Fetch fresh profile from API
    const token = localStorage.getItem('metrowins_auth_token');
    if (token) {
      const res = await fetch('/api/auth/me', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        if (data.user && data.user.role) {
          const normalized = data.user.role === 'Player' ? 'User' : data.user.role;
          roleCache.set(cacheKey, { role: normalized, timestamp: Date.now() });
          return normalized;
        }
      }
    }
  } catch (err) {
    console.error('[Auth] Role resolution error:', err);
  }

  return 'User';
}

/**
 * Renders a clean 404 page directly in the viewport so protected routes never leak.
 */
export function render404() {
  document.title = '404 Not Found';
  document.body.style.margin = '0';
  document.body.style.padding = '0';
  document.body.style.background = '#07090e';
  document.body.innerHTML = `
    <div style="min-height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; background: #07090e; color: #f1f5f9; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; text-align: center; padding: 24px; box-sizing: border-box;">
      <div style="font-size: 6rem; font-weight: 900; color: #1e293b; line-height: 1; margin-bottom: 12px; letter-spacing: -3px;">404</div>
      <h1 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 8px; color: #f8fafc;">404 Not Found</h1>
      <p style="color: #64748b; font-size: 0.95rem; max-width: 400px; line-height: 1.5; margin-bottom: 24px;">The page you are looking for does not exist or has been moved.</p>
      <a href="/" style="display: inline-flex; align-items: center; justify-content: center; background: #1e293b; color: #f8fafc; text-decoration: none; padding: 10px 24px; border-radius: 8px; font-weight: 600; font-size: 0.88rem; border: 1px solid #334155; transition: all 0.2s;">Return to Home</a>
    </div>
  `;
  const loader = document.getElementById('app-loading-screen');
  if (loader) loader.remove();
}

/**
 * Performs redirection.
 */
export function performRedirect(destination, reason) {
  console.warn(`[Auth] Redirecting to ${destination}. Reason: ${reason}`);

  const loader = document.getElementById('app-loading-screen');
  if (loader) loader.style.display = 'flex';

  window.location.href = destination;
}

/**
 * Initializes the route guard checks on the current path.
 */
export async function initGuard() {
  const pathname = window.location.pathname.replace(/\/$/, '') || '/';
  const urlParams = new URLSearchParams(window.location.search);
  
  // Support Demo Mode bypass on play/aviator page
  const isDemo = urlParams.get('mode') === 'demo' || urlParams.get('demo') === 'true' || window.location.hostname.startsWith('demo.');
  if (isDemo && (pathname === '/play' || pathname === '/aviator')) {
    const loader = document.getElementById('app-loading-screen');
    if (loader) loader.remove();
    return true;
  }

  // Support Password Recovery bypass on auth page
  if (pathname === '/auth') {
    const isRecovery = window.location.hash.includes('type=recovery') || window.location.search.includes('type=recovery');
    if (isRecovery) {
      const loader = document.getElementById('app-loading-screen');
      if (loader) loader.remove();
      return true;
    }
  }

  // Match path against route config
  const routeConfig = ROUTE_REGISTRY[pathname] || { authRequired: true, allowedRoles: ['User'] };

  const session = await restoreSession();

  if (!session) {
    if (routeConfig.authRequired) {
      if (routeConfig.unauthAction === '404') {
        render404();
        return false;
      }
      performRedirect(routeConfig.redirectIfUnauth || '/auth', 'Unauthorized access to protected page');
      return false;
    }
  } else {
    if (routeConfig.redirectIfAuth) {
      performRedirect(routeConfig.redirectIfAuth, 'Authorized user navigated to landing/auth page');
      return false;
    }

    const userRole = await resolveRole(session.user.id);

    if (routeConfig.allowedRoles.length > 0 && !routeConfig.allowedRoles.includes(userRole)) {
      console.warn(`[Auth] Permission denied: Role "${userRole}" lacks permissions for path: ${pathname}`);
      if (routeConfig.unauthAction === '404') {
        render404();
        return false;
      }
      performRedirect('/sports', 'Forbidden: Insufficient roles');
      return false;
    }
  }

  // Hide loading screen and display main content
  const loader = document.getElementById('app-loading-screen');
  if (loader) {
    loader.style.transition = 'opacity 0.25s ease';
    loader.style.opacity = '0';
    setTimeout(() => loader.remove(), 250);
  }

  return true;
}

/**
 * Performs session signout cleanup.
 */
export async function handleLogout() {
  try {
    await supabase.auth.signOut();
    roleCache.clear();
    performRedirect('/auth', 'User requested signout');
  } catch (err) {
    console.error('[Auth] Error executing signout:', err);
    performRedirect('/auth', 'Fallback signout');
  }
}
