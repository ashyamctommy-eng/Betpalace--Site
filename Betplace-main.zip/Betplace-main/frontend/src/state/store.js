/**
 * Centralized Reactive Application Store
 */

class AppStore {
    constructor() {
        this.state = {
            currentUser: null,
            balance: 0,
            isDemoMode: false,
            gameState: 'waiting', // 'waiting' | 'playing' | 'crashed'
            serverRoundId: 0,
            serverRoundStartTime: 0,
            serverCrashPoint: 1.00,
            currentMultiplier: 1.00,
            crashHistory: [],
            currentLobbyCount: 0,
            myBetsList: [],
            bet1: { id: null, amount: 50, active: false, cashed: false, auto: false, winnings: 0, cashoutPending: false, roundId: null },
            bet2: { id: null, amount: 50, active: false, cashed: false, auto: false, winnings: 0, cashoutPending: false, roundId: null }
        };
        this.listeners = new Set();
    }

    getState() {
        return this.state;
    }

    setState(partialState) {
        this.state = { ...this.state, ...partialState };
        this.listeners.forEach(fn => fn(this.state));
    }

    subscribe(listener) {
        this.listeners.add(listener);
        return () => this.listeners.delete(listener);
    }
}

export const store = new AppStore();
