-- ═══════════════════════════════════════════════════════════════════
-- MIGRATION 026: Fix sync_and_get_game_state — honour next_crash_point
--                override and clear it atomically after consumption.
-- ═══════════════════════════════════════════════════════════════════
--
-- PROBLEM: migration 021 replaced the function but did NOT include
--   the next_crash_point column in the UPDATE statement, so admin
--   signal overrides were never consumed and the value remained stuck
--   permanently, causing the Predictor Panel to always show the same
--   value.
--
-- FIX:
--   1. Re-create the function with the override check in the crashed→waiting
--      transition AND clear next_crash_point = NULL when transitioning
--      to 'waiting' (override consumed).
--   2. Clear any currently-stuck value immediately.
-- ═══════════════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION public.sync_and_get_game_state()
RETURNS JSON AS $$
DECLARE
    v_state              RECORD;
    v_now                TIMESTAMPTZ;
    v_elapsed            INT;
    v_needs_update       BOOLEAN := false;
    v_status             TEXT;
    v_round_id           BIGINT;
    v_crash_point        DECIMAL;
    v_start_time         TIMESTAMPTZ;
    v_waiting_ms         INT := 5000;
    v_max_flight_ms      INT := 300000;
    v_post_crash_ms      INT := 3000;
    v_elapsed_sec        DECIMAL;
    v_calc_mult          DECIMAL;
    v_random             DECIMAL;
    v_new_crash_point    DECIMAL;
    v_instant_crash_rate DECIMAL := 0.03;
    v_total_bets         DECIMAL;
    v_high_bet_limit     DECIMAL := 100000;
    v_extreme_bet_limit  DECIMAL := 500000;
    v_dynamic_mode       BOOLEAN := true;
BEGIN
    v_now := now();

    -- Get current state (lock the row to prevent concurrent updates)
    SELECT * INTO v_state FROM public.active_game_state WHERE id = 1 LIMIT 1 FOR UPDATE SKIP LOCKED;

    -- If no row found (lock skipped by another caller), return current state without changes
    IF v_state IS NULL THEN
        SELECT * INTO v_state FROM public.active_game_state WHERE id = 1 LIMIT 1;
        IF v_state IS NULL THEN
            INSERT INTO public.active_game_state (id, round_id, start_time, crash_point, status, server_time)
            VALUES (1, 1, v_now, 2.50, 'waiting', v_now)
            RETURNING * INTO v_state;
        END IF;

        RETURN json_build_object(
            'roundId',        v_state.round_id,
            'roundStartTime', EXTRACT(EPOCH FROM v_state.start_time) * 1000,
            'crashPoint',     v_state.crash_point,
            'gameStatus',     v_state.status,
            'serverTime',     EXTRACT(EPOCH FROM v_now) * 1000,
            'elapsedMs',      EXTRACT(EPOCH FROM (v_now - v_state.start_time)) * 1000
        );
    END IF;

    v_status      := v_state.status;
    v_round_id    := v_state.round_id;
    v_crash_point := v_state.crash_point;
    v_start_time  := v_state.start_time;

    -- Calculate elapsed milliseconds since last phase transition
    v_elapsed := EXTRACT(EPOCH FROM (v_now - v_start_time)) * 1000;

    -- ── Phase advance logic ─────────────────────────────────────────────────────
    IF v_status = 'waiting' THEN
        IF v_elapsed >= v_waiting_ms THEN
            v_status     := 'playing';
            v_start_time := v_now;
            v_elapsed    := 0;

            -- Dynamic bet-based cap (protect extreme liquidity exposure)
            IF v_dynamic_mode THEN
                SELECT COALESCE(SUM(amount), 0) INTO v_total_bets
                FROM public.bets
                WHERE round_id = v_round_id;

                IF v_total_bets >= v_extreme_bet_limit THEN
                    IF random() < 0.85 THEN
                        v_crash_point := round(1.00 + (random() * 0.19), 2);
                    ELSE
                        v_crash_point := 1.00;
                    END IF;
                ELSIF v_total_bets >= v_high_bet_limit THEN
                    IF random() < 0.70 THEN
                        v_crash_point := round(1.01 + (random() * 0.79), 2);
                    END IF;
                END IF;
            END IF;

            v_needs_update := true;
        END IF;

    ELSIF v_status = 'playing' THEN
        v_elapsed_sec := v_elapsed::DECIMAL / 1000.0;
        v_calc_mult   := power(1.06, v_elapsed_sec);

        IF v_calc_mult >= v_crash_point OR v_elapsed >= v_max_flight_ms THEN
            v_status     := 'crashed';
            v_start_time := v_now;
            v_elapsed    := 0;
            v_needs_update := true;
        END IF;

    ELSIF v_status = 'crashed' THEN
        IF v_elapsed >= v_post_crash_ms + 2000 THEN
            v_status   := 'waiting';
            v_round_id := v_round_id + 1;
            v_start_time := v_now;
            v_elapsed  := 0;

            -- ── Crash point for NEXT round ─────────────────────────────────────
            -- Honour admin override if one is queued, then clear it.
            IF v_state.next_crash_point IS NOT NULL AND v_state.next_crash_point > 1.00 THEN
                v_new_crash_point := v_state.next_crash_point;
            ELSE
                v_random := random();
                IF v_random < v_instant_crash_rate THEN
                    v_new_crash_point := 1.00;
                ELSIF v_random < 0.40 THEN
                    v_new_crash_point := 1.01 + (random() * 0.79);
                ELSIF v_random < 0.80 THEN
                    v_new_crash_point := 1.80 + (random() * 5.20);
                ELSIF v_random < 0.95 THEN
                    v_new_crash_point := 7.00 + (random() * 18.00);
                ELSE
                    v_new_crash_point := 25.00 + (random() * 175.00);
                END IF;
            END IF;

            v_crash_point  := round(v_new_crash_point, 2);
            v_needs_update := true;
        END IF;
    END IF;

    -- ── Persist state change ────────────────────────────────────────────────────
    IF v_needs_update THEN
        UPDATE public.active_game_state
        SET status      = v_status,
            round_id    = v_round_id,
            crash_point = v_crash_point,
            start_time  = v_start_time,
            server_time = v_now,
            -- Consume / clear the override when transitioning to 'waiting' phase
            next_crash_point = CASE
                WHEN v_status = 'waiting' THEN NULL
                ELSE next_crash_point
            END
        WHERE id = 1;

        IF v_status = 'crashed' THEN
            INSERT INTO public.game_history (multiplier)
            VALUES (v_crash_point);
        END IF;
    ELSE
        -- Always touch server_time so external monitors can detect freshness
        UPDATE public.active_game_state
        SET server_time = v_now
        WHERE id = 1;
    END IF;

    RETURN json_build_object(
        'roundId',        v_round_id,
        'roundStartTime', EXTRACT(EPOCH FROM v_start_time) * 1000,
        'crashPoint',     v_crash_point,
        'gameStatus',     v_status,
        'serverTime',     EXTRACT(EPOCH FROM v_now) * 1000,
        'elapsedMs',      v_elapsed
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Clear any currently-stuck override immediately
UPDATE public.active_game_state
SET next_crash_point = NULL
WHERE id = 1;

-- Force PostgREST to reload so the updated function is visible instantly
NOTIFY pgrst, 'reload schema';
