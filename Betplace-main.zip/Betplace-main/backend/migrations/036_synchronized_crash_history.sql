-- ═══════════════════════════════════════════════════════════════════════════
-- MIGRATION 036: Synchronized Crash History & Game State Fixes
-- ═══════════════════════════════════════════════════════════════════════════
--
-- PROBLEMS FIXED:
--   1. Crash history accuracy: history is now embedded directly in the
--      active_game_state row so every Realtime UPDATE already carries it.
--      Clients never need a secondary query — no delayed or missing results.
--
--   2. History ordering: stored by INSERT order (id DESC) so newest is always
--      first; no created_at millisecond-resolution race conditions.
--
--   3. History pruning: game_history table capped at 200 rows. Prevents
--      unbounded growth that degrades query performance over time.
--
--   4. Exactly-once recording: the INSERT into game_history happens inside
--      the same atomic transaction as the status transition to 'crashed',
--      while the UPDATE to active_game_state happens AFTER. This ensures
--      the crash point is recorded before clients are notified.
--
--   5. Duplicate history protection: a unique constraint on
--      (round_id) in game_history prevents double-writes if the function
--      is called concurrently during the same crash event.
-- ═══════════════════════════════════════════════════════════════════════════

SET lock_timeout = '10s';

-- ── 1. Add history column to active_game_state ──────────────────────────────
ALTER TABLE public.active_game_state
    ADD COLUMN IF NOT EXISTS history JSONB NOT NULL DEFAULT '[]'::jsonb;

-- ── 2. Add unique round_id constraint to game_history (idempotent) ──────────
ALTER TABLE public.game_history
    ADD COLUMN IF NOT EXISTS round_id BIGINT;

-- Back-fill round_id for existing rows using row_number (best effort)
UPDATE public.game_history
SET round_id = sub.rn
FROM (
    SELECT id, ROW_NUMBER() OVER (ORDER BY id) AS rn FROM public.game_history
) sub
WHERE public.game_history.id = sub.id AND public.game_history.round_id IS NULL;

-- Create unique constraint only if it doesn't exist yet
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conname = 'game_history_round_id_unique'
    ) THEN
        ALTER TABLE public.game_history
            ADD CONSTRAINT game_history_round_id_unique UNIQUE (round_id);
    END IF;
END $$;

-- Create index on id DESC for fast history queries
CREATE INDEX IF NOT EXISTS idx_game_history_id_desc
    ON public.game_history (id DESC);

-- ── 3. Replace sync_and_get_game_state with fixed, history-aware version ─────
CREATE OR REPLACE FUNCTION public.sync_and_get_game_state()
RETURNS JSON AS $$
DECLARE
    v_state              RECORD;
    v_now                TIMESTAMPTZ;
    v_elapsed            INT;
    v_needs_update       BOOLEAN := false;
    v_status             TEXT;
    v_round_id           BIGINT;
    v_crash_point        DECIMAL;
    v_start_time         TIMESTAMPTZ;
    v_waiting_ms         INT := 5000;
    v_max_flight_ms      INT := 300000;
    v_post_crash_ms      INT := 1200;
    v_elapsed_sec        DECIMAL;
    v_calc_mult          DECIMAL;
    v_random             DECIMAL;
    v_new_crash_point    DECIMAL;
    v_instant_crash_rate DECIMAL := 0.03;
    v_total_bets         DECIMAL := 0;
    v_high_bet_limit     DECIMAL := 100000;
    v_extreme_bet_limit  DECIMAL := 500000;
    v_dynamic_mode       BOOLEAN := true;
    v_history_json       JSONB;
BEGIN
    v_now := clock_timestamp();  -- Use clock_timestamp() not now() to avoid caching

    -- Read current state snapshot non-blocking to get round_id for bet calculations
    SELECT * INTO v_state FROM public.active_game_state WHERE id = 1 LIMIT 1;

    -- Fallback initialization if row does not exist
    IF v_state IS NULL THEN
        INSERT INTO public.active_game_state (id, round_id, start_time, crash_point, status, server_time, history)
        VALUES (1, 1, v_now, 2.50, 'waiting', v_now, '[]'::jsonb)
        ON CONFLICT (id) DO NOTHING;

        SELECT * INTO v_state FROM public.active_game_state WHERE id = 1 LIMIT 1;
    END IF;

    -- Calculate bet liquidity exposure BEFORE acquiring active_game_state row lock
    -- (Strict lock hierarchy: bets -> active_game_state to prevent deadlocks)
    IF v_dynamic_mode AND v_state IS NOT NULL THEN
        SELECT COALESCE(SUM(amount), 0) INTO v_total_bets
        FROM public.bets
        WHERE round_id = v_state.round_id;
    END IF;

    -- Lock active_game_state row for atomic state modification
    SELECT * INTO v_state FROM public.active_game_state WHERE id = 1 LIMIT 1 FOR UPDATE;

    v_status      := v_state.status;
    v_round_id    := v_state.round_id;
    v_crash_point := v_state.crash_point;
    v_start_time  := v_state.start_time;

    -- Calculate elapsed milliseconds since last phase transition
    v_elapsed := EXTRACT(EPOCH FROM (v_now - v_start_time)) * 1000;

    -- ── Phase advance logic ──────────────────────────────────────────────────
    IF v_status = 'waiting' THEN
        IF v_elapsed >= v_waiting_ms THEN
            v_status     := 'playing';
            v_start_time := v_now;
            v_elapsed    := 0;

            -- Dynamic bet-based cap (protect extreme liquidity exposure)
            IF v_dynamic_mode THEN
                IF v_total_bets >= v_extreme_bet_limit THEN
                    IF random() < 0.85 THEN
                        v_crash_point := round(1.00 + (random() * 0.19), 2);
                    ELSE
                        v_crash_point := 1.00;
                    END IF;
                ELSIF v_total_bets >= v_high_bet_limit THEN
                    IF random() < 0.70 THEN
                        v_crash_point := round(1.01 + (random() * 0.79), 2);
                    END IF;
                END IF;
            END IF;

            v_needs_update := true;
        END IF;

    ELSIF v_status = 'playing' THEN
        v_elapsed_sec := v_elapsed::DECIMAL / 1000.0;
        v_calc_mult   := power(1.06, v_elapsed_sec);

        IF v_calc_mult >= v_crash_point OR v_elapsed >= v_max_flight_ms THEN
            -- ── RECORD CRASH IN HISTORY FIRST (before notifying clients) ──
            -- Use ON CONFLICT DO NOTHING to prevent duplicate entries
            INSERT INTO public.game_history (multiplier, round_id)
            VALUES (v_crash_point, v_round_id)
            ON CONFLICT (round_id) DO NOTHING;

            -- Prune game_history to keep only the latest 200 rows
            DELETE FROM public.game_history
            WHERE id NOT IN (
                SELECT id FROM public.game_history ORDER BY id DESC LIMIT 200
            );

            v_status       := 'crashed';
            v_start_time   := v_now;
            v_elapsed      := 0;
            v_needs_update := true;
        END IF;

    ELSIF v_status = 'crashed' THEN
        IF v_elapsed >= v_post_crash_ms THEN
            v_status   := 'waiting';
            v_round_id := v_round_id + 1;
            v_start_time := v_now;
            v_elapsed  := 0;

            -- ── Crash point for NEXT round ────────────────────────────────
            IF v_state.next_crash_point IS NOT NULL AND v_state.next_crash_point > 1.00 THEN
                v_new_crash_point := v_state.next_crash_point;
            ELSE
                v_random := random();
                IF v_random < v_instant_crash_rate THEN
                    v_new_crash_point := 1.00;
                ELSIF v_random < 0.40 THEN
                    v_new_crash_point := 1.01 + (random() * 0.79);
                ELSIF v_random < 0.80 THEN
                    v_new_crash_point := 1.80 + (random() * 5.20);
                ELSIF v_random < 0.95 THEN
                    v_new_crash_point := 7.00 + (random() * 18.00);
                ELSE
                    v_new_crash_point := 25.00 + (random() * 175.00);
                END IF;
            END IF;

            v_crash_point  := round(v_new_crash_point, 2);
            v_needs_update := true;
        END IF;
    END IF;

    -- ── Build history JSON snapshot from game_history table ─────────────────
    -- Always refresh history so it reflects the latest crash (even if inserted
    -- by this call above). Array is newest-first by id DESC.
    SELECT COALESCE(
        json_agg(multiplier ORDER BY id DESC)::jsonb,
        '[]'::jsonb
    ) INTO v_history_json
    FROM (
        SELECT id, multiplier FROM public.game_history ORDER BY id DESC LIMIT 20
    ) sub;

    -- ── Persist state change ─────────────────────────────────────────────────
    IF v_needs_update THEN
        UPDATE public.active_game_state
        SET status      = v_status,
            round_id    = v_round_id,
            crash_point = v_crash_point,
            start_time  = v_start_time,
            server_time = v_now,
            history     = v_history_json,
            next_crash_point = CASE
                WHEN v_status = 'waiting' THEN NULL
                ELSE next_crash_point
            END
        WHERE id = 1;
    ELSE
        -- Always keep history and server_time fresh even on no-op ticks
        UPDATE public.active_game_state
        SET server_time = v_now,
            history     = v_history_json
        WHERE id = 1;
    END IF;

    RETURN json_build_object(
        'roundId',        v_round_id,
        'roundStartTime', EXTRACT(EPOCH FROM v_start_time) * 1000,
        'crashPoint',     v_crash_point,
        'gameStatus',     v_status,
        'serverTime',     EXTRACT(EPOCH FROM v_now) * 1000,
        'elapsedMs',      v_elapsed,
        'history',        v_history_json
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

GRANT EXECUTE ON FUNCTION public.sync_and_get_game_state() TO authenticated, anon;

-- Allow public realtime on history column changes
ALTER TABLE public.active_game_state REPLICA IDENTITY FULL;

NOTIFY pgrst, 'reload schema';
