/**
 * debugPanel.js — Developer Telemetry & Synchronization Debug Panel
 *
 * Provides real-time visibility into the internal state of:
 *   - gameBridge telemetry
 *   - Frame rate (FPS) and animation loop status
 *   - Server round IDs, crash point, time offsets
 *   - Plane canvas coordinates and Bézier curve parameters
 *   - User bet statuses
 *
 * Press Ctrl+Shift+D to toggle the panel overlay.
 */

import { gameBridge } from './gameBridge.js';

let debugContainer = null;
let isVisible = false;

export function initDebugPanel() {
    if (debugContainer) return;

    debugContainer = document.createElement('div');
    debugContainer.id = 'game-debug-panel';
    debugContainer.style.cssText = `
        position: fixed;
        bottom: 12px;
        left: 12px;
        z-index: 99999;
        background: rgba(10, 14, 23, 0.92);
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 8px;
        padding: 10px 14px;
        font-family: monospace;
        font-size: 11px;
        color: #00ffcc;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.6);
        pointer-events: none;
        backdrop-filter: blur(8px);
        display: none;
        min-width: 240px;
        line-height: 1.5;
    `;

    document.body.appendChild(debugContainer);

    window.addEventListener('keydown', (e) => {
        if (e.ctrlKey && e.shiftKey && (e.key === 'D' || e.key === 'd')) {
            isVisible = !isVisible;
            debugContainer.style.display = isVisible ? 'block' : 'none';
        }
    });
}

export function updateDebugPanel(extraInfo = {}) {
    if (!debugContainer || !isVisible) return;

    const stateColor = {
        'WAITING': '#FFCC00',
        'COUNTDOWN': '#FFA500',
        'FLYING': '#00FF66',
        'CRASHED': '#FF3366',
        'RESETTING': '#AAAAAA'
    }[gameBridge.gameState] || '#FFFFFF';

    debugContainer.innerHTML = `
        <div style="font-weight: bold; color: #fff; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 4px; margin-bottom: 4px; display: flex; justify-content: space-between;">
            <span>🕹️ METRICWIN TELEMETRY</span>
            <span style="color: ${gameBridge.fps > 45 ? '#00FF66' : '#FF3366'}">${gameBridge.fps} FPS</span>
        </div>
        <div>State: <strong style="color: ${stateColor}">${gameBridge.gameState}</strong></div>
        <div>Round ID: <strong>#${gameBridge.roundId}</strong></div>
        <div>Multiplier: <strong style="color: #00FF66">${gameBridge.currentMultiplier.toFixed(2)}x</strong></div>
        <div>Crash Point: <strong style="color: #FF3366">${gameBridge.crashPoint ? gameBridge.crashPoint.toFixed(2) + 'x' : 'N/A'}</strong></div>
        <div>Server Offset: <strong>${gameBridge.serverTimeOffset > 0 ? '+' : ''}${gameBridge.serverTimeOffset}ms</strong></div>
        <div>Bézier T: <strong>${gameBridge.bezierT.toFixed(3)}</strong></div>
        <div>Plane Pos: <strong>X:${gameBridge.planeX} Y:${gameBridge.planeY}</strong></div>
        <div>Last Event: <span>${gameBridge.lastEventLabel}</span></div>
        <div>Socket: <span style="color: #00FF66">${gameBridge.socketStatus}</span></div>
    `;
}

export function toggleDebugPanel(show) {
    if (!debugContainer) initDebugPanel();
    isVisible = show !== undefined ? show : !isVisible;
    if (debugContainer) debugContainer.style.display = isVisible ? 'block' : 'none';
}
