-- ═══════════════════════════════════════════════
-- MIGRATION 019: Referral Rewards System
-- ═══════════════════════════════════════════════

-- 1. Insert default referral reward configuration into system_settings
INSERT INTO public.system_settings (key, value)
VALUES (
    'referral_rewards',
    '{
        "enabled": false,
        "referrer_bonus_kes": 100,
        "referee_bonus_kes": 0,
        "require_first_deposit": false,
        "min_deposit_kes": 100
    }'::jsonb
)
ON CONFLICT (key) DO NOTHING;

-- 2. Ensure referral_code column exists on profiles (defensive)
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS referral_code TEXT UNIQUE;

-- 3. Generate referral codes for profiles that don't have one
-- Format: REF + last 4 of phone digits + 3 random chars
UPDATE public.profiles
SET referral_code = 'REF' || UPPER(
    SUBSTR(MD5(id::text), 1, 7)
)
WHERE referral_code IS NULL;

-- 4. RPC: credit_referral_reward
-- Called via service role (admin API) after a new user account is created.
-- Checks if referral rewards are enabled in system_settings, then credits
-- the referrer and optionally the new user.
CREATE OR REPLACE FUNCTION public.credit_referral_reward(
    p_referrer_code TEXT,
    p_new_user_id   UUID
)
RETURNS JSON AS $$
DECLARE
    v_referrer_id       UUID;
    v_settings          JSONB;
    v_enabled           BOOLEAN;
    v_referrer_bonus    DECIMAL;
    v_referee_bonus     DECIMAL;
    v_require_deposit   BOOLEAN;
BEGIN
    -- Load reward config
    SELECT value INTO v_settings
    FROM public.system_settings
    WHERE key = 'referral_rewards'
    LIMIT 1;

    IF v_settings IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Referral config not found');
    END IF;

    v_enabled         := COALESCE((v_settings->>'enabled')::BOOLEAN, FALSE);
    v_referrer_bonus  := COALESCE((v_settings->>'referrer_bonus_kes')::DECIMAL, 0);
    v_referee_bonus   := COALESCE((v_settings->>'referee_bonus_kes')::DECIMAL, 0);
    v_require_deposit := COALESCE((v_settings->>'require_first_deposit')::BOOLEAN, FALSE);

    IF NOT v_enabled THEN
        RETURN json_build_object('success', false, 'error', 'Referral rewards disabled');
    END IF;

    -- Skip if first deposit is required (handled separately)
    IF v_require_deposit THEN
        RETURN json_build_object('success', false, 'error', 'Awaiting first deposit to credit reward');
    END IF;

    -- Resolve referrer from their referral code
    SELECT id INTO v_referrer_id
    FROM public.profiles
    WHERE UPPER(referral_code) = UPPER(p_referrer_code)
    LIMIT 1;

    IF v_referrer_id IS NULL THEN
        RETURN json_build_object('success', false, 'error', 'Referrer not found');
    END IF;

    -- Prevent self-referral
    IF v_referrer_id = p_new_user_id THEN
        RETURN json_build_object('success', false, 'error', 'Self-referral not allowed');
    END IF;

    -- Credit referrer bonus
    IF v_referrer_bonus > 0 THEN
        UPDATE public.profiles
        SET balance = balance + v_referrer_bonus
        WHERE id = v_referrer_id;

        INSERT INTO public.transactions (user_id, type, amount, status, reference)
        VALUES (v_referrer_id, 'referral_bonus', v_referrer_bonus, 'completed',
                'REF_' || p_new_user_id::TEXT);
    END IF;

    -- Credit referee bonus (new user)
    IF v_referee_bonus > 0 THEN
        UPDATE public.profiles
        SET balance = balance + v_referee_bonus
        WHERE id = p_new_user_id;

        INSERT INTO public.transactions (user_id, type, amount, status, reference)
        VALUES (p_new_user_id, 'referral_bonus', v_referee_bonus, 'completed',
                'REFBONUS_' || v_referrer_id::TEXT);
    END IF;

    -- Record the referral link in profile
    UPDATE public.profiles
    SET referred_by = v_referrer_id
    WHERE id = p_new_user_id AND referred_by IS NULL;

    RETURN json_build_object(
        'success', true,
        'referrer_credited', v_referrer_bonus,
        'referee_credited', v_referee_bonus
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant exec to service role only
REVOKE ALL ON FUNCTION public.credit_referral_reward(TEXT, UUID) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.credit_referral_reward(TEXT, UUID) TO service_role;
