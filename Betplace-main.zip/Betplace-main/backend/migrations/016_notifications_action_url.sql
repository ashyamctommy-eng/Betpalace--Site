-- MIGRATION 016: Add action_url column to notifications table
-- Allows admins to attach a clickable link to notifications sent to users.

ALTER TABLE public.notifications
    ADD COLUMN IF NOT EXISTS action_url TEXT DEFAULT NULL;

-- Reload PostgREST schema cache
NOTIFY pgrst, 'reload schema';
