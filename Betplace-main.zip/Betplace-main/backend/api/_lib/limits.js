/**
 * backend/api/_lib/limits.js
 *
 * Centralized Financial & Operational Limits Provider.
 * Reads dynamically configured limits from system_settings (key: 'financial_limits')
 * with memory caching and robust defaults.
 */

import { query } from './db.js';

let cachedLimits = null;
let cacheExpiresAt = 0;
const CACHE_TTL_MS = 15000; // 15 seconds

export const DEFAULT_FINANCIAL_LIMITS = {
    minDeposit: 99,
    maxDeposit: 300000,
    minWithdrawal: 100,
    maxWithdrawal: 150000,
    minBetAviator: 10,
    maxBetAviator: 50000,
    requireWithdrawalApproval: true
};

/**
 * Returns current financial limits.
 * @returns {Promise<typeof DEFAULT_FINANCIAL_LIMITS>}
 */
export async function getFinancialLimits() {
    const now = Date.now();
    if (cachedLimits && now < cacheExpiresAt) {
        return cachedLimits;
    }

    try {
        const { rows } = await query(
            "SELECT value FROM system_settings WHERE key = 'financial_limits' LIMIT 1"
        );

        const val = rows[0]?.value || {};
        const parsed = typeof val === 'string' ? JSON.parse(val) : val;

        cachedLimits = {
            minDeposit: Number(parsed.minDeposit ?? parsed.min_deposit ?? DEFAULT_FINANCIAL_LIMITS.minDeposit),
            maxDeposit: Number(parsed.maxDeposit ?? parsed.max_deposit ?? DEFAULT_FINANCIAL_LIMITS.maxDeposit),
            minWithdrawal: Number(parsed.minWithdrawal ?? parsed.min_withdrawal ?? DEFAULT_FINANCIAL_LIMITS.minWithdrawal),
            maxWithdrawal: Number(parsed.maxWithdrawal ?? parsed.max_withdrawal ?? DEFAULT_FINANCIAL_LIMITS.maxWithdrawal),
            minBetAviator: Number(parsed.minBetAviator ?? parsed.min_bet ?? DEFAULT_FINANCIAL_LIMITS.minBetAviator),
            maxBetAviator: Number(parsed.maxBetAviator ?? parsed.max_bet ?? DEFAULT_FINANCIAL_LIMITS.maxBetAviator),
            requireWithdrawalApproval: parsed.requireWithdrawalApproval !== undefined
                ? Boolean(parsed.requireWithdrawalApproval)
                : DEFAULT_FINANCIAL_LIMITS.requireWithdrawalApproval
        };

        cacheExpiresAt = now + CACHE_TTL_MS;
        return cachedLimits;
    } catch (err) {
        console.warn('[Financial Limits] Failed to fetch settings, using defaults:', err.message);
        return { ...DEFAULT_FINANCIAL_LIMITS };
    }
}

/**
 * Invalidate cached limits immediately (used after Super Admin updates)
 */
export function clearFinancialLimitsCache() {
    cachedLimits = null;
    cacheExpiresAt = 0;
}
