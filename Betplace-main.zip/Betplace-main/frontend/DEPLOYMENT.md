# MetroWins Frontend — Vercel Deployment Guide (Zero Supabase)

This guide details how to deploy the **MetroWins Frontend** to **[Vercel](https://vercel.com)**.

The frontend is a completely standalone Vite multi-page web application that connects directly to the **MetroWins Backend** (on Render or a Linux VPS) via standard REST API and WebSockets.

---

## 1. Prerequisites

1. A **[Vercel](https://vercel.com)** account.
2. A running **MetroWins Backend** instance on **Render** (e.g. `https://metrowins-backend.onrender.com`) or a **VPS** (`https://api.yourdomain.com`).
3. Your codebase pushed to a Git repository (GitHub / GitLab / Bitbucket).

---

## 2. Environment Variables

Create `.env` locally from `.env.example`:
```bash
cp .env.example .env
```

Set the following variable in Vercel during deployment:

| Variable | Required | Description | Example |
| :--- | :--- | :--- | :--- |
| `VITE_API_URL` | **Yes** | URL of your Backend API (Render or VPS) | `https://metrowins-backend.onrender.com` |
| `VITE_GAME_STATE_URL` | Optional | Fallback game state endpoint | `/api/game` |

> **Zero Third-Party Services**: No Supabase keys or accounts are required. All authentication, betting, and telemetry run directly through your backend server.

---

## 3. Deploy via Vercel Dashboard

### Step 1: Import Repository
1. Log in to [dashboard.vercel.com](https://dashboard.vercel.com).
2. Click **Add New...** → **Project**.
3. Select your repository (`MetroWins`).

### Step 2: Configure Project Settings
- **Framework Preset**: `Vite`
- **Root Directory**: Click **Edit** and select `frontend`
- **Build Command**: `npm run build`
- **Output Directory**: `dist`
- **Install Command**: `npm install`

### Step 3: Add Environment Variables
Under **Environment Variables**, add:
- `VITE_API_URL`: `https://your-backend.onrender.com` (or your VPS backend URL)

### Step 4: Deploy
Click **Deploy**. Vercel will build the project in ~30–45 seconds and provide a production URL (e.g. `https://metrowins.vercel.app`).

---

## 4. Connecting Frontend to Backend

In your **Backend** environment variables (on Render or VPS):
Add your Vercel frontend URL to `CORS_ORIGIN`:
```
CORS_ORIGIN=https://metrowins.vercel.app
```

---

## 5. Custom Domain Setup

1. In Vercel, navigate to **Project Settings** → **Domains**.
2. Add your domain (e.g., `metrowins.com` or `play.metrowins.com`).
3. Add the DNS records provided by Vercel:
   - **Apex**: `A` record pointing to `76.76.21.21`
   - **Subdomain**: `CNAME` record pointing to `cname.vercel-dns.com`
4. SSL certificates are provisioned and renewed automatically.

---

## 6. Post-Deployment Verification

- [ ] Visit the landing page at `/`
- [ ] Test registration and login at `/auth` (connected to Backend `/api/auth`)
- [ ] Aviator game loads canvas and multiplier at `/play`
- [ ] M-Pesa deposit modal connects to `/api/deposit`
- [ ] Admin panel is accessible at `/admin` for users with Admin role
