-- MIGRATION 015: Add is_frozen column to profiles and admin update RLS policy
-- Ensures the freeze/unfreeze feature works correctly.

-- 1. Add is_frozen column if it does not already exist
ALTER TABLE public.profiles
    ADD COLUMN IF NOT EXISTS is_frozen BOOLEAN NOT NULL DEFAULT FALSE;

-- 2. Drop any stale admin-update policy and recreate it cleanly
DROP POLICY IF EXISTS "Admin can update profile freeze status" ON public.profiles;
DROP POLICY IF EXISTS "Admins can update profiles"            ON public.profiles;

-- Allow authenticated admins (Admin / Super Admin roles) to UPDATE any profile row
CREATE POLICY "Admin can update profile freeze status"
ON public.profiles
FOR UPDATE
USING (
    EXISTS (
        SELECT 1 FROM public.user_roles ur
        JOIN public.roles r ON ur.role_id = r.id
        WHERE ur.user_id = auth.uid()
          AND r.name IN ('Admin', 'Super Admin')
    )
)
WITH CHECK (
    EXISTS (
        SELECT 1 FROM public.user_roles ur
        JOIN public.roles r ON ur.role_id = r.id
        WHERE ur.user_id = auth.uid()
          AND r.name IN ('Admin', 'Super Admin')
    )
);

-- 3. Notify PostgREST to reload its schema cache immediately
NOTIFY pgrst, 'reload schema';
