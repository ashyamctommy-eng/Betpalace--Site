/**
 * src/utils/notFound.js
 *
 * Renders 404 Not Found directly in the viewport for unauthorized users.
 */

import { render404 } from './routeGuard.js';

export function showNotFound() {
    render404();
}
