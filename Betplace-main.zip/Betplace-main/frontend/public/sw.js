/**
 * sw.js - MetricWin Progressive Web App Service Worker
 * Serves offline shell assets & manages Web Push Notifications.
 */

const CACHE_NAME = 'metricwin-v1.1';
const STATIC_ASSETS = [
    '/',
    '/aviator',
    '/sports',
    '/account',
    '/manifest.json',
    '/logo.svg'
];

// 1. Install Event: Cache Core App Shell Assets
self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => {
            console.log('[SW] Caching PWA App Shell assets');
            return cache.addAll(STATIC_ASSETS).catch(err => console.warn('[SW] Non-critical cache skip:', err));
        }).then(() => self.skipWaiting())
    );
});

// 2. Activate Event: Clean Stale Caches
self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then((keys) => {
            return Promise.all(
                keys.map((key) => {
                    if (key !== CACHE_NAME) {
                        console.log('[SW] Purging legacy cache:', key);
                        return caches.delete(key);
                    }
                })
            );
        }).then(() => self.clients.claim())
    );
});

// 3. Fetch Event: Network-First Strategy for API & Realtime, Cache Fallback for Shell
self.addEventListener('fetch', (event) => {
    const url = new URL(event.request.url);

    // Bypass caching for API endpoints and webhooks
    if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/webhooks') || url.pathname.startsWith('/ws')) {
        return;
    }

    event.respondWith(
        fetch(event.request).catch(() => {
            return caches.match(event.request).then((cachedResponse) => {
                if (cachedResponse) return cachedResponse;
                if (event.request.mode === 'navigate') {
                    return caches.match('/aviator');
                }
            });
        })
    );
});

// 4. Push Event: Render Native System Notifications
self.addEventListener('push', (event) => {
    let payload = {
        title: 'MetricWin Alert ✈️',
        body: 'New update available on MetricWin!',
        icon: '/logo.svg',
        badge: '/logo.svg',
        url: '/aviator',
        tag: 'metricwin-notification'
    };

    if (event.data) {
        try {
            const data = event.data.json();
            payload = { ...payload, ...data };
        } catch (_) {
            payload.body = event.data.text();
        }
    }

    const options = {
        body: payload.body,
        icon: payload.icon || '/logo.svg',
        badge: payload.badge || '/logo.svg',
        vibrate: [100, 50, 100, 50, 200],
        data: {
            url: payload.url || '/aviator',
            timestamp: Date.now()
        },
        actions: [
            { action: 'open', title: 'Open MetricWin ✈️' },
            { action: 'close', title: 'Dismiss' }
        ],
        tag: payload.tag || 'metricwin-push',
        renotify: true
    };

    event.waitUntil(
        self.registration.showNotification(payload.title, options)
    );
});

// 5. Notification Click Event: Focus or Open MetricWin Target Window
self.addEventListener('notificationclick', (event) => {
    event.notification.close();

    if (event.action === 'close') return;

    const targetUrl = event.notification.data?.url || '/aviator';

    event.waitUntil(
        clients.matchAll({ type: 'window', includeUncontrolled: true }).then((windowClients) => {
            // Focus open tab if matching origin exists
            for (let client of windowClients) {
                if (client.url.includes(self.location.origin) && 'focus' in client) {
                    client.navigate(targetUrl);
                    return client.focus();
                }
            }
            // Otherwise open a new window
            if (clients.openWindow) {
                return clients.openWindow(targetUrl);
            }
        })
    );
});
