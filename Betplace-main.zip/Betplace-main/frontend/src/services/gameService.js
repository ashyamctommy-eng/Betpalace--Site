import { supabase } from '../config/supabase.js';

export async function fetchGameStateRpc() {
    try {
        const { data, error } = await supabase.rpc('sync_and_get_game_state');
        if (error) return { data: null, error };
        return { data, error: null };
    } catch (err) {
        return { data: null, error: err };
    }
}

export async function placeBetRpc(amount, roundId) {
    try {
        const { data, error } = await supabase.rpc('place_bet', {
            p_amount: amount,
            p_round_id: roundId,
            p_use_free_bet: false
        });
        return { data, error };
    } catch (err) {
        return { data: null, error: err };
    }
}

export async function cashOutBetRpc(betId, multiplier) {
    try {
        const { data, error } = await supabase.rpc('cash_out', {
            p_bet_id: betId,
            p_multiplier: multiplier
        });
        return { data, error };
    } catch (err) {
        return { data: null, error: err };
    }
}

export async function cancelBetRpc(betId) {
    try {
        const { data, error } = await supabase.rpc('cancel_bet', {
            p_bet_id: betId
        });
        return { data, error };
    } catch (err) {
        return { data: null, error: err };
    }
}

export async function fetchGameHistory(limit = 20) {
    try {
        const { data, error } = await supabase
            .from('game_history')
            .select('multiplier')
            .order('created_at', { ascending: false })
            .limit(limit);
        return { data: data ? data.map(h => h.multiplier) : [], error };
    } catch (err) {
        return { data: [], error: err };
    }
}
